/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  lombok.Generated
 *  org.bukkit.GameMode
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.event.player.PlayerTeleportEvent$TeleportCause
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.tasks.SynchronizeWithServerThreadTask;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u0394;
import com.nickuc.login.\u03b5\u03c6\u03bc\u03c9\u03c9\u03c3\u03b7\u03ba\u03bc\u0394\u03c7\u03bc\u03bb\u03c6;
import com.nickuc.login.\u03b7\u03c4\u03c2\u039b\u03b6\u03be\u03bc\u03a3\u03bc\u03a8\u03be;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3;
import com.nickuc.login.\u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03b1\u03b4\u03ba\u03bc\u03a0\u0394\u03b1\u03c9\u03b5\u03b7\u03b5\u039b;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c3\u03c9\u03bc\u03b1\u0394\u03c8\u03c2\u0394\u03a0\u03a0\u03a0\u03b2\u03a0\u03be\u03be;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import java.io.File;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393
implements \u03b7\u03c4\u03c2\u039b\u03b6\u03be\u03bc\u03a3\u03bc\u03a8\u03be {
    private static int au;
    private static int bz;
    private static int dh;
    private static int cj;
    private static int x;
    private static int cn;
    private final \u03c3\u03c9\u03bc\u03b1\u0394\u03c8\u03c2\u0394\u03a0\u03a0\u03a0\u03b2\u03a0\u03be\u03be a;
    private static long ag;
    private static float br;
    private static long z;
    private Location b;
    private static long s;
    private static int cu;
    private static int dd;
    private static int bk;
    private static int ai;
    private static long ak;
    private static float bt;
    private static long ah;
    private static long bm;
    private static int ae;
    private static int aq;
    private static long o;
    private static int dk;
    private static int bd;
    private static int dl;
    private static long df;
    private static int cf;
    private static int aa;
    private static int av;
    private static long cl;
    private static long ar;
    private Location d;
    private static int cv;
    private static int w;
    private static String[] b;
    private static long cm;
    private static long cd;
    private static int bf;
    private static int dm;
    private static long bc;
    private static int an;
    private static double cr;
    private static int n;
    private static int ax;
    private static int al;
    private static int aw;
    private static int bj;
    private static int ct;
    private static long ca;
    private static long v;
    private static int p;
    private static int cc;
    private static long ay;
    private static int co;
    private static int am;
    private final File a;
    private static int cw;
    private static int bl;
    private static int dg;
    private final nLoginBukkit c;
    private static long ap;
    private static int cy;
    private static int k;
    private static int da;
    private static float bw;
    private static long cz;
    private static int ab;
    private static long b;
    private static int bp;
    private static long cx;
    private static int af;
    private static long c;
    private static int ce;
    private Location c;
    private static float bu;
    private static int r;
    private static int t;
    private static int db;
    private static int bi;
    private static String[] a;
    private static int j;
    private static int bq;
    private static long ac;
    private static int ch;
    private static long bn;
    private static int ba;
    private static float bx;
    private static int bo;
    private static int ck;
    private static long h;
    private static int cq;
    private static long cp;
    private static int e;
    private static long di;
    private static long ci;
    private Location e;
    private static int y;
    private static int q;
    private static long l;
    private static int a;
    private static int at;
    private static float bv;
    private static long bb;
    private static long dc;
    private static int i;
    private static int bg;
    private static long cb;
    private static int be;
    private static int de;
    private static long aj;
    private static long g;
    private Location f;
    private static long d;
    private static int as;
    private static int u;
    private boolean c;
    private static int ao;
    private static double cs;
    private static int ad;
    private static float bs;
    private static int f;
    private static long cg;
    private static int m;
    private static int dj;
    private static int bh;
    private static long az;
    private static float by;

    @Generated
    public Location e() {
        return this.f;
    }

    @Generated
    public Location b() {
        return this.c;
    }

    private void a(Player player, Location location) {
        if (\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.V()) {
            player.teleportAsync(location, PlayerTeleportEvent.TeleportCause.PLUGIN);
        } else {
            player.teleport(location, PlayerTeleportEvent.TeleportCause.PLUGIN);
        }
    }

    @Nullable
    private Location a(nLoginBukkit nLoginBukkit2, \u03c1\u03b1\u03b4\u03ba\u03bc\u03a0\u0394\u03b1\u03c9\u03b5\u03b7\u03b5\u039b \u03c1\u03b1\u03b4\u03ba\u03bc\u03a0\u0394\u03b1\u03c9\u03b5\u03b7\u03b5\u039b2) {
        if (\u03c1\u03b1\u03b4\u03ba\u03bc\u03a0\u0394\u03b1\u03c9\u03b5\u03b7\u03b5\u039b2 == \u03c1\u03b1\u03b4\u03ba\u03bc\u03a0\u0394\u03b1\u03c9\u03b5\u03b7\u03b5\u039b.f) {
            throw new UnsupportedOperationException((String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e80", (int)cw, (long)cx) + (Object)((Object)\u03c1\u03b1\u03b4\u03ba\u03bc\u03a0\u0394\u03b1\u03c9\u03b5\u03b7\u03b5\u039b2));
        }
        \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3 \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b32 = this.c.a().a();
        String string = \u03c1\u03b1\u03b4\u03ba\u03bc\u03a0\u0394\u03b1\u03c9\u03b5\u03b7\u03b5\u039b2.aE();
        try {
            World world;
            Location location = \u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9.a(\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b32.k(string));
            if (location != null && ((world = location.getWorld()) == null || nLoginBukkit2.a().getWorld(world.getName()) == null)) {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.d((String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e83", (int)cy, (long)cz) + (Object)((Object)\u03c1\u03b1\u03b4\u03ba\u03bc\u03a0\u0394\u03b1\u03c9\u03b5\u03b7\u03b5\u039b2) + (String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e86", (int)(da & db), (long)dc), new Object[dd]);
                \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b32.a(string).ag();
                location = null;
            }
            return location;
        }
        catch (Exception exception) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e89", (int)de, (long)df) + (Object)((Object)\u03c1\u03b1\u03b4\u03ba\u03bc\u03a0\u0394\u03b1\u03c9\u03b5\u03b7\u03b5\u039b2) + (String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e8c", (int)(dg & dh), (long)di), exception, new Object[dj]);
            \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b32.a(string).ag();
            return null;
        }
    }

    @Nullable
    public Location a(Location location, boolean bl) {
        World world;
        if (bl && this.e != null) {
            return this.e;
        }
        if (this.d != null) {
            return this.d;
        }
        if (\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.B.ar() && (world = location.getWorld()) != null) {
            return world.getHighestBlockAt(location).getLocation().add(cr, 0.0, cs);
        }
        return null;
    }

    private static void b() {
        int n;
        c = 1074098528926546133L;
        long l = c ^ 0x9353183841470F27L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(2 + 66), (byte)(20 + 49), (byte)(9 + 74), (byte)(43 + 4), 67, (byte)(38 + 28), (byte)(48 + 19), (byte)(3 + 44), (byte)(67 + 13), (byte)(25 + 50), (byte)(26 + 41), (byte)(76 + 7), (byte)(39 + 14), (byte)(44 + 36), (byte)(12 + 85), 100, (byte)(30 + 70), (byte)(61 + 44), (byte)(70 + 40), (byte)(48 + 55)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(17 + 66)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.E("\u054b\u0527\u050b\u053c\u0511\u0532\u0520\u0550\u054c\u050e\u0538\u051d", (byte)25, 69);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[1] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.A("\u00f5\u00ea\u00f7\u0102\u010f\u00ea\u00ec\u00fa\u010d\u00e5\u0132\u00f9", (byte)25, 65);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[2] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u0433\u043a\u0432\u0467\u046a\u0458\u045a\u046b\u046f\u043d\u0453\u0436\u046d\u043c\u045b\u0447\u0466\u0445\u0443\u0489\u0462\u048f\u0462\u047f\u0463\u0460\u047f\u0467\u0491\u0496\u0457\u0481\u0465\u0454\u0486\u0488\u0471\u0494\u0492\u0472\u0469\u0490\u048e\u0481\u0499\u046f\u046f\u049a\u045f\u049a\u0497\u049c\u0469\u0486\u0473\u0474", (byte)25, 67);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[3] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.B("\u0125\u0117\u011f\u011a\u00f6\u00fa\u00fc\u011a\u0125\u0111\u00fc\u00f2\u012c\u0103\u0137\u012b\u0109\u011a\u0111\u0126\u00fd\u0119\u012e\u0112\u013a\u0114\u0133\u0116\u0137\u011c\u0133\u0141", (byte)25, 66);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[4] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u00e4\u00eb\u00e3\u0118\u011b\u0109\u010b\u011c\u0120\u00ee\u0104\u00e7\u011e\u00ed\u010c\u00f8\u0117\u00f6\u00f4\u013a\u0113\u0140\u0113\u0130\u0114\u0111\u0130\u0118\u0142\u0147\u0108\u0132\u0116\u0105\u0137\u0139\u0122\u0145\u0143\u0123\u011a\u0141\u013f\u0132\u014a\u0120\u0120\u014b\u0110\u014b\u0148\u014d\u011a\u0137\u0124\u0125", (byte)25, 66);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[5] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u052e\u053e\u0526\u052e\u0521\u054c\u0510\u0507\u0541\u0513\u0552\u051d", (byte)25, 69);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[6] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u00e4\u00eb\u00e3\u0118\u011b\u0109\u010b\u011c\u0120\u00ee\u0106\u0103\u012d\u010a\u0133\u0109\u00ec\u0139\u0117\u00f8\u011d\u010e\u0131\u00f7\u0123\u013d\u010e\u012e\u0145\u0139\u0115\u013d\u0114\u00fd\u0108\u0142\u0146\u0105\u010d\u0131\u014a\u0140\u0122\u012f\u010c\u010e\u0145\u0153\u0113\u0139\u0154\u0151\u0126\u0137\u0124\u0125", (byte)25, 66);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[7] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u0539\u0501\u0518\u053d\u052b\u052e\u0531\u051f\u050f\u0532\u052b\u0553\u0516\u054b\u054f\u053a\u055a\u0538\u0551\u0561\u0519\u0558\u052e\u0520\u0555\u0547\u0540\u051b\u056a\u0557\u0543\u054a\u0525\u053a\u056f\u056d\u0529\u054d\u0545\u0541\u0565\u056c\u0566\u053d", (byte)25, 70);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[8] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0508\u050f\u0507\u053c\u053f\u052d\u052f\u0540\u0544\u0512\u052a\u0527\u0551\u052e\u0557\u052d\u0510\u055d\u053b\u051c\u0541\u0532\u0555\u051b\u0547\u0561\u0532\u0552\u0569\u055d\u0539\u0561\u0538\u0521\u052c\u0566\u056a\u0529\u0531\u0555\u056e\u0564\u0546\u0553\u0530\u0532\u0569\u0577\u0537\u055d\u0578\u0575\u054a\u055b\u0548\u0549", (byte)25, 70);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[9] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.B("\u010a\u011a\u0102\u010a\u00fd\u0128\u00ec\u00e3\u011d\u00ef\u012e\u00f9", (byte)25, 66);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[10] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.B("\u00f7\u0121\u00e5\u0119\u012f\u0129\u012b\u010a\u00f0\u0110\u0106\u00f0\u0133\u0127\u0108\u010d\u012e\u010d\u013b\u010c\u0111\u0119\u0136\u00fc\u0118\u0131\u012c\u0110\u011d\u011c\u0122\u0132\u0103\u0136\u0120\u0147\u013f\u0137\u0143\u014f\u0133\u0144\u0146\u0119", (byte)25, 66);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[11] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u00e9\u00e4\u00fa\u0125\u012c\u00e1\u011c\u00fb\u00ef\u0124\u00ec\u010a\u012b\u0125\u0110\u0137\u0130\u0138\u0127\u00f7\u0132\u00fe\u010e\u010c\u00f4\u0124\u0114\u0144\u011d\u011e\u0126\u012a", (byte)25, 65);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[12] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u054f\u0539\u0506\u053f\u0547\u0545\u050b\u053e\u0528\u0534\u0548\u0516\u0549\u055c\u0548\u052b\u053e\u053b\u0556\u051e\u055e\u053d\u0521\u0542\u0563\u0541\u0528\u0546\u0556\u053d\u0544\u0562\u053b\u052e\u054f\u0567\u0543\u0541\u0569\u056b\u0565\u0534\u0533\u053d", (byte)25, 70);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[13] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u0477\u042c\u043a\u0472\u042f\u0448\u045a\u0477\u0474\u046c\u0440\u0477\u0443\u045e\u0479\u047a\u045a\u047c\u0455\u0474\u047d\u0487\u0449\u047f\u044a\u047a\u045d\u0463\u046e\u0466\u0480\u0485\u0452\u0469\u0464\u046a\u049b\u0499\u0458\u0469\u046d\u046e\u0492\u047b\u045e\u0463\u0486\u0493\u0472\u048b\u04a9\u047e\u04ac\u049c\u048c\u04a9\u04a4\u0488\u047c\u046a\u04b3\u0484\u0487\u0495", (byte)25, 68);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[14] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u0120\u00fb\u00e5\u012d\u00e8\u011b\u00ef\u00ed\u012d\u00f1\u0134\u0110\u0126\u00ed\u0130\u0118\u0107\u0123\u0104\u0116\u011a\u0119\u013d\u0114\u0134\u0119\u00f6\u0105\u013f\u011d\u0131\u0112\u0141\u013b\u0143\u0123\u013b\u0123\u0119\u0111\u012d\u0131\u012c\u0150\u014f\u0149\u012c\u013a\u010c\u0147\u013c\u014a\u0126\u015c\u0158\u011c\u0153\u015d\u0140\u014d\u0151\u0124\u0124\u0158", (byte)25, 65);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[15] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u00f2\u0104\u00fd\u0121\u010a\u0102\u0130\u0130\u012f\u00ff\u010e\u0124\u0116\u0111\u0106\u0134\u0132\u012a\u0129\u00f9\u00f6\u012c\u011c\u0137\u013b\u011b\u0130\u00fb\u0114\u0137\u011f\u0149\u011a\u0147\u011d\u0144\u0136\u010c\u0146\u013d\u0140\u0109\u013e\u0119", (byte)25, 66);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[16] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u00f3\u00f4\u0121\u0125\u00fb\u011f\u010f\u0130\u010f\u0108\u0112\u00ec\u0136\u010b\u0110\u0125\u00f2\u0119\u0137\u012c\u010e\u0136\u0111\u0139\u0142\u013e\u0139\u0135\u0137\u0127\u0103\u0138", (byte)25, 65);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[17] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u00f2\u0104\u00fd\u0121\u010a\u0102\u0130\u0130\u012f\u00ff\u010e\u0124\u0116\u0111\u0106\u0134\u0132\u012a\u0129\u00f9\u00f6\u012c\u011c\u0137\u013b\u011b\u0130\u00fb\u0114\u0137\u011f\u0149\u011a\u0147\u011d\u0144\u0136\u010c\u0146\u013d\u0140\u0109\u013e\u0119", (byte)25, 66);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[18] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u00e3\u011b\u00e5\u00f5\u011a\u00e8\u00fb\u011c\u011a\u0124\u00f2\u0128\u011f\u0132\u0136\u00f8\u0132\u0112\u012a\u0116\u0112\u0107\u0104\u0105", (byte)25, 65);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[19] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u0441\u0453\u044c\u0470\u0459\u0451\u047f\u047f\u047e\u044e\u045d\u0473\u0465\u0460\u0455\u0483\u0481\u0479\u0478\u0448\u0445\u047b\u046b\u0486\u048a\u046a\u047f\u044a\u0463\u0486\u046e\u0498\u0469\u0496\u046c\u0493\u0485\u045b\u0495\u048c\u048f\u0458\u048d\u0468", (byte)25, 67);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[20] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u042b\u046d\u046b\u0434\u043c\u0454\u044d\u0472\u0470\u043d\u045f\u0462\u0450\u0466\u0474\u043a\u0488\u0462\u0462\u0488\u0487\u0440\u045c\u0487\u0462\u044b\u0452\u0464\u0455\u044d\u046f\u0486", (byte)25, 68);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[21] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u0466\u0448\u046e\u0473\u0452\u046d\u044f\u0457\u0482\u044b\u0439\u0461\u046d\u0472\u045e\u0440\u0483\u047f\u044a\u0467\u047d\u0468\u045b\u0442\u044b\u0491\u046c\u046e\u0469\u0477\u045f\u048c\u0458\u0475\u0483\u0498\u0474\u0472\u0496\u0489\u0461\u0496\u0499\u0468", (byte)25, 67);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[22] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u0475\u0464\u043b\u0434\u0448\u0453\u0448\u0469\u0470\u0462\u0479\u045e\u047c\u0443\u0466\u0464\u045f\u044a\u047d\u0481\u0467\u0466\u0453\u0454", (byte)25, 68);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[23] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.D("\u0435\u0447\u0470\u043b\u043a\u0457\u0473\u043c\u045b\u046e\u0452\u047f\u0450\u045e\u0473\u0470\u0453\u0485\u0483\u046a\u048b\u0462\u0485\u047c\u0471\u048b\u048b\u0466\u0468\u0496\u0473\u0493\u0497\u0459\u0494\u048e\u048a\u0479\u0459\u0488\u045c\u045d\u04a3\u046e\u0492\u049d\u04a4\u0478\u0486\u0462\u0477\u0464\u047c\u0476\u0473\u0474", (byte)25, 68);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[24] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u0475\u0464\u043b\u0434\u0448\u0453\u0448\u0469\u0470\u0462\u0479\u045e\u047c\u0443\u0466\u0464\u045f\u044a\u047d\u0481\u0467\u0466\u0453\u0454", (byte)25, 68);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[25] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u050a\u051c\u0545\u0510\u050f\u052c\u0548\u0511\u0530\u0543\u0525\u0524\u0530\u0546\u052b\u0553\u0557\u0556\u0532\u051b\u054d\u051e\u0535\u0552\u0550\u051e\u0528\u0544\u0567\u055d\u056c\u0546", (byte)25, 69);
                    continue block7;
                }
                case 1: {
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u0449\u0471\u0455\u0459\u044a\u044c\u0435\u0480\u0438\u0455\u044f\u0448", (byte)25, 67);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[1] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u0127\u011c\u00fc\u0122\u00ed\u011d\u012b\u0107\u0127\u00fe\u00fc\u00f9", (byte)25, 66);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[2] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u00e4\u00eb\u00e3\u0118\u011b\u0109\u010b\u011c\u0120\u00ee\u0104\u00e7\u011e\u00ed\u010c\u00f8\u0117\u00f6\u00f4\u013a\u0113\u0140\u0113\u0130\u0114\u0111\u0130\u0118\u0142\u0147\u0108\u0132\u0116\u0105\u0137\u0139\u0122\u0145\u0143\u0123\u011a\u0141\u013f\u012d\u0142\u0146\u0128\u0150\u014c\u0130\u0132\u0155\u0159\u0137\u0124\u0125", (byte)25, 66);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[3] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.F("\u0549\u053b\u0543\u053e\u051a\u051e\u0520\u053e\u0549\u0535\u0520\u0516\u0550\u0527\u055b\u054f\u052d\u053e\u0535\u054a\u0521\u053e\u0557\u053b\u0546\u0533\u0569\u0555\u0559\u0521\u0555\u0527", (byte)25, 70);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[4] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.D("\u0433\u043a\u0432\u0467\u046a\u0458\u045a\u046b\u046f\u043d\u0453\u0436\u046d\u043c\u045b\u0447\u0466\u0445\u0443\u0489\u0462\u048f\u0462\u047f\u0463\u0460\u047f\u0467\u0491\u0496\u0457\u0481\u0465\u0454\u0486\u0488\u0471\u0494\u0492\u0472\u0469\u0490\u048e\u049e\u04a4\u0484\u0461\u0476\u0495\u0499\u0489\u049d\u0465\u04a1\u0483\u049a\u048d\u048a\u0494\u0482\u04b4\u048a\u0493\u0474", (byte)25, 68);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[5] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u051b\u0537\u0539\u0526\u051e\u0520\u0548\u0527\u054c\u0529\u054a\u051d", (byte)25, 69);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[6] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u0508\u050f\u0507\u053c\u053f\u052d\u052f\u0540\u0544\u0512\u052a\u0527\u0551\u052e\u0557\u052d\u0510\u055d\u053b\u051c\u0541\u0532\u0555\u051b\u0547\u0561\u0532\u0552\u0569\u055d\u0539\u0561\u0538\u0521\u052c\u0566\u056a\u0529\u0531\u0555\u056e\u0564\u0546\u0575\u056c\u057b\u0568\u057b\u0570\u056d\u0576\u056b\u0576\u053f\u055f\u0557\u057f\u0557\u0553\u0561\u057a\u0556\u0586\u058a", (byte)25, 69);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[7] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.E("\u0539\u0501\u0518\u053d\u052b\u052e\u0531\u051f\u050f\u0532\u052b\u0553\u0516\u054b\u054f\u053a\u055a\u0538\u0551\u0561\u0519\u0558\u052e\u0520\u0555\u0547\u0540\u051b\u056a\u0557\u0543\u054a\u0527\u053b\u0522\u056e\u0545\u0564\u054d\u052b\u0545\u054f\u0548\u053d", (byte)25, 69);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[8] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u0433\u043a\u0432\u0467\u046a\u0458\u045a\u046b\u046f\u043d\u0455\u0452\u047c\u0459\u0482\u0458\u043b\u0488\u0466\u0447\u046c\u045d\u0480\u0446\u0472\u048c\u045d\u047d\u0494\u0488\u0464\u048c\u0463\u044c\u0457\u0491\u0495\u0454\u045c\u0480\u0499\u048f\u0472\u048c\u0472\u04a0\u047b\u04a4\u0465\u0475\u0495\u04a6\u04a7\u0485\u04ac\u046f\u04a2\u04a4\u0470\u0494\u04b5\u04b7\u0485\u0478", (byte)25, 68);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[9] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u0548\u054c\u0538\u0509\u053b\u050d\u0534\u051f\u0556\u0523\u054a\u051d", (byte)25, 70);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[10] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.B("\u00f7\u0121\u00e5\u0119\u012f\u0129\u012b\u010a\u00f0\u0110\u0106\u00f0\u0133\u0127\u0108\u010d\u012e\u010d\u013b\u010c\u0111\u0119\u0136\u00fc\u0118\u0131\u012c\u0110\u011d\u011c\u0122\u0132\u0118\u0125\u0142\u0117\u014e\u011a\u011d\u014b\u013e\u012d\u0128\u0119", (byte)25, 66);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[11] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u0438\u0433\u0449\u0474\u047b\u0430\u046b\u044a\u043e\u0473\u043b\u0459\u047a\u0474\u045f\u0486\u047f\u0487\u0476\u0446\u0481\u044c\u0484\u0462\u045d\u0486\u045b\u0463\u0483\u0481\u0454\u0450", (byte)25, 67);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[12] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u012b\u0115\u00e2\u011b\u0123\u0121\u00e7\u011a\u0104\u0110\u0124\u00f2\u0125\u0138\u0124\u0107\u011a\u0117\u0132\u00fa\u013a\u0119\u00fd\u011e\u013f\u011d\u0104\u0122\u0132\u0119\u0120\u013e\u0106\u0138\u0134\u011c\u0122\u013a\u0120\u0126\u0104\u013d\u010f\u0119", (byte)25, 65);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[13] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u0128\u00dd\u00eb\u0123\u00e0\u00f9\u010b\u0128\u0125\u011d\u00f1\u0128\u00f4\u010f\u012a\u012b\u010b\u012d\u0106\u0125\u012e\u0138\u00fa\u0130\u00fb\u012b\u010e\u0114\u011f\u0117\u0131\u0136\u0103\u011a\u0115\u011b\u014c\u014a\u0109\u011a\u011e\u011f\u0143\u012c\u010f\u0114\u0137\u0144\u0123\u013c\u015a\u012f\u015d\u015a\u011d\u012a\u0159\u0150\u014d\u0121\u0140\u0142\u013f\u0164\u0132\u0127\u0163\u0136\u0141\u0170\u015f\u0169\u016a\u0152\u016a\u0139", (byte)25, 65);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[14] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u0544\u051f\u0509\u0551\u050c\u053f\u0513\u0511\u0551\u0515\u0558\u0534\u054a\u0511\u0554\u053c\u052b\u0547\u0528\u053a\u053e\u053d\u0561\u0538\u0558\u053d\u051a\u0529\u0563\u0541\u0555\u0536\u0565\u055f\u0567\u0547\u055f\u0547\u053d\u0535\u0551\u0555\u0550\u0574\u0573\u056d\u0550\u055e\u0530\u056b\u0560\u056e\u054a\u0572\u0564\u0545\u0574\u0571\u0563\u057e\u057b\u0565\u0577\u0559\u0565\u0545\u055a\u055d\u0568\u0572\u0590\u0591\u0593\u056a\u0574\u055d", (byte)25, 69);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[15] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.C("\u0441\u0453\u044c\u0470\u0459\u0451\u047f\u047f\u047e\u044e\u045d\u0473\u0465\u0460\u0455\u0483\u0481\u0479\u0478\u0448\u0445\u047b\u046b\u0486\u048a\u046a\u047f\u044a\u0463\u0486\u046e\u0498\u0466\u0464\u0484\u045c\u045a\u0455\u0458\u0472\u049e\u0471\u046f\u0468", (byte)25, 67);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[16] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u0442\u0443\u0470\u0474\u044a\u046e\u045e\u047f\u045e\u0457\u0461\u043b\u0485\u045a\u045f\u0474\u0441\u0468\u0486\u047b\u045d\u047f\u048e\u0442\u0449\u0473\u045e\u046e\u0476\u045f\u0496\u0467", (byte)25, 67);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[17] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u0516\u0528\u0521\u0545\u052e\u0526\u0554\u0554\u0553\u0523\u0532\u0548\u053a\u0535\u052a\u0558\u0556\u054e\u054d\u051d\u051a\u0550\u0540\u055b\u055f\u053f\u0554\u051f\u0538\u055b\u0543\u056d\u0558\u052c\u0569\u0546\u056b\u054f\u0574\u053f\u055f\u056d\u052f\u053d", (byte)25, 69);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[18] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u0507\u053f\u0509\u0519\u053e\u050c\u051f\u0540\u053e\u0548\u0515\u0524\u054d\u0519\u0547\u0533\u055c\u0554\u0536\u0534\u0514\u0554\u055c\u0554\u052e\u0544\u0565\u0525\u054b\u0559\u054d\u056c", (byte)25, 70);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[19] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0516\u0528\u0521\u0545\u052e\u0526\u0554\u0554\u0553\u0523\u0532\u0548\u053a\u0535\u052a\u0558\u0556\u054e\u054d\u051d\u051a\u0550\u0540\u055b\u055f\u053f\u0554\u051f\u0538\u055b\u0543\u056d\u0565\u0539\u054a\u0523\u0564\u0572\u0573\u0531\u054a\u0568\u0576\u053d", (byte)25, 70);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[20] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.D("\u042b\u046d\u046b\u0434\u043c\u0454\u044d\u0472\u0470\u043d\u045f\u0462\u0450\u0466\u0474\u043a\u0488\u0462\u0462\u0488\u0487\u048e\u0489\u048c\u045b\u048f\u044c\u047c\u0486\u0485\u044d\u0458", (byte)25, 68);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[21] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u053b\u051d\u0543\u0548\u0527\u0542\u0524\u052c\u0557\u0520\u050e\u0536\u0542\u0547\u0533\u0515\u0558\u0554\u051f\u053c\u0552\u053d\u0530\u0517\u0520\u0566\u0541\u0543\u053e\u054c\u0534\u0561\u0547\u0544\u054e\u0530\u0546\u0531\u0551\u0550\u052f\u054d\u0537\u053d", (byte)25, 69);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[22] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u0475\u0464\u043b\u0434\u0448\u0453\u0448\u0469\u0470\u0462\u047b\u0440\u0479\u0446\u0466\u047b\u0478\u0458\u0458\u0456\u044c\u048c\u0453\u0454", (byte)25, 68);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[23] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.B("\u00e6\u00f8\u0121\u00ec\u00eb\u0108\u0124\u00ed\u010c\u011f\u0103\u0130\u0101\u010f\u0124\u0121\u0104\u0136\u0134\u011b\u013c\u0113\u0136\u012d\u0122\u013c\u013c\u0117\u0119\u0147\u0124\u0144\u0148\u010a\u0145\u013f\u013b\u012a\u010a\u0139\u010d\u010e\u0155\u0147\u0146\u0142\u0121\u0156\u014a\u012b\u0154\u015d\u0127\u0127\u0124\u0125", (byte)25, 66);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[24] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u0126\u0115\u00ec\u00e5\u00f9\u0104\u00f9\u011a\u0121\u0113\u012c\u00ed\u00f6\u00e9\u0107\u0131\u0117\u0107\u0133\u00f5\u00f6\u012d\u0104\u0105", (byte)25, 65);
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[25] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u050a\u051c\u0545\u0510\u050f\u052c\u0548\u0511\u0530\u0543\u0525\u0524\u0530\u0546\u052b\u0553\u0557\u0556\u0532\u051b\u054d\u051a\u054c\u0535\u0521\u055e\u0559\u0526\u0565\u0553\u052c\u0538", (byte)25, 69);
                    continue block7;
                }
                case 2: {
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u051c\u0537\u0551\u050a\u052b\u053e\u0511\u0514\u0551\u0531\u0520\u0529\u0522\u055a\u0545\u0547\u055a\u0534\u0561\u052d\u0535\u051c\u0522\u0523\u0561\u0564\u0535\u0551\u0567\u051d\u0527\u0559", (byte)25, 70);
                    continue block7;
                }
                case 4: {
                    \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u0118\u0102\u012b\u012b\u00e4\u0110\u00eb\u00fd\u00f0\u0126\u0135\u0129\u0131\u0103\u0116\u0119\u0118\u012e\u0129\u0116\u013d\u0131\u0134\u0136\u013e\u0144\u0145\u011e\u013b\u0107\u0123\u0148", (byte)25, 66);
                }
            }
        }
    }

    private void b(\u03a9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3 \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3) {
        Player player = \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.a;
        if (\u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.e && this.c != null) {
            try {
                this.a(player, this.c);
            }
            catch (Exception exception) {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e80", (int)bz, (long)(ca ^ cb)) + player.getName() + (String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e83", (int)cc, (long)cd), exception, new Object[ce]);
            }
            return;
        }
        if (!this.c && this.b != null) {
            try {
                this.a(player, this.b);
            }
            catch (Exception exception) {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e86", (int)cf, (long)cg) + player.getName() + (String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e89", (int)ch, (long)ci), exception, new Object[cj]);
            }
            return;
        }
        if (this.d != null) {
            Location location;
            Object object = \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.g != null ? \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.g : (location = this.c ? \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.h : null);
            if (location != null) {
                try {
                    this.a(player, location);
                }
                catch (Exception exception) {
                    \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e8c", (int)ck, (long)(cl ^ cm)) + player.getName() + (String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e8f", (int)(cn & co), (long)cp), exception, new Object[cq]);
                }
            }
        }
    }

    static {
        a = 0 >>> 26 | 0 << ~26 + 1;
        b = Long.reverse(-6116461775862896784L);
        d = Long.reverse(0x4200000000000000L);
        e = 0 >>> 67 | 0 << -67;
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Long.reverse(-6116461775862896784L);
        h = Long.reverse(0x4200000000000000L);
        i = 32 >>> 69 | 32 << -69;
        j = (32 >>> 100 | 32 << ~100 + 1) & 0xFFFFFFFF;
        k = Integer.reverse(-1);
        l = Long.reverse(-1648890945511364752L);
        m = -1073741824 >>> 158 | -1073741824 << ~158 + 1;
        n = Integer.reverse(-1);
        o = Long.reverse(-1648890945511364752L);
        p = Integer.reverse(0);
        q = Integer.reverse(0);
        r = (65536 >>> 142 | 65536 << ~142 + 1) & 0xFFFFFFFF;
        s = Long.reverse(-1648890945511364752L);
        t = Integer.reverse(-1610612736);
        u = -1 >>> 168 | -1 << -168;
        v = Long.reverse(-1648890945511364752L);
        w = (0 >>> 232 | 0 << ~232 + 1) & 0xFFFFFFFF;
        x = 0 >>> 148 | 0 << -148;
        y = Integer.reverse(0x60000000);
        z = Long.reverse(-1648890945511364752L);
        aa = 0x700000 >>> 116 | 0x700000 << ~116 + 1;
        ab = Integer.reverse(-1);
        ac = Long.reverse(-1648890945511364752L);
        ad = Integer.reverse(0);
        ae = (0 >>> 87 | 0 << -87) & 0xFFFFFFFF;
        af = (8192 >>> 10 | 8192 << ~10 + 1) & 0xFFFFFFFF;
        ag = Long.reverse(-6116461775862896784L);
        ah = Long.reverse(0x4200000000000000L);
        ai = Integer.reverse(-1879048192);
        aj = Long.reverse(-6116461775862896784L);
        ak = Long.reverse(0x4200000000000000L);
        al = (0 >>> 47 | 0 << -47) & 0xFFFFFFFF;
        am = Integer.reverse(0);
        an = (0x28000000 >>> 58 | 0x28000000 << -58) & 0xFFFFFFFF;
        ao = Integer.reverse(-1);
        ap = Long.reverse(-1648890945511364752L);
        aq = Integer.reverse(-805306368);
        ar = Long.reverse(-1648890945511364752L);
        as = (0 >>> 214 | 0 << -214) & 0xFFFFFFFF;
        at = 0x1000000 >>> 216 | 0x1000000 << ~216 + 1;
        au = Integer.reverse(Integer.MIN_VALUE);
        av = Integer.reverse(Integer.MIN_VALUE);
        aw = 524288 >>> 19 | 524288 << -19;
        ax = Integer.reverse(0x30000000);
        ay = Long.reverse(-6116461775862896784L);
        az = Long.reverse(0x4200000000000000L);
        ba = 0x340000 >>> 210 | 0x340000 << -210;
        bb = Long.reverse(-6116461775862896784L);
        bc = Long.reverse(0x4200000000000000L);
        bd = Integer.reverse(Integer.MIN_VALUE);
        be = Integer.reverse(0);
        bf = 0 >>> 112 | 0 << ~112 + 1;
        bg = Integer.reverse(0x28000000);
        bh = Integer.reverse(0);
        bi = 5119488 >>> 73 | 5119488 << -73;
        bj = 508 >>> 194 | 508 << ~194 + 1;
        bk = (8192 >>> 109 | 8192 << -109) & 0xFFFFFFFF;
        bl = Integer.reverse(0x70000000);
        bm = Long.reverse(-6116461775862896784L);
        bn = Long.reverse(0x4200000000000000L);
        bo = Integer.reverse(Integer.MIN_VALUE);
        bp = Integer.reverse(Integer.MIN_VALUE);
        bq = 0 >>> 81 | 0 << ~81 + 1;
        br = Float.intBitsToFloat(Integer.reverse(-1288490052));
        bs = Float.intBitsToFloat(Integer.reverse(-1288490372));
        bt = Float.intBitsToFloat(Integer.reverse(-1288490052));
        bu = Float.intBitsToFloat(Integer.reverse(-1288490052));
        bv = Float.intBitsToFloat(Integer.reverse(-1288490052));
        bw = Float.intBitsToFloat((1717987826 >>> 139 | 1717987826 << ~139 + 1) & 0xFFFFFFFF);
        bx = Float.intBitsToFloat((888615731 >>> 250 | 888615731 << -250) & 0xFFFFFFFF);
        by = Float.intBitsToFloat((-1717061223 >>> 149 | -1717061223 << -149) & 0xFFFFFFFF);
        bz = Integer.reverse(-268435456);
        ca = Long.reverse(-6116461775862896784L);
        cb = Long.reverse(0x4200000000000000L);
        cc = 0x10000000 >>> 56 | 0x10000000 << ~56 + 1;
        cd = Long.reverse(-1648890945511364752L);
        ce = (0 >>> 59 | 0 << ~59 + 1) & 0xFFFFFFFF;
        cf = Integer.reverse(-2013265920);
        cg = Long.reverse(-1648890945511364752L);
        ch = Integer.reverse(0x48000000);
        ci = Long.reverse(-1648890945511364752L);
        cj = Integer.reverse(0);
        ck = Integer.reverse(-939524096);
        cl = Long.reverse(-6116461775862896784L);
        cm = Long.reverse(0x4200000000000000L);
        cn = 81920 >>> 140 | 81920 << ~140 + 1;
        co = -1 >>> 246 | -1 << -246;
        cp = Long.reverse(-1648890945511364752L);
        cq = 0 >>> 20 | 0 << ~20 + 1;
        cr = Double.longBitsToDouble(Long.reverse(2044L));
        cs = Double.longBitsToDouble(Long.reverse(2044L));
        ct = Integer.reverse(Integer.MIN_VALUE);
        cu = 0 >>> 85 | 0 << -85;
        cv = (128 >>> 71 | 128 << ~71 + 1) & 0xFFFFFFFF;
        cw = Integer.reverse(-1476395008);
        cx = Long.reverse(-1648890945511364752L);
        cy = 352 >>> 164 | 352 << ~164 + 1;
        cz = Long.reverse(-1648890945511364752L);
        da = Integer.reverse(-402653184);
        db = (-1 >>> 50 | -1 << -50) & 0xFFFFFFFF;
        dc = Long.reverse(-1648890945511364752L);
        dd = 0 >>> 159 | 0 << ~159 + 1;
        de = Integer.reverse(0x18000000);
        df = Long.reverse(-1648890945511364752L);
        dg = (-2147483636 >>> 127 | -2147483636 << ~127 + 1) & 0xFFFFFFFF;
        dh = (-1 >>> 187 | -1 << ~187 + 1) & 0xFFFFFFFF;
        di = Long.reverse(-1648890945511364752L);
        dj = Integer.reverse(0);
        dk = Integer.reverse(0);
        dl = Integer.reverse(0x58000000);
        dm = Integer.reverse(0x58000000);
        a = new String[dl];
        b = new String[dm];
        \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.b();
    }

    @Generated
    public File a() {
        return this.a;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u0551\u0573\u0575\u0555\u0579\u0598\u0590\u05a6\u0592\u0561\u059f\u0595\u05a3\u059d\u0566\u058b\u05ad\u05ac\u05a4\u05aa\u05a4\u0579", (byte)124, 67), \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u059b\u05a8\u05a7\u056a\u05aa\u05a6\u05a1\u05aa\u05b5\u05a4\u0571\u05af\u05b3\u05ac\u05af\u05b5\u0577\u0903\u0900\u0905\u0900\u08f3\u090d\u0918\u090f\u0907\u0910\u08e7\u091c\u0911\u08e9\u0591", (byte)124, 70) + string + \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u01b1", (byte)124, 65) + methodType.toString(), exception);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03a9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3 \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3, boolean bl) {
        Object object = \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.n;
        synchronized (object) {
            try {
                Player player = \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.a;
                if (!player.isOnline()) {
                    return;
                }
                if (!this.c.a().isPrimaryThread() && !\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.V()) {
                    throw new IllegalStateException((String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e80", (int)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.bl, (long)(bm ^ bn)));
                }
                player.updateInventory();
                if (\u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.a != \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.d) {
                    if (\u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.a == \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.e) return;
                    this.b(\u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3);
                    return;
                }
                this.a(\u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3);
                this.b(\u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3);
                if (\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.y.ar() || bl) {
                    \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b(this.c, player);
                }
                if (\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.A.ar()) {
                    player.removePotionEffect(PotionEffectType.BLINDNESS);
                }
                this.c.b(bo != 0).a(\u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.b::delete);
            }
            finally {
                \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.a = \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.e;
            }
            return;
        }
    }

    /*
     * Exception decompiling
     */
    public boolean a(\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 var1_1, \u03a9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3 var2_2, boolean var3_3) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 8 blocks at once
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:412)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:487)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static String a(int n, long l) {
        l ^= 0x42L;
        l ^= 0x9353183841470F27L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(29 + 39), (byte)(14 + 55), (byte)(75 + 8), (byte)(13 + 34), (byte)(42 + 25), (byte)(20 + 46), (byte)(12 + 55), (byte)(13 + 34), (byte)(8 + 72), (byte)(28 + 47), (byte)(52 + 15), 83, (byte)(41 + 12), (byte)(68 + 12), (byte)(87 + 10), (byte)(54 + 46), (byte)(95 + 5), (byte)(50 + 55), (byte)(7 + 103), (byte)(61 + 42)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(43 + 40)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u0546\u0553\u0552\u0515\u0555\u0551\u054c\u0555\u0560\u054f\u051c\u055a\u055e\u0557\u055a\u0560\u0522\u08ae\u08ab\u08b0\u08ab\u089e\u08b8\u08c3\u08ba\u08b2\u08bb\u0892\u08c7\u08bc\u0894", (byte)39, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Generated
    public Location d() {
        return this.e;
    }

    @Generated
    public Location a() {
        return this.b;
    }

    @Generated
    public Location c() {
        return this.d;
    }

    public \u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393(nLoginBukkit nLoginBukkit2) {
        this.c = nLoginBukkit2;
        this.a = new \u03c3\u03c9\u03bc\u03b1\u0394\u03c8\u03c2\u0394\u03a0\u03a0\u03a0\u03b2\u03a0\u03be\u03be(this);
        this.a = new File(nLoginBukkit2.c(), (String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e80", (int)a, (long)(b ^ d)));
        nLoginBukkit2.b(e != 0).a(new SynchronizeWithServerThreadTask(() -> this.a(nLoginBukkit2.a(), dk != 0)));
        File file = new File(nLoginBukkit2.c(), (String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e83", (int)f, (long)(g ^ h)));
        if (!this.a.exists() && file.exists() && file.isDirectory()) {
            file.renameTo(this.a);
        }
    }

    @Generated
    public boolean g() {
        return this.c;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public boolean a(\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03a9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3 \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3) {
        Object object = \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.n;
        synchronized (object) {
            Player player = \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.a;
            if (\u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.a != \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.c) {
                return au != 0;
            }
            try {
                if (!player.isOnline()) {
                    boolean bl = av;
                    return bl;
                }
                \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u0394 \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942 = this.c.a().a();
                if (\u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942.b(this.c.b().a(player))) {
                    boolean bl = aw;
                    return bl;
                }
                File file = \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.b;
                if (!file.exists()) {
                    throw new IllegalStateException((String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e80", (int)ax, (long)(ay ^ az)));
                }
                if (!this.c.a().isPrimaryThread() && !\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.V()) {
                    throw new IllegalStateException((String)\u03ba\u03b6\u03ba\u03b4\u03a6\u03bf\u03c9\u03bf\u03b6\u03be\u0394\u03c8\u03bc\u0393.c("\u3e83", (int)ba, (long)(bb ^ bc)));
                }
                if (\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.w.ar()) {
                    \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.d = bd;
                    player.removePotionEffect(PotionEffectType.BLINDNESS);
                    player.setGameMode(GameMode.ADVENTURE);
                    player.setAllowFlight(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.z.ar());
                    player.setFlying(be != 0);
                    \u03b5\u03c6\u03bc\u03c9\u03c9\u03c3\u03b7\u03ba\u03bc\u0394\u03c7\u03bc\u03bb\u03c6.a(player, bf != 0);
                    player.setFoodLevel(bg);
                    player.setTotalExperience(bh);
                    if (player.getHealth() > 0.0) {
                        double d = player.getMaxHealth();
                        player.setHealth(d);
                    }
                }
                if (\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.z.ar()) {
                    player.setFlySpeed(0.0f);
                    player.setWalkSpeed(0.0f);
                }
                if (\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.y.ar()) {
                    \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.a(this.c, player);
                }
                if (\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.A.ar()) {
                    player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, bi, bj));
                }
                boolean bl = bk;
                return bl;
            }
            finally {
                \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.a = \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.d;
            }
        }
    }

    @Override
    public void a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, boolean bl) {
        String string;
        nLoginBukkit nLoginBukkit2 = this.c;
        this.b = this.a(nLoginBukkit2, \u03c1\u03b1\u03b4\u03ba\u03bc\u03a0\u0394\u03b1\u03c9\u03b5\u03b7\u03b5\u039b.c);
        this.c = this.a(nLoginBukkit2, \u03c1\u03b1\u03b4\u03ba\u03bc\u03a0\u0394\u03b1\u03c9\u03b5\u03b7\u03b5\u039b.d);
        this.d = this.a(nLoginBukkit2, \u03c1\u03b1\u03b4\u03ba\u03bc\u03a0\u0394\u03b1\u03c9\u03b5\u03b7\u03b5\u039b.a);
        this.e = this.a(nLoginBukkit2, \u03c1\u03b1\u03b4\u03ba\u03bc\u03a0\u0394\u03b1\u03c9\u03b5\u03b7\u03b5\u039b.b);
        this.f = this.a(nLoginBukkit2, \u03c1\u03b1\u03b4\u03ba\u03bc\u03a0\u0394\u03b1\u03c9\u03b5\u03b7\u03b5\u039b.e);
        \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3 \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b32 = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().a();
        if (!\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b32.c(string = \u03c1\u03b1\u03b4\u03ba\u03bc\u03a0\u0394\u03b1\u03c9\u03b5\u03b7\u03b5\u039b.f.aE())) {
            \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b32.a(string, (this.b == null ? ct : cu) != 0);
        }
        this.c = \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b32.a(string, cv != 0);
    }

    private void a(\u03a9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3 \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3) {
        Player player = \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.a;
        if (\u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.d) {
            float f;
            double d;
            GameMode gameMode = \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.a;
            player.setGameMode(gameMode != null ? gameMode : GameMode.SURVIVAL);
            player.setAllowFlight(\u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.g);
            player.setFlying((\u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.h && player.getAllowFlight() ? bp : bq) != 0);
            \u03b5\u03c6\u03bc\u03c9\u03c9\u03c3\u03b7\u03ba\u03bc\u0394\u03c7\u03bc\u03bb\u03c6.a(player, \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.i);
            player.setFoodLevel(\u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.h);
            int n = \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.i;
            if (n > 0) {
                player.setTotalExperience(n);
            }
            if ((d = \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.d) > 0.0) {
                double d2 = Math.max(player.getMaxHealth(), 0.0);
                player.setHealth(Math.min(d, d2));
            }
            player.setWalkSpeed(Math.abs(f = \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.c) > 1.0f || f <= br ? bs : f);
            float f2 = \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3.d;
            player.setFlySpeed(Math.abs(f2) > 1.0f || f2 <= bt ? bu : f2);
        } else {
            float f = player.getWalkSpeed();
            player.setWalkSpeed(Math.abs(f) > 1.0f || f <= bv ? bw : f);
            float f3 = player.getFlySpeed();
            player.setFlySpeed(Math.abs(f3) > 1.0f || f3 <= bx ? by : f3);
        }
    }
}

