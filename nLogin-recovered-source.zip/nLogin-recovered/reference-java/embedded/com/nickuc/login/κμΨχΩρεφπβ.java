/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a8\u03c8\u03bc\u039b\u03c1\u03bf\u03c2\u03b6;
import com.nickuc.login.\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b2\u03a3\u03a3\u0393\u03bd\u03b8\u03a9\u03bb\u03bd\u03bd\u03a9\u03b3\u03c5\u03b4\u03c2;
import com.nickuc.login.\u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2 {
    private static String[] a;
    private static int b;
    private final \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 s;
    private final boolean ar;
    private static int c;
    private final boolean at;
    private int ab = i;
    private static int i;
    private final boolean as;
    private static int j;
    private static int e;
    private static String[] b;
    private static int g;
    private static int a;
    private static long h;
    private static long c;
    private static int d;
    private static int k;
    private static int f;

    public synchronized \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 a() {
        return this.b().a();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u0518\u053a\u053c\u051c\u0540\u055f\u0557\u056d\u0559\u0528\u0566\u055c\u056a\u0564\u052d\u0552\u0574\u0573\u056b\u0571\u056b\u0540", (byte)105, 67), \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u0588\u0595\u0594\u0557\u0597\u0593\u058e\u0597\u05a2\u0591\u055e\u059c\u05a0\u0599\u059c\u05a2\u0564\u08f0\u08f3\u08e0\u0900\u08e3\u08fc\u08f1\u0903\u08fe\u08f1\u057a", (byte)105, 70) + string + \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.C("\u052a", (byte)105, 67) + methodType.toString(), exception);
        }
    }

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = 0x8000000 >>> 59 | 0x8000000 << ~59 + 1;
        c = (0x400000 >>> 118 | 0x400000 << -118) & 0xFFFFFFFF;
        d = (0 >>> 143 | 0 << ~143 + 1) & 0xFFFFFFFF;
        e = (0x800000 >>> 183 | 0x800000 << ~183 + 1) & 0xFFFFFFFF;
        f = -1 >>> 82 | -1 << -82;
        g = 0 >>> 94 | 0 << -94;
        h = Long.reverse(-1821656720285671805L);
        i = Integer.reverse(-1);
        j = 65536 >>> 176 | 65536 << ~176 + 1;
        k = Integer.reverse(Integer.MIN_VALUE);
        a = new String[j];
        b = new String[k];
        \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2.b();
    }

    @Nullable
    public synchronized \u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b b(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42) {
        int n;
        if (this.ab + a >= \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4.size()) {
            return null;
        }
        int n2 = this.ab += b;
        \u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b \u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b2 = \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4.a(n2, this.s.a().p()).a();
        if (\u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b2 instanceof \u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4 && !this.at) {
            return this.b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42);
        }
        if (this.ar && !(\u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b2 instanceof \u03b2\u03a3\u03a3\u0393\u03bd\u03b8\u03a9\u03bb\u03bd\u03bd\u03a9\u03b3\u03c5\u03b4\u03c2)) {
            return this.b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42);
        }
        int n3 = n = \u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b2 instanceof \u03a8\u03c8\u03bc\u039b\u03c1\u03bf\u03c2\u03b6 && ((\u03a8\u03c8\u03bc\u039b\u03c1\u03bf\u03c2\u03b6)\u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b2).c(this.s) ? c : d;
        if (this.as && n == 0 || !this.as && n != 0) {
            return this.b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42);
        }
        if (!\u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b2.a(this.s, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42)) {
            return this.b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42);
        }
        return \u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b2;
    }

    @Generated
    public \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, boolean bl, boolean bl2, boolean bl3) {
        this.s = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
        this.ar = bl;
        this.as = bl2;
        this.at = bl3;
    }

    public \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2 a() {
        \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2 \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b22 = new \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2(this.s, this.ar, this.as, e != 0);
        \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b22.ab = this.ab;
        return \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b22;
    }

    public synchronized \u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b b() {
        if (this.ab == f) {
            throw new IllegalStateException((String)\u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2.c("\u3e80", (int)g, (long)h));
        }
        return \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4.a(this.ab, this.s.a().p()).a();
    }

    private static void b() {
        int n;
        c = -4505054063364924082L;
        long l = c ^ 0x65340027BAD80E21L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(23 + 45), (byte)(41 + 28), (byte)(55 + 28), (byte)(3 + 44), (byte)(31 + 36), (byte)(27 + 39), (byte)(4 + 63), (byte)(37 + 10), (byte)(45 + 35), (byte)(30 + 45), (byte)(23 + 44), (byte)(35 + 48), (byte)(7 + 46), 80, (byte)(74 + 23), 100, (byte)(50 + 50), (byte)(63 + 42), (byte)(75 + 35), (byte)(101 + 2)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(40 + 28), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u04ac\u048f\u0489\u04ac\u0477\u048e\u04b0\u04bc\u0474\u0495\u049e\u047d\u04a1\u0497\u04ac\u048f\u04a5\u04b1\u04a7\u04be\u04ca\u04a0\u0482\u04a2\u048a\u04b7\u04c4\u0499\u048d\u04cb\u04c5\u04cb", (byte)45, 68);
                    continue block7;
                }
                case 1: {
                    \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2.b[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u0149\u012c\u0126\u0149\u0114\u012b\u014d\u0159\u0111\u0132\u013b\u011a\u013e\u0134\u0149\u012c\u0142\u014e\u0144\u015b\u0167\u0133\u0130\u0126\u0153\u0142\u0156\u0126\u016a\u0139\u012a\u0164", (byte)45, 66);
                    continue block7;
                }
                case 2: {
                    \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u0110\u010a\u0142\u013f\u013e\u014a\u0144\u014a\u0116\u0146\u0130\u0135\u0116\u013e\u014e\u0120\u015b\u012c\u011c\u0137\u015e\u012f\u012c\u012d", (byte)45, 66);
                    continue block7;
                }
                case 4: {
                    \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u054f\u0531\u0522\u055a\u0563\u0551\u0544\u053b\u0523\u0561\u053b\u054b\u056f\u0528\u0560\u0539\u0531\u0540\u0571\u0552\u0565\u0566\u0562\u054f\u0576\u0552\u0536\u055e\u0546\u055c\u0540\u0562", (byte)45, 70);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x29L;
        l ^= 0x65340027BAD80E21L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(53 + 15), (byte)(10 + 59), (byte)(6 + 77), (byte)(10 + 37), (byte)(13 + 54), (byte)(32 + 34), (byte)(34 + 33), (byte)(36 + 11), (byte)(76 + 4), (byte)(44 + 31), 67, (byte)(49 + 34), (byte)(3 + 50), (byte)(75 + 5), (byte)(94 + 3), (byte)(30 + 70), 100, (byte)(76 + 29), (byte)(40 + 70), (byte)(40 + 63)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(50 + 18), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u057a\u0587\u0586\u0549\u0589\u0585\u0580\u0589\u0594\u0583\u0550\u058e\u0592\u058b\u058e\u0594\u0556\u08e2\u08e5\u08d2\u08f2\u08d5\u08ee\u08e3\u08f5\u08f0\u08e3", (byte)118, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }
}

