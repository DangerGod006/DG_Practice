/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;

class \u03b1\u03bd\u03a0\u039b\u03be\u03a3\u03a9\u03c0\u0394\u03c4\u03a8\u03c2 {
    private static int a = Integer.reverse(Integer.MIN_VALUE);
    static final /* synthetic */ int[] I;
    private static int b = 32768 >>> 174 | 32768 << ~174 + 1;

    static {
        I = new int[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.values().length];
        try {
            \u03b1\u03bd\u03a0\u039b\u03be\u03a3\u03a9\u03c0\u0394\u03c4\u03a8\u03c2.I[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.b.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b1\u03bd\u03a0\u039b\u03be\u03a3\u03a9\u03c0\u0394\u03c4\u03a8\u03c2.I[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.c.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

