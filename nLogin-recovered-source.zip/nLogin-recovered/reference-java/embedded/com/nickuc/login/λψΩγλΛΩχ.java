/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.waterfallmc.waterfall.event.ProxyDefineCommandsEvent
 *  lombok.Generated
 *  net.md_5.bungee.api.connection.ProxiedPlayer
 *  net.md_5.bungee.event.EventHandler
 */
package com.nickuc.login;

import com.nickuc.login.\u03c7\u03b9\u03c2\u03b6\u0393\u03b8\u03c9\u03c6\u03c1\u03bf;
import io.github.waterfallmc.waterfall.event.ProxyDefineCommandsEvent;
import java.util.Locale;
import java.util.Set;
import lombok.Generated;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.event.EventHandler;

public class \u03bb\u03c8\u03a9\u03b3\u03bb\u039b\u03a9\u03c7
implements \u03c7\u03b9\u03c2\u03b6\u0393\u03b8\u03c9\u03c6\u03c1\u03bf {
    private static int b;
    private final String aq;
    private static int c;
    private final Set<String> l;
    private static int a;

    @EventHandler(priority=-32)
    public void a(ProxyDefineCommandsEvent proxyDefineCommandsEvent) {
        if (!(proxyDefineCommandsEvent.getReceiver() instanceof ProxiedPlayer)) {
            return;
        }
        proxyDefineCommandsEvent.getCommands().values().removeIf(command -> {
            String string = command.getName().toLowerCase(Locale.ENGLISH);
            return (string.startsWith(this.aq + (char)a) || this.l.contains(string) ? b : c) != 0;
        });
    }

    @Generated
    \u03bb\u03c8\u03a9\u03b3\u03bb\u039b\u03a9\u03c7(String string, Set<String> set) {
        this.aq = string;
        this.l = set;
    }

    static {
        a = Integer.reverse(0x5C000000);
        b = Integer.reverse(Integer.MIN_VALUE);
        c = Integer.reverse(0);
    }
}

