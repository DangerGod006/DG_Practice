/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;
import java.util.Base64;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba {
    private static int c;
    private static int h;
    private static long c;
    private static int n;
    private static String[] b;
    private static long k;
    private static int g;
    private static int a;
    private static int j;
    private static String[] a;
    private static long f;
    private static int o;
    private static int d;
    private static int e;
    private static int l;
    private static int p;
    private static int i;
    private static int b;
    private static int m;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u04a0\u04c2\u04c4\u04a4\u04c8\u04e7\u04df\u04f5\u04e1\u04b0\u04ee\u04e4\u04f2\u04ec\u04b5\u04da\u04fc\u04fb\u04f3\u04f9\u04f3\u04c8", (byte)65, 68), \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u04db\u04e8\u04e7\u04aa\u04ea\u04e6\u04e1\u04ea\u04f5\u04e4\u04b1\u04ef\u04f3\u04ec\u04ef\u04f5\u04b7\u081c\u0825\u0843\u084f\u0853\u0844\u0851\u0847\u084b\u04cc", (byte)65, 67) + string + \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.A("\u013b", (byte)65, 65) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = 2411970491308811360L;
        long l = c ^ 0x5635A2903C71AC1CL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(50 + 18), (byte)(64 + 5), (byte)(70 + 13), (byte)(21 + 26), (byte)(53 + 14), 66, (byte)(56 + 11), (byte)(8 + 39), (byte)(48 + 32), (byte)(46 + 29), (byte)(30 + 37), (byte)(49 + 34), (byte)(8 + 45), (byte)(13 + 67), 97, (byte)(58 + 42), (byte)(63 + 37), (byte)(70 + 35), (byte)(30 + 80), (byte)(86 + 17)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(21 + 47), (byte)(34 + 35), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.b[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.B("\u01c9\u01e1\u01e8\u01dd\u01d8\u01e3\u01c4\u01cc\u01cd\u01ef\u01e6\u01cb\u01ee\u01be\u01df\u01d1\u01e4\u01b9\u01cf\u01cf\u01f9\u01ba\u01d9\u01f3\u01fc\u01fe\u01b8\u01ba\u0204\u01ee\u01d7\u01c3", (byte)120, 66);
                    \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.b[1] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u0596\u0563\u054f\u0552\u0556\u0573\u0577\u059e\u056a\u0559\u0591\u055f\u0583\u055f\u0582\u0570\u055e\u05a2\u059c\u05a6\u0568\u057c\u05a6\u059f\u0586\u05ac\u05b0\u0591\u056c\u0590\u058c\u0582", (byte)120, 68);
                    continue block7;
                }
                case 1: {
                    \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.F("\u058e\u05a6\u05ad\u05a2\u059d\u05a8\u0589\u0591\u0592\u05b4\u05ab\u0590\u05b3\u0583\u05a4\u0596\u05a9\u057e\u0594\u0594\u05be\u057a\u0594\u059b\u059c\u0586\u0591\u05a6\u0589\u0588\u0599\u05b9", (byte)120, 70);
                    \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.b[1] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.B("\u01e8\u01b5\u01a1\u01a4\u01a8\u01c5\u01c9\u01f0\u01bc\u01ab\u01e3\u01b1\u01d5\u01b1\u01d4\u01c2\u01b0\u01f4\u01ee\u01f8\u01ba\u01c7\u01cd\u01d0\u01e9\u01d0\u01c0\u01f5\u01ed\u01e1\u01db\u01bf\u01c0\u0201\u01e2\u01e3\u01e7\u01ff\u01c4\u01ce\u01fb\u01dd\u01d1\u01d7", (byte)120, 66);
                    continue block7;
                }
                case 2: {
                    \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.b[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.F("\u05ae\u0586\u05ad\u05a3\u05a8\u0585\u056c\u05b3\u0587\u05b6\u0590\u058d\u0579\u056c\u05bb\u0588\u0577\u05ae\u0599\u05b4\u05bb\u05c0\u0587\u0588", (byte)120, 70);
                    continue block7;
                }
                case 4: {
                    \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u01b3\u01e1\u01d2\u01c3\u01c8\u01dc\u01e4\u01cb\u01c5\u01a7\u01be\u01b7", (byte)120, 66);
                }
            }
        }
    }

    public static <T> T b(Method method, Object ... objectArray) {
        return \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.b(method, null, objectArray);
    }

    static {
        a = (4096 >>> 172 | 4096 << -172) & 0xFFFFFFFF;
        b = Integer.reverse(0);
        c = Integer.reverse(Integer.MIN_VALUE);
        d = Integer.reverse(0);
        e = (-1 >>> 37 | -1 << ~37 + 1) & 0xFFFFFFFF;
        f = Long.reverse(-7483305896218419580L);
        g = Integer.reverse(0);
        h = Integer.reverse(0);
        i = Integer.reverse(Integer.MIN_VALUE);
        j = Integer.reverse(Integer.MIN_VALUE);
        k = Long.reverse(-7483305896218419580L);
        l = Integer.reverse(0);
        m = 0x800000 >>> 151 | 0x800000 << ~151 + 1;
        n = Integer.reverse(Integer.MIN_VALUE);
        o = 128 >>> 38 | 128 << -38;
        p = (65536 >>> 111 | 65536 << ~111 + 1) & 0xFFFFFFFF;
        a = new String[o];
        b = new String[p];
        \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.b();
    }

    private static String a(int n, long l) {
        l ^= 0x79L;
        l ^= 0x5635A2903C71AC1CL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(38 + 30), (byte)(9 + 60), (byte)(67 + 16), (byte)(11 + 36), (byte)(26 + 41), (byte)(29 + 37), (byte)(42 + 25), (byte)(27 + 20), (byte)(74 + 6), (byte)(13 + 62), 67, (byte)(61 + 22), (byte)(21 + 32), (byte)(44 + 36), (byte)(26 + 71), (byte)(94 + 6), (byte)(21 + 79), (byte)(29 + 76), 110, (byte)(28 + 75)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(71 + 12)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u0575\u0582\u0581\u0544\u0584\u0580\u057b\u0584\u058f\u057e\u054b\u0589\u058d\u0586\u0589\u058f\u0551\u08b6\u08bf\u08dd\u08e9\u08ed\u08de\u08eb\u08e1\u08e5", (byte)86, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static <T> T a(Method method, Object ... objectArray) {
        if (method != null) {
            try {
                return \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.b(method, objectArray);
            }
            catch (ClassCastException | IllegalAccessException | InvocationTargetException exception) {
                // empty catch block
            }
        }
        return null;
    }

    public static <T> Constructor<T> b(Class<?> clazz, Class<?> ... classArray) {
        Constructor<?> constructor = clazz.getDeclaredConstructor(classArray);
        constructor.setAccessible(n != 0);
        return constructor;
    }

    @Nullable
    public static Method a(Class<?> clazz, @Nullable String string, @Nullable Class<?> clazz2, Class<?> ... classArray) {
        Method[] methodArray = clazz.getDeclaredMethods();
        int n = methodArray.length;
        for (int i = b; i < n; ++i) {
            Method method = methodArray[i];
            if (string != null && !method.getName().equals(string) || clazz2 != null && !method.getReturnType().equals(clazz2) || !Arrays.equals(method.getParameterTypes(), classArray)) continue;
            method.setAccessible(c != 0);
            return method;
        }
        return null;
    }

    public static <T> T b(Method method, Object object, Object ... objectArray) {
        return (T)method.invoke(object, objectArray);
    }

    @Nullable
    public static Field a(Class<?> clazz, int n) {
        return \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(clazz, null, n);
    }

    @Nullable
    public static Method a(Class<?> clazz, String string, Class<?> ... classArray) {
        try {
            return \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.b(clazz, string, classArray);
        }
        catch (NoSuchMethodException noSuchMethodException) {
            return null;
        }
    }

    public static Method b(Class<?> clazz, String string, Class<?> ... classArray) {
        Method method = clazz.getDeclaredMethod(string, classArray);
        method.setAccessible(a != 0);
        return method;
    }

    @Nullable
    public static Field a(Class<?> clazz, @Nullable Class<?> clazz2, int n) {
        if (n < 0) {
            throw new IllegalArgumentException((String)\u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.c("\u3e80", (int)(d & e), (long)f) + n);
        }
        Field[] fieldArray = clazz.getDeclaredFields();
        if (fieldArray.length > 0) {
            int n2 = g;
            Field[] fieldArray2 = fieldArray;
            int n3 = fieldArray2.length;
            for (int i = h; i < n3; ++i) {
                Field field = fieldArray2[i];
                if (clazz2 != null) {
                    Class<?> clazz3 = field.getType();
                    if (clazz2 != Object.class ? clazz3 == Object.class || !clazz2.isAssignableFrom(clazz3) : clazz3 != Object.class) continue;
                }
                if (n2 == n) {
                    field.setAccessible(\u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.i != 0);
                    return field;
                }
                ++n2;
            }
        }
        return null;
    }

    @Nullable
    public static <T> T a(Method method, Object object, Object ... objectArray) {
        if (method != null) {
            try {
                return \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.b(method, object, objectArray);
            }
            catch (ClassCastException | IllegalAccessException | InvocationTargetException exception) {
                // empty catch block
            }
        }
        return null;
    }

    @Nullable
    public static Field a(Class<?> clazz, String ... stringArray) {
        if (stringArray.length == 0) {
            throw new IllegalArgumentException((String)\u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.c("\u3e80", (int)j, (long)k));
        }
        String[] stringArray2 = stringArray;
        int n = stringArray2.length;
        for (int i = l; i < n; ++i) {
            String string = stringArray2[i];
            try {
                return \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(clazz, string);
            }
            catch (NoSuchFieldException noSuchFieldException) {
                continue;
            }
        }
        return null;
    }

    @Nullable
    public static <T> Constructor<T> a(Class<?> clazz, Class<?> ... classArray) {
        try {
            return \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.b(clazz, classArray);
        }
        catch (ClassCastException | NoSuchMethodException exception) {
            return null;
        }
    }

    public static Field a(Class<?> clazz, String string) {
        Field field = clazz.getDeclaredField(string);
        field.setAccessible(m != 0);
        return field;
    }
}

