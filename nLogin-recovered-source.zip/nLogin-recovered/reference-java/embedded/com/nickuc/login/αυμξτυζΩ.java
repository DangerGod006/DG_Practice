/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.protocol.player.User
 *  com.nickuc.login.lib.packetevents.api.wrapper.PacketWrapper
 *  com.nickuc.login.lib.packetevents.api.wrapper.configuration.server.WrapperConfigServerDisconnect
 *  com.nickuc.login.lib.packetevents.api.wrapper.login.server.WrapperLoginServerDisconnect
 *  com.nickuc.login.lib.packetevents.api.wrapper.play.server.WrapperPlayServerDisconnect
 *  net.kyori.adventure.text.Component
 */
package com.nickuc.login;

import com.nickuc.login.lib.packetevents.api.protocol.player.User;
import com.nickuc.login.lib.packetevents.api.wrapper.PacketWrapper;
import com.nickuc.login.lib.packetevents.api.wrapper.configuration.server.WrapperConfigServerDisconnect;
import com.nickuc.login.lib.packetevents.api.wrapper.login.server.WrapperLoginServerDisconnect;
import com.nickuc.login.lib.packetevents.api.wrapper.play.server.WrapperPlayServerDisconnect;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03be\u03c7\u03c2\u03ba\u03a8\u03c1\u03b3\u03c0\u039b\u0393\u03bc\u03b3\u03b6;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.kyori.adventure.text.Component;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9 {
    private static String[] a;
    private static long f;
    private static long c;
    private static int a;
    private static int h;
    private static int e;
    private static int b;
    private static int g;
    private static String[] b;
    private static long d;

    static {
        a = (0 >>> 240 | 0 << -240) & 0xFFFFFFFF;
        b = -1 >>> 203 | -1 << -203;
        d = Long.reverse(5217588037830820497L);
        e = (65536 >>> 240 | 65536 << ~240 + 1) & 0xFFFFFFFF;
        f = Long.reverse(5217588037830820497L);
        g = Integer.reverse(0x40000000);
        h = Integer.reverse(0x40000000);
        a = new String[g];
        b = new String[h];
        \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.b();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u04f9\u051b\u051d\u04fd\u0521\u0540\u0538\u054e\u053a\u0509\u0547\u053d\u054b\u0545\u050e\u0533\u0555\u0554\u054c\u0552\u054c\u0521", (byte)21, 69), \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u010c\u0119\u0118\u00db\u011b\u0117\u0112\u011b\u0126\u0115\u00e2\u0120\u0124\u011d\u0120\u0126\u00e8\u046b\u0480\u0478\u047b\u0482\u0484\u0476\u046a\u00fc", (byte)21, 66) + string + \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u042e", (byte)21, 68) + methodType.toString(), exception);
        }
    }

    public static void a(User user, Component component) {
        switch (\u03be\u03c7\u03c2\u03ba\u03a8\u03c1\u03b3\u03c0\u039b\u0393\u03bc\u03b3\u03b6.R[user.getEncoderState().ordinal()]) {
            case 1: {
                user.sendPacketSilently((PacketWrapper)new WrapperLoginServerDisconnect(component));
                break;
            }
            case 2: {
                user.sendPacketSilently((PacketWrapper)new WrapperConfigServerDisconnect(component));
                break;
            }
            case 3: {
                user.sendPacketSilently((PacketWrapper)new WrapperPlayServerDisconnect(component));
                break;
            }
            default: {
                user.closeConnection();
                throw new IllegalStateException((String)\u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.c("\u3e80", (int)(a & b), (long)d) + user.getEncoderState() + (String)\u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.c("\u3e83", (int)e, (long)f) + user.getDecoderState());
            }
        }
    }

    private static void b() {
        int n;
        c = -8555752060944312823L;
        long l = c ^ 0x66C1786C63C9D3F7L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(30 + 38), 69, (byte)(18 + 65), (byte)(30 + 17), (byte)(4 + 63), (byte)(8 + 58), (byte)(33 + 34), (byte)(15 + 32), (byte)(16 + 64), (byte)(23 + 52), 67, (byte)(8 + 75), (byte)(24 + 29), (byte)(61 + 19), (byte)(23 + 74), (byte)(18 + 82), (byte)(50 + 50), (byte)(10 + 95), (byte)(27 + 83), (byte)(102 + 1)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(28 + 41), (byte)(7 + 76)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.E("\u0545\u054a\u052f\u0511\u053d\u0555\u0530\u0513\u0527\u0551\u0516\u0515\u053c\u0545\u0530\u0540\u0550\u051c\u0559\u054c\u053f\u051b\u0530\u0553\u0539\u0568\u0552\u0521\u0556\u053f\u054f\u056c\u054b\u0565\u0570\u0540\u056b\u054b\u055f\u0530\u0542\u0575\u0545\u053a\u0544\u0551\u0574\u053c\u057d\u0549\u0558\u0555\u055d\u0583\u054a\u054b", (byte)27, 69);
                    \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.b[1] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.F("\u0524\u0551\u054f\u0542\u050d\u052e\u0511\u0514\u0535\u0518\u054c\u0516\u052f\u0527\u0530\u051b\u0516\u0532\u0539\u0542\u0555\u053d\u052a\u052b", (byte)27, 70);
                    continue block7;
                }
                case 1: {
                    \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.b[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u0474\u0479\u045e\u0440\u046c\u0484\u045f\u0442\u0456\u0480\u0445\u0444\u046b\u0474\u045f\u046f\u047f\u044b\u0488\u047b\u046e\u044a\u045f\u0482\u0468\u0497\u0481\u0450\u0485\u046e\u047e\u049b\u047a\u0494\u049f\u046f\u049a\u047a\u048e\u045f\u0471\u04a4\u0471\u0478\u046b\u04a9\u04a1\u0485\u047f\u047c\u04b1\u049e\u04ac\u04a2\u0479\u047a", (byte)27, 67);
                    \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.b[1] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u0524\u0551\u054f\u0542\u050d\u052e\u0511\u0514\u0535\u0518\u054f\u0535\u054d\u0546\u054c\u0552\u0553\u053c\u0563\u0535\u0565\u053d\u052a\u052b", (byte)27, 69);
                    continue block7;
                }
                case 2: {
                    \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u012c\u00ed\u012b\u011c\u011c\u011f\u011d\u00fd\u0133\u0109\u0103\u010b\u00fa\u010e\u0104\u0127\u0119\u0134\u010b\u0133\u012a\u0131\u0108\u0109", (byte)27, 65);
                    continue block7;
                }
                case 4: {
                    \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.D("\u047c\u047a\u044d\u0455\u0472\u044d\u0470\u0456\u0464\u047b\u045f\u0446\u0459\u044c\u045e\u0466\u048a\u047c\u0469\u048a\u0490\u0482\u0459\u045a", (byte)27, 68);
                }
            }
        }
    }

    public static void j(User user, String string) {
        \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.a(user, (Component)Component.translatable((String)string));
    }

    private static String a(int n, long l) {
        l ^= 0x1BL;
        l ^= 0x66C1786C63C9D3F7L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(51 + 17), (byte)(39 + 30), (byte)(51 + 32), (byte)(18 + 29), (byte)(51 + 16), (byte)(50 + 16), (byte)(25 + 42), 47, (byte)(51 + 29), (byte)(39 + 36), (byte)(36 + 31), (byte)(39 + 44), (byte)(34 + 19), (byte)(20 + 60), (byte)(96 + 1), (byte)(19 + 81), (byte)(86 + 14), (byte)(29 + 76), (byte)(33 + 77), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(30 + 38), 69, (byte)(25 + 58)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u0190\u019d\u019c\u015f\u019f\u019b\u0196\u019f\u01aa\u0199\u0166\u01a4\u01a8\u01a1\u01a4\u01aa\u016c\u04ef\u0504\u04fc\u04ff\u0506\u0508\u04fa\u04ee", (byte)87, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static void i(User user, String string) {
        \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.a(user, (Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(string));
    }
}

