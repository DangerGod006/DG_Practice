/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7;

class \u03b5\u03c4\u03c2\u03b6\u03bf\u03b6\u03b7\u03c5\u03b3\u03c2 {
    private static int b;
    private static int a;
    static final /* synthetic */ int[] q;

    static {
        a = (0x20000000 >>> 221 | 0x20000000 << ~221 + 1) & 0xFFFFFFFF;
        b = 64 >>> 229 | 64 << ~229 + 1;
        q = new int[\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.values().length];
        try {
            \u03b5\u03c4\u03c2\u03b6\u03bf\u03b6\u03b7\u03c5\u03b3\u03c2.q[\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.a.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b5\u03c4\u03c2\u03b6\u03bf\u03b6\u03b7\u03c5\u03b3\u03c2.q[\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.b.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

