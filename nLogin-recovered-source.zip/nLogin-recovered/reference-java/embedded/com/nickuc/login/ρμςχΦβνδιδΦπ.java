/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c5\u03b2\u03b2\u03b1\u03ba\u03c3\u03b4\u03c4\u03b9\u03a0\u03a3\u03bd;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0
implements \u03c9\u03c5\u03b2\u03b2\u03b1\u03ba\u03c3\u03b4\u03c4\u03b9\u03a0\u03a3\u03bd {
    private static int aa;
    private static long s;
    private static long c;
    private static int p;
    private static int u;
    private final Method e;
    private static long b;
    private static int f;
    private final Constructor<?> b;
    private static int y;
    private static int ac;
    private static int z;
    private static int l;
    private static int i;
    private static long ah;
    private static int j;
    private static long t;
    private static int h;
    private static long m;
    private static int a;
    private static int ab;
    private static int v;
    private static int o;
    private static int g;
    private static int r;
    private static long ad;
    private static String[] a;
    private static String[] b;
    private static long d;
    private static long ag;
    private static int k;
    private static long q;
    private static int w;
    private static int e;
    private static int n;
    private static int af;
    private static int ai;
    private static int aj;
    private static int x;
    private static long ae;

    private static String a(int n, long l) {
        l ^= 0x56L;
        l ^= 0xED4FB302F4C97A0EL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(58 + 10), (byte)(20 + 49), (byte)(13 + 70), (byte)(46 + 1), (byte)(63 + 4), (byte)(56 + 10), 67, (byte)(37 + 10), (byte)(29 + 51), (byte)(36 + 39), (byte)(50 + 17), (byte)(76 + 7), (byte)(43 + 10), (byte)(66 + 14), (byte)(10 + 87), 100, (byte)(46 + 54), (byte)(2 + 103), (byte)(6 + 104), (byte)(42 + 61)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(50 + 33)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.A("\u01b6\u01c3\u01c2\u0185\u01c5\u01c1\u01bc\u01c5\u01d0\u01bf\u018c\u01ca\u01ce\u01c7\u01ca\u01d0\u0192\u0525\u0521\u0528\u052e\u050e\u051b\u0527\u051f\u0525\u0521\u0514\u052f", (byte)106, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0() {
        Class<?> clazz = Class.forName((String)\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.c("\u3e80", (int)a, (long)(b ^ d)));
        Class[] classArray = new Class[e];
        classArray[\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.f] = String.class;
        classArray[\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.g] = String.class;
        classArray[\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.h] = Integer.TYPE;
        classArray[\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.i] = Integer.TYPE;
        classArray[\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.j] = Integer.TYPE;
        this.b = (long)clazz.getConstructor(classArray);
        Class[] classArray2 = new Class[n];
        classArray2[\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.o] = clazz;
        this.e = Player.class.getMethod((String)\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.c("\u3e83", (int)(k & l), (long)m), classArray2);
    }

    @Override
    public void a(Player player, String object, String object2, int n, int n2, int n3) {
        if (((String)object).isEmpty() && ((String)object2).isEmpty()) {
            this.a(player);
            return;
        }
        if (((String)object).isEmpty()) {
            object = \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.c("\u3e80", (int)p, (long)q);
        }
        if (((String)object2).isEmpty()) {
            object2 = \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.c("\u3e83", (int)r, (long)(s ^ t));
        }
        try {
            Object[] objectArray = new Object[u];
            objectArray[\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.v] = object;
            objectArray[\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.w] = object2;
            objectArray[\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.x] = n;
            objectArray[\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.y] = n2;
            objectArray[\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.z] = n3;
            Object t = this.b.newInstance(objectArray);
            Object[] objectArray2 = new Object[aa];
            objectArray2[\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.ab] = t;
            this.e.invoke((Object)player, objectArray2);
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            throw new RuntimeException((String)\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.c("\u3e86", (int)ac, (long)(ad ^ ae)) + player.getName() + (String)\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.c("\u3e89", (int)af, (long)(ag ^ ah)), reflectiveOperationException);
        }
    }

    private static void b() {
        int n;
        c = -6547814358203301624L;
        long l = c ^ 0xED4FB302F4C97A0EL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(59 + 10), (byte)(66 + 17), (byte)(17 + 30), 67, (byte)(65 + 1), (byte)(29 + 38), (byte)(11 + 36), (byte)(50 + 30), (byte)(69 + 6), (byte)(37 + 30), (byte)(76 + 7), (byte)(7 + 46), (byte)(20 + 60), (byte)(39 + 58), (byte)(66 + 34), (byte)(3 + 97), (byte)(67 + 38), (byte)(66 + 44), (byte)(55 + 48)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(27 + 56)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u0155\u0157\u0170\u016a\u0153\u0164\u015f\u0183\u014c\u014f\u016d\u0150\u0187\u0166\u0170\u0191\u0173\u0184\u0170\u019a\u0176\u0188\u0193\u0186\u0150\u0187\u0196\u015a\u0180\u016e\u0162\u0163\u01a6\u0191\u0164\u0194\u015c\u017a\u0187\u016c\u0197\u019a\u01a6\u0175", (byte)71, 66);
                    \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.b[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u0550\u0533\u0538\u0559\u056f\u056b\u0550\u057f\u0582\u054f\u0582\u0566\u055b\u0586\u0554\u057b\u0588\u057f\u054c\u0590\u0578\u0559\u0556\u0557", (byte)71, 70);
                    \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.b[2] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u0568\u057e\u0546\u056d\u053a\u056a\u054a\u0543\u0559\u057a\u0541\u054b", (byte)71, 69);
                    \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.b[3] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u0568\u057e\u0546\u056d\u053a\u056a\u054a\u0543\u0559\u057a\u0541\u054b", (byte)71, 69);
                    \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.b[4] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u0181\u017e\u0166\u0185\u0173\u0173\u014b\u0157\u0187\u018c\u018a\u015c\u015a\u015e\u014c\u0167\u0167\u0151\u0196\u0150\u0157\u0178\u0197\u0155\u0178\u015a\u0168\u017d\u018c\u0199\u0198\u0171", (byte)71, 66);
                    \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.b[5] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0557\u053d\u057e\u054c\u054a\u0549\u055e\u0584\u055b\u055b\u057c\u054b", (byte)71, 70);
                    continue block7;
                }
                case 1: {
                    \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u0155\u0157\u0170\u016a\u0153\u0164\u015f\u0183\u014c\u014f\u016d\u0150\u0187\u0166\u0170\u0191\u0173\u0184\u0170\u019a\u0176\u0188\u0193\u0186\u0150\u0187\u0196\u015a\u0180\u016e\u0162\u0163\u017a\u017f\u0183\u0174\u01ab\u01a9\u019d\u0197\u0197\u0181\u016b\u0175", (byte)71, 65);
                    \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.b[1] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.D("\u04d7\u04ba\u04bf\u04e0\u04f6\u04f2\u04d7\u0506\u0509\u04d6\u0508\u04df\u04c5\u04cf\u04c8\u050a\u0512\u04cf\u0510\u0506\u04f5\u0506\u04dd\u04de", (byte)71, 68);
                    \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.b[2] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u04c1\u04df\u04bd\u04e5\u04f2\u04f4\u0508\u04e6\u0505\u04c2\u04f7\u04d2", (byte)71, 67);
                    \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.b[3] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.F("\u0548\u0565\u0567\u055c\u0551\u0579\u055f\u055c\u0551\u0561\u0584\u054b", (byte)71, 70);
                    \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.b[4] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.E("\u0577\u0574\u055c\u057b\u0569\u0569\u0541\u054d\u057d\u0582\u0580\u0552\u0550\u0554\u0542\u055d\u055d\u0547\u058c\u0546\u054d\u057a\u056b\u058b\u0585\u058b\u0596\u0581\u0558\u0576\u0555\u056e\u0590\u0565\u0559\u058c\u0593\u0599\u0558\u05a1\u0594\u056d\u0561\u056b", (byte)71, 69);
                    \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.b[5] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.B("\u0175\u0173\u0147\u0189\u0176\u0166\u0155\u0184\u0144\u014f\u0182\u0155", (byte)71, 66);
                    continue block7;
                }
                case 2: {
                    \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.b[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0557\u0571\u056c\u0556\u053c\u056a\u054a\u0555\u0581\u0551\u0555\u055a\u0543\u0560\u0587\u0566\u0583\u055e\u0589\u058e\u058b\u058f\u0556\u0557", (byte)71, 69);
                    continue block7;
                }
                case 4: {
                    \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.b[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u0577\u0548\u055b\u055d\u0580\u057e\u054f\u0541\u057c\u0586\u0555\u057a\u0570\u0580\u0566\u056c\u057d\u0588\u055f\u0590\u0579\u0559\u0556\u0557", (byte)71, 69);
                }
            }
        }
    }

    @Override
    public void a(Player player) {
        player.resetTitle();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u04f2\u0514\u0516\u04f6\u051a\u0539\u0531\u0547\u0533\u0502\u0540\u0536\u0544\u053e\u0507\u052c\u054e\u054d\u0545\u054b\u0545\u051a", (byte)14, 70), \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u0442\u044f\u044e\u0411\u0451\u044d\u0448\u0451\u045c\u044b\u0418\u0456\u045a\u0453\u0456\u045c\u041e\u07b1\u07ad\u07b4\u07ba\u079a\u07a7\u07b3\u07ab\u07b1\u07ad\u07a0\u07bb\u0436", (byte)14, 68) + string + \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u0419", (byte)14, 68) + methodType.toString(), exception);
        }
    }

    static {
        a = (0 >>> 199 | 0 << ~199 + 1) & 0xFFFFFFFF;
        b = Long.reverse(1189205586189649061L);
        d = Long.reverse(0x6A00000000000000L);
        e = 0x2800000 >>> 23 | 0x2800000 << -23;
        f = (0 >>> 31 | 0 << ~31 + 1) & 0xFFFFFFFF;
        g = Integer.reverse(Integer.MIN_VALUE);
        h = Integer.reverse(0x40000000);
        i = Integer.reverse(-1073741824);
        j = (0x10000000 >>> 218 | 0x10000000 << ~218 + 1) & 0xFFFFFFFF;
        k = 2 >>> 65 | 2 << ~65 + 1;
        l = Integer.reverse(-1);
        m = Long.reverse(8827310554210010277L);
        n = Integer.reverse(Integer.MIN_VALUE);
        o = (0 >>> 228 | 0 << -228) & 0xFFFFFFFF;
        p = 4096 >>> 171 | 4096 << -171;
        q = Long.reverse(8827310554210010277L);
        r = Integer.reverse(-1073741824);
        s = Long.reverse(1189205586189649061L);
        t = Long.reverse(0x6A00000000000000L);
        u = (0x280000 >>> 51 | 0x280000 << ~51 + 1) & 0xFFFFFFFF;
        v = Integer.reverse(0);
        w = Integer.reverse(Integer.MIN_VALUE);
        x = (0x40000000 >>> 221 | 0x40000000 << ~221 + 1) & 0xFFFFFFFF;
        y = Integer.reverse(-1073741824);
        z = Integer.reverse(0x20000000);
        aa = 0x2000000 >>> 153 | 0x2000000 << ~153 + 1;
        ab = Integer.reverse(0);
        ac = Integer.reverse(0x20000000);
        ad = Long.reverse(1189205586189649061L);
        ae = Long.reverse(0x6A00000000000000L);
        af = Integer.reverse(-1610612736);
        ag = Long.reverse(1189205586189649061L);
        ah = Long.reverse(0x6A00000000000000L);
        ai = (12 >>> 129 | 12 << -129) & 0xFFFFFFFF;
        aj = 6 >>> 0 | 6 << ~0 + 1;
        a = new String[ai];
        b = new String[aj];
        \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0.b();
    }
}

