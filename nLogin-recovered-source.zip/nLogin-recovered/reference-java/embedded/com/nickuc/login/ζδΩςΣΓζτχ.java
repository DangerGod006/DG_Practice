/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.jetbrains.annotations.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd;
import com.nickuc.login.\u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c8\u03a8\u03c0\u03b7\u03b7\u03c5\u03c5\u03b4\u0394\u03b7;
import com.nickuc.login.\u03c8\u03c4\u03bb\u03bd\u03b8\u03be\u03b2\u0393\u03ba\u03b1;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;
import java.util.Base64;
import java.util.concurrent.Callable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.Nullable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7 {
    private static long bg;
    private static long u;
    private static int cx;
    private static int ao;
    private static int ck;
    @Nullable
    public static final Field d;
    private static long s;
    private static int ct;
    private static long ai;
    @Nullable
    public static final Method g;
    private static long ch;
    private static int bs;
    private static int h;
    private static int br;
    private static int bm;
    public static final Method h;
    private static int a;
    private static long cv;
    private static long bt;
    private static int cl;
    private static int cp;
    private static int l;
    private static int ak;
    private static int o;
    private static int bh;
    @Nullable
    public static final Class<?> k;
    private static int ar;
    @Nullable
    public static final Method f;
    private static long bp;
    private static long am;
    private static int cj;
    private static int cq;
    private static int ad;
    private static int cf;
    private static long q;
    private static int e;
    private static int bv;
    private static long g;
    private static int au;
    private static long v;
    private static int at;
    private static long cw;
    private static int ag;
    private static int ah;
    private static long bj;
    private static int m;
    private static long cg;
    private static long aq;
    private static int ae;
    private static String[] b;
    private static int ci;
    private static long ax;
    private static long f;
    private static int az;
    @Nullable
    public static final Field e;
    private static long cr;
    private static int by;
    private static int i;
    private static int cy;
    private static int bz;
    private static int bi;
    private static long cn;
    private static int w;
    private static int an;
    private static int y;
    private static int t;
    private static int n;
    private static int cs;
    @Nullable
    public static final Class<?> i;
    private static int b;
    private static long bo;
    private static long c;
    private static long cm;
    private static int as;
    private static int af;
    private static int ba;
    private static long bd;
    private static long cc;
    private static int al;
    @Nullable
    public static final Class<?> j;
    private static int j;
    private static long av;
    private static int bq;
    private static int bb;
    private static long bw;
    private static long ab;
    private static long cd;
    private static long ac;
    private static int be;
    private static int r;
    private static int aa;
    private static int cu;
    private static int ca;
    private static int co;
    private static int bl;
    private static long k;
    private static int aj;
    private static long ay;
    private static int ap;
    private static String[] a;
    private static int bf;
    private static int p;
    @Nullable
    public static final Class<?> h;
    private static long d;
    private static int bc;
    private static long bx;
    @Nullable
    public static final Class<?> l;
    private static int x;
    private static int aw;
    private static long bk;
    private static int z;
    private static int ce;
    private static int bu;
    private static int bn;
    private static int cb;

    public static void ae() {
    }

    private static String a(int n, long l) {
        l ^= 0x5CL;
        l ^= 0x60B968E385FA0AFL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(64 + 4), (byte)(57 + 12), (byte)(49 + 34), (byte)(6 + 41), (byte)(8 + 59), (byte)(39 + 27), (byte)(62 + 5), 47, (byte)(32 + 48), (byte)(40 + 35), (byte)(12 + 55), (byte)(8 + 75), (byte)(29 + 24), (byte)(59 + 21), 97, (byte)(26 + 74), (byte)(93 + 7), (byte)(34 + 71), (byte)(54 + 56), (byte)(34 + 69)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(71 + 12)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.D("\u0568\u0575\u0574\u0537\u0577\u0573\u056e\u0577\u0582\u0571\u053e\u057c\u0580\u0579\u057c\u0582\u0544\u08cc\u08cb\u08c1\u08db\u08bd\u08ae\u08d2\u08e1\u08e5", (byte)112, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static void a(Player player, Object object) {
        if (object == null) {
            throw new IllegalArgumentException((String)\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e80", (int)p, (long)q));
        }
        if (d == null) {
            throw new IllegalArgumentException((String)\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e83", (int)r, (long)s));
        }
        if (e == null) {
            throw new IllegalArgumentException((String)\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e86", (int)t, (long)(u ^ v)));
        }
        Object object2 = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.a(player);
        if (object2 == null) {
            return;
        }
        Object object3 = d.get(object2);
        if (\u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.a().a(\u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.i)) {
            Object object4 = e.get(object3);
            Object[] objectArray = new Object[w];
            objectArray[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.x] = object;
            \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(g, object4, objectArray);
        } else {
            Object[] objectArray = new Object[y];
            objectArray[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.z] = object;
            \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(g, object3, objectArray);
        }
    }

    static {
        Method method;
        Object object;
        Class<?> clazz;
        a = Integer.reverse(0);
        b = Integer.reverse(-1);
        d = Long.reverse(2453561993088467776L);
        e = (1 >>> 128 | 1 << ~128 + 1) & 0xFFFFFFFF;
        f = Long.reverse(1732986052709188416L);
        g = Long.reverse(0x3A00000000000000L);
        h = 0 >>> 211 | 0 << ~211 + 1;
        i = Integer.reverse(0);
        j = Integer.reverse(0x40000000);
        k = Long.reverse(2453561993088467776L);
        l = 0 >>> 134 | 0 << ~134 + 1;
        m = Integer.reverse(0);
        n = 0 >>> 49 | 0 << ~49 + 1;
        o = (0 >>> 96 | 0 << ~96 + 1) & 0xFFFFFFFF;
        p = Integer.reverse(-1073741824);
        q = Long.reverse(2453561993088467776L);
        r = 0x20000000 >>> 187 | 0x20000000 << ~187 + 1;
        s = Long.reverse(2453561993088467776L);
        t = 655360 >>> 177 | 655360 << ~177 + 1;
        u = Long.reverse(1732986052709188416L);
        v = Long.reverse(0x3A00000000000000L);
        w = Integer.reverse(Integer.MIN_VALUE);
        x = Integer.reverse(0);
        y = (16 >>> 68 | 16 << -68) & 0xFFFFFFFF;
        z = Integer.reverse(0);
        aa = 0xC000000 >>> 217 | 0xC000000 << ~217 + 1;
        ab = Long.reverse(1732986052709188416L);
        ac = Long.reverse(0x3A00000000000000L);
        ad = Integer.reverse(-402653184);
        ae = Integer.reverse(-402653184);
        af = Integer.reverse(0x40000000);
        ag = Integer.reverse(0);
        ah = (-1073741823 >>> 190 | -1073741823 << ~190 + 1) & 0xFFFFFFFF;
        ai = Long.reverse(2453561993088467776L);
        aj = (65536 >>> 16 | 65536 << ~16 + 1) & 0xFFFFFFFF;
        ak = 2 >>> 158 | 2 << ~158 + 1;
        al = Integer.reverse(-1);
        am = Long.reverse(2453561993088467776L);
        an = Integer.reverse(Integer.MIN_VALUE);
        ao = (0 >>> 144 | 0 << -144) & 0xFFFFFFFF;
        ap = 294912 >>> 15 | 294912 << ~15 + 1;
        aq = Long.reverse(2453561993088467776L);
        ar = Integer.reverse(Integer.MIN_VALUE);
        as = Integer.reverse(0);
        at = Integer.reverse(0x50000000);
        au = (-1 >>> 32 | -1 << -32) & 0xFFFFFFFF;
        av = Long.reverse(2453561993088467776L);
        aw = (11 >>> 32 | 11 << ~32 + 1) & 0xFFFFFFFF;
        ax = Long.reverse(1732986052709188416L);
        ay = Long.reverse(0x3A00000000000000L);
        az = (0 >>> 17 | 0 << ~17 + 1) & 0xFFFFFFFF;
        ba = Integer.reverse(-1073741824);
        bb = (0 >>> 192 | 0 << ~192 + 1) & 0xFFFFFFFF;
        bc = 1536 >>> 71 | 1536 << -71;
        bd = Long.reverse(2453561993088467776L);
        be = Integer.reverse(Integer.MIN_VALUE);
        bf = Integer.reverse(-1342177280);
        bg = Long.reverse(2453561993088467776L);
        bh = Integer.reverse(0x40000000);
        bi = Integer.reverse(0x70000000);
        bj = Long.reverse(1732986052709188416L);
        bk = Long.reverse(0x3A00000000000000L);
        bl = Integer.reverse(-1073741824);
        bm = Integer.reverse(0);
        bn = 240 >>> 36 | 240 << -36;
        bo = Long.reverse(1732986052709188416L);
        bp = Long.reverse(0x3A00000000000000L);
        bq = (524288 >>> 179 | 524288 << -179) & 0xFFFFFFFF;
        br = Integer.reverse(0x8000000);
        bs = Integer.reverse(-1);
        bt = Long.reverse(2453561993088467776L);
        bu = 0x100000 >>> 211 | 0x100000 << ~211 + 1;
        bv = Integer.reverse(-2013265920);
        bw = Long.reverse(1732986052709188416L);
        bx = Long.reverse(0x3A00000000000000L);
        by = Integer.reverse(0);
        bz = Integer.reverse(0x40000000);
        ca = Integer.reverse(0);
        cb = (0x240000 >>> 145 | 0x240000 << ~145 + 1) & 0xFFFFFFFF;
        cc = Long.reverse(1732986052709188416L);
        cd = Long.reverse(0x3A00000000000000L);
        ce = Integer.reverse(Integer.MIN_VALUE);
        cf = Integer.reverse(-939524096);
        cg = Long.reverse(1732986052709188416L);
        ch = Long.reverse(0x3A00000000000000L);
        ci = Integer.reverse(0);
        cj = (32 >>> 196 | 32 << -196) & 0xFFFFFFFF;
        ck = Integer.reverse(0);
        cl = Integer.reverse(0x28000000);
        cm = Long.reverse(1732986052709188416L);
        cn = Long.reverse(0x3A00000000000000L);
        co = Integer.reverse(Integer.MIN_VALUE);
        cp = Integer.reverse(-1476395008);
        cq = Integer.reverse(-1);
        cr = Long.reverse(2453561993088467776L);
        cs = Integer.reverse(Integer.MIN_VALUE);
        ct = 0 >>> 142 | 0 << ~142 + 1;
        cu = 5632 >>> 168 | 5632 << ~168 + 1;
        cv = Long.reverse(1732986052709188416L);
        cw = Long.reverse(0x3A00000000000000L);
        cx = Integer.reverse(Integer.MIN_VALUE);
        cy = Integer.reverse(0);
        a = new String[ad];
        b = new String[ae];
        \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b();
        String[] stringArray = new String[af];
        stringArray[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.ag] = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e80", (int)ah, (long)ai);
        stringArray[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.aj] = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e83", (int)(ak & al), (long)am);
        h = (int)\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.a(stringArray);
        String[] stringArray2 = new String[an];
        stringArray2[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.ao] = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e86", (int)ap, (long)aq);
        i = (int)\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.a(stringArray2);
        String[] stringArray3 = new String[ar];
        stringArray3[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.as] = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e89", (int)(at & au), (long)av);
        j = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.a(stringArray3);
        f = j != null ? \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(j, (String)\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e8c", (int)aw, (long)(ax ^ ay)), new Class[az]) : null;
        String[] stringArray4 = new String[ba];
        stringArray4[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.bb] = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e8f", (int)bc, (long)bd);
        stringArray4[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.be] = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e92", (int)bf, (long)bg);
        stringArray4[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.bh] = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e95", (int)bi, (long)(bj ^ bk));
        k = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.a(() -> f != null ? f.getReturnType() : null, stringArray4);
        String[] stringArray5 = new String[bl];
        stringArray5[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.bm] = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e98", (int)bn, (long)(bo ^ bp));
        stringArray5[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.bq] = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e9b", (int)(br & bs), (long)bt);
        stringArray5[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.bu] = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e9e", (int)bv, (long)(bw ^ bx));
        l = (int)\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.a(() -> k != null ? (Class)Arrays.stream(k.getDeclaredFields()).map(Field::getType).filter(clazz -> clazz.getSimpleName().contains((CharSequence)\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e80", (int)aa, (long)(ab ^ ac)))).findFirst().orElse(null) : null, stringArray5);
        Field field = d = k != null && l != null ? \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(k, l, by) : null;
        if (\u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.a().a(\u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.i) && l != null) {
            String[] stringArray6 = new String[bz];
            stringArray6[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.ca] = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3ea1", (int)cb, (long)(cc ^ cd));
            stringArray6[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.ce] = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3ea4", (int)cf, (long)(cg ^ ch));
            clazz = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.a(stringArray6);
            e = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(l, clazz, ci);
            object = clazz;
        } else {
            e = null;
            object = l;
        }
        String[] stringArray7 = new String[cj];
        stringArray7[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.ck] = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3ea7", (int)cl, (long)(cm ^ cn));
        stringArray7[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.co] = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3eaa", (int)(cp & cq), (long)cr);
        clazz = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.a(stringArray7);
        if (clazz != null && object != null) {
            Class[] classArray = new Class[cs];
            classArray[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.ct] = clazz;
            method = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(object, null, Void.TYPE, classArray);
        } else {
            method = null;
        }
        g = method;
        Class[] classArray = new Class[cx];
        classArray[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.cy] = String.class;
        h = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(Sound.class, (String)\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3ead", (int)cu, (long)(cv ^ cw)), classArray);
    }

    @Nullable
    public static Class<?> a(String ... stringArray) {
        for (int i = l; i < stringArray.length; ++i) {
            stringArray[i] = \u03c8\u03c4\u03bb\u03bd\u03b8\u03be\u03b2\u0393\u03ba\u03b1.i(stringArray[i]);
        }
        String[] stringArray2 = stringArray;
        int n = stringArray2.length;
        for (int i = m; i < n; ++i) {
            String string = stringArray2[i];
            try {
                Class<?> clazz = \u03c8\u03a8\u03c0\u03b7\u03b7\u03c5\u03c5\u03b4\u0394\u03b7.a(\u03c8\u03c4\u03bb\u03bd\u03b8\u03be\u03b2\u0393\u03ba\u03b1.i(string), new String[\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.n]);
                if (clazz == null) continue;
                return clazz;
            }
            catch (Throwable throwable) {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.a(throwable);
            }
        }
        return null;
    }

    @Nullable
    public static Object a(Player player) {
        return f != null ? \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(f, (Object)player, new Object[o]) : null;
    }

    private static void b() {
        int n;
        c = 198173881015676952L;
        long l = c ^ 0x60B968E385FA0AFL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(62 + 6), (byte)(9 + 60), (byte)(51 + 32), (byte)(9 + 38), (byte)(36 + 31), (byte)(14 + 52), (byte)(51 + 16), (byte)(37 + 10), (byte)(75 + 5), 75, (byte)(51 + 16), (byte)(74 + 9), (byte)(13 + 40), (byte)(44 + 36), (byte)(93 + 4), (byte)(39 + 61), (byte)(72 + 28), (byte)(85 + 20), 110, (byte)(22 + 81)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(46 + 22), 69, (byte)(23 + 60)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u04a1\u0474\u0473\u0483\u048d\u0478\u049a\u04b5\u0491\u04bf\u04ad\u04b7\u0497\u047d\u04a0\u048e\u0480\u04c2\u04bf\u04c5\u04b2\u0492\u0498\u04a1\u04c7\u04c2\u049b\u04ae\u0490\u048c\u04d2\u04bf\u04c0\u04a0\u04d1\u04a2\u04b7\u04c8\u048d\u04c5\u04d6\u04c7\u0496\u04a4", (byte)45, 67);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u013c\u0148\u0132\u0126\u0150\u0112\u0159\u0119\u0154\u0139\u0117\u0121", (byte)45, 66);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[2] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u055d\u0540\u0550\u051e\u054e\u0542\u0542\u0561\u0563\u053d\u0566\u0531", (byte)45, 70);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[3] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.D("\u0490\u048f\u0488\u04a5\u0483\u0498\u049a\u04b8\u04b4\u0496\u049f\u0493\u049b\u047a\u049a\u04be\u04c6\u04a2\u0499\u04a0\u04c4\u0485\u048b\u048a\u04b8\u04c7\u04cc\u04a6\u0487\u049e\u04c7\u04be", (byte)45, 68);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[4] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.B("\u0108\u010c\u0131\u013e\u0120\u0130\u0130\u0157\u0115\u0137\u012b\u0125\u0139\u0148\u015f\u015a\u015d\u013d\u012c\u0132\u013e\u0157\u0131\u013f\u0159\u0121\u0125\u015e\u0147\u013e\u012b\u0139\u013a\u013b\u0168\u0147\u012f\u0156\u0156\u0167\u0145\u0177\u0174\u0133\u0156\u0177\u0160\u0155\u017a\u0141\u013b\u017c\u017d\u0146\u0156\u0156\u014a\u0189\u0162\u0187\u0189\u0162\u015b\u017b\u0189\u0150\u018b\u0187\u018c\u0190\u0183\u0167\u0183\u0156\u015b\u0195\u0178\u0172\u018b\u0197\u0161\u017b\u016e\u0193\u0184\u017f\u016c\u016d", (byte)45, 66);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[5] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u046b\u046f\u0494\u04a1\u0483\u0493\u0493\u04ba\u0478\u049a\u048e\u0488\u049c\u04ab\u04c2\u04bd\u04c0\u04a0\u048f\u0495\u04a1\u04bb\u04bc\u04b7\u04c9\u04c7\u04a8\u049d\u04c7\u04c2\u04cb\u04a2\u04d4\u04c9\u04c3\u04cd\u04c8\u04c8\u04c3\u04d3\u04da\u04d2\u04b4\u04a0\u04bc\u04cc\u04ac\u04b7\u04ce\u04d0\u049d\u04b8\u04d2\u04c9\u04e2\u04db\u04ec\u04bb\u04c6\u04af\u04ab\u04d2\u04f0\u04e0\u04e0\u04e2\u04d7\u04b1\u04d8\u04e2\u04c9\u04ca\u04d4\u04e8\u04bf\u04f3\u04cd\u04f4\u04eb\u04f1\u04c1\u0503\u04cf\u0506\u04d2\u0508\u04cf\u04d0", (byte)45, 68);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[6] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u051b\u051e\u0540\u0544\u0541\u0550\u051a\u0569\u0523\u0538\u0540\u0540\u0559\u052b\u054c\u0530\u053d\u0571\u055d\u054c\u0567\u0565\u053c\u053d", (byte)45, 69);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[7] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u0474\u0470\u0484\u0483\u0499\u04b7\u04b7\u0473\u048b\u04b2\u04b5\u0493\u049e\u04ad\u04a4\u049a\u047f\u04b8\u04bc\u04b5\u04c4\u0498\u0496\u04a8\u04c8\u048c\u04ba\u04a5\u04a4\u04a3\u049c\u04a5\u04cf\u049f\u04d4\u0492\u04c9\u0494\u04a6\u04d8\u04de\u04ab\u04c7\u04bd\u04b3\u04dd\u04e1\u04a4\u0497\u04a5\u04dd\u04b8\u04b8\u04b2\u04af\u04b0", (byte)45, 67);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[8] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u051a\u0520\u0564\u054d\u0564\u055f\u0520\u055b\u054a\u0560\u0527\u0556\u0528\u0541\u0543\u0529\u056f\u055d\u055f\u053e\u0536\u052e\u0542\u057a\u054c\u057c\u0564\u054f\u0539\u0560\u0537\u053a", (byte)45, 70);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[9] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u0133\u014d\u0130\u0122\u0156\u012f\u014b\u0124\u0134\u015b\u012c\u014c\u0130\u0111\u0161\u0158\u0132\u013d\u015c\u012f\u011d\u0135\u0159\u013a\u0156\u0159\u0136\u0148\u0139\u0165\u0128\u014c", (byte)45, 65);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[10] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.E("\u053b\u0564\u051b\u0522\u0537\u0568\u053b\u053a\u0547\u0540\u0555\u0567\u0556\u055e\u0541\u056f\u0560\u0544\u055f\u0570\u0530\u0560\u0579\u052f\u054b\u0563\u0557\u057c\u0536\u0549\u0537\u055b\u056a\u053b\u0571\u056d\u0572\u0574\u0553\u056a\u0572\u054b\u0576\u0551", (byte)45, 69);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[11] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u048d\u0474\u0475\u04a0\u04ad\u0495\u0496\u04af\u0498\u04a8\u048c\u049a\u04b2\u04be\u04ae\u049f\u0492\u04b4\u04bf\u04b3\u04a4\u0492\u048f\u0490", (byte)45, 68);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[12] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u0474\u0470\u0484\u0483\u0499\u04b7\u04b7\u0473\u048b\u04b2\u04b5\u0493\u049e\u04ad\u04a4\u049a\u047f\u04b8\u04bc\u04b5\u04c4\u0498\u04c5\u04b6\u0495\u04b9\u0498\u04a8\u04ad\u04c1\u0490\u04d2\u04af\u04c6\u04bf\u04c1\u04b0\u04d9\u04d2\u04cc\u0496\u04cd\u049a\u04d8\u04c9\u04ad\u049d\u04c0\u04bd\u04c1\u04a3\u04d7\u04bc\u04c2\u04af\u04b0", (byte)45, 67);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[13] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u0474\u0470\u0484\u0483\u0499\u04b7\u04b7\u0473\u048b\u04b2\u04b5\u0493\u049e\u04ad\u04a4\u049a\u047f\u04b8\u04bc\u04b5\u04c4\u0498\u04c5\u04b6\u0495\u04b9\u0498\u04a8\u04ad\u04c1\u0490\u04d2\u049e\u04b7\u04c6\u04c8\u048b\u04cf\u04bb\u04b5\u04bb\u04cb\u04b0\u04b8\u04e2\u04a0\u04ce\u04c0\u04b4\u04e6\u04be\u04c8\u04e9\u04d8\u04af\u04b0", (byte)45, 67);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[14] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.C("\u04a3\u0496\u04b2\u04a6\u04a4\u0479\u04a3\u0478\u04a5\u04af\u04b4\u04b1\u048f\u0482\u04ae\u047a\u04c5\u04a6\u0486\u04bb\u04b1\u04c5\u04bc\u04c3\u04a0\u0496\u04b9\u049a\u048a\u04ba\u0485\u04ae", (byte)45, 67);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[15] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u0521\u051d\u0531\u0530\u0546\u0564\u0564\u0520\u0538\u055f\u0562\u0540\u054b\u055a\u0551\u0547\u052c\u0565\u0569\u0562\u0571\u0546\u0534\u052f\u0537\u0577\u0537\u057b\u0534\u0575\u0548\u0559\u0582\u0578\u0581\u0571\u0566\u0543\u055f\u0548\u0575\u057c\u0544\u0582\u0562\u058d\u056a\u057b\u058f\u0569\u0586\u055d\u0550\u0568\u056e\u057a\u057b\u058c\u0589\u0556\u0559\u058f\u0552\u0591", (byte)45, 69);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[16] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u0521\u051d\u0531\u0530\u0546\u0564\u0564\u0520\u0538\u055f\u0562\u0540\u054b\u055a\u0551\u0547\u052c\u0565\u0569\u0562\u0571\u0546\u0534\u052f\u0537\u0577\u0537\u057b\u0534\u0575\u0548\u0559\u0550\u0541\u0574\u0572\u0557\u055a\u0578\u0558\u056a\u055f\u0556\u057d\u057c\u056a\u0547\u057b\u0548\u054a\u056a\u0553\u055f\u0586\u0553\u058b\u056b\u058d\u0597\u0556\u059e\u055c\u055a\u05a1\u057f\u058c\u055f\u05a1\u057b\u0559\u0598\u0598\u0577\u0576\u059f\u0596\u058b\u0577\u05ad\u0581\u058b\u0594\u0585\u05b5\u0573\u058f\u057c\u057d", (byte)45, 69);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[17] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u04b0\u0492\u0473\u04a3\u04ba\u0496\u0494\u0475\u0487\u049a\u047d\u0488\u04a9\u0493\u04bc\u04b6\u049a\u04af\u0480\u049f\u04a1\u049c\u0483\u04b8\u04a2\u049b\u048c\u04a6\u048e\u04ae\u04a0\u04a5", (byte)45, 68);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[18] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u0521\u051d\u0531\u0530\u0546\u0564\u0564\u0520\u0538\u055f\u0564\u0524\u053d\u054f\u056a\u054a\u052d\u056b\u0540\u0566\u0573\u0549\u056b\u0579\u054a\u0549\u0577\u0539\u0566\u0569\u054e\u057b\u0570\u055f\u0581\u0584\u0580\u0563\u057b\u0562\u0577\u0562\u0586\u0575\u055c\u0558\u0566\u0580\u056c\u0586\u058b\u0587\u0584\u055f\u055c\u055d", (byte)45, 69);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[19] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u0111\u010d\u0121\u0120\u0136\u0154\u0154\u0110\u0128\u014f\u0154\u0114\u012d\u013f\u015a\u013a\u011d\u015b\u0130\u0156\u0163\u0136\u0157\u0155\u013e\u0148\u0148\u0149\u015c\u0163\u013b\u0152\u014a\u012f\u0167\u0162\u0177\u0142\u0169\u0139\u0134\u0171\u0158\u014f\u0168\u017d\u015b\u014c\u0178\u0173\u0161\u0154\u015a\u0175\u014c\u014d", (byte)45, 65);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[20] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u0521\u051d\u0531\u0530\u0546\u0564\u0564\u0520\u0538\u055f\u0564\u0524\u053d\u054f\u056a\u054a\u052d\u056b\u0540\u0566\u0573\u0545\u0561\u0552\u0555\u055b\u054d\u056d\u057b\u0552\u056a\u0562\u0570\u057f\u0541\u053b\u057a\u055e\u0587\u0566\u0568\u0566\u0577\u0543\u0567\u057f\u0564\u0591\u0560\u0549\u055c\u0596\u0548\u0585\u055c\u055d", (byte)45, 70);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[21] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.B("\u0128\u010f\u0151\u0131\u014b\u0113\u0145\u0110\u0138\u0112\u013d\u0135\u015a\u0132\u0158\u015b\u0131\u0140\u0150\u015a\u0134\u0155\u012c\u012d", (byte)45, 66);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[22] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0518\u0533\u0564\u0540\u0532\u0527\u0530\u051f\u0535\u0528\u054c\u0531", (byte)45, 70);
                    continue block7;
                }
                case 1: {
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u04a1\u0474\u0473\u0483\u048d\u0478\u049a\u04b5\u0491\u04bf\u04ad\u04b7\u0497\u047d\u04a0\u048e\u0480\u04c2\u04bf\u04c5\u04b2\u0492\u0498\u04a1\u04c7\u04c2\u049b\u04ae\u0490\u048c\u04d2\u04bf\u048d\u04a6\u048e\u04d4\u0490\u04af\u0499\u0493\u04c7\u04cc\u04b7\u04a4", (byte)45, 68);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[1] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u047e\u04b1\u0485\u04b7\u04ad\u04aa\u0487\u0495\u04a6\u0488\u04ab\u04a8\u0480\u04ab\u04b8\u04b7\u048e\u04b8\u04a3\u0492\u04c0\u04c8\u048f\u0490", (byte)45, 68);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[2] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u0124\u0143\u0153\u012a\u0121\u0125\u0144\u0141\u0149\u0127\u0152\u0121", (byte)45, 65);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[3] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u053d\u053c\u0535\u0552\u0530\u0545\u0547\u0565\u0561\u0543\u054c\u0540\u0548\u0527\u0547\u056b\u0573\u054f\u0546\u054d\u0571\u052d\u0535\u054a\u0566\u055b\u0544\u0557\u0576\u055e\u053d\u0549\u0540\u055f\u0540\u0570\u0565\u0546\u0544\u0575\u0563\u056a\u0554\u0551", (byte)45, 70);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[4] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u0518\u051c\u0541\u054e\u0530\u0540\u0540\u0567\u0525\u0547\u053b\u0535\u0549\u0558\u056f\u056a\u056d\u054d\u053c\u0542\u054e\u0567\u0541\u054f\u0569\u0531\u0535\u056e\u0557\u054e\u053b\u0549\u054a\u054b\u0578\u0557\u053f\u0566\u0566\u0577\u0555\u0587\u0584\u0543\u0566\u0587\u0570\u0565\u058a\u0551\u054b\u058c\u058d\u0556\u0566\u0566\u055a\u0599\u0572\u0597\u0599\u0572\u056b\u058b\u0599\u0560\u059b\u0597\u059c\u05a0\u0593\u0577\u0593\u0566\u056b\u055f\u057c\u056c\u05ae\u058c\u057f\u0586\u05b1\u05ad\u05a1\u058b\u0580\u05b2\u0572\u0585\u05ab\u05ab\u059d\u05af\u058c\u0589", (byte)45, 70);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[5] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u0108\u010c\u0131\u013e\u0120\u0130\u0130\u0157\u0115\u0137\u012b\u0125\u0139\u0148\u015f\u015a\u015d\u013d\u012c\u0132\u013e\u0158\u0159\u0154\u0166\u0164\u0145\u013a\u0164\u015f\u0168\u013f\u0171\u0166\u0160\u016a\u0165\u0165\u0160\u0170\u0177\u016f\u0151\u013d\u0159\u0169\u0149\u0154\u016b\u016d\u013a\u0155\u016f\u0166\u017f\u0178\u0189\u0158\u0163\u014c\u0148\u016f\u018d\u017d\u017d\u017f\u0174\u014e\u0175\u017f\u0166\u0167\u0171\u0185\u015b\u0153\u018b\u0194\u018f\u0176\u016c\u019b\u0161\u0164\u017a\u016f\u016c\u016d", (byte)45, 66);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[6] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u010b\u010e\u0130\u0134\u0131\u0140\u010a\u0159\u0113\u0128\u0131\u015b\u0148\u0152\u0141\u0150\u0131\u0140\u0162\u011e\u0163\u0165\u012c\u012d", (byte)45, 65);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[7] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.B("\u0111\u010d\u0121\u0120\u0136\u0154\u0154\u0110\u0128\u014f\u0152\u0130\u013b\u014a\u0141\u0137\u011c\u0155\u0159\u0152\u0161\u0135\u0133\u0145\u0165\u0129\u0157\u0142\u0141\u0140\u0139\u0142\u016c\u013c\u0171\u012f\u0166\u0131\u0143\u0175\u017b\u0148\u015d\u0166\u015c\u0159\u014f\u017f\u016e\u0142\u0175\u0166\u0165\u0185\u014c\u014d", (byte)45, 66);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[8] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u051a\u0520\u0564\u054d\u0564\u055f\u0520\u055b\u054a\u0560\u0527\u0556\u0528\u0541\u0543\u0529\u056f\u055d\u055f\u053e\u0536\u0575\u0567\u0530\u057b\u0553\u0571\u053c\u0579\u0539\u053d\u0553", (byte)45, 69);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[9] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u0133\u014d\u0130\u0122\u0156\u012f\u014b\u0124\u0134\u015b\u012c\u014c\u0130\u0111\u0161\u0158\u0132\u013d\u015c\u012f\u011d\u013e\u013a\u0159\u0132\u0143\u0157\u0162\u012c\u0138\u013f\u0172", (byte)45, 65);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[10] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u053b\u0564\u051b\u0522\u0537\u0568\u053b\u053a\u0547\u0540\u0555\u0567\u0556\u055e\u0541\u056f\u0560\u0544\u055f\u0570\u0530\u0560\u0579\u052f\u054b\u0563\u0557\u057c\u0536\u0549\u0537\u055b\u057b\u0558\u057c\u0566\u0584\u0558\u057c\u0563\u0540\u0546\u0558\u0551", (byte)45, 69);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[11] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.E("\u053a\u0521\u0522\u054d\u055a\u0542\u0543\u055c\u0545\u0555\u053a\u0545\u052d\u0557\u0546\u0567\u052c\u0562\u0571\u052b\u0541\u054f\u053c\u053d", (byte)45, 69);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[12] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.A("\u0111\u010d\u0121\u0120\u0136\u0154\u0154\u0110\u0128\u014f\u0152\u0130\u013b\u014a\u0141\u0137\u011c\u0155\u0159\u0152\u0161\u0135\u0162\u0153\u0132\u0156\u0135\u0145\u014a\u015e\u012d\u016f\u014c\u0163\u015c\u015e\u014d\u0176\u016f\u0169\u0133\u016a\u013a\u0159\u0148\u015f\u0132\u015e\u0180\u016d\u0179\u0180\u015c\u0171\u015b\u0141\u015a\u0157\u0176\u0180\u0140\u015d\u0146\u0150", (byte)45, 65);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[13] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0521\u051d\u0531\u0530\u0546\u0564\u0564\u0520\u0538\u055f\u0562\u0540\u054b\u055a\u0551\u0547\u052c\u0565\u0569\u0562\u0571\u0545\u0572\u0563\u0542\u0566\u0545\u0555\u055a\u056e\u053d\u057f\u054b\u0564\u0573\u0575\u0538\u057c\u0568\u0562\u0568\u0578\u055c\u058e\u0569\u057f\u057f\u0547\u0563\u0580\u055c\u0561\u0597\u0570\u0566\u0557\u056a\u0567\u058b\u0568\u057b\u0596\u056d\u057b", (byte)45, 70);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[14] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.B("\u0140\u0133\u014f\u0143\u0141\u0116\u0140\u0115\u0142\u014c\u0151\u014e\u012c\u011f\u014b\u0117\u0162\u0143\u0123\u0158\u014e\u015e\u0146\u0167\u0163\u0155\u0164\u0126\u015c\u0162\u016b\u0130", (byte)45, 66);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[15] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u0521\u051d\u0531\u0530\u0546\u0564\u0564\u0520\u0538\u055f\u0562\u0540\u054b\u055a\u0551\u0547\u052c\u0565\u0569\u0562\u0571\u0546\u0534\u052f\u0537\u0577\u0537\u057b\u0534\u0575\u0548\u0559\u0582\u0578\u0581\u0571\u0566\u0543\u055f\u0548\u0575\u057c\u0544\u0582\u0562\u058d\u056a\u057b\u058f\u0569\u0586\u055d\u0550\u0567\u0565\u0585\u0554\u058b\u0589\u057b\u0567\u057a\u055d\u055a\u0561\u056c\u057b\u055d\u05a3\u0593\u0589\u0595\u0585\u0584\u0596\u0571", (byte)45, 69);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[16] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u0111\u010d\u0121\u0120\u0136\u0154\u0154\u0110\u0128\u014f\u0152\u0130\u013b\u014a\u0141\u0137\u011c\u0155\u0159\u0152\u0161\u0136\u0124\u011f\u0127\u0167\u0127\u016b\u0124\u0165\u0138\u0149\u0140\u0131\u0164\u0162\u0147\u014a\u0168\u0148\u015a\u014f\u0146\u016d\u016c\u015a\u0137\u016b\u0138\u013a\u015a\u0143\u014f\u0176\u0143\u017b\u015b\u017d\u0187\u0146\u018e\u014c\u014a\u0191\u016f\u017c\u014f\u0191\u016b\u0149\u0188\u0188\u0167\u0166\u018e\u0197\u0198\u0196\u0173\u019c\u0198\u0195\u017a\u0192\u019a\u0195\u016c\u016d", (byte)45, 65);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[17] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u014d\u012f\u0110\u0140\u0157\u0133\u0131\u0112\u0124\u0137\u011a\u0125\u0146\u0130\u0159\u0153\u0137\u014c\u011d\u013c\u013e\u0138\u013c\u0120\u0123\u0159\u0160\u0139\u016a\u012c\u012d\u0170\u0130\u012b\u0131\u016a\u012d\u0169\u0162\u0177\u014a\u0166\u013b\u0141", (byte)45, 66);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[18] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0521\u051d\u0531\u0530\u0546\u0564\u0564\u0520\u0538\u055f\u0564\u0524\u053d\u054f\u056a\u054a\u052d\u056b\u0540\u0566\u0573\u0549\u056b\u0579\u054a\u0549\u0577\u0539\u0566\u0569\u054e\u057b\u0570\u055f\u0581\u0584\u0580\u0563\u057b\u0562\u0577\u0562\u0588\u0569\u057e\u0565\u0558\u056e\u054a\u055b\u0554\u057d\u054f\u0578\u0588\u056d\u057a\u057c\u0585\u0592\u056b\u058a\u058c\u055c", (byte)45, 69);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[19] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.B("\u0111\u010d\u0121\u0120\u0136\u0154\u0154\u0110\u0128\u014f\u0154\u0114\u012d\u013f\u015a\u013a\u011d\u015b\u0130\u0156\u0163\u0136\u0157\u0155\u013e\u0148\u0148\u0149\u015c\u0163\u013b\u0152\u014a\u012f\u0167\u0162\u0177\u0142\u0169\u0139\u0134\u0171\u015a\u017e\u0147\u0131\u017a\u0138\u015e\u016c\u0136\u017b\u0152\u015f\u014c\u014d", (byte)45, 66);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[20] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u0111\u010d\u0121\u0120\u0136\u0154\u0154\u0110\u0128\u014f\u0154\u0114\u012d\u013f\u015a\u013a\u011d\u015b\u0130\u0156\u0163\u0135\u0151\u0142\u0145\u014b\u013d\u015d\u016b\u0142\u015a\u0152\u0160\u016f\u0131\u012b\u016a\u014e\u0177\u0156\u0158\u0156\u0166\u0136\u0154\u0158\u0159\u013e\u0171\u015c\u013c\u0180\u015b\u017d\u015a\u0140\u0183\u016a\u0179\u0167\u0140\u0169\u0164\u015a", (byte)45, 65);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[21] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u0538\u051f\u0561\u0541\u055b\u0523\u0555\u0520\u0548\u0522\u0554\u053c\u0542\u054f\u054c\u053e\u0551\u056f\u0542\u054e\u0566\u054f\u053c\u053d", (byte)45, 69);
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[22] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.D("\u04ae\u0485\u04a1\u04a1\u0477\u0487\u0486\u0498\u04ad\u04b8\u0479\u049d\u048e\u0478\u04a3\u0482\u04c6\u0481\u04c1\u0485\u04b5\u04a2\u048f\u0490", (byte)45, 68);
                    continue block7;
                }
                case 2: {
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u051b\u0515\u0540\u0541\u0536\u0564\u0528\u0540\u0540\u0564\u0568\u0558\u0561\u0569\u054e\u053f\u0528\u0541\u0531\u0564\u0563\u0537\u0547\u0570\u0569\u054a\u0577\u0534\u0535\u0575\u056d\u053b", (byte)45, 70);
                    continue block7;
                }
                case 4: {
                    \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.A("\u0128\u0146\u011c\u0121\u0156\u0144\u0147\u0141\u0159\u0155\u014e\u0139\u014d\u0134\u0133\u014c\u012f\u014c\u0144\u0121\u0151\u0155\u012c\u012d", (byte)45, 65);
                }
            }
        }
    }

    public static Class<?> a(Callable<Class<?>> callable, String ... stringArray) {
        Class<?> clazz = \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.a(stringArray);
        if (clazz != null) {
            return clazz;
        }
        try {
            return callable.call();
        }
        catch (Exception exception) {
            throw new RuntimeException((String)\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e80", (int)(a & b), (long)d) + (stringArray.length > 0 ? (String)\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e83", (int)e, (long)(f ^ g)) + stringArray[h] : Integer.valueOf(i)) + (String)\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.c("\u3e86", (int)j, (long)k), exception);
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u052a\u054c\u054e\u052e\u0552\u0571\u0569\u057f\u056b\u053a\u0578\u056e\u057c\u0576\u053f\u0564\u0586\u0585\u057d\u0583\u057d\u0552", (byte)70, 69), \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u04ea\u04f7\u04f6\u04b9\u04f9\u04f5\u04f0\u04f9\u0504\u04f3\u04c0\u04fe\u0502\u04fb\u04fe\u0504\u04c6\u084e\u084d\u0843\u085d\u083f\u0830\u0854\u0863\u0867\u04db", (byte)70, 67) + string + \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u0145", (byte)70, 65) + methodType.toString(), exception);
        }
    }
}

