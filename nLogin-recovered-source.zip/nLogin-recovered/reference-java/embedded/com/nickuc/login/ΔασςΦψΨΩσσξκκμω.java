/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03a0\u03b6\u03a3\u03a8\u03b1\u03a9\u03c8\u03bf\u03b7\u03b9\u03b7\u0393\u0393;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Generated;

public class \u0394\u03b1\u03c3\u03c2\u03a6\u03c8\u03a8\u03a9\u03c3\u03c3\u03be\u03ba\u03ba\u03bc\u03c9
implements \u03a0\u03b6\u03a3\u03a8\u03b1\u03a9\u03c8\u03bf\u03b7\u03b9\u03b7\u0393\u0393 {
    private final Logger a;

    @Override
    public void a(String string, Throwable throwable) {
        this.a.log(Level.WARNING, string, throwable);
    }

    @Override
    public void s(String string) {
        this.a.severe(string);
    }

    @Generated
    public \u0394\u03b1\u03c3\u03c2\u03a6\u03c8\u03a8\u03a9\u03c3\u03c3\u03be\u03ba\u03ba\u03bc\u03c9(Logger logger) {
        this.a = logger;
    }

    @Override
    public void b(String string, Throwable throwable) {
        this.a.log(Level.SEVERE, string, throwable);
    }

    @Override
    public void q(String string) {
        this.a.info(string);
    }

    @Override
    public void r(String string) {
        this.a.warning(string);
    }

    @Override
    public <T> T c() {
        return (T)this.a;
    }
}

