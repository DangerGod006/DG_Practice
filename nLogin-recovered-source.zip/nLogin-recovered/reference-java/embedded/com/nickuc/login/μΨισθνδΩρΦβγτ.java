/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b9\u0393\u03b1\u03a9\u03bb\u03c2\u03b7\u03bd\u03b1\u03a9\u03bb\u03b3\u03b4\u0393;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5;
import com.nickuc.login.\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb;
import com.nickuc.login.\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4
extends \u03b9\u0393\u03b1\u03a9\u03bb\u03c2\u03b7\u03bd\u03b1\u03a9\u03bb\u03b3\u03b4\u0393 {
    private static int s;
    private static int l;
    private static int h;
    private static int i;
    private static int g;
    private static String[] b;
    private static String[] a;
    private static int r;
    private static int f;
    private static int p;
    private static int e;
    private static long c;
    private static long n;
    private static int j;
    private static long d;
    private static int c;
    private static long k;
    private static long o;
    private static int m;
    private static int t;
    private static int u;
    private static int q;

    static {
        c = Integer.reverse(0);
        d = Long.reverse(-5981226714693520684L);
        e = Integer.reverse(0);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Integer.reverse(0);
        h = Integer.reverse(0);
        i = (0x800000 >>> 181 | 0x800000 << -181) & 0xFFFFFFFF;
        j = Integer.reverse(Integer.MIN_VALUE);
        k = Long.reverse(-5981226714693520684L);
        l = 8192 >>> 45 | 8192 << ~45 + 1;
        m = Integer.reverse(0x40000000);
        n = Long.reverse(-1946001448569556268L);
        o = Long.reverse(0x4800000000000000L);
        p = 131072 >>> 80 | 131072 << -80;
        q = Integer.reverse(-1);
        r = (3072 >>> 10 | 3072 << -10) & 0xFFFFFFFF;
        s = Integer.reverse(-1);
        t = Integer.reverse(-1073741824);
        u = Integer.reverse(-1073741824);
        a = new String[t];
        b = new String[u];
        \u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4.b();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void b(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String[] stringArray) {
        if (!(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2 instanceof \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)) {
            \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.z, new Object[h]);
            return;
        }
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = (\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2;
        \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = this.a.a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
        if (\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.d(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.e) != false) {
            return;
        }
        \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5 \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52 = \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a();
        if (stringArray.length < i) {
            \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52.a((String)\u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4.c("\u3e80", (int)j, (long)k));
            return;
        }
        String string = stringArray[l];
        if (string.equals(\u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4.c("\u3e83", (int)m, (long)(n ^ o)))) {
            int n = \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.a(stringArray[p], (Integer)q);
            int n2 = \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.a(stringArray[r], (Integer)s);
            Object object = \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.n;
            synchronized (object) {
                \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2 \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b22 = (\u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b2)\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.d(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.n);
                if (\u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b22 == null) {
                    return;
                }
                \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7 \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72 = \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.a(n2);
                if (\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72 == null) {
                    return;
                }
                \u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b \u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b2 = \u03ba\u03bc\u03a8\u03c7\u03a9\u03c1\u03b5\u03c6\u03c0\u03b22.b();
                if (\u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b2.a().v() != n) {
                    return;
                }
                \u03b5\u03b2\u03bf\u03c2\u03bf\u03b7\u03a6\u03c2\u03c8\u03bc\u03bd\u03c2\u03c9\u03be\u039b2.a((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)this.a, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52, \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72);
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x12L;
        l ^= 0xF2DF88FAC8D28A5BL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(26 + 42), (byte)(48 + 21), 83, (byte)(10 + 37), (byte)(57 + 10), (byte)(35 + 31), (byte)(48 + 19), (byte)(4 + 43), (byte)(6 + 74), (byte)(25 + 50), (byte)(2 + 65), (byte)(20 + 63), (byte)(31 + 22), (byte)(69 + 11), (byte)(63 + 34), (byte)(70 + 30), 100, (byte)(33 + 72), (byte)(84 + 26), (byte)(69 + 34)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(11 + 58), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u0481\u048e\u048d\u0450\u0490\u048c\u0487\u0490\u049b\u048a\u0457\u0495\u0499\u0492\u0495\u049b\u045d\u07eb\u07d8\u07ea\u07f5\u07eb\u07f1\u07e9\u07df\u07f8\u07de\u07eb\u07ed\u07ff", (byte)35, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u013b\u015d\u015f\u013f\u0163\u0182\u017a\u0190\u017c\u014b\u0189\u017f\u018d\u0187\u0150\u0175\u0197\u0196\u018e\u0194\u018e\u0163", (byte)74, 66), \u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u0176\u0183\u0182\u0145\u0185\u0181\u017c\u0185\u0190\u017f\u014c\u018a\u018e\u0187\u018a\u0190\u0152\u04e0\u04cd\u04df\u04ea\u04e0\u04e6\u04de\u04d4\u04ed\u04d3\u04e0\u04e2\u04f4\u016b", (byte)74, 66) + string + \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u04cd", (byte)74, 68) + methodType.toString(), exception);
        }
    }

    public \u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, (String)\u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4.c("\u3e80", (int)c, (long)d), null, e != 0, f != 0, new String[g]);
    }

    private static void b() {
        int n;
        c = 3120354301723442983L;
        long l = c ^ 0xF2DF88FAC8D28A5BL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(22 + 46), (byte)(34 + 35), (byte)(58 + 25), (byte)(19 + 28), (byte)(62 + 5), (byte)(28 + 38), (byte)(3 + 64), (byte)(9 + 38), (byte)(55 + 25), (byte)(63 + 12), (byte)(57 + 10), (byte)(17 + 66), (byte)(28 + 25), (byte)(62 + 18), (byte)(92 + 5), (byte)(8 + 92), (byte)(40 + 60), (byte)(49 + 56), 110, 103}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(41 + 27), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.C("\u0514\u04de\u051f\u04f0\u04e0\u0507\u0517\u04e0\u04db\u04e4\u0507\u04f0", (byte)81, 67);
                    \u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4.b[1] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u018e\u0172\u0175\u0192\u018e\u0168\u0168\u0171\u017f\u018e\u0197\u015c\u0199\u019d\u019c\u017a\u0176\u01a4\u019d\u0165\u019e\u017f\u0189\u01a3\u01ab\u01af\u0186\u016b\u0193\u0191\u0174\u0185\u01b1\u01ab\u01ac\u01b3\u01a8\u01b5\u01a9\u01bf\u0182\u018c\u01b5\u01c6\u01c4\u019f\u0193\u01c3\u019e\u019f\u01ba\u01c5\u019e\u01cb\u01bf\u01a6\u0189\u0185\u01be\u01a8\u01c4\u01c2\u01c5\u01d4\u01d7\u0191\u01dd\u019a\u0199\u01ce\u01ad\u01c9\u019c\u01de\u01b8\u019d\u01b9\u01a6\u01a4\u01e2\u01c2\u01a4\u01c3\u01eb\u01e5\u01c7\u01b4\u01b5", (byte)81, 66);
                    \u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4.b[2] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u0544\u0582\u0545\u0555\u053c\u0553\u0563\u0586\u0580\u058d\u0561\u056e\u0588\u0587\u057d\u0586\u0567\u0565\u0589\u0565\u057b\u0563\u0560\u0561", (byte)81, 70);
                    continue block7;
                }
                case 1: {
                    \u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u018f\u018b\u0197\u0156\u019b\u015e\u015d\u0195\u017a\u015a\u0174\u0169", (byte)81, 66);
                    \u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4.b[1] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u018e\u0172\u0175\u0192\u018e\u0168\u0168\u0171\u017f\u018e\u0197\u015c\u0199\u019d\u019c\u017a\u0176\u01a4\u019d\u0165\u019e\u017f\u0189\u01a3\u01ab\u01af\u0186\u016b\u0193\u0191\u0174\u0185\u01b1\u01ab\u01ac\u01b3\u01a8\u01b5\u01a9\u01bf\u0182\u018c\u01b5\u01c6\u01c4\u019f\u0193\u01c3\u019e\u019f\u01ba\u01c5\u019e\u01cb\u01bf\u01a6\u0189\u0185\u01be\u01a8\u01c4\u01c2\u01c5\u01d4\u01d7\u0191\u01dd\u019a\u0199\u01ce\u01ad\u01c9\u019c\u01de\u01ba\u01b6\u01c3\u01b9\u01d4\u01e9\u01a8\u01bd\u01a6\u01e7\u01a9\u01a5\u01b8\u01e2\u01eb\u01bf\u01f5\u01ef\u01e4\u01ee\u01e5\u01b2", (byte)81, 66);
                    \u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4.b[2] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u0544\u0582\u0545\u0555\u053c\u0553\u0563\u0586\u0580\u058d\u0562\u057a\u056d\u0567\u058b\u0590\u0577\u057f\u058c\u0595\u0598\u0573\u056e\u0596\u0558\u05a0\u057b\u0561\u057c\u0578\u056f\u0575", (byte)81, 69);
                    continue block7;
                }
                case 2: {
                    \u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u0545\u0551\u0540\u0555\u0549\u0581\u058a\u0561\u0556\u057c\u054f\u0543\u054d\u0586\u0581\u0565\u0592\u056d\u058f\u0585\u0596\u058e\u0568\u058e\u057d\u0575\u0560\u056a\u056a\u0593\u059e\u059a", (byte)81, 69);
                    continue block7;
                }
                case 4: {
                    \u03bc\u03a8\u03b9\u03c3\u03b8\u03bd\u03b4\u03a9\u03c1\u03a6\u03b2\u03b3\u03c4.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u0159\u0168\u017d\u0192\u017b\u017c\u0195\u0170\u0190\u017c\u0196\u0169", (byte)81, 65);
                }
            }
        }
    }
}

