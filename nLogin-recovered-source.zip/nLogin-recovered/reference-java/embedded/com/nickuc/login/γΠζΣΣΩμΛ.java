/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b
extends Enum<\u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b> {
    public static final /* enum */ \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b d;
    public static final /* enum */ \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b e;
    public static final /* enum */ \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b f;
    private static final /* synthetic */ \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b[] a;
    private static String[] a;
    private static String[] b;
    private static long c;
    private static int a;
    private static int b;
    private static int c;
    private static int d;
    private static int e;
    private static int f;
    private static int g;
    private static long h;
    private static long i;
    private static int j;
    private static int k;
    private static long l;
    private static long m;
    private static int n;
    private static int o;
    private static long p;
    private static int q;

    public static \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b valueOf(String string) {
        return Enum.valueOf(\u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.class, string);
    }

    static {
        a = 24576 >>> 173 | 24576 << ~173 + 1;
        b = (0 >>> 246 | 0 << ~246 + 1) & 0xFFFFFFFF;
        c = (131072 >>> 17 | 131072 << ~17 + 1) & 0xFFFFFFFF;
        d = Integer.reverse(0x40000000);
        e = Integer.reverse(-1073741824);
        f = Integer.reverse(-1073741824);
        g = Integer.reverse(0);
        h = Long.reverse(-1017467014675344328L);
        i = Long.reverse(0x4400000000000000L);
        j = Integer.reverse(0);
        k = Integer.reverse(Integer.MIN_VALUE);
        l = Long.reverse(-1017467014675344328L);
        m = Long.reverse(0x4400000000000000L);
        n = (64 >>> 166 | 64 << -166) & 0xFFFFFFFF;
        o = Integer.reverse(0x40000000);
        p = Long.reverse(-5340922656951020488L);
        q = 2048 >>> 74 | 2048 << -74;
        a = new String[e];
        b = new String[f];
        \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.b();
        d = new \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b();
        e = new \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b();
        f = new \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b();
        a = \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.a();
    }

    private static void b() {
        int n;
        c = 2029603666974771087L;
        long l = c ^ 0xD41836EA65B69974L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(26 + 42), (byte)(24 + 45), (byte)(76 + 7), (byte)(38 + 9), (byte)(61 + 6), (byte)(37 + 29), (byte)(39 + 28), (byte)(33 + 14), (byte)(75 + 5), (byte)(10 + 65), (byte)(30 + 37), (byte)(62 + 21), 53, (byte)(27 + 53), (byte)(85 + 12), (byte)(9 + 91), (byte)(24 + 76), (byte)(40 + 65), (byte)(91 + 19), (byte)(60 + 43)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(64 + 5), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.B("\u00f1\u00be\u0101\u00d9\u0105\u00d9\u00c8\u00e8\u00e1\u00db\u00ee\u00d3", (byte)6, 66);
                    \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.b[1] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u043b\u040a\u043a\u03f9\u042f\u0434\u03fc\u043b\u0439\u0405\u0439\u0428\u0439\u0445\u0445\u0441\u0446\u042e\u0433\u041c\u040d\u042d\u041a\u041b", (byte)6, 67);
                    \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.b[2] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0533\u0514\u0511\u050d\u0531\u04f6\u0530\u053d\u04fc\u0530\u053b\u050a", (byte)6, 70);
                    continue block7;
                }
                case 1: {
                    \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u0428\u040d\u0436\u0423\u041b\u0402\u0427\u0421\u0443\u0446\u0424\u0428\u041a\u044e\u0426\u040d\u042d\u0428\u042e\u042a\u0425\u041d\u041a\u041b", (byte)6, 68);
                    \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.b[1] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u0536\u0505\u0535\u04f4\u052a\u052f\u04f7\u0536\u0534\u0500\u0536\u0521\u0525\u053f\u0541\u051a\u0533\u053e\u050b\u0521\u051c\u054e\u0515\u0516", (byte)6, 70);
                    \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.b[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u0433\u040c\u0415\u0431\u0412\u0430\u041e\u0415\u0401\u0438\u0439\u0447\u0408\u0405\u0421\u041c\u043e\u044f\u044f\u041e\u0446\u042d\u041a\u041b", (byte)6, 68);
                    continue block7;
                }
                case 2: {
                    \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.A("\u00f9\u00d1\u00fd\u00c0\u00fd\u00f2\u00e8\u00dd\u00f6\u00c8\u0108\u00e3\u0107\u00ed\u00ed\u00f0\u0114\u00e9\u0111\u0107\u00f4\u0107\u00de\u00df", (byte)6, 65);
                    continue block7;
                }
                case 4: {
                    \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.D("\u0412\u03fa\u0431\u0422\u0436\u0438\u03fc\u041a\u0433\u0423\u0415\u03fd\u0417\u0428\u043e\u0439\u0408\u0423\u041e\u042e\u040e\u0453\u041a\u041b", (byte)6, 68);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x22L;
        l ^= 0xD41836EA65B69974L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(28 + 40), (byte)(27 + 42), (byte)(61 + 22), (byte)(32 + 15), (byte)(55 + 12), (byte)(15 + 51), (byte)(47 + 20), (byte)(20 + 27), (byte)(12 + 68), 75, (byte)(60 + 7), (byte)(79 + 4), (byte)(3 + 50), (byte)(65 + 15), (byte)(58 + 39), (byte)(16 + 84), (byte)(32 + 68), (byte)(44 + 61), (byte)(48 + 62), (byte)(91 + 12)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(72 + 11)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0571\u057e\u057d\u0540\u0580\u057c\u0577\u0580\u058b\u057a\u0547\u0585\u0589\u0582\u0585\u058b\u054d\u08d2\u08c0\u08d7\u08c5\u08c6\u08cd\u08e1\u08c1", (byte)82, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static /* synthetic */ \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b[] a() {
        \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b[] \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039bArray = new \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b[a];
        \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039bArray[\u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.b] = d;
        \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039bArray[\u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.c] = e;
        \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039bArray[\u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.d] = f;
        return \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039bArray;
    }

    public static \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b[] values() {
        return (\u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b[])a.clone();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u00cf\u00f1\u00f3\u00d3\u00f7\u0116\u010e\u0124\u0110\u00df\u011d\u0113\u0121\u011b\u00e4\u0109\u012b\u012a\u0122\u0128\u0122\u00f7", (byte)20, 65), \u03b3\u03a0\u03b6\u03a3\u03a3\u03a9\u03bc\u039b.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u010a\u0117\u0116\u00d9\u0119\u0115\u0110\u0119\u0124\u0113\u00e0\u011e\u0122\u011b\u011e\u0124\u00e6\u046b\u0459\u0470\u045e\u045f\u0466\u047a\u045a\u00fa", (byte)20, 66) + string + \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.B("\u00e1", (byte)20, 66) + methodType.toString(), exception);
        }
    }
}

