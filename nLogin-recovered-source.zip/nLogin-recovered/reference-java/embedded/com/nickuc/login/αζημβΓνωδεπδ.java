/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class \u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4
extends \u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394 {
    private static int f = 0 >>> 53 | 0 << ~53 + 1;
    private static int bc;
    private static int am;
    private static long ac;
    private static int al;
    private static long aq;
    private static String[] g;
    private static long ad;
    private static long s;
    private static String[] h;
    private static int ax;
    private static long az;
    private static int be;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u041c\u043e\u0440\u0420\u0444\u0463\u045b\u0471\u045d\u042c\u046a\u0460\u046e\u0468\u0431\u0456\u0478\u0477\u046f\u0475\u046f\u0444", (byte)21, 67), \u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0534\u0541\u0540\u0503\u0543\u053f\u053a\u0543\u054e\u053d\u050a\u0548\u054c\u0545\u0548\u054e\u0510\u0893\u0899\u089b\u08a1\u0898\u087a\u08a5\u08b2\u089e\u08a0\u08ac\u08a1\u0528", (byte)21, 70) + string + \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.B("\u00e3", (byte)21, 66) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x67L;
        l ^= 0x93282FF8E31B4B07L;
        if (g[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(28 + 40), (byte)(27 + 42), 83, (byte)(4 + 43), (byte)(39 + 28), (byte)(57 + 9), (byte)(40 + 27), (byte)(12 + 35), (byte)(78 + 2), (byte)(2 + 73), (byte)(58 + 9), (byte)(38 + 45), (byte)(13 + 40), 80, (byte)(48 + 49), (byte)(78 + 22), (byte)(68 + 32), (byte)(39 + 66), (byte)(25 + 85), (byte)(3 + 100)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(26 + 42), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u00e6\u00f3\u00f2\u00b5\u00f5\u00f1\u00ec\u00f5\u0100\u00ef\u00bc\u00fa\u00fe\u00f7\u00fa\u0100\u00c2\u0445\u044b\u044d\u0453\u044a\u042c\u0457\u0464\u0450\u0452\u045e\u0453", (byte)2, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4.g[n] = new String(cipher.doFinal(Base64.getDecoder().decode(h[n])), StandardCharsets.UTF_8);
        }
        return g[n];
    }

    static {
        ac = Long.reverse(-1587722565921137733L);
        ad = Long.reverse(-1873497444986126336L);
        al = Integer.reverse(Integer.MIN_VALUE);
        am = -1 >>> 158 | -1 << ~158 + 1;
        aq = Long.reverse(1150466007520123835L);
        ax = 0x400000 >>> 53 | 0x400000 << -53;
        az = Long.reverse(1150466007520123835L);
        bc = Integer.reverse(-1073741824);
        be = 0x30000000 >>> 220 | 0x30000000 << ~220 + 1;
        g = new String[bc];
        h = new String[be];
        \u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4.b();
    }

    public \u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4.z, (String)\u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4.c("\u3e80", (int)f, (long)(ac ^ ad)), (String)\u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4.c("\u3e83", (int)(al & am), (long)aq), (String)\u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4.c("\u3e86", (int)ax, (long)az), null);
    }

    private static void b() {
        int n;
        s = -2461104974275088489L;
        long l = s ^ 0x93282FF8E31B4B07L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(22 + 47), (byte)(75 + 8), (byte)(32 + 15), (byte)(40 + 27), (byte)(55 + 11), (byte)(65 + 2), (byte)(36 + 11), (byte)(54 + 26), (byte)(55 + 20), (byte)(56 + 11), (byte)(77 + 6), (byte)(18 + 35), (byte)(54 + 26), (byte)(30 + 67), (byte)(19 + 81), (byte)(13 + 87), (byte)(22 + 83), (byte)(88 + 22), 103}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(33 + 50)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4.h[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u053d\u0579\u055c\u0564\u0561\u0557\u057e\u0543\u0563\u0577\u0559\u0563\u055c\u054b\u0542\u057f\u0564\u0593\u056b\u0572\u0570\u055f\u055c\u055d", (byte)77, 69);
                    \u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4.h[1] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.E("\u0559\u0583\u054e\u057d\u0553\u0556\u057a\u0547\u0559\u0559\u0558\u0551", (byte)77, 69);
                    \u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4.h[2] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u0183\u0171\u014e\u018f\u014c\u0150\u0158\u0156\u0176\u015a\u019a\u0161", (byte)77, 66);
                    continue block7;
                }
                case 1: {
                    \u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4.h[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u04d0\u050c\u04ef\u04f7\u04f4\u04ea\u0511\u04d6\u04f6\u050a\u04ee\u0520\u0509\u04df\u04f2\u0523\u0505\u0503\u04f0\u04fd\u0513\u0502\u04ef\u04f0", (byte)77, 68);
                    \u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4.h[1] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u04ea\u04ce\u04df\u04f1\u04f0\u04f9\u050b\u04d7\u050b\u051f\u04ff\u04e4", (byte)77, 67);
                    \u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4.h[2] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u018e\u0153\u017f\u0153\u0171\u016e\u0197\u0176\u0168\u0174\u018e\u0166\u0169\u019b\u017e\u015e\u017c\u01a1\u019e\u0165\u0195\u0195\u016c\u016d", (byte)77, 65);
                    continue block7;
                }
                case 2: {
                    \u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4.h[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u056a\u0540\u0576\u0553\u0558\u0577\u0572\u0545\u0566\u058c\u0556\u0548\u0562\u057f\u0588\u0547\u0586\u054b\u0586\u0589\u0593\u0595\u055c\u055d", (byte)77, 70);
                    continue block7;
                }
                case 4: {
                    \u03b1\u03b6\u03b7\u03bc\u03b2\u0393\u03bd\u03c9\u03b4\u03b5\u03c0\u03b4.h[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u015a\u0163\u014f\u0194\u0164\u0180\u016e\u0171\u0188\u016d\u016c\u0161", (byte)77, 65);
                }
            }
        }
    }
}

