/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6 {
    private static int h;
    private static long e;
    private static long c;
    private final int Y;
    private static long i;
    private static long j;
    private static String[] a;
    private static int n;
    private static long m;
    private static long g;
    private final byte[] c;
    private static long l;
    private static int k;
    private static int c;
    private static String[] b;
    private static int d;
    private static int b;
    private static int a;
    private static int o;
    private static int f;
    private final Throwable b;

    @Generated
    public \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6(byte[] byArray, int n, Throwable throwable) {
        this.c = byArray;
        this.Y = n;
        this.b = throwable;
    }

    private static void b() {
        int n;
        c = -4109369689060693553L;
        long l = c ^ 0xCC9AC477FEB9266BL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(43 + 25), (byte)(8 + 61), (byte)(67 + 16), (byte)(23 + 24), (byte)(29 + 38), (byte)(13 + 53), (byte)(59 + 8), 47, (byte)(69 + 11), (byte)(61 + 14), (byte)(2 + 65), (byte)(69 + 14), (byte)(45 + 8), (byte)(75 + 5), (byte)(69 + 28), (byte)(2 + 98), (byte)(7 + 93), (byte)(78 + 27), 110, (byte)(10 + 93)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(61 + 7), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u0559\u0555\u057a\u0544\u0542\u055e\u0561\u0558\u056a\u0546\u056c\u056f\u0581\u0572\u057d\u0588\u0583\u0551\u055f\u0594\u0562\u0578\u058b\u0564\u059c\u0574\u056e\u0591\u056b\u0579\u0558\u055d", (byte)114, 67);
                    \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.b[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.C("\u0540\u053f\u0564\u0560\u053f\u057b\u057a\u056b\u058b\u058a\u0564\u0549\u0588\u0569\u056b\u0566\u0587\u0561\u058c\u056e\u0554\u0571\u055e\u055f", (byte)114, 67);
                    \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.b[2] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u057a\u0583\u057e\u0597\u0580\u0584\u05a8\u0567\u059b\u05a6\u057f\u0593\u05ae\u0582\u05ae\u0573\u0581\u0592\u0598\u0578\u0587\u05ba\u0581\u0582", (byte)114, 70);
                    \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.b[3] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u0540\u0544\u0586\u0564\u0541\u0579\u0587\u0546\u0566\u0545\u0562\u0553", (byte)114, 67);
                    continue block7;
                }
                case 1: {
                    \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u0559\u0555\u057a\u0544\u0542\u055e\u0561\u0558\u056a\u0546\u056c\u056f\u0581\u0572\u057d\u0588\u0583\u0551\u055f\u0594\u0562\u0586\u059a\u058f\u058f\u0573\u059f\u0599\u05a0\u0569\u059f\u057c", (byte)114, 67);
                    \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.b[1] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.B("\u0198\u0197\u01bc\u01b8\u0197\u01d3\u01d2\u01c3\u01e3\u01e2\u01bd\u01e1\u01d7\u01c0\u01a5\u01e8\u01b6\u01b7\u01c2\u01ba\u01bc\u01cb\u01c1\u01f3\u01f3\u01c0\u01c3\u01d1\u01ca\u01f1\u01cd\u01ca", (byte)114, 66);
                    \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.b[2] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.C("\u0557\u0560\u055b\u0574\u055d\u0561\u0585\u0544\u0578\u0583\u055a\u055a\u0569\u0591\u058d\u0584\u0588\u0555\u054e\u0577\u056b\u056e\u0557\u0574\u0584\u0568\u0554\u0580\u0571\u056c\u0593\u0594", (byte)114, 67);
                    \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.b[3] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u0585\u056f\u0579\u0554\u055c\u0548\u057f\u0544\u057b\u0547\u0580\u0553", (byte)114, 68);
                    continue block7;
                }
                case 2: {
                    \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.D("\u0576\u0564\u0562\u0558\u0559\u053f\u0545\u057a\u055f\u0580\u055e\u0541\u055d\u0571\u054c\u0574\u058c\u058e\u0567\u0569\u0550\u0581\u057a\u0590\u0594\u0577\u0557\u058f\u056a\u055f\u055e\u0578", (byte)114, 68);
                    continue block7;
                }
                case 4: {
                    \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.b[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u01da\u019a\u0194\u01c7\u01d0\u01e0\u01c3\u01ab\u01d4\u01d8\u01a1\u01ab", (byte)114, 65);
                }
            }
        }
    }

    @Generated
    public byte[] c() {
        return this.c;
    }

    public boolean ag() {
        return (this.Y != 0 ? a : b) != 0;
    }

    @Generated
    public int p() {
        return this.Y;
    }

    @Generated
    public String toString() {
        return (String)\u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.c("\u3e80", (int)(c & d), (long)e) + Arrays.toString(this.c()) + (String)\u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.c("\u3e83", (int)f, (long)g) + this.p() + (String)\u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.c("\u3e86", (int)h, (long)(i ^ j)) + this.a() + (String)\u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.c("\u3e89", (int)k, (long)(l ^ m));
    }

    @Generated
    public Throwable a() {
        return this.b;
    }

    public String V() {
        if (this.c == null) {
            return null;
        }
        return new String(this.c, StandardCharsets.UTF_8);
    }

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = Integer.reverse(0);
        c = (0 >>> 35 | 0 << ~35 + 1) & 0xFFFFFFFF;
        d = Integer.reverse(-1);
        e = Long.reverse(546592597593366371L);
        f = 0x400000 >>> 86 | 0x400000 << ~86 + 1;
        g = Long.reverse(546592597593366371L);
        h = Integer.reverse(0x40000000);
        i = Long.reverse(-894559283165192349L);
        j = Long.reverse(-864691128455135232L);
        k = 3 >>> 64 | 3 << ~64 + 1;
        l = Long.reverse(-894559283165192349L);
        m = Long.reverse(-864691128455135232L);
        n = Integer.reverse(0x20000000);
        o = Integer.reverse(0x20000000);
        a = new String[n];
        b = new String[o];
        \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.b();
    }

    public \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6(byte[] byArray, int n) {
        this(byArray, n, null);
    }

    private static String a(int n, long l) {
        l ^= 0x2FL;
        l ^= 0xCC9AC477FEB9266BL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(4 + 64), (byte)(47 + 22), (byte)(64 + 19), 47, (byte)(32 + 35), (byte)(23 + 43), (byte)(11 + 56), (byte)(19 + 28), (byte)(61 + 19), 75, (byte)(38 + 29), (byte)(47 + 36), (byte)(15 + 38), (byte)(4 + 76), (byte)(85 + 12), (byte)(48 + 52), (byte)(56 + 44), (byte)(67 + 38), (byte)(93 + 17), (byte)(78 + 25)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(19 + 49), (byte)(66 + 3), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u0563\u0570\u056f\u0532\u0572\u056e\u0569\u0572\u057d\u056c\u0539\u0577\u057b\u0574\u0577\u057d\u053f\u08ce\u08c7\u08d2\u08d2\u08c8\u08cd\u08cd\u08c0\u08da\u08ad\u08c1", (byte)68, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u0524\u0546\u0548\u0528\u054c\u056b\u0563\u0579\u0565\u0534\u0572\u0568\u0576\u0570\u0539\u055e\u0580\u057f\u0577\u057d\u0577\u054c", (byte)109, 67), \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u058c\u0599\u0598\u055b\u059b\u0597\u0592\u059b\u05a6\u0595\u0562\u05a0\u05a4\u059d\u05a0\u05a6\u0568\u08f7\u08f0\u08fb\u08fb\u08f1\u08f6\u08f6\u08e9\u0903\u08d6\u08ea\u057f", (byte)109, 70) + string + \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u0563", (byte)109, 70) + methodType.toString(), exception);
        }
    }
}

