/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.geysermc.floodgate.api.FloodgateApi
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u0394\u03a8\u03bc\u03c9\u03c7\u03c9\u03a6\u03bb\u03a6\u03c0\u03a9\u03c5;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2;
import com.nickuc.login.\u03b2\u03b9\u03a0\u03c1\u03c8\u03bc\u03c0\u0394\u03b2\u03a0\u03b4;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03b9\u03a0\u03b4\u03c6\u03bc\u03b7\u03c9\u03b7;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c3\u0394\u03c5\u03b3\u03ba\u03c2\u03bd\u0393\u03bb\u03be;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u039b\u039b\u03b2\u03b7\u03b5\u03b4\u03bf\u03b5;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03c2\u03b4\u03c9\u03bb\u03bb\u03bd\u03b4\u03b4;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.io.File;
import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Collections;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.geysermc.floodgate.api.FloodgateApi;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb
implements \u03c7\u039b\u039b\u03b2\u03b7\u03b5\u03b4\u03bf\u03b5 {
    private static int l;
    private static long ag;
    private static int k;
    private static int ab;
    private static long af;
    private static long c;
    private static int m;
    private static int n;
    private static long g;
    private static int am;
    private static long ad;
    private static int aa;
    private static int p;
    private static int i;
    private static int e;
    private static long x;
    private static long v;
    private static int f;
    private static int an;
    private static final int s;
    private static int r;
    private static int ar;
    private static int z;
    public static \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb a;
    private static int a;
    private static long s;
    private static int ap;
    private static String[] b;
    private static long y;
    private static int aj;
    private static long j;
    private static int aq;
    private static String[] a;
    private static int t;
    private static int h;
    private static long ao;
    private static int ah;
    private static long al;
    private static int ak;
    private static int ae;
    private static long d;
    private static int o;
    private static int w;
    private static long q;
    private static long ai;
    private static int ac;
    private static int u;
    private static long b;

    @Override
    public void a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03c3\u0394\u03c5\u03b3\u03ba\u03c2\u03bd\u0393\u03bb\u03be \u03c3\u0394\u03c5\u03b3\u03ba\u03c2\u03bd\u0393\u03bb\u03be2, \u03a8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2 \u03c8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2) {
        String string;
        if (\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.b().j((String)\u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.c("\u3e80", (int)(e & f), (long)g)) && (string = FloodgateApi.getInstance().getPlayerPrefix()) != null && string.isEmpty()) {
            \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.d(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6);
        }
        \u03c3\u0394\u03c5\u03b3\u03ba\u03c2\u03bd\u0393\u03bb\u03be2.a(h);
        \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.c("\u3e83", (int)i, (long)j) + this.q(), new Object[k]);
    }

    @Override
    public boolean I() {
        return n != 0;
    }

    private static void b() {
        int n;
        c = 6277739954227239608L;
        long l = c ^ 0xAB68EA987995FF6BL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(30 + 39), (byte)(19 + 64), 47, (byte)(49 + 18), (byte)(39 + 27), (byte)(34 + 33), (byte)(6 + 41), (byte)(11 + 69), (byte)(40 + 35), (byte)(60 + 7), (byte)(35 + 48), (byte)(25 + 28), (byte)(64 + 16), (byte)(67 + 30), (byte)(89 + 11), (byte)(41 + 59), (byte)(41 + 64), (byte)(100 + 10), (byte)(55 + 48)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(37 + 31), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.A("\u0102\u00ef\u0108\u0108\u0123\u00ef\u010b\u0108\u0127\u00f2\u0102\u00f3\u0115\u013b\u010b\u0111\u0110\u0130\u00fe\u013b\u0114\u011f\u0119\u011a\u00fe\u0120\u0138\u0126\u0107\u0113\u0127\u0126\u0149\u0145\u010b\u0120\u011f\u014a\u0143\u012b\u0125\u0150\u0113\u011d", (byte)27, 65);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[1] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u010a\u00fe\u00e8\u00f0\u0126\u0106\u00f1\u012e\u0114\u0120\u010e\u012b\u0108\u00f5\u0110\u011e\u012a\u012f\u0108\u0118\u00fe\u011b\u0108\u0109", (byte)27, 65);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[2] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u051c\u0541\u054e\u0533\u0521\u0522\u0532\u0516\u0511\u0548\u054e\u055c\u0526\u054a\u052c\u051c\u0541\u055f\u053b\u051b\u052d\u051d\u053c\u0523\u055c\u0542\u0566\u0564\u0548\u0549\u0548\u0566", (byte)27, 69);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[3] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u011e\u011e\u0129\u0120\u010e\u011f\u0112\u012a\u0100\u0102\u0126\u00fd", (byte)27, 65);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[4] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u0459\u0458\u047b\u0434\u044f\u0482\u0457\u043f\u0483\u0442\u0488\u0467\u047a\u0463\u045e\u0440\u0481\u046f\u047f\u044c\u0482\u046d\u0490\u0461\u0482\u0458\u048e\u0495\u045a\u046b\u047c\u0470", (byte)27, 67);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[5] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.E("\u052a\u0529\u054c\u0505\u0520\u0553\u0528\u0510\u0554\u0513\u0559\u0538\u054b\u0534\u052f\u0511\u0552\u0540\u0550\u051d\u0553\u0541\u054e\u0559\u0555\u0553\u0563\u0537\u0566\u0535\u053b\u0542\u053d\u0541\u0566\u0552\u0573\u053d\u0573\u054f\u0538\u0535\u0574\u053f", (byte)27, 69);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[6] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u0108\u0107\u012a\u00e3\u00fe\u0131\u0106\u00ee\u0132\u00f1\u0137\u0116\u0129\u0112\u010d\u00ef\u0130\u011e\u012e\u00fb\u0131\u0121\u0104\u00fe\u0127\u0133\u0100\u0121\u0145\u0129\u0117\u010a", (byte)27, 65);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[7] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u051a\u0508\u054b\u0505\u0523\u054b\u0514\u054b\u054f\u0512\u0547\u0532\u0512\u0529\u052a\u054e\u053d\u051a\u054b\u053a\u0537\u053d\u052a\u052b", (byte)27, 70);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[8] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.E("\u052f\u0531\u0548\u050b\u0530\u0550\u0530\u050f\u0534\u052e\u0515\u051f", (byte)27, 69);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[9] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u0540\u0540\u054b\u0542\u0530\u0541\u0534\u054c\u0522\u0524\u0548\u051f", (byte)27, 70);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[10] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u0449\u0437\u047a\u0434\u0452\u047a\u0443\u047a\u047e\u0441\u0473\u0487\u0468\u047c\u0486\u0465\u044d\u0450\u044b\u0444\u048c\u046d\u0451\u046a\u0488\u0461\u0468\u0495\u046f\u045b\u047a\u0474", (byte)27, 67);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[11] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.F("\u052f\u0531\u0548\u050b\u0530\u0550\u0530\u050f\u0534\u052e\u0515\u051f", (byte)27, 70);
                    continue block7;
                }
                case 1: {
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u0524\u0511\u052a\u052a\u0545\u0511\u052d\u052a\u0549\u0514\u0524\u0515\u0537\u055d\u052d\u0533\u0532\u0552\u0520\u055d\u0536\u0541\u053b\u053c\u0520\u0542\u055a\u0548\u0529\u0535\u0549\u0548\u054f\u053f\u052f\u052a\u0542\u0575\u0574\u056c\u052e\u054a\u0556\u053f", (byte)27, 70);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[1] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.E("\u052c\u0520\u050a\u0512\u0548\u0528\u0513\u0550\u0536\u0542\u0530\u052d\u055c\u054a\u0535\u051e\u054e\u052d\u055b\u051b\u053b\u053d\u052a\u052b", (byte)27, 69);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[2] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u00fa\u011f\u012c\u0111\u00ff\u0100\u0110\u00f4\u00ef\u0126\u012c\u013a\u0104\u0128\u010a\u00fa\u011f\u013d\u0119\u00f9\u010b\u0143\u0145\u0116\u0110\u0122\u011e\u0121\u0104\u013e\u0121\u011c\u0136\u0144\u014d\u011c\u0129\u012e\u011d\u0128\u0141\u0113\u0152\u011d", (byte)27, 66);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[3] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u0121\u0126\u00fb\u010d\u0108\u010d\u0128\u0126\u00ef\u0108\u0126\u00fd", (byte)27, 66);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[4] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.C("\u0459\u0458\u047b\u0434\u044f\u0482\u0457\u043f\u0483\u0442\u0488\u0467\u047a\u0463\u045e\u0440\u0481\u046f\u047f\u044c\u0482\u0471\u0473\u048a\u046a\u046e\u0461\u0487\u0473\u047c\u0470\u049c", (byte)27, 67);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[5] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.A("\u0108\u0107\u012a\u00e3\u00fe\u0131\u0106\u00ee\u0132\u00f1\u0137\u0116\u0129\u0112\u010d\u00ef\u0130\u011e\u012e\u00fb\u0131\u011f\u012c\u0137\u0133\u0131\u0141\u0115\u0144\u0113\u0119\u0120\u0118\u013a\u0110\u0150\u0126\u010f\u0148\u0130\u0130\u0154\u0117\u011d", (byte)27, 65);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[6] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u052a\u0529\u054c\u0505\u0520\u0553\u0528\u0510\u0554\u0513\u0559\u0538\u054b\u0534\u052f\u0511\u0552\u0540\u0550\u051d\u0553\u0545\u0522\u0566\u0535\u053a\u053c\u053c\u054a\u0524\u0565\u0521\u056b\u0552\u055a\u0542\u054a\u056a\u056d\u0535\u0542\u0554\u056c\u053f", (byte)27, 70);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[7] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u0449\u0437\u047a\u0434\u0452\u047a\u0443\u047a\u047e\u0441\u0474\u045c\u047d\u0487\u047f\u044d\u0466\u0471\u047c\u048e\u046c\u048e\u0453\u0465\u0496\u0455\u0484\u049b\u048d\u048c\u046e\u0471", (byte)27, 67);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[8] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u0453\u0477\u043d\u046e\u044f\u043c\u0455\u045c\u0439\u0485\u0455\u0487\u047c\u0466\u0448\u0445\u046f\u0491\u046f\u046d\u0481\u045c\u0459\u045a", (byte)27, 67);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[9] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u044e\u0438\u0450\u044e\u0484\u043b\u0463\u0453\u0452\u0478\u047b\u044e", (byte)27, 68);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[10] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.C("\u0449\u0437\u047a\u0434\u0452\u047a\u0443\u047a\u047e\u0441\u0473\u0487\u0468\u047c\u0486\u0465\u044d\u0450\u044b\u0444\u048c\u0472\u045e\u0476\u0465\u0454\u0463\u048f\u0472\u0477\u0475\u048a", (byte)27, 67);
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[11] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u0116\u0104\u00fa\u0124\u00ec\u012e\u0114\u0122\u00f0\u0130\u00f3\u0139\u010f\u0130\u0117\u00f4\u00f6\u012d\u012f\u00f7\u0121\u010b\u0108\u0109", (byte)27, 65);
                    continue block7;
                }
                case 2: {
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u050d\u050f\u0504\u0521\u0541\u0546\u0522\u054f\u0543\u0525\u0530\u0553\u052e\u0529\u055d\u0539\u0519\u0558\u052d\u0521\u051a\u0543\u0522\u0567\u055b\u0543\u051c\u0548\u056d\u056c\u0544\u053b", (byte)27, 70);
                    continue block7;
                }
                case 4: {
                    \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.D("\u043b\u0460\u043a\u045d\u0451\u0480\u046e\u0445\u0442\u0441\u0457\u0478\u0455\u0479\u0458\u0479\u0461\u0449\u0470\u0483\u0488\u0482\u0459\u045a", (byte)27, 68);
                }
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void d(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        File file = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().d();
        StringBuilder stringBuilder = new StringBuilder();
        try {
            \u0394\u03a8\u03bc\u03c9\u03c7\u03c9\u03a6\u03bb\u03a6\u03c0\u03a9\u03c5 \u03b4\u03a8\u03bc\u03c9\u03c7\u03c9\u03a6\u03bb\u03a6\u03c0\u03a9\u03c5 = \u03c9\u03c2\u03b4\u03c9\u03bb\u03bb\u03bd\u03b4\u03b4.a(file);
            try {
                String string;
                while ((string = \u03b4\u03a8\u03bc\u03c9\u03c7\u03c9\u03a6\u03bb\u03a6\u03c0\u03a9\u03c5.ah()) != null) {
                    if (stringBuilder.length() > 0) {
                        stringBuilder.append((String)\u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.c("\u3e80", (int)(o & p), (long)q));
                    }
                    if (string.trim().startsWith((String)\u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.c("\u3e83", (int)r, (long)s))) {
                        stringBuilder.append(string.replace((CharSequence)\u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.c("\u3e86", (int)(t & u), (long)v), (CharSequence)\u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.c("\u3e89", (int)w, (long)(x ^ y))));
                        continue;
                    }
                    stringBuilder.append(string);
                }
            }
            finally {
                if (Collections.singletonList(\u03b4\u03a8\u03bc\u03c9\u03c7\u03c9\u03a6\u03bb\u03a6\u03c0\u03a9\u03c5).get(z) != null) {
                    \u03b4\u03a8\u03bc\u03c9\u03c7\u03c9\u03a6\u03bb\u03a6\u03c0\u03a9\u03c5.close();
                }
            }
        }
        catch (IOException iOException) {
            throw new RuntimeException((String)\u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.c("\u3e8c", (int)(ab & ac), (long)ad) + file + (String)\u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.c("\u3e8f", (int)ae, (long)(af ^ ag)), iOException);
        }
        try {
            if (file.delete()) {
                \u03b2\u03b9\u03a0\u03c1\u03c8\u03bc\u03c0\u0394\u03b2\u03a0\u03b4.a(file, stringBuilder.toString().split((String)\u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.c("\u3e92", (int)ah, (long)ai)));
                \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().X();
                \u03c2\u03b9\u03a0\u03b4\u03c6\u03bc\u03b7\u03c9\u03b7.e(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6);
            }
        }
        catch (IOException iOException) {
            throw new RuntimeException((String)\u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.c("\u3e95", (int)(aj & ak), (long)al) + file + (String)\u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.c("\u3e98", (int)(am & an), (long)ao), iOException);
        }
    }

    @Override
    public String q() {
        return \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.c("\u3e80", (int)a, (long)(b ^ d));
    }

    static {
        a = (0 >>> 234 | 0 << ~234 + 1) & 0xFFFFFFFF;
        b = Long.reverse(2115495403150440682L);
        d = Long.reverse(0x3400000000000000L);
        e = (2 >>> 65 | 2 << -65) & 0xFFFFFFFF;
        f = (-1 >>> 9 | -1 << ~9 + 1) & 0xFFFFFFFF;
        g = Long.reverse(2980186531605575914L);
        h = (1 >>> 64 | 1 << -64) & 0xFFFFFFFF;
        i = Integer.reverse(0x40000000);
        j = Long.reverse(2980186531605575914L);
        k = (0 >>> 58 | 0 << ~58 + 1) & 0xFFFFFFFF;
        l = 32768 >>> 239 | 32768 << -239;
        m = 0 >>> 20 | 0 << -20;
        n = Integer.reverse(0);
        o = 3 >>> 0 | 3 << -0;
        p = Integer.reverse(-1);
        q = Long.reverse(2980186531605575914L);
        r = 0x4000000 >>> 184 | 0x4000000 << -184;
        s = Long.reverse(2980186531605575914L);
        t = Integer.reverse(-1610612736);
        u = Integer.reverse(-1);
        v = Long.reverse(2980186531605575914L);
        w = Integer.reverse(0x60000000);
        x = Long.reverse(2115495403150440682L);
        y = Long.reverse(0x3400000000000000L);
        z = 0 >>> 244 | 0 << -244;
        aa = (0 >>> 126 | 0 << ~126 + 1) & 0xFFFFFFFF;
        ab = Integer.reverse(-536870912);
        ac = Integer.reverse(-1);
        ad = Long.reverse(2980186531605575914L);
        ae = (4 >>> 127 | 4 << -127) & 0xFFFFFFFF;
        af = Long.reverse(2115495403150440682L);
        ag = Long.reverse(0x3400000000000000L);
        ah = Integer.reverse(-1879048192);
        ai = Long.reverse(2980186531605575914L);
        aj = Integer.reverse(0x50000000);
        ak = -1 >>> 23 | -1 << ~23 + 1;
        al = Long.reverse(2980186531605575914L);
        am = Integer.reverse(-805306368);
        an = Integer.reverse(-1);
        ao = Long.reverse(2980186531605575914L);
        ap = Integer.reverse(0x30000000);
        aq = Integer.reverse(0x30000000);
        ar = Integer.reverse(Integer.MIN_VALUE);
        a = new String[ap];
        b = new String[aq];
        \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.b();
        s = ar;
        a = new \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.B("\u00df\u0101\u0103\u00e3\u0107\u0126\u011e\u0134\u0120\u00ef\u012d\u0123\u0131\u012b\u00f4\u0119\u013b\u013a\u0132\u0138\u0132\u0107", (byte)28, 66), \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u011a\u0127\u0126\u00e9\u0129\u0125\u0120\u0129\u0134\u0123\u00f0\u012e\u0132\u012b\u012e\u0134\u00f6\u0483\u0482\u048f\u048b\u048f\u0480\u0493\u048a\u010a", (byte)28, 65) + string + \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.D("\u0443", (byte)28, 68) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x2CL;
        l ^= 0xAB68EA987995FF6BL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(25 + 43), 69, (byte)(68 + 15), (byte)(7 + 40), (byte)(4 + 63), (byte)(51 + 15), 67, (byte)(16 + 31), (byte)(64 + 16), (byte)(52 + 23), (byte)(42 + 25), (byte)(41 + 42), (byte)(3 + 50), (byte)(73 + 7), (byte)(96 + 1), (byte)(24 + 76), (byte)(62 + 38), (byte)(96 + 9), (byte)(74 + 36), (byte)(84 + 19)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(52 + 16), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u0586\u0593\u0592\u0555\u0595\u0591\u058c\u0595\u05a0\u058f\u055c\u059a\u059e\u0597\u059a\u05a0\u0562\u08ef\u08ee\u08fb\u08f7\u08fb\u08ec\u08ff\u08f6", (byte)103, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bb\u03b9\u03c5\u03c0\u03c3\u03b3\u03c5\u03bb.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public boolean a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03c3\u0394\u03c5\u03b3\u03ba\u03c2\u03bd\u0393\u03bb\u03be \u03c3\u0394\u03c5\u03b3\u03ba\u03c2\u03bd\u0393\u03bb\u03be2, \u03a8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2 \u03c8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2) {
        return (\u03c3\u0394\u03c5\u03b3\u03ba\u03c2\u03bd\u0393\u03bb\u03be2.a() == null ? l : m) != 0;
    }
}

