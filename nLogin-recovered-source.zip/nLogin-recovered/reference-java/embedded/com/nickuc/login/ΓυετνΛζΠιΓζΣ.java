/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.jedis.DefaultJedisClientConfig
 *  com.nickuc.login.lib.jedis.HostAndPort
 *  com.nickuc.login.lib.jedis.JedisClientConfig
 *  com.nickuc.login.lib.jedis.JedisCluster
 *  com.nickuc.login.lib.jedis.JedisPooled
 *  com.nickuc.login.lib.jedis.UnifiedJedis
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.lib.jedis.DefaultJedisClientConfig;
import com.nickuc.login.lib.jedis.HostAndPort;
import com.nickuc.login.lib.jedis.JedisClientConfig;
import com.nickuc.login.lib.jedis.JedisCluster;
import com.nickuc.login.lib.jedis.JedisPooled;
import com.nickuc.login.lib.jedis.UnifiedJedis;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4;
import com.nickuc.login.\u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import java.io.Closeable;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3
implements Closeable {
    private static int a = Integer.reverse(0xBE00000);
    private static int b = Integer.reverse(0);
    private static int n;
    private boolean ad;
    private final UnifiedJedis a;
    private static int q;
    private static int i;
    private static int l;
    private final \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?> f;
    private static long o;
    private static int e;
    private static int g;
    private final Map<String, \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb> i = (int)new HashMap();
    private static int h;
    private static int f;
    private static int m;
    private static long d;
    private static String[] b;
    private static long j;
    private static String[] a;
    private static long k;
    private static int r;
    private static int c;
    private static long c;
    private static int p;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void a(String string, Consumer<String> consumer) {
        if (this.ad) {
            throw new IllegalStateException((String)\u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.c("\u3e80", (int)i, (long)(j ^ k)));
        }
        int n = this.i;
        synchronized (n) {
            \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb2 = new \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb(this, string, consumer, null);
            this.i.put(string, \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb2);
            this.f.b(l != 0).a(\u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb2);
        }
    }

    static /* synthetic */ UnifiedJedis a(\u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3 \u03b3\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3) {
        return \u03b3\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.a;
    }

    public static \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3 a(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?> \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, List<String> list, String string, String string2, boolean bl) {
        Set set = list.stream().map(\u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3::a).collect(Collectors.toSet());
        return new \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, (UnifiedJedis)new JedisCluster(set, \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.a(string, string2, bl)));
    }

    @Generated
    private \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?> \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, UnifiedJedis unifiedJedis) {
        this.f = \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42;
        this.a = unifiedJedis;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.D("\u0500\u0522\u0524\u0504\u0528\u0547\u053f\u0555\u0541\u0510\u054e\u0544\u0552\u054c\u0515\u053a\u055c\u055b\u0553\u0559\u0553\u0528", (byte)97, 68), \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.B("\u01a4\u01b1\u01b0\u0173\u01b3\u01af\u01aa\u01b3\u01be\u01ad\u017a\u01b8\u01bc\u01b5\u01b8\u01be\u0180\u04e5\u0518\u0509\u0519\u0513\u04f2\u050e\u04f9\u0513\u04ee\u0512\u0500\u0198", (byte)97, 66) + string + \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.B("\u017b", (byte)97, 66) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = -94248921794608169L;
        long l = c ^ 0x26B583ABCA90005EL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(12 + 56), (byte)(32 + 37), (byte)(41 + 42), (byte)(38 + 9), (byte)(39 + 28), (byte)(32 + 34), (byte)(5 + 62), (byte)(29 + 18), (byte)(9 + 71), (byte)(26 + 49), (byte)(32 + 35), (byte)(50 + 33), (byte)(30 + 23), 80, (byte)(8 + 89), (byte)(89 + 11), (byte)(64 + 36), (byte)(43 + 62), 110, (byte)(15 + 88)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(33 + 36), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u0177\u0191\u018a\u0175\u0195\u0170\u017f\u01a0\u016e\u017b\u0167\u016d", (byte)83, 66);
                    \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.b[1] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u0519\u0515\u0519\u04e1\u051a\u052a\u051e\u0529\u04e7\u04fa\u0503\u04eb\u0533\u050d\u0530\u0520\u04f0\u0534\u0515\u0536\u0504\u0532\u04f7\u0508\u0519\u052e\u0517\u04ff\u050f\u0516\u04fe\u04fe\u0523\u0502\u053b\u0505\u04fd\u051f\u0507\u0528\u0506\u0547\u054b\u0516", (byte)83, 68);
                    \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.b[2] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u057a\u0576\u057a\u0542\u057b\u058b\u057f\u058a\u0548\u055b\u0564\u054c\u0594\u056e\u0591\u0581\u0551\u0595\u0576\u0597\u0565\u0593\u0558\u0569\u057a\u058f\u0578\u0560\u0570\u0577\u055f\u055f\u0584\u0563\u059c\u0566\u055e\u0580\u0568\u0589\u0567\u05a8\u05ac\u0577", (byte)83, 70);
                    continue block7;
                }
                case 1: {
                    \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.b[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0582\u0581\u0584\u0580\u0574\u0569\u0559\u057b\u058f\u0551\u0584\u0557", (byte)83, 70);
                    \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.b[1] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.E("\u057a\u0576\u057a\u0542\u057b\u058b\u057f\u058a\u0548\u055b\u0564\u054c\u0594\u056e\u0591\u0581\u0551\u0595\u0576\u0597\u0565\u0593\u0558\u0569\u057a\u058f\u0578\u0560\u0570\u0577\u055f\u055f\u0564\u059a\u0585\u0589\u05a6\u0588\u059c\u05a3\u056e\u05b2\u05a3\u05b0\u05ad\u059e\u05ae\u0580\u05ad\u058e\u0598\u0599\u0577\u05ab\u0582\u0583", (byte)83, 69);
                    \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.b[2] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u0190\u018c\u0190\u0158\u0191\u01a1\u0195\u01a0\u015e\u0171\u017a\u0162\u01aa\u0184\u01a7\u0197\u0167\u01ab\u018c\u01ad\u017b\u01a9\u016e\u017f\u0190\u01a5\u018e\u0176\u0186\u018d\u0175\u0175\u01b8\u0176\u01aa\u01b5\u01bb\u0179\u017e\u019d\u01ae\u01c6\u01c7\u019c\u01c3\u0195\u01b5\u01cb\u019d\u01a4\u0190\u019f\u018b\u01c1\u0198\u0199", (byte)83, 66);
                    continue block7;
                }
                case 2: {
                    \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.b[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u055e\u0577\u0574\u054b\u055c\u0545\u0587\u057b\u0579\u055e\u0552\u058b\u0553\u054e\u054c\u0584\u058f\u0564\u057a\u0586\u0555\u057e\u0575\u0597\u057c\u0569\u059f\u0559\u057f\u05a2\u0583\u0579", (byte)83, 70);
                    continue block7;
                }
                case 4: {
                    \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.D("\u04e5\u0517\u0506\u0521\u0524\u04e4\u0518\u0509\u0519\u0524\u0508\u04fd\u0522\u04ec\u0513\u04ec\u04ee\u0536\u0514\u0513\u0524\u0514\u0501\u0502", (byte)83, 68);
                }
            }
        }
    }

    public void l(String string, String string2) {
        this.a.publish(string, string2);
    }

    private static JedisClientConfig a(String string, String string2, boolean bl) {
        return DefaultJedisClientConfig.builder().user(string).password(string2).ssl(bl).timeoutMillis(a).build();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void t(String string) {
        if (this.ad) {
            throw new IllegalStateException((String)\u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.c("\u3e80", (int)(m & n), (long)o));
        }
        int n = this.i;
        synchronized (n) {
            \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb2 = (\u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb)this.i.remove(string);
            if (\u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb2 != null) {
                \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb2.close();
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void close() {
        this.ad = p;
        int n = this.i;
        synchronized (n) {
            this.i.values().forEach(\u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb::close);
        }
        this.a.close();
    }

    private static String a(int n, long l) {
        l ^= 0x5DL;
        l ^= 0x26B583ABCA90005EL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(11 + 57), (byte)(50 + 19), (byte)(71 + 12), (byte)(27 + 20), (byte)(55 + 12), (byte)(12 + 54), (byte)(3 + 64), (byte)(13 + 34), (byte)(32 + 48), (byte)(50 + 25), (byte)(61 + 6), (byte)(27 + 56), (byte)(4 + 49), 80, (byte)(96 + 1), 100, (byte)(25 + 75), (byte)(78 + 27), (byte)(75 + 35), (byte)(50 + 53)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(26 + 42), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u010e\u011b\u011a\u00dd\u011d\u0119\u0114\u011d\u0128\u0117\u00e4\u0122\u0126\u011f\u0122\u0128\u00ea\u044f\u0482\u0473\u0483\u047d\u045c\u0478\u0463\u047d\u0458\u047c\u046a", (byte)22, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        c = Integer.reverse(-1);
        d = Long.reverse(5890743476983991679L);
        e = Integer.reverse(0);
        f = 2 >>> 33 | 2 << ~33 + 1;
        g = 0x40000000 >>> 190 | 0x40000000 << -190;
        h = -704643023 >>> 25 | -704643023 << -25;
        i = (0x8000000 >>> 187 | 0x8000000 << -187) & 0xFFFFFFFF;
        j = Long.reverse(-1459131114884657793L);
        k = Long.reverse(-5044031582654955520L);
        l = Integer.reverse(Integer.MIN_VALUE);
        m = 128 >>> 166 | 128 << ~166 + 1;
        n = (-1 >>> 151 | -1 << ~151 + 1) & 0xFFFFFFFF;
        o = Long.reverse(5890743476983991679L);
        p = (0x20000000 >>> 125 | 0x20000000 << ~125 + 1) & 0xFFFFFFFF;
        q = (48 >>> 132 | 48 << -132) & 0xFFFFFFFF;
        r = Integer.reverse(-1073741824);
        a = new String[q];
        b = new String[r];
        \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.b();
    }

    private static HostAndPort a(String string) {
        String[] stringArray = string.split((String)\u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.c("\u3e80", (int)(b & c), (long)d));
        String string2 = stringArray[e];
        int n = stringArray.length > f ? Integer.parseInt(stringArray[g]) : h;
        return new HostAndPort(string2, n);
    }

    public static \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3 a(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?> \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, String string, String string2, String string3, boolean bl) {
        return new \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, (UnifiedJedis)new JedisPooled(\u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.a(string), \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.a(string2, string3, bl)));
    }
}

