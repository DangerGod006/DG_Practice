/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9 {
    private static int o;
    private static int u;
    private static int ae;
    private static long v;
    private static long b;
    private static int a;
    private static int j;
    private static long h;
    private static long c;
    private static int ac;
    private static long p;
    private static String[] b;
    private static int f;
    private static long d;
    private static String[] a;
    private static long q;
    private static int z;
    private static long i;
    private static int w;
    private static int ab;
    private static int k;
    private static long y;
    private static long n;
    private static int t;
    private static int l;
    private static int x;
    private static int ad;
    private static int r;
    private static long s;
    private static int m;
    private static int g;
    private static int aa;
    private static int e;

    private static void b() {
        int n;
        c = -4165445831788461230L;
        long l = c ^ 0x6D0DA0BBBF130C49L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(64 + 4), (byte)(49 + 20), (byte)(19 + 64), 47, (byte)(64 + 3), (byte)(39 + 27), (byte)(3 + 64), (byte)(23 + 24), (byte)(46 + 34), 75, (byte)(40 + 27), (byte)(31 + 52), (byte)(31 + 22), (byte)(63 + 17), (byte)(10 + 87), (byte)(21 + 79), (byte)(65 + 35), (byte)(28 + 77), (byte)(20 + 90), (byte)(43 + 60)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(61 + 7), (byte)(17 + 52), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u011f\u0132\u0150\u0141\u0122\u0128\u0117\u0150\u010e\u0157\u0136\u0123", (byte)46, 65);
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[1] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.D("\u048d\u04aa\u04b2\u0474\u0499\u0496\u049a\u0496\u04ad\u047c\u0492\u0487", (byte)46, 68);
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[2] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u04ae\u0490\u0494\u04b0\u049b\u047b\u0479\u04ba\u0472\u04ab\u0482\u04b5\u04bb\u0497\u04b7\u0485\u0488\u04bf\u0497\u04cb\u049f\u04a1\u049d\u049a\u04c3\u04a9\u0491\u04c6\u0493\u04c0\u04b6\u04c3\u04c9\u04c9\u0497\u04a3\u04b0\u0498\u04ba\u049e\u04c0\u04af\u04d4\u0499\u049e\u04bd\u04d2\u04d9\u04c9\u04b9\u04c8\u04c7\u04e5\u04db\u04b2\u04b3", (byte)46, 67);
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[3] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u048b\u0471\u0486\u0475\u04a6\u049e\u04bc\u0493\u0488\u0473\u04b6\u0499\u0482\u04ad\u048f\u049f\u0494\u049b\u04bd\u0483\u049a\u04cb\u0492\u0493", (byte)46, 68);
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[4] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u0134\u0111\u0134\u0113\u0149\u013a\u0137\u0127\u0129\u0159\u012e\u0123", (byte)46, 66);
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[5] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0540\u0560\u051f\u0564\u0541\u0558\u0532\u055f\u0566\u056c\u0535\u0532", (byte)46, 70);
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[6] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u0491\u0486\u0499\u0483\u0495\u049c\u04be\u0479\u04b0\u0479\u048a\u0487", (byte)46, 68);
                    continue block7;
                }
                case 1: {
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u0141\u013d\u0151\u0113\u0120\u0115\u0157\u011a\u014b\u0156\u0115\u0123", (byte)46, 65);
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[1] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.D("\u048c\u04ab\u04b6\u04af\u049c\u04ae\u04b0\u04bb\u04b3\u04a1\u0481\u0487", (byte)46, 68);
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u0559\u053b\u053f\u055b\u0546\u0526\u0524\u0565\u051d\u0556\u052d\u0560\u0566\u0542\u0562\u0530\u0533\u056a\u0542\u0576\u054a\u054c\u0548\u0545\u056e\u0554\u053c\u0571\u053e\u056b\u0561\u056e\u0574\u0574\u0542\u054e\u055b\u0543\u0565\u0549\u056b\u055a\u0582\u0544\u0547\u0565\u057a\u0563\u0572\u0584\u0552\u0564\u0595\u0589\u0584\u0592\u055b\u0556\u0553\u0556\u056c\u0558\u0580\u057a", (byte)46, 70);
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[3] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u048b\u0471\u0486\u0475\u04a6\u049e\u04bc\u0493\u0488\u0473\u04b4\u048d\u04b9\u049b\u0494\u04b7\u04c5\u049e\u04b3\u04ab\u04bb\u04bb\u0492\u0493", (byte)46, 67);
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[4] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.A("\u014e\u014b\u0146\u013f\u0150\u0149\u0116\u0139\u0130\u0132\u0136\u0123", (byte)46, 65);
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[5] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u0539\u0516\u052d\u055a\u051f\u0561\u0537\u0555\u0560\u055c\u0539\u0532", (byte)46, 70);
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[6] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.E("\u0531\u051b\u0538\u0530\u0526\u0524\u0568\u054a\u055a\u0522\u0557\u0532", (byte)46, 69);
                    continue block7;
                }
                case 2: {
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u013c\u0132\u0142\u0127\u0126\u0149\u0147\u0128\u0157\u0136\u0130\u0115\u014e\u0160\u0154\u0163\u011e\u0150\u0126\u012f\u015b\u0157\u012e\u012f", (byte)46, 66);
                    continue block7;
                }
                case 4: {
                    \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u0499\u0493\u04a9\u04bc\u049b\u0488\u0496\u04c0\u047b\u04be\u047f\u04b5\u047d\u049e\u049a\u04a4\u049f\u04c7\u04b3\u04cc\u04b8\u0495\u0492\u0493", (byte)46, 67);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x5BL;
        l ^= 0x6D0DA0BBBF130C49L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(2 + 66), (byte)(15 + 54), (byte)(29 + 54), (byte)(21 + 26), (byte)(5 + 62), 66, (byte)(26 + 41), (byte)(36 + 11), (byte)(51 + 29), (byte)(37 + 38), (byte)(24 + 43), (byte)(63 + 20), (byte)(13 + 40), (byte)(34 + 46), (byte)(52 + 45), 100, (byte)(51 + 49), (byte)(73 + 32), (byte)(86 + 24), (byte)(3 + 100)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(79 + 4)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u043c\u0449\u0448\u040b\u044b\u0447\u0442\u044b\u0456\u0445\u0412\u0450\u0454\u044d\u0450\u0456\u0418\u07a8\u07ac\u07a9\u079e\u0782\u07b6\u07b8\u07b0\u07a5\u0796\u07b2\u0789\u07bf", (byte)12, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static String ae() {
        return System.getProperty((String)\u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.c("\u3e80", (int)o, (long)(p ^ q)));
    }

    public static OperatingSystemMXBean a() {
        return ManagementFactory.getOperatingSystemMXBean();
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(5386437678381829219L);
        d = Long.reverse(-2738188573441261568L);
        e = Integer.reverse(0x40000000);
        f = (3 >>> 192 | 3 << -192) & 0xFFFFFFFF;
        g = 0x800000 >>> 119 | 0x800000 << ~119 + 1;
        h = Long.reverse(5386437678381829219L);
        i = Long.reverse(-2738188573441261568L);
        j = -1 >>> 84 | -1 << -84;
        k = (0 >>> 108 | 0 << -108) & 0xFFFFFFFF;
        l = (0 >>> 69 | 0 << -69) & 0xFFFFFFFF;
        m = Integer.reverse(0x40000000);
        n = Long.reverse(-8016274812672766877L);
        o = (6 >>> 1 | 6 << ~1 + 1) & 0xFFFFFFFF;
        p = Long.reverse(5386437678381829219L);
        q = Long.reverse(-2738188573441261568L);
        r = Integer.reverse(0x20000000);
        s = Long.reverse(-8016274812672766877L);
        t = Integer.reverse(-1610612736);
        u = Integer.reverse(-1);
        v = Long.reverse(-8016274812672766877L);
        w = 0x300000 >>> 147 | 0x300000 << -147;
        x = Integer.reverse(-1);
        y = Long.reverse(-8016274812672766877L);
        z = Integer.reverse(Integer.MIN_VALUE);
        aa = Integer.reverse(0);
        ab = Integer.reverse(Integer.MIN_VALUE);
        ac = Integer.reverse(0);
        ad = (14336 >>> 43 | 14336 << ~43 + 1) & 0xFFFFFFFF;
        ae = (0x1C00000 >>> 86 | 0x1C00000 << -86) & 0xFFFFFFFF;
        a = new String[ad];
        b = new String[ae];
        \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.b();
    }

    public static void c(int n) {
        try {
            Class[] classArray = new Class[z];
            classArray[\u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.aa] = Integer.TYPE;
            Object[] objectArray = new Object[ab];
            objectArray[\u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.ac] = n;
            \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(System.class, ((String)\u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.c("\u3e80", (int)r, (long)s)).concat((String)\u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.c("\u3e83", (int)(t & u), (long)v)).concat((String)\u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.c("\u3e86", (int)(w & x), (long)y)), classArray).invoke(null, objectArray);
        }
        catch (IllegalAccessException | InvocationTargetException reflectiveOperationException) {
            throw new RuntimeException(reflectiveOperationException);
        }
    }

    public static int u() {
        char c;
        String string = \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.ae();
        if (string.startsWith((String)\u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.c("\u3e80", (int)a, (long)(b ^ d)))) {
            string = string.substring(e, f);
        } else {
            int n = string.indexOf((String)\u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.c("\u3e83", (int)g, (long)(h ^ i)));
            if (n != j) {
                string = string.substring(k, n);
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = l; i < string.length() && \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.a(c = string.charAt(i)); ++i) {
            stringBuilder.append(c);
        }
        if (stringBuilder.length() == 0) {
            throw new RuntimeException((String)\u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.c("\u3e86", (int)m, (long)n) + \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.ae());
        }
        return Integer.parseInt(stringBuilder.toString());
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u0127\u0149\u014b\u012b\u014f\u016e\u0166\u017c\u0168\u0137\u0175\u016b\u0179\u0173\u013c\u0161\u0183\u0182\u017a\u0180\u017a\u014f", (byte)64, 66), \u03be\u03c1\u03bd\u03b1\u0394\u03c7\u03c8\u03bf\u03b3\u03a3\u03be\u0394\u03c9.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u0162\u016f\u016e\u0131\u0171\u016d\u0168\u0171\u017c\u016b\u0138\u0176\u017a\u0173\u0176\u017c\u013e\u04ce\u04d2\u04cf\u04c4\u04a8\u04dc\u04de\u04d6\u04cb\u04bc\u04d8\u04af\u04e5\u0157", (byte)64, 65) + string + \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u0139", (byte)64, 65) + methodType.toString(), exception);
        }
    }
}

