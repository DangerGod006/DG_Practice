/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.caffeine.cache.Cache
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.lib.caffeine.cache.Cache;
import lombok.Generated;

public class \u0394\u03a3\u03c9\u03b9\u03c8\u03a9\u03c2\u0393\u039b\u03bd\u03b6 {
    private static int b;
    private final Cache<String, Long> h;
    private static int a;

    @Generated
    public \u0394\u03a3\u03c9\u03b9\u03c8\u03a9\u03c2\u0393\u039b\u03bd\u03b6(Cache<String, Long> cache) {
        this.h = cache;
    }

    public boolean s(String string) {
        return \u0394\u03a3\u03c9\u03b9\u03c8\u03a9\u03c2\u0393\u039b\u03bd\u03b6.a(string, this.h);
    }

    public static boolean a(String string2, Cache<String, Long> cache) {
        long l = System.currentTimeMillis();
        long l2 = (Long)cache.get((Object)string2, string -> l);
        return (l2 == l ? a : b) != 0;
    }

    static {
        a = (0x10000000 >>> 156 | 0x10000000 << -156) & 0xFFFFFFFF;
        b = (0 >>> 164 | 0 << -164) & 0xFFFFFFFF;
    }
}

