/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

public final class \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be {
    public static String A(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (127 + i) - 2 * nickuc);
        }
        return new String(x);
    }

    public static String C(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (949 + i) - -3 * -nickuc);
        }
        return new String(x);
    }

    public static String E(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (1212 + i) - nickuc);
        }
        return new String(x);
    }

    public static String B(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (127 + i) - 2 * nickuc);
        }
        return new String(x);
    }

    public static String D(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (949 + i) - -3 * -nickuc);
        }
        return new String(x);
    }

    public static String F(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (1212 + i) - nickuc);
        }
        return new String(x);
    }
}

