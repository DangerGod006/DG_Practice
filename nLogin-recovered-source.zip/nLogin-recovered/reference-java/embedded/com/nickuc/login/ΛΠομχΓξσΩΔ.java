/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.event.bukkit.auth.request.LoginRequestEvent
 *  com.nickuc.login.api.event.internal.LockableEvent
 *  com.nickuc.login.api.event.internal.LockableNewActionEvent
 *  org.bukkit.entity.Player
 */
package com.nickuc.login;

import com.nickuc.login.api.event.bukkit.auth.request.LoginRequestEvent;
import com.nickuc.login.api.event.internal.LockableEvent;
import com.nickuc.login.api.event.internal.LockableNewActionEvent;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b9\u03b2\u03b9\u03c8\u03ba\u03c9\u0393\u03b3;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c9\u03b4\u03c0\u03b7\u03be\u03b9\u0393\u03a3\u03c6\u03a8\u0394\u03c1\u0393\u0393;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u039b\u03a0\u03bf\u03bc\u03c7\u0393\u03be\u03c3\u03a9\u0394
extends \u03a8\u03b9\u03b2\u03b9\u03c8\u03ba\u03c9\u0393\u03b3 {
    final /* synthetic */ \u03c9\u03b4\u03c0\u03b7\u03be\u03b9\u0393\u03a3\u03c6\u03a8\u0394\u03c1\u0393\u0393 a;
    private static int g;
    private static String[] c;
    private static int i;
    private static int c;
    private static String[] d;
    private static long f;
    private static int b;
    private static long e;

    private static String a(int n, long l) {
        l ^= 6L;
        l ^= 0x8C11307E42C606C1L;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(17 + 51), (byte)(5 + 64), (byte)(58 + 25), (byte)(40 + 7), (byte)(33 + 34), (byte)(3 + 63), (byte)(36 + 31), (byte)(46 + 1), (byte)(53 + 27), (byte)(69 + 6), (byte)(64 + 3), (byte)(49 + 34), (byte)(20 + 33), (byte)(30 + 50), 97, 100, (byte)(52 + 48), (byte)(44 + 61), (byte)(17 + 93), (byte)(71 + 32)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(35 + 33), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u01dc\u01e9\u01e8\u01ab\u01eb\u01e7\u01e2\u01eb\u01f6\u01e5\u01b2\u01f0\u01f4\u01ed\u01f0\u01f6\u01b8\u0525\u052b\u054b\u0549\u0555\u0522\u054e\u0554\u053b\u0527", (byte)125, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u039b\u03a0\u03bf\u03bc\u03c7\u0393\u03be\u03c3\u03a9\u0394.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    static {
        b = Integer.reverse(0);
        c = Integer.reverse(-1);
        f = Long.reverse(6523483668573997495L);
        g = 32768 >>> 47 | 32768 << -47;
        i = (0x40000000 >>> 158 | 0x40000000 << -158) & 0xFFFFFFFF;
        c = new String[g];
        d = new String[i];
        \u039b\u03a0\u03bf\u03bc\u03c7\u0393\u03be\u03c3\u03a9\u0394.b();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u039b\u03a0\u03bf\u03bc\u03c7\u0393\u03be\u03c3\u03a9\u0394.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u00ef\u0111\u0113\u00f3\u0117\u0136\u012e\u0144\u0130\u00ff\u013d\u0133\u0141\u013b\u0104\u0129\u014b\u014a\u0142\u0148\u0142\u0117", (byte)36, 65), \u039b\u03a0\u03bf\u03bc\u03c7\u0393\u03be\u03c3\u03a9\u0394.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u0543\u0550\u054f\u0512\u0552\u054e\u0549\u0552\u055d\u054c\u0519\u0557\u055b\u0554\u0557\u055d\u051f\u088c\u0892\u08b2\u08b0\u08bc\u0889\u08b5\u08bb\u08a2\u088e\u0535", (byte)36, 69) + string + \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u051a", (byte)36, 70) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        e = -1327903460120063652L;
        long l = e ^ 0x8C11307E42C606C1L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(22 + 46), 69, (byte)(44 + 39), (byte)(29 + 18), (byte)(21 + 46), (byte)(54 + 12), (byte)(24 + 43), 47, (byte)(12 + 68), (byte)(3 + 72), (byte)(45 + 22), (byte)(18 + 65), (byte)(22 + 31), (byte)(65 + 15), (byte)(67 + 30), (byte)(18 + 82), (byte)(67 + 33), (byte)(69 + 36), (byte)(73 + 37), (byte)(27 + 76)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(14 + 69)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u039b\u03a0\u03bf\u03bc\u03c7\u0393\u03be\u03c3\u03a9\u0394.d[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u0582\u0557\u0556\u0559\u057e\u0579\u0551\u056c\u0550\u0594\u0588\u0570\u0550\u0590\u0593\u0579\u0579\u059d\u058d\u056c\u0567\u0578\u0565\u0566", (byte)86, 69);
                    continue block7;
                }
                case 1: {
                    \u039b\u03a0\u03bf\u03bc\u03c7\u0393\u03be\u03c3\u03a9\u0394.d[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u0582\u0557\u0556\u0559\u057e\u0579\u0551\u056c\u0550\u0594\u0589\u0565\u056d\u0554\u056a\u058d\u058a\u059c\u056f\u0579\u0568\u0580\u059e\u0577\u0599\u0578\u0571\u0562\u059e\u059e\u0579\u057e", (byte)86, 69);
                    continue block7;
                }
                case 2: {
                    \u039b\u03a0\u03bf\u03bc\u03c7\u0393\u03be\u03c3\u03a9\u0394.d[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u04f8\u052a\u051b\u050c\u050b\u052b\u050a\u050f\u052c\u0513\u0530\u0525\u050f\u053a\u0531\u04f9\u052a\u0512\u04f9\u0501\u0513\u0501\u0545\u0536\u051c\u053c\u0534\u0546\u0518\u053e\u050b\u0537", (byte)86, 68);
                    continue block7;
                }
                case 4: {
                    \u039b\u03a0\u03bf\u03bc\u03c7\u0393\u03be\u03c3\u03a9\u0394.d[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u0553\u0585\u056e\u0557\u0568\u0584\u0551\u0560\u0592\u056b\u0589\u056f\u0555\u0555\u0574\u0575\u055b\u0569\u0591\u058a\u0551\u0578\u0565\u0566", (byte)86, 70);
                }
            }
        }
    }

    public void lockableEvent(LockableEvent lockableEvent, byte by, byte by2) {
        if (by == 0) {
            LoginRequestEvent loginRequestEvent = (LoginRequestEvent)lockableEvent;
            Player player = loginRequestEvent.getPlayer();
            if (!player.isOnline()) {
                return;
            }
            switch (by2) {
                case 1: {
                    \u03c9\u03b4\u03c0\u03b7\u03be\u03b9\u0393\u03a3\u03c6\u03a8\u0394\u03c1\u0393\u0393.a(this.a).callEvent(loginRequestEvent);
                    break;
                }
                case 2: {
                    break;
                }
                default: {
                    throw new IllegalArgumentException((String)\u039b\u03a0\u03bf\u03bc\u03c7\u0393\u03be\u03c3\u03a9\u0394.c("\u3e80", (int)(b & c), (long)f) + by);
                }
            }
        }
    }

    public \u039b\u03a0\u03bf\u03bc\u03c7\u0393\u03be\u03c3\u03a9\u0394(\u03c9\u03b4\u03c0\u03b7\u03be\u03b9\u0393\u03a3\u03c6\u03a8\u0394\u03c1\u0393\u0393 \u03c9\u03b4\u03c0\u03b7\u03be\u03b9\u0393\u03a3\u03c6\u03a8\u0394\u03c1\u0393\u03932) {
        this.a = \u03c9\u03b4\u03c0\u03b7\u03be\u03b9\u0393\u03a3\u03c6\u03a8\u0394\u03c1\u0393\u03932;
    }

    public void lockableNewAction(LockableNewActionEvent<?> lockableNewActionEvent) {
    }
}

