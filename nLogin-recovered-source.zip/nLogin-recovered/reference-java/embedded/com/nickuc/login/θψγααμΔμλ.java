/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import java.util.concurrent.TimeUnit;

class \u03b8\u03c8\u03b3\u03b1\u03b1\u03bc\u0394\u03bc\u03bb {
    private static int a = Integer.reverse(Integer.MIN_VALUE);
    private static int b = Integer.MIN_VALUE >>> 158 | Integer.MIN_VALUE << ~158 + 1;
    private static int c = Integer.reverse(-1073741824);
    private static int f;
    private static int e;
    private static int d;
    static final /* synthetic */ int[] aj;

    static {
        d = Integer.reverse(0x20000000);
        e = 0xA00000 >>> 181 | 0xA00000 << ~181 + 1;
        f = Integer.reverse(0x60000000);
        aj = new int[TimeUnit.values().length];
        try {
            \u03b8\u03c8\u03b3\u03b1\u03b1\u03bc\u0394\u03bc\u03bb.aj[TimeUnit.MICROSECONDS.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b8\u03c8\u03b3\u03b1\u03b1\u03bc\u0394\u03bc\u03bb.aj[TimeUnit.MILLISECONDS.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b8\u03c8\u03b3\u03b1\u03b1\u03bc\u0394\u03bc\u03bb.aj[TimeUnit.SECONDS.ordinal()] = c;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b8\u03c8\u03b3\u03b1\u03b1\u03bc\u0394\u03bc\u03bb.aj[TimeUnit.MINUTES.ordinal()] = d;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b8\u03c8\u03b3\u03b1\u03b1\u03bc\u0394\u03bc\u03bb.aj[TimeUnit.HOURS.ordinal()] = e;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b8\u03c8\u03b3\u03b1\u03b1\u03bc\u0394\u03bc\u03bb.aj[TimeUnit.DAYS.ordinal()] = f;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

