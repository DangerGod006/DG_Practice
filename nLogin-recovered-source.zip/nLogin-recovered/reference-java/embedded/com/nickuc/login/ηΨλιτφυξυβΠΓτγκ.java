/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03a3\u03a3\u03c0\u03b4\u03b2\u03c9\u03a6\u03b4\u03b9\u03c2\u03b4\u03c2\u03c8\u03a3\u03c2;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

class \u03b7\u03a8\u03bb\u03b9\u03c4\u03c6\u03c5\u03be\u03c5\u03b2\u03a0\u0393\u03c4\u03b3\u03ba
implements \u03a3\u03a3\u03c0\u03b4\u03b2\u03c9\u03a6\u03b4\u03b9\u03c2\u03b4\u03c2\u03c8\u03a3\u03c2 {
    private static int b;
    private final Set<String> n;
    private static int c;
    private static int a;

    @Override
    public boolean filter(String string, String string2, Object ... objectArray) {
        if (!this.n.isEmpty()) {
            String string3 = string2.toLowerCase(Locale.ENGLISH);
            return this.n.stream().anyMatch(string3::contains);
        }
        return c != 0;
    }

    \u03b7\u03a8\u03bb\u03b9\u03c4\u03c6\u03c5\u03be\u03c5\u03b2\u03a0\u0393\u03c4\u03b3\u03ba a(String string, String ... stringArray) {
        this.n.add(string.toLowerCase(Locale.ENGLISH));
        if (stringArray.length > 0) {
            String[] stringArray2 = stringArray;
            int n = stringArray2.length;
            for (int i = b; i < n; ++i) {
                String string2 = stringArray2[i];
                this.n.add(string2.toLowerCase(Locale.ENGLISH));
            }
        }
        return this;
    }

    static {
        a = Integer.reverse(0);
        b = Integer.reverse(0);
        c = 0 >>> 157 | 0 << -157;
    }

    \u03b7\u03a8\u03bb\u03b9\u03c4\u03c6\u03c5\u03be\u03c5\u03b2\u03a0\u0393\u03c4\u03b3\u03ba(Set<String> set, String ... stringArray) {
        if (!set.isEmpty()) {
            set = set.stream().map(String::toLowerCase).collect(Collectors.toSet());
        }
        this.n = set;
        if (stringArray.length > 0) {
            String[] stringArray2 = stringArray;
            int n = stringArray2.length;
            for (int i = a; i < n; ++i) {
                String string = stringArray2[i];
                this.n.add(string.toLowerCase(Locale.ENGLISH));
            }
        }
    }
}

