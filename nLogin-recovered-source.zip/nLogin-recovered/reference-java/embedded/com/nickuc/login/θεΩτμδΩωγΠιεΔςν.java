/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityEvent
 *  org.bukkit.event.player.PlayerEvent
 *  org.bukkit.event.player.PlayerInteractAtEntityEvent
 */
package com.nickuc.login;

import com.nickuc.login.\u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8;
import com.nickuc.login.\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5;
import lombok.Generated;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityEvent;
import org.bukkit.event.player.PlayerEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;

public class \u03b8\u03b5\u03a9\u03c4\u03bc\u03b4\u03a9\u03c9\u03b3\u03a0\u03b9\u03b5\u0394\u03c2\u03bd
implements \u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8 {
    private static int b;
    private static int a;
    private final \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5 e;

    @EventHandler(priority=EventPriority.LOWEST)
    public void a(PlayerInteractAtEntityEvent playerInteractAtEntityEvent) {
        if (this.e.a((PlayerEvent)playerInteractAtEntityEvent)) {
            playerInteractAtEntityEvent.setCancelled(a != 0);
        }
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void b(EntityDamageByEntityEvent entityDamageByEntityEvent) {
        if (this.e.a((EntityEvent)entityDamageByEntityEvent)) {
            entityDamageByEntityEvent.setCancelled(b != 0);
        }
    }

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = (8192 >>> 237 | 8192 << ~237 + 1) & 0xFFFFFFFF;
    }

    @Generated
    public \u03b8\u03b5\u03a9\u03c4\u03bc\u03b4\u03a9\u03c9\u03b3\u03a0\u03b9\u03b5\u0394\u03c2\u03bd(\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5 \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b52) {
        this.e = \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b52;
    }
}

