/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7
extends Enum<\u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7> {
    public static final /* enum */ \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7 a;
    public static final /* enum */ \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7 b;
    public static final /* enum */ \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7 c;
    public static final /* enum */ \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7 d;
    public static final /* enum */ \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7 e;
    private static final /* synthetic */ \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7[] a;
    private static String[] a;
    private static String[] b;
    private static long c;
    private static int a;
    private static long b;
    private static int c;
    private static long d;
    private static int e;
    private static int f;
    private static long g;
    private static int h;
    private static int i;
    private static int j;
    private static int k;
    private static int l;
    private static int m;
    private static int n;
    private static int o;
    private static int p;
    private static int q;
    private static long r;
    private static int s;
    private static int t;
    private static int u;
    private static long v;
    private static int w;
    private static int x;
    private static int y;
    private static long z;
    private static int aa;
    private static int ab;
    private static long ac;
    private static long ad;
    private static int ae;
    private static int af;
    private static long ag;
    private static int ah;

    private static /* synthetic */ \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7[] a() {
        \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7[] \u03bb\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7Array = new \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7[h];
        \u03bb\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7Array[\u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.i] = a;
        \u03bb\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7Array[\u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.j] = b;
        \u03bb\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7Array[\u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.k] = c;
        \u03bb\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7Array[\u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.l] = d;
        \u03bb\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7Array[\u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.m] = e;
        return \u03bb\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7Array;
    }

    public static \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7[] values() {
        return (\u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7[])a.clone();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u04ef\u0511\u0513\u04f3\u0517\u0536\u052e\u0544\u0530\u04ff\u053d\u0533\u0541\u053b\u0504\u0529\u054b\u054a\u0542\u0548\u0542\u0517", (byte)11, 69), \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.A("\u00f8\u0105\u0104\u00c7\u0107\u0103\u00fe\u0107\u0112\u0101\u00ce\u010c\u0110\u0109\u010c\u0112\u00d4\u0441\u045e\u0459\u0463\u0472\u0453\u0463\u046b\u0465\u00e9", (byte)11, 65) + string + \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u00cf", (byte)11, 65) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = 5482969510757454698L;
        long l = c ^ 0x893FA9ACAF0B3957L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(28 + 40), (byte)(24 + 45), (byte)(69 + 14), (byte)(33 + 14), (byte)(23 + 44), (byte)(64 + 2), (byte)(44 + 23), (byte)(28 + 19), (byte)(74 + 6), (byte)(31 + 44), (byte)(15 + 52), (byte)(19 + 64), (byte)(5 + 48), 80, (byte)(93 + 4), (byte)(61 + 39), (byte)(18 + 82), 105, (byte)(74 + 36), (byte)(63 + 40)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(22 + 47), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u058b\u0597\u0592\u0594\u0579\u057f\u0588\u0558\u0574\u0575\u0596\u0569", (byte)101, 70);
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[1] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u019e\u01c3\u01b6\u01be\u0184\u0199\u019e\u01c9\u01c0\u01bd\u01a3\u0196\u01a3\u0199\u01b9\u019c\u01cd\u01bd\u01be\u01be\u01a7\u019f\u019c\u019d", (byte)101, 65);
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[2] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u051a\u053f\u055d\u055c\u0520\u0559\u054d\u0524\u054e\u055a\u053f\u0553\u0534\u0569\u0526\u055f\u0558\u055c\u0545\u053e\u0559\u054a\u0537\u0538", (byte)101, 67);
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[3] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u051c\u0530\u0554\u0560\u052b\u0556\u051a\u054e\u055f\u055f\u0559\u052c", (byte)101, 68);
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[4] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u0579\u0568\u056d\u0599\u057b\u0575\u0581\u058e\u05a0\u0593\u0563\u0569", (byte)101, 70);
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[5] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.C("\u0516\u055d\u055e\u055e\u055b\u0563\u053e\u055e\u052e\u0563\u0543\u052c", (byte)101, 67);
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[6] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u0571\u0592\u058b\u057a\u0596\u055a\u056c\u0570\u0582\u0573\u0570\u0569", (byte)101, 70);
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[7] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u0546\u0558\u0547\u0518\u052b\u0536\u0560\u0539\u0550\u055b\u0551\u052c", (byte)101, 67);
                    continue block7;
                }
                case 1: {
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u019b\u01c2\u0183\u01b1\u01af\u01b4\u01b4\u01b3\u01b7\u01ba\u0194\u0191", (byte)101, 66);
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[1] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u0576\u059b\u058e\u0596\u055c\u0571\u0576\u05a1\u0598\u0595\u0579\u0575\u0584\u05a8\u0586\u0573\u0573\u05a7\u0575\u0587\u0585\u0587\u0574\u0575", (byte)101, 69);
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[2] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u051a\u053f\u055d\u055c\u0520\u0559\u054d\u0524\u054e\u055a\u0541\u0546\u054a\u0549\u053c\u0527\u054b\u0569\u0564\u052b\u054f\u0560\u0537\u0538", (byte)101, 67);
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[3] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u0553\u0591\u0595\u057b\u0588\u0576\u0560\u05a0\u059a\u059d\u0592\u0569", (byte)101, 70);
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[4] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u058d\u057a\u0585\u058d\u057d\u059d\u055a\u0594\u0590\u055f\u055d\u056d\u05a3\u05a8\u05a2\u0569\u0597\u05a7\u0563\u0579\u0588\u059d\u0574\u0575", (byte)101, 70);
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[5] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.A("\u0191\u018b\u01b6\u01ae\u01bf\u01bb\u01c0\u0198\u01cb\u01ba\u019f\u01bc\u018e\u01b8\u01c7\u01bc\u019b\u018a\u01d3\u01bf\u01af\u01d5\u019c\u019d", (byte)101, 65);
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[6] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u019b\u01a2\u01b4\u0192\u01c2\u019b\u01c7\u01bb\u01cb\u0183\u019a\u01a8\u01c3\u01a3\u01ce\u019d\u01a3\u01b0\u01c3\u01d3\u019f\u019f\u019c\u019d", (byte)101, 66);
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[7] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.F("\u0575\u0594\u0588\u0588\u058f\u057b\u058f\u055d\u055e\u055b\u056f\u055c\u0585\u0564\u0563\u0587\u0561\u0562\u059e\u057e\u056a\u05ad\u0574\u0575", (byte)101, 70);
                    continue block7;
                }
                case 2: {
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.E("\u057a\u0564\u057a\u0556\u0573\u057f\u057d\u0561\u0559\u0575\u058e\u0569", (byte)101, 69);
                    continue block7;
                }
                case 4: {
                    \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u055d\u0546\u0517\u0557\u0513\u051f\u0522\u0521\u0537\u0538\u0551\u052c", (byte)101, 67);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x67L;
        l ^= 0x893FA9ACAF0B3957L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(61 + 7), (byte)(17 + 52), (byte)(60 + 23), (byte)(2 + 45), 67, (byte)(5 + 61), (byte)(39 + 28), (byte)(42 + 5), (byte)(4 + 76), (byte)(2 + 73), (byte)(53 + 14), (byte)(37 + 46), (byte)(22 + 31), (byte)(71 + 9), (byte)(8 + 89), 100, (byte)(64 + 36), (byte)(47 + 58), (byte)(102 + 8), (byte)(92 + 11)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(41 + 28), (byte)(41 + 42)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u048a\u0497\u0496\u0459\u0499\u0495\u0490\u0499\u04a4\u0493\u0460\u049e\u04a2\u049b\u049e\u04a4\u0466\u07d3\u07f0\u07eb\u07f5\u0804\u07e5\u07f5\u07fd\u07f7", (byte)38, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Generated
    private \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7() {
    }

    public String e(String string) {
        switch (this.ordinal()) {
            case 0: {
                return (String)\u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.c("\u3e80", (int)a, (long)b) + string;
            }
            case 1: {
                return (String)\u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.c("\u3e83", (int)c, (long)d) + string;
            }
            case 2: {
                return (String)\u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.c("\u3e86", (int)(e & f), (long)g) + string;
            }
        }
        return string;
    }

    public static \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7 valueOf(String string) {
        return Enum.valueOf(\u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.class, string);
    }

    static {
        a = 0 >>> 135 | 0 << ~135 + 1;
        b = Long.reverse(-5707328146457040846L);
        c = Integer.reverse(Integer.MIN_VALUE);
        d = Long.reverse(-5707328146457040846L);
        e = Integer.reverse(0x40000000);
        f = Integer.reverse(-1);
        g = Long.reverse(-5707328146457040846L);
        h = Integer.reverse(-1610612736);
        i = Integer.reverse(0);
        j = Integer.reverse(Integer.MIN_VALUE);
        k = (2048 >>> 170 | 2048 << ~170 + 1) & 0xFFFFFFFF;
        l = (0x30000000 >>> 220 | 0x30000000 << ~220 + 1) & 0xFFFFFFFF;
        m = Integer.reverse(0x20000000);
        n = Integer.reverse(0x10000000);
        o = Integer.MIN_VALUE >>> 188 | Integer.MIN_VALUE << ~188 + 1;
        p = (384 >>> 39 | 384 << -39) & 0xFFFFFFFF;
        q = (-1 >>> 46 | -1 << -46) & 0xFFFFFFFF;
        r = Long.reverse(-5707328146457040846L);
        s = 0 >>> 177 | 0 << -177;
        t = (0x1000000 >>> 118 | 0x1000000 << ~118 + 1) & 0xFFFFFFFF;
        u = Integer.reverse(-1);
        v = Long.reverse(-5707328146457040846L);
        w = 16384 >>> 14 | 16384 << ~14 + 1;
        x = Integer.reverse(-1610612736);
        y = Integer.reverse(-1);
        z = Long.reverse(-5707328146457040846L);
        aa = 65536 >>> 143 | 65536 << -143;
        ab = Integer.reverse(0x60000000);
        ac = Long.reverse(6254232463838996530L);
        ad = Long.reverse(-1873497444986126336L);
        ae = Integer.reverse(-1073741824);
        af = (0x38000000 >>> 59 | 0x38000000 << -59) & 0xFFFFFFFF;
        ag = Long.reverse(-5707328146457040846L);
        ah = Integer.reverse(0x20000000);
        a = new String[n];
        b = new String[o];
        \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.b();
        a = new \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7();
        b = new \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7();
        c = new \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7();
        d = new \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7();
        e = new \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7();
        a = \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.a();
    }
}

