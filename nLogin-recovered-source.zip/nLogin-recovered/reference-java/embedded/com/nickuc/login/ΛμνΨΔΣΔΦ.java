/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

public final class \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6 {
    public static String B(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (127 + i) - 2 * nickuc);
        }
        return new String(x);
    }

    public static String C(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (949 + i) - -3 * -nickuc);
        }
        return new String(x);
    }

    public static String F(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (1212 + i) - nickuc);
        }
        return new String(x);
    }

    public static String D(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (949 + i) - -3 * -nickuc);
        }
        return new String(x);
    }

    public static String E(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (1212 + i) - nickuc);
        }
        return new String(x);
    }

    public static String A(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (127 + i) - 2 * nickuc);
        }
        return new String(x);
    }
}

