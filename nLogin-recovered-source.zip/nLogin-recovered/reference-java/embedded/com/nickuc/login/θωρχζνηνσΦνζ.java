/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

public final class \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6 {
    public static String B(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (127 + i) - 2 * nickuc);
        }
        return new String(x);
    }

    public static String F(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (1212 + i) - nickuc);
        }
        return new String(x);
    }

    public static String E(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (1212 + i) - nickuc);
        }
        return new String(x);
    }

    public static String C(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (949 + i) - -3 * -nickuc);
        }
        return new String(x);
    }

    public static String D(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (949 + i) - -3 * -nickuc);
        }
        return new String(x);
    }

    public static String A(String www, byte nickuc, int com) {
        char[] x = new char[www.length()];
        int i = -1;
        for (char c : www.toCharArray()) {
            x[++i] = (char)(c - (127 + i) - 2 * nickuc);
        }
        return new String(x);
    }
}

