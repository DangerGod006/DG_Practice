/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be;
import com.nickuc.login.\u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2;
import java.util.Collection;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

public interface \u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9 {
    default public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer, long l, long l2) {
        return this.a(consumer, l, l2, TimeUnit.MILLISECONDS);
    }

    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Runnable var1, long var2, TimeUnit var4);

    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Runnable var1, long var2, long var4, TimeUnit var6);

    default public boolean a(int n, TimeUnit timeUnit) {
        return this.a().a(n, timeUnit);
    }

    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Runnable var1);

    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> var1, long var2, TimeUnit var4);

    default public Collection<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> f() {
        return this.a().e();
    }

    public \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2 a();

    public void Y();

    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> var1);

    default public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Runnable runnable, long l) {
        return this.a(runnable, l, TimeUnit.MILLISECONDS);
    }

    public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> var1, long var2, long var4, TimeUnit var6);

    default public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer, long l) {
        return this.a(consumer, l, TimeUnit.MILLISECONDS);
    }

    default public \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be a(Runnable runnable, long l, long l2) {
        return this.a(runnable, l, l2, TimeUnit.MILLISECONDS);
    }
}

