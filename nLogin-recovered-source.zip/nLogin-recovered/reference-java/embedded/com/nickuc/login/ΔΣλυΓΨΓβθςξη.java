/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7 {
    private static long l;
    private final String aO;
    private static long k;
    private static long d;
    private static long c;
    private static int n;
    private static String[] a;
    private static long i;
    private static int e;
    private static int q;
    private static long o;
    private static long h;
    private static int g;
    private static int b;
    private static int m;
    private static int p;
    private static long f;
    private static String[] b;
    private static int j;
    private final String aP;
    private static int a;

    @Generated
    public String E() {
        return this.aO;
    }

    private static void b() {
        int n;
        c = -5573973285080135168L;
        long l = c ^ 0xDAED0F59A7130469L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(45 + 23), (byte)(47 + 22), (byte)(17 + 66), (byte)(40 + 7), (byte)(15 + 52), (byte)(40 + 26), (byte)(24 + 43), (byte)(12 + 35), (byte)(63 + 17), (byte)(32 + 43), (byte)(27 + 40), 83, (byte)(43 + 10), (byte)(5 + 75), (byte)(96 + 1), (byte)(75 + 25), (byte)(65 + 35), (byte)(46 + 59), (byte)(67 + 43), (byte)(68 + 35)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(32 + 37), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.B("\u015c\u0141\u0155\u013a\u012f\u013b\u0166\u0141\u015b\u013d\u012b\u0131", (byte)53, 66);
                    \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.b[1] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.F("\u056a\u0525\u055c\u0566\u052b\u0550\u055d\u0543\u053b\u0551\u056a\u0539", (byte)53, 70);
                    \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.b[2] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u012d\u0137\u0124\u0153\u0144\u0155\u0161\u0167\u0133\u0166\u0149\u012d\u0143\u012e\u016b\u0170\u016f\u0151\u0133\u0131\u0142\u0142\u0162\u0149\u0132\u0139\u0157\u0152\u0157\u017c\u0155\u013d", (byte)53, 65);
                    \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.b[3] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u012a\u0138\u0151\u0156\u014f\u0124\u0141\u013b\u0144\u0156\u014c\u015b\u0148\u0148\u0161\u013c\u0171\u0170\u0155\u0143\u016a\u016f\u016e\u0148\u017b\u0155\u0166\u0169\u015e\u0139\u016a\u0141", (byte)53, 66);
                    \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.b[4] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.B("\u011c\u012d\u011b\u0136\u0162\u0122\u0165\u016a\u0133\u0154\u0134\u0131", (byte)53, 66);
                    continue block7;
                }
                case 1: {
                    \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u0132\u0130\u013f\u0123\u0133\u0125\u0131\u0138\u0122\u0159\u013c\u0131", (byte)53, 65);
                    \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.b[1] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.A("\u011d\u0140\u015a\u0124\u0132\u015b\u015e\u0138\u0138\u0147\u015a\u0131", (byte)53, 65);
                    \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.b[2] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.D("\u0498\u04a2\u048f\u04be\u04af\u04c0\u04cc\u04d2\u049e\u04d1\u04b4\u0498\u04ae\u0499\u04d6\u04db\u04da\u04bc\u049e\u049c\u04ad\u04b7\u04b8\u049a\u04e0\u04c4\u049f\u04c8\u04d8\u04dd\u04d7\u04b5", (byte)53, 68);
                    \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.b[3] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u0495\u04a3\u04bc\u04c1\u04ba\u048f\u04ac\u04a6\u04af\u04c1\u04b7\u04c6\u04b3\u04b3\u04cc\u04a7\u04dc\u04db\u04c0\u04ae\u04d5\u04d7\u04cc\u04cd\u04ae\u04c3\u04d4\u04bc\u04bc\u04e8\u04a4\u04dc", (byte)53, 68);
                    \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.b[4] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.E("\u0536\u0522\u0541\u055a\u054b\u052f\u0559\u055c\u0570\u0550\u0572\u0539", (byte)53, 69);
                    continue block7;
                }
                case 2: {
                    \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u056b\u0558\u056b\u052b\u0567\u054e\u054e\u0528\u0552\u0544\u0548\u0539", (byte)53, 70);
                    continue block7;
                }
                case 4: {
                    \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.F("\u0561\u054c\u0548\u0541\u052e\u0566\u055f\u0568\u0529\u053e\u054c\u0539", (byte)53, 70);
                }
            }
        }
    }

    static {
        a = Integer.reverse(0);
        b = Integer.reverse(-1);
        d = Long.reverse(1031344974184228173L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Long.reverse(1031344974184228173L);
        g = Integer.reverse(0x40000000);
        h = Long.reverse(22538657653237069L);
        i = Long.reverse(0xE00000000000000L);
        j = Integer.reverse(-1073741824);
        k = Long.reverse(22538657653237069L);
        l = Long.reverse(0xE00000000000000L);
        m = 4 >>> 64 | 4 << -64;
        n = Integer.reverse(-1);
        o = Long.reverse(1031344974184228173L);
        p = Integer.reverse(-1610612736);
        q = 0xA00000 >>> 213 | 0xA00000 << ~213 + 1;
        a = new String[p];
        b = new String[q];
        \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.b();
    }

    @Generated
    public \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7(String string, String string2) {
        this.aO = string;
        this.aP = string2;
    }

    private static String a(int n, long l) {
        l ^= 0x70L;
        l ^= 0xDAED0F59A7130469L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(3 + 65), (byte)(60 + 9), (byte)(28 + 55), 47, (byte)(2 + 65), (byte)(10 + 56), (byte)(29 + 38), 47, (byte)(20 + 60), (byte)(27 + 48), (byte)(32 + 35), (byte)(72 + 11), (byte)(35 + 18), (byte)(20 + 60), (byte)(55 + 42), (byte)(59 + 41), (byte)(16 + 84), (byte)(17 + 88), (byte)(6 + 104), (byte)(67 + 36)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(38 + 31), (byte)(79 + 4)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u016e\u017b\u017a\u013d\u017d\u0179\u0174\u017d\u0188\u0177\u0144\u0182\u0186\u017f\u0182\u0188\u014a\u04b0\u04c0\u04d9\u04e4\u04b3\u04c9\u04b5\u04d5\u04dc\u04e7\u04e4\u04de", (byte)70, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.E("\u04e9\u050b\u050d\u04ed\u0511\u0530\u0528\u053e\u052a\u04f9\u0537\u052d\u053b\u0535\u04fe\u0523\u0545\u0544\u053c\u0542\u053c\u0511", (byte)5, 69), \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0524\u0531\u0530\u04f3\u0533\u052f\u052a\u0533\u053e\u052d\u04fa\u0538\u053c\u0535\u0538\u053e\u0500\u0866\u0876\u088f\u089a\u0869\u087f\u086b\u088b\u0892\u089d\u089a\u0894\u0518", (byte)5, 69) + string + \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u04fb", (byte)5, 70) + methodType.toString(), exception);
        }
    }

    @Generated
    public String F() {
        return this.aP;
    }

    public static \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7 a(String string, String string2) {
        return new \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7(string2.replace((CharSequence)\u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.c("\u3e80", (int)(a & b), (long)d), (CharSequence)\u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.c("\u3e83", (int)e, (long)f)), string);
    }

    @Generated
    public String toString() {
        return (String)\u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.c("\u3e80", (int)g, (long)(h ^ i)) + this.E() + (String)\u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.c("\u3e83", (int)j, (long)(k ^ l)) + this.F() + (String)\u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7.c("\u3e86", (int)(m & n), (long)o);
    }
}

