/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.PacketEvents
 *  com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent
 *  com.nickuc.login.lib.packetevents.api.netty.channel.ChannelHelper
 *  com.nickuc.login.lib.packetevents.api.protocol.player.User
 *  com.nickuc.login.lib.packetevents.api.wrapper.PacketWrapper
 *  com.nickuc.login.lib.packetevents.api.wrapper.configuration.client.WrapperConfigClientSelectKnownPacks
 *  io.netty.buffer.ByteBuf
 *  io.netty.channel.Channel
 */
package com.nickuc.login;

import com.nickuc.login.lib.packetevents.api.PacketEvents;
import com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent;
import com.nickuc.login.lib.packetevents.api.netty.channel.ChannelHelper;
import com.nickuc.login.lib.packetevents.api.protocol.player.User;
import com.nickuc.login.lib.packetevents.api.wrapper.PacketWrapper;
import com.nickuc.login.lib.packetevents.api.wrapper.configuration.client.WrapperConfigClientSelectKnownPacks;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3;
import com.nickuc.login.\u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bc\u03a6\u03be\u03b2\u03b5\u03c4\u03b4\u03bc\u03b3;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4;
import io.netty.buffer.ByteBuf;
import io.netty.channel.Channel;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b2\u0393\u03c4\u03be\u03a6\u0393\u03c8\u03b4
implements \u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6 {
    private static String[] a;
    private static int b;
    private static String[] b;
    private static int d;
    private static int f;
    private static long c;
    private static long e;
    final /* synthetic */ \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8 d;
    private static int c;
    private static int a;
    private static int g;

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = (0 >>> 195 | 0 << -195) & 0xFFFFFFFF;
        c = Integer.MIN_VALUE >>> 255 | Integer.MIN_VALUE << ~255 + 1;
        d = (0 >>> 189 | 0 << -189) & 0xFFFFFFFF;
        e = Long.reverse(-1023616021484679879L);
        f = 262144 >>> 18 | 262144 << -18;
        g = Integer.reverse(Integer.MIN_VALUE);
        a = new String[f];
        b = new String[g];
        \u03b2\u0393\u03c4\u03be\u03a6\u0393\u03c8\u03b4.b();
    }

    @Override
    public void a(PacketReceiveEvent packetReceiveEvent) {
        \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2;
        Channel channel = (Channel)packetReceiveEvent.getChannel();
        if (!channel.hasAttr(\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4.c)) {
            return;
        }
        \u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4 \u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b42 = (\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4)channel.attr(\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4.c).get();
        if (\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b42 == null || \u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b42.f != 0) {
            return;
        }
        WrapperConfigClientSelectKnownPacks wrapperConfigClientSelectKnownPacks = new WrapperConfigClientSelectKnownPacks(packetReceiveEvent);
        User user = packetReceiveEvent.getUser();
        if (this.d.a(user, \u03c5\u03b7\u03b7\u03a0\u03c7\u039b\u03b3\u03be2 = bl -> {
            if (bl) {
                this.a(user, (PacketWrapper<?>)wrapperConfigClientSelectKnownPacks);
            }
        })) {
            if (\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.a(this.d).L()) {
                Object object = packetReceiveEvent.getPlayer();
                if (object != null) {
                    \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.a(this.d).b().a(object);
                    \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.a(this.d).a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
                    \u03bc\u03a6\u03be\u03b2\u03b5\u03c4\u03b4\u03bc\u03b3 \u03bc\u03a6\u03be\u03b2\u03b5\u03c4\u03b4\u03bc\u03b32 = (\u03bc\u03a6\u03be\u03b2\u03b5\u03c4\u03b4\u03bc\u03b3)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.a(this.d).c();
                    String string = \u03bc\u03a6\u03be\u03b2\u03b5\u03c4\u03b4\u03bc\u03b32.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
                    if (string != null) {
                        \u03bc\u03a6\u03be\u03b2\u03b5\u03c4\u03b4\u03bc\u03b32.a().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, string);
                    }
                }
                packetReceiveEvent.setCancelled(a != 0);
            }
        } else {
            channel.attr(\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4.c).set(null);
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b2\u0393\u03c4\u03be\u03a6\u0393\u03c8\u03b4.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u052c\u054e\u0550\u0530\u0554\u0573\u056b\u0581\u056d\u053c\u057a\u0570\u057e\u0578\u0541\u0566\u0588\u0587\u057f\u0585\u057f\u0554", (byte)72, 70), \u03b2\u0393\u03c4\u03be\u03a6\u0393\u03c8\u03b4.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u04f0\u04fd\u04fc\u04bf\u04ff\u04fb\u04f6\u04ff\u050a\u04f9\u04c6\u0504\u0508\u0501\u0504\u050a\u04cc\u0850\u0832\u0864\u085f\u0848\u0836\u086c\u0859\u04e0", (byte)72, 68) + string + \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u053e", (byte)72, 70) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x4AL;
        l ^= 0x8F94EA9B67897964L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(18 + 50), 69, (byte)(36 + 47), (byte)(2 + 45), (byte)(50 + 17), 66, (byte)(46 + 21), (byte)(14 + 33), (byte)(70 + 10), (byte)(21 + 54), (byte)(33 + 34), (byte)(29 + 54), (byte)(19 + 34), (byte)(10 + 70), (byte)(94 + 3), (byte)(94 + 6), (byte)(63 + 37), (byte)(88 + 17), (byte)(32 + 78), (byte)(7 + 96)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(68 + 1), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u055b\u0568\u0567\u052a\u056a\u0566\u0561\u056a\u0575\u0564\u0531\u056f\u0573\u056c\u056f\u0575\u0537\u08bb\u089d\u08cf\u08ca\u08b3\u08a1\u08d7\u08c4", (byte)60, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b2\u0393\u03c4\u03be\u03a6\u0393\u03c8\u03b4.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static void b() {
        int n;
        c = -7155233840615205947L;
        long l = c ^ 0x8F94EA9B67897964L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(49 + 19), (byte)(44 + 25), (byte)(7 + 76), (byte)(19 + 28), (byte)(12 + 55), (byte)(38 + 28), (byte)(41 + 26), (byte)(19 + 28), (byte)(24 + 56), (byte)(5 + 70), (byte)(52 + 15), (byte)(18 + 65), (byte)(22 + 31), (byte)(28 + 52), 97, (byte)(26 + 74), (byte)(21 + 79), (byte)(11 + 94), (byte)(102 + 8), 103}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(25 + 58)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b2\u0393\u03c4\u03be\u03a6\u0393\u03c8\u03b4.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.B("\u00cc\u00e9\u00fa\u0100\u00fd\u00e6\u00d7\u00f4\u00f8\u00e5\u00d4\u00d6\u00d5\u010d\u00e0\u00ed\u00f8\u00ca\u00d0\u00c5\u00dd\u00f1\u00ed\u00d7\u00e4\u00eb\u0116\u00ee\u00dc\u00d5\u011d\u010e", (byte)4, 66);
                    continue block7;
                }
                case 1: {
                    \u03b2\u0393\u03c4\u03be\u03a6\u0393\u03c8\u03b4.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u0406\u0423\u0434\u043a\u0437\u0420\u0411\u042e\u0432\u041f\u040e\u0410\u040f\u0447\u041a\u0427\u0432\u0404\u040a\u03ff\u0417\u042d\u0410\u0446\u0446\u0451\u0434\u0414\u044d\u042a\u0418\u0413\u042b\u0416\u0425\u045e\u0426\u043b\u0452\u043a\u041f\u045d\u0438\u0429", (byte)4, 68);
                    continue block7;
                }
                case 2: {
                    \u03b2\u0393\u03c4\u03be\u03a6\u0393\u03c8\u03b4.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u00bd\u00d7\u0100\u00cb\u0102\u00be\u00e3\u00d2\u00d5\u00c8\u00e6\u00cf", (byte)4, 65);
                    continue block7;
                }
                case 4: {
                    \u03b2\u0393\u03c4\u03be\u03a6\u0393\u03c8\u03b4.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0525\u0530\u0532\u0537\u0513\u0507\u04f6\u0510\u0541\u0522\u0531\u0508", (byte)4, 69);
                }
            }
        }
    }

    private void a(User user, PacketWrapper<?> packetWrapper) {
        if (((\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3)\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8.a(this.d).b()).a().L()) {
            Channel channel = (Channel)user.getChannel();
            packetWrapper.prepareForSend((Object)channel, b != 0, c != 0);
            ByteBuf byteBuf = (ByteBuf)packetWrapper.buffer;
            if (byteBuf == null) {
                throw new IllegalStateException((String)\u03b2\u0393\u03c4\u03be\u03a6\u0393\u03c8\u03b4.c("\u3e80", (int)d, (long)e));
            }
            if (ChannelHelper.isOpen((Object)channel)) {
                ChannelHelper.fireChannelReadInContext((Object)channel, (String)PacketEvents.DECODER_NAME, (Object)byteBuf);
            } else {
                byteBuf.release();
            }
        } else {
            user.receivePacketSilently(packetWrapper);
        }
    }

    public \u03b2\u0393\u03c4\u03be\u03a6\u0393\u03c8\u03b4(\u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c8 \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c82) {
        this.d = \u03b1\u03bb\u03bc\u03a3\u03a9\u03c4\u03c8\u03c6\u03b3\u03b6\u03b7\u03b8\u03be\u03c82;
    }
}

