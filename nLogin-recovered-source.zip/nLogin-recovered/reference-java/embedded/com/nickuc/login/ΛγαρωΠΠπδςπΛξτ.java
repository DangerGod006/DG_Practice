/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import lombok.Generated;

public class \u039b\u03b3\u03b1\u03c1\u03c9\u03a0\u03a0\u03c0\u03b4\u03c2\u03c0\u039b\u03be\u03c4 {
    private final boolean an;
    private static int a = (0 >>> 107 | 0 << -107) & 0xFFFFFFFF;
    private final String[] d;

    @Generated
    private \u039b\u03b3\u03b1\u03c1\u03c9\u03a0\u03a0\u03c0\u03b4\u03c2\u03c0\u039b\u03be\u03c4(String[] stringArray, boolean bl) {
        this.d = stringArray;
        this.an = bl;
    }

    public static \u039b\u03b3\u03b1\u03c1\u03c9\u03a0\u03a0\u03c0\u03b4\u03c2\u03c0\u039b\u03be\u03c4 a(String ... stringArray) {
        return \u039b\u03b3\u03b1\u03c1\u03c9\u03a0\u03a0\u03c0\u03b4\u03c2\u03c0\u039b\u03be\u03c4.a(a != 0, stringArray);
    }

    public static \u039b\u03b3\u03b1\u03c1\u03c9\u03a0\u03a0\u03c0\u03b4\u03c2\u03c0\u039b\u03be\u03c4 a(boolean bl, String ... stringArray) {
        return new \u039b\u03b3\u03b1\u03c1\u03c9\u03a0\u03a0\u03c0\u03b4\u03c2\u03c0\u039b\u03be\u03c4(stringArray, bl);
    }

    @Generated
    public String[] a() {
        return this.d;
    }

    @Generated
    public boolean t() {
        return this.an;
    }
}

