/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03c5\u03a3\u03b1\u039b\u03c6\u03a3\u03c5\u03c7\u03a3\u03b9\u03c0\u03c9\u03bc;

class \u03a0\u03b9\u03c3\u03bb\u03b6\u03c1\u03c3\u03a3\u03ba\u03b3\u03b7\u03b1\u03b9\u03bf\u03bb {
    static final /* synthetic */ int[] c;
    private static int b;
    private static int a;

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = (0x8000000 >>> 90 | 0x8000000 << -90) & 0xFFFFFFFF;
        c = new int[\u03c5\u03a3\u03b1\u039b\u03c6\u03a3\u03c5\u03c7\u03a3\u03b9\u03c0\u03c9\u03bc.values().length];
        try {
            \u03a0\u03b9\u03c3\u03bb\u03b6\u03c1\u03c3\u03a3\u03ba\u03b3\u03b7\u03b1\u03b9\u03bf\u03bb.c[\u03c5\u03a3\u03b1\u039b\u03c6\u03a3\u03c5\u03c7\u03a3\u03b9\u03c0\u03c9\u03bc.d.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03a0\u03b9\u03c3\u03bb\u03b6\u03c1\u03c3\u03a3\u03ba\u03b3\u03b7\u03b1\u03b9\u03bf\u03bb.c[\u03c5\u03a3\u03b1\u039b\u03c6\u03a3\u03c5\u03c7\u03a3\u03b9\u03c0\u03c9\u03bc.b.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

