/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent
 *  com.nickuc.login.lib.packetevents.api.event.PacketSendEvent
 *  com.nickuc.login.lib.packetevents.api.protocol.player.User
 *  io.netty.channel.Channel
 *  io.netty.util.AttributeKey
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent;
import com.nickuc.login.lib.packetevents.api.event.PacketSendEvent;
import com.nickuc.login.lib.packetevents.api.protocol.player.User;
import com.nickuc.login.\u0393\u03b9\u03c4\u03c7\u03b6\u03b4\u0393\u03a0;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9;
import com.nickuc.login.\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bc\u03b8\u03bf\u03b4\u03b7\u03bf\u03a0\u03bd\u03a6\u039b\u03bd\u03be\u039b;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b1;
import io.netty.channel.Channel;
import io.netty.util.AttributeKey;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3
implements \u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6,
\u03bc\u03b8\u03bf\u03b4\u03b7\u03bf\u03a0\u03bd\u03a6\u039b\u03bd\u03be\u039b {
    private static long f;
    private static int af;
    private static long s;
    private static int an;
    private static int ag;
    private static long ak;
    private static int v;
    private static int n;
    private static long ar;
    private static int e;
    private static long aj;
    private static int at;
    private static long d;
    private static long l;
    private static int aq;
    private static int az;
    private final \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 z;
    private static int ai;
    private static int y;
    private static long z;
    private static int as;
    private static int h;
    private static int al;
    private static long ac;
    private static long o;
    private static long au;
    private static int a;
    private static long ao;
    private static int i;
    private static int g;
    private static long ae;
    private static int m;
    private static int j;
    private static int ah;
    private static int ap;
    private static long ay;
    private static int ax;
    private static int ba;
    private static int ad;
    private static int ab;
    private static long k;
    private static int q;
    private static long w;
    private static long b;
    private static int aw;
    private static int av;
    private static int u;
    private static long c;
    private static int am;
    private static String[] a;
    private static String[] b;
    private static long t;
    private static int aa;
    private static int x;
    private static long p;
    private static int r;

    @Override
    public void a(PacketReceiveEvent packetReceiveEvent) {
        User user = packetReceiveEvent.getUser();
        Channel channel = (Channel)packetReceiveEvent.getChannel();
        \u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b1 \u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b12 = (\u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b1)channel.attr((AttributeKey)\u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b1.f).get();
        if (\u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b12 == null) {
            String string = (String)\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.c("\u3e80", (int)a, (long)(b ^ d)) + user.getName() + (String)\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.c("\u3e83", (int)e, (long)f);
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c(string, new Object[g]);
            String[] stringArray = new String[h];
            stringArray[\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.i] = \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.c("\u3e86", (int)j, (long)(k ^ l));
            stringArray[\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.m] = \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.c("\u3e89", (int)n, (long)(o ^ p));
            stringArray[\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.q] = (String)\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.c("\u3e8c", (int)r, (long)(s ^ t)) + string;
            stringArray[\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.u] = \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.c("\u3e8f", (int)v, (long)w);
            stringArray[\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.x] = \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.c("\u3e92", (int)y, (long)z);
            \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.i(user, \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(stringArray));
            return;
        }
        String string = \u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b12.d();
        InetAddress inetAddress = user.getAddress().getAddress();
        \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 = \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.a(string, inetAddress);
        switch (\u0393\u03b9\u03c4\u03c7\u03b6\u03b4\u0393\u03a0.Q[\u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.ordinal()]) {
            case 1: 
            case 2: {
                \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.a(this.z, string, inetAddress, \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.a);
            }
        }
    }

    @Generated
    public \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        this.z = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.B("\u0169\u018b\u018d\u016d\u0191\u01b0\u01a8\u01be\u01aa\u0179\u01b7\u01ad\u01bb\u01b5\u017e\u01a3\u01c5\u01c4\u01bc\u01c2\u01bc\u0191", (byte)97, 66), \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u01a4\u01b1\u01b0\u0173\u01b3\u01af\u01aa\u01b3\u01be\u01ad\u017a\u01b8\u01bc\u01b5\u01b8\u01be\u0180\u050d\u0519\u04f4\u04fe\u050b\u0518\u0512\u0514\u04fd\u0195", (byte)97, 65) + string + \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u0512", (byte)97, 67) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x6DL;
        l ^= 0x183543F1679F2384L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(54 + 14), (byte)(32 + 37), 83, (byte)(37 + 10), (byte)(47 + 20), (byte)(8 + 58), (byte)(15 + 52), (byte)(42 + 5), (byte)(49 + 31), 75, (byte)(7 + 60), (byte)(12 + 71), (byte)(52 + 1), (byte)(30 + 50), (byte)(19 + 78), (byte)(48 + 52), (byte)(14 + 86), (byte)(71 + 34), (byte)(80 + 30), (byte)(15 + 88)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(37 + 31), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.B("\u01cc\u01d9\u01d8\u019b\u01db\u01d7\u01d2\u01db\u01e6\u01d5\u01a2\u01e0\u01e4\u01dd\u01e0\u01e6\u01a8\u0535\u0541\u051c\u0526\u0533\u0540\u053a\u053c\u0525", (byte)117, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = (0 >>> 220 | 0 << -220) & 0xFFFFFFFF;
        b = Long.reverse(-3100098962525242912L);
        d = Long.reverse(-5332261958806667264L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Long.reverse(7132079390860524000L);
        g = Integer.reverse(0);
        h = -1610612736 >>> 61 | -1610612736 << -61;
        i = 0 >>> 119 | 0 << ~119 + 1;
        j = 128 >>> 134 | 128 << -134;
        k = Long.reverse(-3100098962525242912L);
        l = Long.reverse(-5332261958806667264L);
        m = Integer.reverse(Integer.MIN_VALUE);
        n = (0xC00000 >>> 22 | 0xC00000 << ~22 + 1) & 0xFFFFFFFF;
        o = Long.reverse(-3100098962525242912L);
        p = Long.reverse(-5332261958806667264L);
        q = Integer.reverse(0x40000000);
        r = Integer.reverse(0x20000000);
        s = Long.reverse(-3100098962525242912L);
        t = Long.reverse(-5332261958806667264L);
        u = Integer.reverse(-1073741824);
        v = Integer.reverse(-1610612736);
        w = Long.reverse(7132079390860524000L);
        x = Integer.reverse(0x20000000);
        y = 24576 >>> 172 | 24576 << ~172 + 1;
        z = Long.reverse(7132079390860524000L);
        aa = (0x1C0000 >>> 242 | 0x1C0000 << -242) & 0xFFFFFFFF;
        ab = Integer.reverse(-1);
        ac = Long.reverse(7132079390860524000L);
        ad = (4096 >>> 73 | 4096 << ~73 + 1) & 0xFFFFFFFF;
        ae = Long.reverse(7132079390860524000L);
        af = (0 >>> 75 | 0 << -75) & 0xFFFFFFFF;
        ag = 2560 >>> 137 | 2560 << -137;
        ah = (0 >>> 112 | 0 << ~112 + 1) & 0xFFFFFFFF;
        ai = -1879048192 >>> 220 | -1879048192 << ~220 + 1;
        aj = Long.reverse(-3100098962525242912L);
        ak = Long.reverse(-5332261958806667264L);
        al = (16 >>> 68 | 16 << -68) & 0xFFFFFFFF;
        am = Integer.reverse(0x50000000);
        an = Integer.reverse(-1);
        ao = Long.reverse(7132079390860524000L);
        ap = Integer.reverse(0x40000000);
        aq = Integer.reverse(-805306368);
        ar = Long.reverse(7132079390860524000L);
        as = Integer.reverse(-1073741824);
        at = (96 >>> 67 | 96 << ~67 + 1) & 0xFFFFFFFF;
        au = Long.reverse(7132079390860524000L);
        av = Integer.reverse(0x20000000);
        aw = Integer.reverse(-1342177280);
        ax = (-1 >>> 38 | -1 << ~38 + 1) & 0xFFFFFFFF;
        ay = Long.reverse(7132079390860524000L);
        az = Integer.reverse(0x70000000);
        ba = Integer.reverse(0x70000000);
        a = new String[az];
        b = new String[ba];
        \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b();
    }

    @Override
    public void a(PacketSendEvent packetSendEvent) {
        InetAddress inetAddress;
        String string;
        User user = packetSendEvent.getUser();
        Channel channel = (Channel)packetSendEvent.getChannel();
        \u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b1 \u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b12 = (\u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b1)channel.attr((AttributeKey)\u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b1.f).get();
        if (\u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b12 == null) {
            String string2 = (String)\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.c("\u3e80", (int)(aa & ab), (long)ac) + user.getName() + (String)\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.c("\u3e83", (int)ad, (long)ae);
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c(string2, new Object[af]);
            String[] stringArray = new String[ag];
            stringArray[\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.ah] = \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.c("\u3e86", (int)ai, (long)(aj ^ ak));
            stringArray[\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.al] = \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.c("\u3e89", (int)(am & an), (long)ao);
            stringArray[\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.ap] = (String)\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.c("\u3e8c", (int)aq, (long)ar) + string2;
            stringArray[\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.as] = \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.c("\u3e8f", (int)at, (long)au);
            stringArray[\u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.av] = \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.c("\u3e92", (int)(aw & ax), (long)ay);
            \u03b1\u03c5\u03bc\u03be\u03c4\u03c5\u03b6\u03a9.i(user, \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(stringArray));
            return;
        }
        \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 = \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.a(string = \u03c9\u03a6\u039b\u03a9\u03bc\u03c5\u03bd\u03b8\u03c6\u03c2\u03c2\u03ba\u03b1\u03b12.d(), inetAddress = user.getAddress().getAddress());
        \u03bd\u03ba\u03c3\u03a9\u03bd\u03bd\u03bf\u03c8\u03be.a(this.z, string, inetAddress, \u03bb\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5 == \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.b ? \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.d : \u039b\u03a8\u03a8\u03b3\u03b4\u03c3\u03ba\u03bd\u03c8\u03bd\u03b5.e);
    }

    private static void b() {
        int n;
        c = 548318017050402603L;
        long l = c ^ 0x183543F1679F2384L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(64 + 4), (byte)(47 + 22), (byte)(5 + 78), (byte)(39 + 8), 67, (byte)(22 + 44), (byte)(17 + 50), (byte)(39 + 8), (byte)(53 + 27), (byte)(2 + 73), (byte)(30 + 37), (byte)(10 + 73), (byte)(21 + 32), (byte)(30 + 50), (byte)(31 + 66), (byte)(91 + 9), (byte)(32 + 68), 105, (byte)(89 + 21), (byte)(3 + 100)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(43 + 25), 69, (byte)(49 + 34)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u051e\u0509\u052d\u054e\u0529\u054c\u0520\u052a\u051f\u0546\u052f\u0523\u0554\u0546\u0558\u0538\u0551\u0556\u0559\u0553\u0554\u0538\u0533\u051a\u0559\u0539\u052d\u0543\u0519\u0563\u053f\u0523\u0521\u0539\u0558\u055f\u055a\u052b\u053d\u0540\u0547\u056a\u0548\u0533\u0563\u0553\u0543\u0536\u054a\u0569\u0570\u0575\u0558\u056e\u0561\u0541\u0557\u054e\u055a\u055b\u0568\u0551\u0586\u0552", (byte)22, 69);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[1] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u00ee\u0125\u00e6\u00fe\u00f8\u00fe\u00ea\u0123\u0116\u012d\u010a\u012b\u00e7\u011b\u00fb\u012f\u00f4\u0108\u00e8\u0136\u010b\u012b\u0139\u0108\u010a\u0110\u010c\u0133\u0130\u0129\u0101\u0123\u0102\u010e\u0103\u0106\u0140\u0119\u0120\u0102\u0126\u0123\u010c\u014c\u010e\u011a\u0142\u0131\u0110\u0122\u014b\u0154\u0130\u0110\u0122\u014a\u0124\u011b\u0159\u013f\u012b\u0134\u012b\u0151\u0135\u011f\u011f\u0135\u0162\u015f\u0156\u015b\u0158\u0164\u015a\u0159\u012e\u0144\u0164\u0125\u0166\u016f\u0169\u0134\u0164\u0167\u013e\u013f", (byte)22, 65);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[2] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u0125\u0113\u00e5\u0103\u011d\u00f5\u010b\u0105\u011a\u012b\u0126\u010e\u0126\u011d\u0127\u012d\u00ea\u00eb\u0125\u00f1\u0137\u0111\u00fe\u00ff", (byte)22, 65);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[3] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u043c\u046b\u045f\u0449\u0426\u0453\u0468\u046f\u0431\u0461\u045a\u043f", (byte)22, 67);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[4] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u045b\u0468\u0451\u0460\u0467\u0462\u045e\u044e\u0437\u046b\u0474\u043f", (byte)22, 68);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[5] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u043c\u046b\u045f\u0449\u0426\u0453\u0468\u046f\u0431\u0461\u045a\u043f", (byte)22, 67);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[6] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u0122\u0104\u0112\u00e0\u00da\u00f5\u00e1\u00e1\u010b\u0123\u010e\u0109\u0126\u010a\u011b\u0127\u0102\u0102\u00ed\u00ed\u0129\u0132\u012a\u0125\u012a\u00f3\u0115\u0115\u012c\u00fb\u0110\u013c\u0133\u00fb\u012e\u010f\u0112\u0139\u014a\u0123\u0143\u011d\u012d\u0144\u012a\u0146\u014a\u012b\u014d\u0130\u013f\u0135\u0118\u0121\u011e\u011f", (byte)22, 65);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[7] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u0443\u042e\u0452\u0473\u044e\u0471\u0445\u044f\u0444\u046b\u0454\u0448\u0479\u046b\u047d\u045d\u0476\u047b\u047e\u0478\u0479\u045d\u0458\u043f\u047e\u045e\u0452\u0468\u043e\u0488\u0464\u0448\u0446\u045e\u047d\u0484\u047f\u0450\u0462\u0465\u046c\u048f\u046d\u0458\u0488\u0478\u0468\u045b\u046f\u048e\u0495\u049a\u047d\u0493\u0486\u0466\u047c\u0473\u047f\u0480\u048d\u0476\u04ab\u0477", (byte)22, 67);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[8] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.E("\u0515\u054c\u050d\u0525\u051f\u0525\u0511\u054a\u053d\u0554\u0531\u0552\u050e\u0542\u0522\u0556\u051b\u052f\u050f\u055d\u0532\u0552\u0560\u052f\u0531\u0537\u0533\u055a\u0557\u0550\u0528\u054a\u0529\u0535\u052a\u052d\u0567\u0540\u0547\u0529\u054d\u054a\u0533\u0573\u0535\u0541\u0569\u0558\u0537\u0549\u0572\u057b\u0557\u0537\u0549\u0571\u054b\u0542\u0580\u0566\u0552\u055b\u0552\u0578\u055c\u0546\u0546\u055c\u0589\u0586\u057d\u0582\u057f\u058b\u0581\u0580\u0555\u056b\u058b\u054c\u058d\u0596\u0590\u055b\u058b\u058e\u0565\u0566", (byte)22, 69);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[9] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u0125\u0113\u00e5\u0103\u011d\u00f5\u010b\u0105\u011a\u012b\u0126\u010e\u0126\u011d\u0127\u012d\u00ea\u00eb\u0125\u00f1\u0137\u0111\u00fe\u00ff", (byte)22, 65);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[10] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0517\u0546\u053a\u0524\u0501\u052e\u0543\u054a\u050c\u053c\u0535\u051a", (byte)22, 69);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[11] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u010f\u011c\u0105\u0114\u011b\u0116\u0112\u0102\u00eb\u011f\u0128\u00f3", (byte)22, 65);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[12] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u00f0\u011f\u0113\u00fd\u00da\u0107\u011c\u0123\u00e5\u0115\u010e\u00f3", (byte)22, 66);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[13] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.F("\u0549\u052b\u0539\u0507\u0501\u051c\u0508\u0508\u0532\u054a\u0535\u0530\u054d\u0531\u0542\u054e\u0529\u0529\u0514\u0514\u0550\u0559\u0551\u054c\u0551\u051a\u053c\u053c\u0553\u0522\u0537\u0563\u055a\u0522\u0555\u0536\u0539\u0560\u0571\u054a\u056a\u0544\u0554\u056b\u0551\u056d\u0571\u0552\u0574\u0557\u0566\u055c\u053f\u0548\u0545\u0546", (byte)22, 70);
                    continue block7;
                }
                case 1: {
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u00f7\u00e2\u0106\u0127\u0102\u0125\u00f9\u0103\u00f8\u011f\u0108\u00fc\u012d\u011f\u0131\u0111\u012a\u012f\u0132\u012c\u012d\u0111\u010c\u00f3\u0132\u0112\u0106\u011c\u00f2\u013c\u0118\u00fc\u00fa\u0112\u0131\u0138\u0133\u0104\u0116\u0119\u0120\u0143\u0121\u010c\u013c\u012c\u011c\u010f\u0123\u0142\u0149\u014e\u0131\u014d\u0112\u0112\u0119\u014f\u014b\u0133\u012b\u0136\u011f\u011c", (byte)22, 65);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[1] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.F("\u0515\u054c\u050d\u0525\u051f\u0525\u0511\u054a\u053d\u0554\u0531\u0552\u050e\u0542\u0522\u0556\u051b\u052f\u050f\u055d\u0532\u0552\u0560\u052f\u0531\u0537\u0533\u055a\u0557\u0550\u0528\u054a\u0529\u0535\u052a\u052d\u0567\u0540\u0547\u0529\u054d\u054a\u0533\u0573\u0535\u0541\u0569\u0558\u0537\u0549\u0572\u057b\u0557\u0537\u0549\u0571\u054b\u0542\u0580\u0566\u0552\u055b\u0552\u0578\u055c\u0546\u0546\u055c\u0589\u0586\u057d\u0582\u057f\u058b\u0581\u056f\u058f\u0593\u0581\u0589\u0588\u0553\u059e\u0550\u0591\u059e\u0565\u0566", (byte)22, 70);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[2] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.E("\u054c\u053a\u050c\u052a\u0544\u051c\u0532\u052c\u0541\u0552\u054d\u0555\u0558\u052a\u0549\u0530\u0559\u0527\u053d\u0519\u051d\u054e\u0525\u0526", (byte)22, 69);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[3] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.D("\u0427\u0471\u0446\u043d\u0471\u044a\u0472\u0445\u0444\u0437\u0468\u043f", (byte)22, 68);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[4] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u011b\u0112\u0117\u0126\u0129\u0106\u00e8\u0102\u0108\u0104\u0128\u00f3", (byte)22, 65);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[5] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.A("\u0121\u00d7\u0114\u00f7\u0108\u0119\u00e0\u00f9\u011b\u0124\u0124\u00f3", (byte)22, 65);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[6] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u0549\u052b\u0539\u0507\u0501\u051c\u0508\u0508\u0532\u054a\u0535\u0530\u054d\u0531\u0542\u054e\u0529\u0529\u0514\u0514\u0550\u0559\u0551\u054c\u0551\u051a\u053c\u053c\u0553\u0522\u0537\u0563\u055a\u0522\u0555\u0536\u0539\u0560\u0571\u054a\u056a\u0544\u0552\u054f\u054c\u0534\u0533\u0575\u0533\u0537\u056d\u055c\u0548\u0558\u0545\u0546", (byte)22, 69);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[7] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.D("\u0443\u042e\u0452\u0473\u044e\u0471\u0445\u044f\u0444\u046b\u0454\u0448\u0479\u046b\u047d\u045d\u0476\u047b\u047e\u0478\u0479\u045d\u0458\u043f\u047e\u045e\u0452\u0468\u043e\u0488\u0464\u0448\u0446\u045e\u047d\u0484\u047f\u0450\u0462\u0465\u046c\u048f\u046d\u0458\u0488\u0478\u0468\u045b\u046f\u048e\u0495\u049a\u047d\u0496\u0494\u0480\u04a1\u0460\u047e\u04a2\u0495\u04a5\u048a\u04b0", (byte)22, 68);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[8] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.E("\u0515\u054c\u050d\u0525\u051f\u0525\u0511\u054a\u053d\u0554\u0531\u0552\u050e\u0542\u0522\u0556\u051b\u052f\u050f\u055d\u0532\u0552\u0560\u052f\u0531\u0537\u0533\u055a\u0557\u0550\u0528\u054a\u0529\u0535\u052a\u052d\u0567\u0540\u0547\u0529\u054d\u054a\u0533\u0573\u0535\u0541\u0569\u0558\u0537\u0549\u0572\u057b\u0557\u0537\u0549\u0571\u054b\u0542\u0580\u0566\u0552\u055b\u0552\u0578\u055c\u0546\u0546\u055c\u0589\u0586\u057d\u0582\u057f\u058b\u057f\u058a\u0572\u0591\u054f\u0591\u0551\u056d\u055c\u0599\u0577\u0568\u0565\u0566", (byte)22, 69);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[9] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u054c\u053a\u050c\u052a\u0544\u051c\u0532\u052c\u0541\u0552\u054e\u0532\u054d\u0513\u0537\u0549\u0523\u055a\u0519\u054f\u054c\u0528\u0525\u0526", (byte)22, 69);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[10] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u00e1\u011c\u011a\u0118\u00f8\u0115\u010b\u0116\u00f4\u012a\u00fa\u00f3", (byte)22, 66);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[11] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u00fe\u0101\u00d8\u00de\u0103\u0115\u00e8\u0120\u0127\u0128\u010e\u00f3", (byte)22, 66);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[12] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0514\u0545\u054b\u050e\u051e\u054d\u051e\u050d\u0512\u050f\u050c\u051a", (byte)22, 70);
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[13] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0549\u052b\u0539\u0507\u0501\u051c\u0508\u0508\u0532\u054a\u0535\u0530\u054d\u0531\u0542\u054e\u0529\u0529\u0514\u0514\u0550\u0559\u0551\u054c\u0551\u051a\u053c\u053c\u0553\u0522\u0537\u0563\u055a\u0522\u0555\u0536\u0539\u0560\u0571\u054a\u056a\u0544\u0553\u0543\u0560\u0536\u0554\u0559\u0559\u0532\u0553\u057e\u054f\u057e\u0545\u0546", (byte)22, 70);
                    continue block7;
                }
                case 2: {
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u00fc\u0110\u011a\u0105\u00fb\u00fa\u012a\u0101\u00e9\u0100\u00e9\u00e8\u00f9\u0132\u00ec\u0103\u0103\u010e\u010b\u00f5\u00ea\u0111\u00fe\u00ff", (byte)22, 66);
                    continue block7;
                }
                case 4: {
                    \u03bb\u03c6\u03a0\u03a9\u03b5\u03c1\u03ba\u03bb\u03a3.b[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u0444\u042c\u0448\u046f\u0446\u0475\u046a\u0440\u0460\u0459\u044f\u0456\u0456\u045d\u046f\u043e\u047a\u0437\u0479\u047c\u044d\u045d\u044a\u044b", (byte)22, 68);
                }
            }
        }
    }
}

