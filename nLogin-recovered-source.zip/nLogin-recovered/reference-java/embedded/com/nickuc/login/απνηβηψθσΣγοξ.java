/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03c8\u03bd\u03c1\u03c9\u03ba\u03bb\u03b1\u0393\u03c2\u03c3\u03bb\u03b6\u03c2\u03a3;

public interface \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be
extends \u03c8\u03bd\u03c1\u03c9\u03ba\u03bb\u03b1\u0393\u03c2\u03c3\u03bb\u03b6\u03c2\u03a3 {
    public boolean P();

    public String t();

    public void Z();
}

