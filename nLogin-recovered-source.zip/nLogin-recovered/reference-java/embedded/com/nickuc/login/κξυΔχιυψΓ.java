/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import lombok.Generated;

public class \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393 {
    int ab = a;
    final String bB;
    final int aa;
    private static int a = -1 >>> 146 | -1 << ~146 + 1;

    public int t() {
        return this.ab;
    }

    @Generated
    public \u03ba\u03be\u03c5\u0394\u03c7\u03b9\u03c5\u03c8\u0393(String string, int n) {
        this.bB = string;
        this.aa = n;
    }

    public int s() {
        return this.aa;
    }

    public String ad() {
        return this.bB;
    }
}

