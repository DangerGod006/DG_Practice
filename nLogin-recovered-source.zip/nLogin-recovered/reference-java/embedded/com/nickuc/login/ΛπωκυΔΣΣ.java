/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.Server
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.ConsoleCommandSender
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6;
import com.nickuc.login.\u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a8;
import com.nickuc.login.\u03c4\u03c0\u03c4\u03bd\u03bc\u03c8\u03bf\u03c2\u03a3\u03c5\u03bd;
import lombok.Generated;
import org.bukkit.Server;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u039b\u03c0\u03c9\u03ba\u03c5\u0394\u03a3\u03a3
implements \u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a8 {
    private static int d;
    private static int b;
    private static int a;
    private final Server b;
    private static int c;
    private final ConsoleCommandSender a;

    static {
        a = Integer.reverse(0x40000000);
        b = (0 >>> 149 | 0 << ~149 + 1) & 0xFFFFFFFF;
        c = 12032 >>> 200 | 12032 << ~200 + 1;
        d = 0x10000000 >>> 252 | 0x10000000 << -252;
    }

    @Override
    public <T> T c() {
        return (T)this.a;
    }

    public static \u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a8 a(Server server, ConsoleCommandSender consoleCommandSender) {
        return consoleCommandSender != null ? new \u039b\u03c0\u03c9\u03ba\u03c5\u0394\u03a3\u03a3(server, consoleCommandSender) : \u03c4\u03c0\u03c4\u03bd\u03bc\u03c8\u03bf\u03c2\u03a3\u03c5\u03bd.a;
    }

    @Override
    public void l(String string) {
        if (string.length() >= a && string.charAt(b) == c) {
            string = string.substring(d);
        }
        if (this.b.isPrimaryThread()) {
            this.b.dispatchCommand((CommandSender)this.a, string);
        } else {
            String string2 = string;
            \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.a(() -> this.b.dispatchCommand((CommandSender)this.a, string2));
        }
    }

    @Override
    public boolean i(String string) {
        return this.a.hasPermission(string);
    }

    @Override
    public void k(String string) {
        this.a.sendMessage(string);
    }

    @Override
    public String getName() {
        return this.a.getName();
    }

    @Generated
    private \u039b\u03c0\u03c9\u03ba\u03c5\u0394\u03a3\u03a3(Server server, ConsoleCommandSender consoleCommandSender) {
        this.b = server;
        this.a = consoleCommandSender;
    }
}

