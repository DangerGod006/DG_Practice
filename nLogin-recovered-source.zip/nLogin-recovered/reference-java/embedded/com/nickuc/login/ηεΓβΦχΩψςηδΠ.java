/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.List;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0
extends Enum<\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0> {
    public static final /* enum */ \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0 b;
    public static final /* enum */ \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0 c;
    public static final /* enum */ \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0 d;
    public static final /* enum */ \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0 e;
    private final boolean aQ;
    private static final /* synthetic */ \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0[] a;
    private static String[] a;
    private static String[] b;
    private static long c;
    private static int a;
    private static int b;
    private static int c;
    private static int d;
    private static int e;
    private static int f;
    private static int g;
    private static int h;
    private static int i;
    private static int j;
    private static long k;
    private static long l;
    private static int m;
    private static int n;
    private static int o;
    private static int p;
    private static long q;
    private static int r;
    private static int s;
    private static int t;
    private static long u;
    private static long v;
    private static int w;
    private static int x;
    private static int y;
    private static long z;
    private static int aa;
    private static int ab;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.B("\u00c9\u00eb\u00ed\u00cd\u00f1\u0110\u0108\u011e\u010a\u00d9\u0117\u010d\u011b\u0115\u00de\u0103\u0125\u0124\u011c\u0122\u011c\u00f1", (byte)17, 66), \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0530\u053d\u053c\u04ff\u053f\u053b\u0536\u053f\u054a\u0539\u0506\u0544\u0548\u0541\u0544\u054a\u050c\u0895\u0894\u0873\u0893\u0888\u08aa\u088d\u08ad\u08a8\u089e\u089c\u0889\u0524", (byte)17, 70) + string + \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u0422", (byte)17, 67) + methodType.toString(), exception);
        }
    }

    static {
        a = 8 >>> 131 | 8 << ~131 + 1;
        b = 0 >>> 228 | 0 << -228;
        c = (0x4000000 >>> 216 | 0x4000000 << ~216 + 1) & 0xFFFFFFFF;
        d = (0 >>> 232 | 0 << ~232 + 1) & 0xFFFFFFFF;
        e = Integer.reverse(Integer.MIN_VALUE);
        f = (1 >>> 191 | 1 << ~191 + 1) & 0xFFFFFFFF;
        g = 0xC000000 >>> 58 | 0xC000000 << -58;
        h = 0x1000000 >>> 86 | 0x1000000 << -86;
        i = (Integer.MIN_VALUE >>> 157 | Integer.MIN_VALUE << ~157 + 1) & 0xFFFFFFFF;
        j = Integer.reverse(0);
        k = Long.reverse(-7505802007922535235L);
        l = Long.reverse(-4035225266123964416L);
        m = Integer.reverse(0);
        n = (64 >>> 230 | 64 << -230) & 0xFFFFFFFF;
        o = Integer.reverse(Integer.MIN_VALUE);
        p = Integer.reverse(-1);
        q = Long.reverse(6905716799663051965L);
        r = Integer.reverse(Integer.MIN_VALUE);
        s = Integer.reverse(Integer.MIN_VALUE);
        t = Integer.reverse(0x40000000);
        u = Long.reverse(-7505802007922535235L);
        v = Long.reverse(-4035225266123964416L);
        w = Integer.reverse(0x40000000);
        x = Integer.reverse(0);
        y = Integer.reverse(-1073741824);
        z = Long.reverse(6905716799663051965L);
        aa = Integer.reverse(-1073741824);
        ab = Integer.reverse(0);
        a = new String[h];
        b = new String[i];
        \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.b();
        b = new \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0(n != 0);
        c = new \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0(s != 0);
        d = new \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0(x != 0);
        e = new \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0(ab != 0);
        a = \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.a();
    }

    @Generated
    private \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0(boolean bl) {
        this.aQ = bl;
    }

    public static \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0[] values() {
        return (\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0[])a.clone();
    }

    @Generated
    public boolean aQ() {
        return this.aQ;
    }

    private static /* synthetic */ \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0[] a() {
        \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0[] \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0Array = new \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0[c];
        \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0Array[\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.d] = b;
        \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0Array[\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.e] = c;
        \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0Array[\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.f] = d;
        \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0Array[\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.g] = e;
        return \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0Array;
    }

    public static \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0 valueOf(String string) {
        return Enum.valueOf(\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.class, string);
    }

    private static void b() {
        int n;
        c = -4816394352063386647L;
        long l = c ^ 0x15FA6DD318A2BC1AL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(3 + 65), (byte)(2 + 67), (byte)(32 + 51), (byte)(33 + 14), (byte)(25 + 42), (byte)(24 + 42), (byte)(58 + 9), (byte)(39 + 8), (byte)(6 + 74), (byte)(61 + 14), (byte)(26 + 41), (byte)(28 + 55), (byte)(26 + 27), (byte)(6 + 74), 97, (byte)(34 + 66), (byte)(21 + 79), (byte)(17 + 88), (byte)(12 + 98), (byte)(55 + 48)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(53 + 16), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u04c2\u04b1\u049a\u0498\u0484\u0499\u04b0\u0491\u04c6\u04ba\u048a\u0490", (byte)49, 68);
                    \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.b[1] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u048f\u04b6\u047c\u04c5\u04ae\u04b0\u0483\u04c2\u04bd\u049a\u04c5\u0490", (byte)49, 67);
                    \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.b[2] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.E("\u0567\u0519\u0551\u053a\u0559\u0525\u0525\u054a\u055a\u0561\u056e\u0535", (byte)49, 69);
                    \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.b[3] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u0525\u0537\u0527\u0535\u0545\u0524\u0541\u0556\u0541\u0570\u0544\u0535", (byte)49, 69);
                    continue block7;
                }
                case 1: {
                    \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.C("\u0489\u0495\u0481\u0498\u04b6\u048f\u0494\u04c9\u0480\u04c0\u04ac\u04ac\u0484\u049c\u0487\u04c1\u04ac\u04c8\u04ae\u049e\u04be\u04c4\u049b\u049c", (byte)49, 67);
                    \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.b[1] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u0490\u04a0\u0493\u049e\u04c1\u04b5\u04c4\u04b5\u04c9\u04c5\u04a6\u0482\u0484\u04c0\u04a5\u04a1\u048e\u048a\u049b\u04a3\u04d4\u04d4\u049b\u049c", (byte)49, 68);
                    \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.b[2] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u0136\u0145\u015a\u0152\u014c\u012b\u0134\u013e\u0161\u0130\u014c\u0136\u0164\u015a\u0160\u015d\u0137\u0135\u015e\u014e\u0149\u015d\u0134\u0135", (byte)49, 65);
                    \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.b[3] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u0112\u0147\u012f\u0139\u013b\u012d\u0139\u014c\u012e\u0153\u011f\u0122\u0140\u0123\u0124\u0135\u0139\u015d\u0136\u012d\u0146\u016d\u0134\u0135", (byte)49, 66);
                    continue block7;
                }
                case 2: {
                    \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.F("\u0558\u0544\u051a\u0557\u0532\u0529\u054b\u0563\u054b\u052d\u0522\u054e\u0549\u0564\u056c\u053e\u0565\u0555\u054a\u0530\u052c\u0553\u0540\u0541", (byte)49, 70);
                    continue block7;
                }
                case 4: {
                    \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u04ae\u04bd\u049f\u0499\u047b\u04b5\u0480\u04b6\u04a0\u04bb\u0493\u0494\u0496\u0484\u0498\u04a9\u048c\u04aa\u04a7\u04a9\u04cb\u04d4\u049b\u049c", (byte)49, 68);
                }
            }
        }
    }

    public static \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0 a(String string) {
        String string2 = string.toLowerCase();
        boolean bl = \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.c(\u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3.k(), string2);
        boolean bl2 = \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.c(\u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3.l(), string2);
        if (bl && bl2) {
            return e;
        }
        if (bl) {
            return b;
        }
        if (bl2) {
            return c;
        }
        return d;
    }

    private static boolean c(List<Pattern> list, String string) {
        for (Pattern pattern : list) {
            if (!pattern.matcher(string).matches()) continue;
            return a != 0;
        }
        return b != 0;
    }

    private static String a(int n, long l) {
        l ^= 0x13L;
        l ^= 0x15FA6DD318A2BC1AL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(28 + 41), (byte)(78 + 5), (byte)(22 + 25), (byte)(29 + 38), (byte)(10 + 56), (byte)(24 + 43), (byte)(10 + 37), (byte)(38 + 42), (byte)(63 + 12), (byte)(57 + 10), (byte)(74 + 9), (byte)(47 + 6), 80, (byte)(16 + 81), (byte)(78 + 22), (byte)(23 + 77), (byte)(19 + 86), (byte)(27 + 83), (byte)(63 + 40)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(70 + 13)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0528\u0535\u0534\u04f7\u0537\u0533\u052e\u0537\u0542\u0531\u04fe\u053c\u0540\u0539\u053c\u0542\u0504\u088d\u088c\u086b\u088b\u0880\u08a2\u0885\u08a5\u08a0\u0896\u0894\u0881", (byte)9, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }
}

