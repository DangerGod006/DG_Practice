/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.enums.event.EventEnum
 *  com.nickuc.login.api.enums.event.UnregisterSource
 *  com.nickuc.login.api.enums.event.UpdatePasswordSource
 */
package com.nickuc.login;

import com.nickuc.login.api.enums.event.EventEnum;
import com.nickuc.login.api.enums.event.UnregisterSource;
import com.nickuc.login.api.enums.event.UpdatePasswordSource;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b5\u03ba\u0393\u03b3\u03a3\u0394\u03c6\u03c5\u03b5\u039b\u03a9\u03c1;
import com.nickuc.login.\u03b5\u03be\u03bd\u03c3\u0394\u03c7\u03a3\u03b5\u03b8\u03b8\u03b6\u0394\u03b1\u03a0\u03b6;
import com.nickuc.login.\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b8\u0393\u03c9\u03a9\u03c0\u03b3\u03a9\u03a9\u0394\u03b2\u03a8\u03c9;
import com.nickuc.login.\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6
extends \u03b5\u03ba\u0393\u03b3\u03a3\u0394\u03c6\u03c5\u03b5\u039b\u03a9\u03c1 {
    private static long aw;
    private static int bx;
    private static int bg;
    private static int cl;
    private static int bb;
    private static int cn;
    private static int bt;
    private static int au;
    private static int bq;
    private static int ch;
    private static long ca;
    private static int cm;
    private static int bk;
    private static long ba;
    private static long az;
    private static long e;
    private static int bn;
    private static int bo;
    private static int ce;
    private static int bz;
    private static int cc;
    private static long ax;
    private static int br;
    private static int bj;
    private static int co;
    private static int bl;
    private static int a;
    private static long bc;
    private static int bm;
    private static int bv;
    private static int ci;
    private static int cf;
    private static int bw;
    private static long cb;
    private static long bi;
    private static int cg;
    private static long cd;
    private static String[] d;
    private static long bh;
    private static long bd;
    private static long bf;
    private static int by;
    private static int bp;
    private static int ay;
    private static int bu;
    private static int be;
    private static int av;
    private static String[] c;
    private static int ck;
    private static int cj;
    private static int bs;

    public \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6(\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9 \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92) {
        super(\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92);
        this.b();
    }

    static {
        a = (16384 >>> 206 | 16384 << ~206 + 1) & 0xFFFFFFFF;
        au = Integer.reverse(0);
        av = (0 >>> 177 | 0 << -177) & 0xFFFFFFFF;
        aw = Long.reverse(9141060873788961178L);
        ax = Long.reverse(-6773413839565225984L);
        ay = Integer.reverse(Integer.MIN_VALUE);
        az = Long.reverse(9141060873788961178L);
        ba = Long.reverse(-6773413839565225984L);
        bb = 0x40000000 >>> 125 | 0x40000000 << ~125 + 1;
        bc = Long.reverse(9141060873788961178L);
        bd = Long.reverse(-6773413839565225984L);
        be = 3 >>> 32 | 3 << ~32 + 1;
        bf = Long.reverse(-2532269360355364454L);
        bg = Integer.reverse(0x20000000);
        bh = Long.reverse(9141060873788961178L);
        bi = Long.reverse(-6773413839565225984L);
        bj = Integer.reverse(0x40000000);
        bk = 0 >>> 32 | 0 << -32;
        bl = (0x10000000 >>> 156 | 0x10000000 << ~156 + 1) & 0xFFFFFFFF;
        bm = (0 >>> 156 | 0 << -156) & 0xFFFFFFFF;
        bn = Integer.reverse(Integer.MIN_VALUE);
        bo = (0 >>> 71 | 0 << ~71 + 1) & 0xFFFFFFFF;
        bp = Integer.reverse(0);
        bq = (0 >>> 206 | 0 << ~206 + 1) & 0xFFFFFFFF;
        br = Integer.reverse(0);
        bs = (32 >>> 163 | 32 << -163) & 0xFFFFFFFF;
        bt = Integer.reverse(0);
        bu = (Integer.MIN_VALUE >>> 159 | Integer.MIN_VALUE << ~159 + 1) & 0xFFFFFFFF;
        bv = Integer.reverse(0x40000000);
        bw = 0x3000000 >>> 24 | 0x3000000 << -24;
        bx = (0 >>> 191 | 0 << -191) & 0xFFFFFFFF;
        by = 0 >>> 12 | 0 << ~12 + 1;
        bz = 81920 >>> 46 | 81920 << ~46 + 1;
        ca = Long.reverse(9141060873788961178L);
        cb = Long.reverse(-6773413839565225984L);
        cc = 0x18000000 >>> 250 | 0x18000000 << ~250 + 1;
        cd = Long.reverse(-2532269360355364454L);
        ce = Integer.reverse(0);
        cf = (0x40000001 >>> 62 | 0x40000001 << -62) & 0xFFFFFFFF;
        cg = (0 >>> 126 | 0 << ~126 + 1) & 0xFFFFFFFF;
        ch = 8 >>> 99 | 8 << -99;
        ci = (0x100000 >>> 147 | 0x100000 << ~147 + 1) & 0xFFFFFFFF;
        cj = Integer.reverse(-1073741824);
        ck = Integer.reverse(0x20000000);
        cl = Integer.reverse(0);
        cm = Integer.reverse(0);
        cn = 114688 >>> 78 | 114688 << ~78 + 1;
        co = Integer.reverse(-536870912);
        c = new String[cn];
        d = new String[co];
        \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.b();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String string, String[] stringArray) {
        block11: {
            String string2;
            if (!(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2 instanceof \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)) {
                Object[] objectArray = new Object[a];
                objectArray[\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.au] = (String)\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.c("\u3e80", (int)av, (long)(aw ^ ax)) + (String)(stringArray.length > 0 ? \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.c("\u3e83", (int)ay, (long)(az ^ ba)) : \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.c("\u3e86", (int)bb, (long)(bc ^ bd))) + String.join((CharSequence)\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.c("\u3e89", (int)be, (long)bf), stringArray);
                \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.x, objectArray);
                return;
            }
            \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = (\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2;
            if (stringArray.length == 0) {
                Object[] objectArray = new Object[bj];
                objectArray[\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.bk] = string;
                objectArray[\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.bl] = \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.D, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, new Object[bm]);
                String string3 = String.format((String)\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.c("\u3e8c", (int)bg, (long)(bh ^ bi)), objectArray);
                Object[] objectArray2 = new Object[bn];
                objectArray2[\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.bo] = string3;
                \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.x, objectArray2);
                return;
            }
            \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = ((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)this.a).a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
            \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92 = \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a();
            if (!\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.h() || \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.t() && !\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.s()) {
                \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.t, new Object[bp]);
                \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b5\u03be\u03bd\u03c3\u0394\u03c7\u03a3\u03b5\u03b8\u03b8\u03b6\u0394\u03b1\u03a0\u03b6.F);
                return;
            }
            \u03c2\u03b8\u0393\u03c9\u03a9\u03c0\u03b3\u03a9\u03a9\u0394\u03b2\u03a8\u03c9 \u03c2\u03b8\u0393\u03c9\u03a9\u03c0\u03b3\u03a9\u03a9\u0394\u03b2\u03a8\u03c92 = ((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)this.a).a();
            if (!\u03c2\u03b8\u0393\u03c9\u03a9\u03c0\u03b3\u03a9\u03a9\u0394\u03b2\u03a8\u03c92.a(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92, string2 = stringArray[bq])) {
                \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.P, new Object[br]);
                \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b5\u03be\u03bd\u03c3\u0394\u03c7\u03a3\u03b5\u03b8\u03b8\u03b6\u0394\u03b1\u03a0\u03b6.F);
                return;
            }
            String string4 = \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.getName();
            UUID uUID = \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a();
            Object[] objectArray = new Object[bs];
            objectArray[\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.bt] = \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
            objectArray[\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.bu] = uUID;
            objectArray[\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.bv] = string4;
            objectArray[\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.bw] = UnregisterSource.BY_PLAYER;
            if (!((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)this.a).a(EventEnum.UNREGISTER, objectArray)) break block11;
            Object object = \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.c;
            synchronized (object) {
                if (!\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.h()) {
                    \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.t, new Object[bx]);
                    \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b5\u03be\u03bd\u03c3\u0394\u03c7\u03a3\u03b5\u03b8\u03b8\u03b6\u0394\u03b1\u03a0\u03b6.F);
                    return;
                }
                if (!\u03c2\u03b8\u0393\u03c9\u03a9\u03c0\u03b3\u03a9\u03a9\u0394\u03b2\u03a8\u03c92.a(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92)) {
                    \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.w, new Object[by]);
                    \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b5\u03be\u03bd\u03c3\u0394\u03c7\u03a3\u03b5\u03b8\u03b8\u03b6\u0394\u03b1\u03a0\u03b6.F);
                    return;
                }
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.b((String)\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.c("\u3e8f", (int)bz, (long)(ca ^ cb)) + string4 + (String)\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.c("\u3e92", (int)cc, (long)cd) + \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.ac(), new Object[ce]);
                try {
                    Object[] objectArray3 = new Object[cf];
                    objectArray3[\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.cg] = \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
                    objectArray3[\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.ch] = uUID;
                    objectArray3[\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.ci] = string4;
                    objectArray3[\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.cj] = null;
                    objectArray3[\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.ck] = UpdatePasswordSource.BY_PLAYER;
                    ((\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)this.a).a(EventEnum.PASSWORD_UPDATE_EVENT, objectArray3);
                    \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.q, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, new Object[cl]));
                }
                catch (Throwable throwable) {
                    \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.q, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, new Object[cm]));
                    throw throwable;
                }
            }
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u013f\u0161\u0163\u0143\u0167\u0186\u017e\u0194\u0180\u014f\u018d\u0183\u0191\u018b\u0154\u0179\u019b\u019a\u0192\u0198\u0192\u0167", (byte)76, 66), \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u056b\u0578\u0577\u053a\u057a\u0576\u0571\u057a\u0585\u0574\u0541\u057f\u0583\u057c\u057f\u0585\u0547\u08ac\u08cb\u08e1\u08d4\u08d8\u08b2\u08b3\u08d6\u08e2\u08b6\u08d6\u08d6\u08dd\u08cc\u0561", (byte)76, 70) + string + \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.C("\u04d3", (byte)76, 67) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        e = 6452979006043708286L;
        long l = e ^ 0x8E347392A464DA08L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(57 + 11), (byte)(43 + 26), (byte)(75 + 8), (byte)(31 + 16), (byte)(4 + 63), (byte)(38 + 28), (byte)(16 + 51), 47, (byte)(38 + 42), (byte)(17 + 58), (byte)(42 + 25), (byte)(49 + 34), (byte)(33 + 20), (byte)(70 + 10), (byte)(21 + 76), (byte)(49 + 51), (byte)(88 + 12), (byte)(45 + 60), (byte)(49 + 61), 103}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(26 + 43), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u0547\u0567\u0536\u054f\u0554\u0554\u052d\u0559\u0578\u0535\u0558\u0540\u056a\u0576\u056b\u0579\u0584\u0586\u057f\u0560\u0545\u0563\u0567\u054c\u0546\u056e\u0567\u0570\u0582\u058d\u0573\u0554", (byte)64, 70);
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[1] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.E("\u0565\u0531\u0566\u0560\u0567\u0562\u057c\u056f\u056f\u055e\u0553\u0544", (byte)64, 69);
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[2] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0554\u052f\u0568\u0534\u0542\u0570\u0559\u057a\u056d\u0573\u055f\u0544", (byte)64, 69);
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[3] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.D("\u04de\u04aa\u04df\u04d9\u04e0\u04db\u04f5\u04e8\u04e8\u04d7\u04cc\u04bd", (byte)64, 68);
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[4] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u0150\u0174\u0159\u014f\u0172\u015a\u015d\u013d\u0181\u0170\u0138\u0176\u017d\u0184\u0173\u0152\u0181\u015f\u0145\u0159\u0186\u0155\u0152\u0153", (byte)64, 65);
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[5] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.B("\u0140\u0167\u0156\u0134\u0149\u0145\u017d\u0178\u0150\u0173\u0174\u0147", (byte)64, 66);
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[6] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u04ae\u04d0\u04ce\u04c2\u04ed\u04d3\u04cd\u04a7\u04d0\u04e1\u04c8\u04f9\u04ef\u04ca\u04d6\u04e5\u04ed\u04f0\u04fd\u04ea\u04bd\u04c0\u04b6\u04d9\u04bd\u04fb\u04ff\u04ea\u04fc\u04e9\u04df\u04d9\u04e0\u0505\u04e0\u04dd\u04e8\u04cd\u04ee\u0502\u050c\u04d0\u050f\u04f6\u04d8\u0518\u04f3\u0512\u04ea\u04ee\u04d6\u0518\u0518\u04f5\u0505\u04f6\u0518\u04f4\u04f5\u04ff\u0529\u04e5\u0515\u04f5", (byte)64, 67);
                    continue block7;
                }
                case 1: {
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.D("\u04c0\u04e0\u04af\u04c8\u04cd\u04cd\u04a6\u04d2\u04f1\u04ae\u04d1\u04b9\u04e3\u04ef\u04e4\u04f2\u04fd\u04ff\u04f8\u04d9\u04be\u04ed\u04f1\u0506\u04d2\u0503\u0501\u04d8\u0502\u04e1\u04e2\u04d5", (byte)64, 68);
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[1] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u053e\u0530\u053f\u054f\u0545\u0539\u0552\u0554\u0556\u0572\u054f\u0544", (byte)64, 69);
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[2] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.E("\u0575\u0572\u054f\u052f\u0553\u0542\u054d\u0535\u057e\u0576\u053a\u0544", (byte)64, 69);
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[3] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u0168\u0164\u0166\u0169\u014c\u017e\u0135\u015d\u015e\u016e\u0170\u0147", (byte)64, 65);
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[4] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u04c6\u04ea\u04cf\u04c5\u04e8\u04d0\u04d3\u04b3\u04f7\u04e6\u04ae\u04e2\u04ec\u04db\u04e4\u04bc\u04ea\u04bc\u04ba\u04eb\u04d6\u04f1\u04c8\u04c9", (byte)64, 68);
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[5] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u0164\u0159\u0163\u0135\u0137\u0171\u0157\u014c\u0149\u016e\u0156\u0147", (byte)64, 66);
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[6] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.D("\u04ae\u04d0\u04ce\u04c2\u04ed\u04d3\u04cd\u04a7\u04d0\u04e1\u04c8\u04f9\u04ef\u04ca\u04d6\u04e5\u04ed\u04f0\u04fd\u04ea\u04bd\u04c0\u04b6\u04d9\u04bd\u04fb\u04ff\u04ea\u04fc\u04e9\u04df\u04d9\u04e0\u0505\u04e0\u04dd\u04e8\u04cd\u04ee\u0502\u050c\u04d0\u050f\u04f6\u04d8\u0518\u04f3\u0512\u04ea\u04ee\u04d6\u0518\u0518\u04f2\u0523\u0512\u0514\u0518\u04ff\u04f3\u052a\u0527\u0523\u04ed", (byte)64, 68);
                    continue block7;
                }
                case 2: {
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u04cb\u04ae\u04c9\u04d0\u04e7\u04c8\u04ed\u04df\u04be\u04eb\u04f5\u04c7\u04f5\u04cb\u04b6\u04f9\u04dd\u04e7\u04dd\u04b9\u04ce\u04c1\u04e5\u04d4\u04df\u04dd\u04d4\u04ff\u04fb\u04e0\u04e4\u04bf", (byte)64, 67);
                    continue block7;
                }
                case 4: {
                    \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.d[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u012f\u014d\u0156\u017c\u0175\u0156\u0146\u0139\u016f\u0180\u0160\u017e\u014f\u0185\u015e\u0173\u0185\u0161\u017a\u0175\u0174\u0155\u0152\u0153", (byte)64, 65);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x45L;
        l ^= 0x8E347392A464DA08L;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(63 + 5), (byte)(37 + 32), (byte)(4 + 79), (byte)(40 + 7), (byte)(51 + 16), (byte)(44 + 22), (byte)(50 + 17), 47, (byte)(78 + 2), (byte)(65 + 10), (byte)(39 + 28), (byte)(17 + 66), (byte)(23 + 30), (byte)(62 + 18), (byte)(3 + 94), 100, (byte)(88 + 12), (byte)(60 + 45), (byte)(10 + 100), (byte)(27 + 76)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(50 + 19), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u056f\u057c\u057b\u053e\u057e\u057a\u0575\u057e\u0589\u0578\u0545\u0583\u0587\u0580\u0583\u0589\u054b\u08b0\u08cf\u08e5\u08d8\u08dc\u08b6\u08b7\u08da\u08e6\u08ba\u08da\u08da\u08e1\u08d0", (byte)80, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u0393\u03b1\u03c6\u03b8\u03bb\u0394\u0394\u03b6\u03c1\u0394\u03b3\u03b2\u03b8\u03a6.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }
}

