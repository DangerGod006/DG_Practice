/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  com.mojang.authlib.properties.Property
 *  com.nickuc.login.lib.packetevents.impl.util.SpigotReflectionUtil
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.nickuc.login.lib.packetevents.impl.util.SpigotReflectionUtil;
import com.nickuc.login.\u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c8\u0394\u03bb\u03b2\u03a0\u03b2\u03c6\u03c4\u03be\u03b6\u03c9\u03b5\u03b5\u03c4;
import com.nickuc.login.\u03c9\u03bf\u03bc\u03a6\u03b4\u0394\u03c0\u03bd\u03a8\u03b5\u03b2\u03c5\u0393;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
class \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5 {
    private static long ab;
    private static String[] b;
    private static long q;
    private static int ai;
    private static int b;
    private static long k;
    private static int j;
    private static long ag;
    private static int u;
    private static String[] a;
    private static int w;
    private static int o;
    private static long ae;
    private static int aa;
    private static int z;
    private static int ad;
    private static int g;
    private static int ac;
    private static int l;
    private static int e;
    private static int y;
    private static long f;
    private static int t;
    private static int s;
    private static long c;
    private static int m;
    private static int n;
    private static int af;
    private static int a;
    private static long d;
    private static long h;
    private static boolean az;
    private static Field n;
    private static Field m;
    private static int p;
    private static long r;
    private static int x;
    private static int v;
    private static long i;
    private static int ah;

    private static void b() {
        int n;
        c = -1133248401576290700L;
        long l = c ^ 0xAC8D77BE5C572A55L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(21 + 47), (byte)(48 + 21), (byte)(24 + 59), (byte)(27 + 20), 67, (byte)(39 + 27), (byte)(6 + 61), 47, (byte)(51 + 29), (byte)(50 + 25), (byte)(42 + 25), (byte)(40 + 43), (byte)(41 + 12), (byte)(66 + 14), (byte)(26 + 71), (byte)(32 + 68), (byte)(87 + 13), (byte)(31 + 74), (byte)(45 + 65), (byte)(70 + 33)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(24 + 45), (byte)(54 + 29)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u01a7\u01be\u01da\u01cd\u01f3\u01e8\u01cb\u01e2\u01d5\u01b7\u01d0\u01f7\u01db\u01f8\u01d5\u01bf\u01ba\u01f7\u01bc\u01d2\u01f9\u01c3\u01c1\u01f1\u0204\u01fb\u0203\u01d5\u01ec\u01e7\u01c5\u01ef\u01e8\u0208\u020a\u020a\u01f4\u01e1\u0207\u01ec\u0211\u0217\u01f2\u01df", (byte)124, 66);
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[1] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.E("\u056e\u058c\u0582\u05a6\u05b0\u05b6\u058c\u0581\u0590\u0597\u0593\u0580", (byte)124, 69);
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[2] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.C("\u055c\u0590\u057b\u055b\u057f\u059e\u059a\u059f\u0587\u0563\u059a\u0571", (byte)124, 67);
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[3] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u05a3\u0571\u0597\u0565\u05a7\u0567\u0576\u0583\u0565\u0584\u0576\u05ac\u0565\u058b\u0570\u0579\u05aa\u05b2\u0582\u05b4\u0582\u058e\u0595\u0583\u0572\u058b\u05aa\u0590\u05ab\u0598\u05ab\u0598\u058a\u05c1\u05ae\u0590\u0595\u05c6\u05b7\u05ca\u05b5\u057d\u05b6\u0591", (byte)124, 67);
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[4] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u056c\u0555\u0591\u0585\u057e\u05a2\u0587\u0572\u0585\u05a1\u05aa\u0571", (byte)124, 68);
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[5] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u0599\u0578\u056f\u0577\u0593\u0587\u0573\u0579\u0569\u0579\u05a3\u0587\u0586\u0566\u0570\u058d\u0569\u05a3\u0582\u0594\u0593\u05b5\u057c\u057d", (byte)124, 67);
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[6] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.A("\u01e7\u01c6\u01bd\u01c5\u01e1\u01d5\u01c1\u01c7\u01b7\u01c7\u01f1\u01d5\u01d4\u01b4\u01be\u01db\u01b7\u01f1\u01d0\u01e2\u01e1\u0203\u01ca\u01cb", (byte)124, 65);
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[7] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u01a7\u01be\u01da\u01cd\u01f3\u01e8\u01cb\u01e2\u01d5\u01b7\u01cf\u01c3\u01ec\u01d0\u01f3\u01fb\u01f1\u01ed\u01ba\u01d9\u01f3\u01b7\u0207\u01fa\u01e0\u01c0\u01c9\u01eb\u01f4\u01ed\u01f9\u01f9\u0201\u01fe\u01e0\u01dc\u01dc\u020f\u0207\u0214\u0211\u0212\u01d4\u0205\u0215\u01e7\u01f1\u021e\u01fd\u01ff\u01fe\u01f9\u0221\u0200\u0200\u01e4\u01f5\u01e9\u01f7\u01f6\u0204\u0202\u020e\u0200\u0204\u021a\u01ea\u0226\u01eb\u020f\u0212\u0206\u0200\u0232\u01f6\u021a\u021d\u022a\u020e\u021a\u022b\u0236\u022c\u0223\u020f\u021d\u020a\u020b", (byte)124, 65);
                    continue block7;
                }
                case 1: {
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u0559\u0570\u058c\u057f\u05a5\u059a\u057d\u0594\u0587\u0569\u0582\u05a9\u058d\u05aa\u0587\u0571\u056c\u05a9\u056e\u0584\u05ab\u0575\u0573\u05a3\u05b6\u05ad\u05b5\u0587\u059e\u0599\u0577\u05a1\u059a\u0583\u0591\u059d\u05b4\u05b3\u0592\u05b1\u05c7\u05b6\u05c2\u0591", (byte)124, 67);
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[1] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.B("\u01ef\u01f2\u01ea\u01ee\u01ef\u01b5\u01c5\u01f1\u01d9\u01ea\u01f9\u01f1\u01bc\u01c7\u01ea\u01be\u01c8\u01d4\u01f0\u0200\u01bf\u01dd\u01ca\u01cb", (byte)124, 66);
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[2] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.D("\u0575\u0591\u056f\u05a5\u0558\u0593\u057b\u05a6\u0573\u0587\u057c\u0571", (byte)124, 68);
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[3] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u05b2\u0580\u05a6\u0574\u05b6\u0576\u0585\u0592\u0574\u0593\u0585\u05bb\u0574\u059a\u057f\u0588\u05b9\u05c1\u0591\u05c3\u0591\u059d\u05a4\u0592\u0581\u059a\u05b9\u059f\u05ba\u05a7\u05ba\u05a7\u05be\u05bc\u0585\u058a\u0595\u05d1\u05c7\u05d4\u05c9\u05d7\u05db\u05bb\u05a7\u05cd\u05ae\u05d0\u05a9\u05af\u05d7\u059a\u05cd\u05ae\u05ab\u05ac", (byte)124, 70);
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[4] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.E("\u057b\u05af\u05af\u056f\u059d\u0580\u05a1\u0593\u0583\u05a9\u05bb\u056e\u0594\u05a6\u0591\u05c0\u059e\u0581\u05be\u0583\u0577\u058e\u058b\u058c", (byte)124, 69);
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[5] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u01e7\u01c6\u01bd\u01c5\u01e1\u01d5\u01c1\u01c7\u01b7\u01c7\u01f2\u01d8\u01e9\u01ca\u01d4\u01fa\u01e9\u01fa\u01ca\u01f0\u01dd\u01dd\u01ca\u01cb", (byte)124, 66);
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[6] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u01e7\u01c6\u01bd\u01c5\u01e1\u01d5\u01c1\u01c7\u01b7\u01c7\u01f0\u01e8\u01e8\u01d0\u01f8\u01d3\u01ca\u01f2\u01b4\u01fd\u01d7\u01dd\u01ca\u01cb", (byte)124, 65);
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[7] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.B("\u01a7\u01be\u01da\u01cd\u01f3\u01e8\u01cb\u01e2\u01d5\u01b7\u01cf\u01c3\u01ec\u01d0\u01f3\u01fb\u01f1\u01ed\u01ba\u01d9\u01f3\u01b7\u0207\u01fa\u01e0\u01c0\u01c9\u01eb\u01f4\u01ed\u01f9\u01f9\u0201\u01fe\u01e0\u01dc\u01dc\u020f\u0207\u0214\u0211\u0212\u01d4\u0205\u0215\u01e7\u01f1\u021e\u01fd\u01ff\u01fe\u01f9\u0221\u0200\u0200\u01e4\u01f5\u01e9\u01f7\u01f6\u0204\u0202\u020e\u0200\u0204\u021a\u01ea\u0226\u01eb\u020f\u0212\u0206\u0200\u0232\u01f7\u0208\u0215\u01fd\u020c\u023a\u01ff\u0200\u023d\u022e\u0245\u0243\u020a\u020b", (byte)124, 66);
                    continue block7;
                }
                case 2: {
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.C("\u058c\u0596\u0560\u056f\u0587\u055f\u05a0\u0569\u05a4\u05a6\u05ac\u0578\u056a\u057d\u05ac\u0568\u05aa\u05ad\u05ab\u0574\u0574\u058f\u057c\u057d", (byte)124, 67);
                    continue block7;
                }
                case 4: {
                    \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0599\u05ab\u05a1\u05ab\u0596\u057f\u05a0\u0592\u0586\u05b1\u05b4\u059d\u05ba\u0586\u05bd\u0591\u05b7\u059d\u05a3\u05c4\u0583\u05c4\u058b\u058c", (byte)124, 70);
                }
            }
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u0554\u0576\u0578\u0558\u057c\u059b\u0593\u05a9\u0595\u0564\u05a2\u0598\u05a6\u05a0\u0569\u058e\u05b0\u05af\u05a7\u05ad\u05a7\u057c", (byte)112, 69), \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u01c2\u01cf\u01ce\u0191\u01d1\u01cd\u01c8\u01d1\u01dc\u01cb\u0198\u01d6\u01da\u01d3\u01d6\u01dc\u019e\u052c\u0505\u053a\u053c\u0514\u053c\u0511\u0535\u052d\u0533\u052f\u01b5", (byte)112, 65) + string + \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u053f", (byte)112, 68) + methodType.toString(), exception);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static boolean f(Object object) {
        if (az) {
            int n;
            if (m != null && \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.n != null) {
                n = m;
                return n != 0;
            }
            n = \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.n;
            return n != 0;
        }
        try {
            Field[] fieldArray = object.getClass().getDeclaredFields();
            int n = fieldArray.length;
            for (int i = o; i < n; ++i) {
                Field field;
                Field field2 = fieldArray[i];
                Class<?> clazz = field2.getType();
                if (clazz.isPrimitive() || clazz.getPackage() == null || clazz.getPackage().getName().startsWith((String)\u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.c("\u3e80", (int)p, (long)(q ^ r)))) continue;
                try {
                    field2.setAccessible(s != 0);
                }
                catch (Throwable throwable) {
                    continue;
                }
                Object object2 = field2.get(object);
                if (object2 == null || (field = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(object2.getClass(), SpigotReflectionUtil.GAME_PROFILE_CLASS, t)) == null) continue;
                m = field2;
                \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.n = field;
                boolean bl = u;
                az = v;
                return bl;
            }
            boolean bl = w;
            az = x;
            return bl;
        }
        catch (Throwable throwable) {
            az = y;
            throw throwable;
        }
    }

    private \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5() {
    }

    static {
        a = (0 >>> 88 | 0 << ~88 + 1) & 0xFFFFFFFF;
        b = (0 >>> 7 | 0 << -7) & 0xFFFFFFFF;
        d = Long.reverse(1326349383459381775L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Long.reverse(1326349383459381775L);
        g = Integer.reverse(0x40000000);
        h = Long.reverse(3343962016521363983L);
        i = Long.reverse(0x3C00000000000000L);
        j = Integer.reverse(-1073741824);
        k = Long.reverse(1326349383459381775L);
        l = Integer.reverse(0);
        m = Integer.reverse(Integer.MIN_VALUE);
        n = Integer.reverse(0);
        o = Integer.reverse(0);
        p = (32 >>> 195 | 32 << ~195 + 1) & 0xFFFFFFFF;
        q = Long.reverse(3343962016521363983L);
        r = Long.reverse(0x3C00000000000000L);
        s = (2 >>> 97 | 2 << -97) & 0xFFFFFFFF;
        t = Integer.reverse(0);
        u = (256 >>> 200 | 256 << -200) & 0xFFFFFFFF;
        v = Integer.reverse(Integer.MIN_VALUE);
        w = Integer.reverse(0);
        x = Integer.reverse(Integer.MIN_VALUE);
        y = Integer.reverse(Integer.MIN_VALUE);
        z = Integer.reverse(-1610612736);
        aa = Integer.reverse(-1);
        ab = Long.reverse(1326349383459381775L);
        ac = (0x3000000 >>> 247 | 0x3000000 << -247) & 0xFFFFFFFF;
        ad = (-1 >>> 133 | -1 << ~133 + 1) & 0xFFFFFFFF;
        ae = Long.reverse(1326349383459381775L);
        af = Integer.reverse(-536870912);
        ag = Long.reverse(1326349383459381775L);
        ah = Integer.reverse(0x10000000);
        ai = (2048 >>> 136 | 2048 << ~136 + 1) & 0xFFFFFFFF;
        a = new String[ah];
        b = new String[ai];
        \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.b();
    }

    private static String a(int n, long l) {
        l ^= 0x3CL;
        l ^= 0xAC8D77BE5C572A55L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(12 + 56), 69, (byte)(15 + 68), 47, (byte)(21 + 46), (byte)(57 + 9), (byte)(26 + 41), (byte)(12 + 35), (byte)(54 + 26), (byte)(62 + 13), (byte)(10 + 57), (byte)(11 + 72), (byte)(19 + 34), (byte)(76 + 4), (byte)(17 + 80), (byte)(77 + 23), (byte)(95 + 5), (byte)(90 + 15), (byte)(93 + 17), (byte)(68 + 35)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(23 + 60)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u04cc\u04d9\u04d8\u049b\u04db\u04d7\u04d2\u04db\u04e6\u04d5\u04a2\u04e0\u04e4\u04dd\u04e0\u04e6\u04a8\u0836\u080f\u0844\u0846\u081e\u0846\u081b\u083f\u0837\u083d\u0839", (byte)60, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Nullable
    public static Runnable a(Object object, String string, UUID uUID, @Nullable \u03c9\u03bf\u03bc\u03a6\u03b4\u0394\u03c0\u03bd\u03a8\u03b5\u03b2\u03c5\u0393 \u03c9\u03bf\u03bc\u03a6\u03b4\u0394\u03c0\u03bd\u03a8\u03b5\u03b2\u03c5\u03932) {
        try {
            Field field = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(object.getClass(), UUID.class, a);
            if (field != null) {
                field.set(object, uUID);
            }
            if (!\u03c8\u0394\u03bb\u03b2\u03a0\u03b2\u03c6\u03c4\u03be\u03b6\u03c9\u03b5\u03b5\u03c4.r) {
                if (!\u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.f(object) && field == null) {
                    throw new RuntimeException((String)\u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.c("\u3e80", (int)b, (long)d) + uUID + (String)\u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.c("\u3e83", (int)e, (long)f) + string + (String)\u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.c("\u3e86", (int)g, (long)(h ^ i)));
                }
                if (az && m != null && n != null) {
                    return () -> {
                        try {
                            Object object2 = m.get(object);
                            GameProfile gameProfile = new GameProfile(uUID, string);
                            if (\u03c9\u03bf\u03bc\u03a6\u03b4\u0394\u03c0\u03bd\u03a8\u03b5\u03b2\u03c5\u03932 != null) {
                                gameProfile.getProperties().put(\u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.c("\u3e80", (int)(z & aa), (long)ab), (Object)new Property((String)\u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.c("\u3e83", (int)(ac & ad), (long)ae), \u03c9\u03bf\u03bc\u03a6\u03b4\u0394\u03c0\u03bd\u03a8\u03b5\u03b2\u03c5\u03932.ce, \u03c9\u03bf\u03bc\u03a6\u03b4\u0394\u03c0\u03bd\u03a8\u03b5\u03b2\u03c5\u03932.cf));
                            }
                            n.set(object2, gameProfile);
                        }
                        catch (IllegalAccessException illegalAccessException) {
                            throw new RuntimeException((String)\u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.c("\u3e86", (int)af, (long)ag), illegalAccessException);
                        }
                    };
                }
            }
        }
        catch (Exception exception) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03bc\u0394\u03c8\u03c9\u03a0\u03c7\u039b\u03be\u03b5\u03ba\u03b5.c("\u3e89", (int)j, (long)k) + string, exception, new Object[l]);
        }
        return null;
    }
}

