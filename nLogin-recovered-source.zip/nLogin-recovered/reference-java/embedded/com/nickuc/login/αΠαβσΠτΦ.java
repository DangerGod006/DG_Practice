/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6 {
    private static long d;
    private static long b;
    private static int g;
    private final \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2 a;
    private static String[] a;
    private final \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7 q;
    private static int a;
    private static String[] b;
    private static int e;
    private static int f;
    private static long c;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u055b\u057d\u057f\u055f\u0583\u05a2\u059a\u05b0\u059c\u056b\u05a9\u059f\u05ad\u05a7\u0570\u0595\u05b7\u05b6\u05ae\u05b4\u05ae\u0583", (byte)119, 70), \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u01d0\u01dd\u01dc\u019f\u01df\u01db\u01d6\u01df\u01ea\u01d9\u01a6\u01e4\u01e8\u01e1\u01e4\u01ea\u01ac\u052f\u051f\u0531\u0533\u0545\u0523\u0548\u052b\u01c0", (byte)119, 65) + string + \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u01a7", (byte)119, 66) + methodType.toString(), exception);
        }
    }

    @Generated
    public \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6(\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7 \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72, \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2 \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b22) {
        this.q = \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72;
        this.a = \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b22;
    }

    static {
        a = 0 >>> 167 | 0 << ~167 + 1;
        b = Long.reverse(2558281847061886676L);
        d = Long.reverse(-2882303761517117440L);
        e = 0 >>> 162 | 0 << ~162 + 1;
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Integer.reverse(Integer.MIN_VALUE);
        a = new String[f];
        b = new String[g];
        \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.b();
    }

    @Generated
    public \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2 a() {
        return this.a;
    }

    private static String a(int n, long l) {
        l ^= 0x1BL;
        l ^= 0xB1DA09A401D08BF4L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(9 + 59), (byte)(33 + 36), (byte)(53 + 30), 47, 67, (byte)(12 + 54), (byte)(61 + 6), (byte)(45 + 2), (byte)(24 + 56), (byte)(62 + 13), (byte)(40 + 27), (byte)(71 + 12), (byte)(17 + 36), (byte)(47 + 33), (byte)(75 + 22), (byte)(52 + 48), (byte)(4 + 96), (byte)(99 + 6), (byte)(3 + 107), (byte)(50 + 53)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(8 + 75)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0567\u0574\u0573\u0536\u0576\u0572\u056d\u0576\u0581\u0570\u053d\u057b\u057f\u0578\u057b\u0581\u0543\u08c6\u08b6\u08c8\u08ca\u08dc\u08ba\u08df\u08c2", (byte)72, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6[] a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7 ... \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array) {
        if (\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array.length == 0) {
            throw new IllegalArgumentException((String)\u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.c("\u3e80", (int)a, (long)(b ^ d)));
        }
        \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6[] \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6Array = new \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array.length];
        for (int i = e; i < \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6Array.length; ++i) {
            \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7 \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72 = \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array[i];
            \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6Array[i] = \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b72.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
        }
        return \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6Array;
    }

    private static void b() {
        int n;
        c = 3128927073967210948L;
        long l = c ^ 0xB1DA09A401D08BF4L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(26 + 42), (byte)(64 + 5), (byte)(18 + 65), 47, (byte)(25 + 42), (byte)(42 + 24), (byte)(8 + 59), 47, (byte)(67 + 13), (byte)(73 + 2), (byte)(25 + 42), (byte)(62 + 21), (byte)(15 + 38), (byte)(46 + 34), (byte)(61 + 36), (byte)(31 + 69), (byte)(22 + 78), (byte)(59 + 46), (byte)(28 + 82), (byte)(50 + 53)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(33 + 35), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u0182\u01ab\u01b4\u01b0\u018f\u01b1\u01a4\u0179\u0189\u0190\u0179\u01ae\u019a\u0191\u0198\u01aa\u0195\u019c\u01bb\u01c4\u01b2\u019c\u0195\u0186\u01c3\u018a\u01bd\u01ab\u01a7\u0181\u01a1\u01c9\u019d\u01bf\u01c7\u01d0\u01c2\u0197\u01b5\u01b3\u01d4\u01b2\u0193\u01a1", (byte)93, 66);
                    continue block7;
                }
                case 1: {
                    \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.b[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.A("\u0182\u01ab\u01b4\u01b0\u018f\u01b1\u01a4\u0179\u0189\u0190\u0179\u01ae\u019a\u0191\u0198\u01aa\u0195\u019c\u01bb\u01c4\u01b2\u019c\u0195\u0186\u01c3\u018a\u01bd\u01ab\u01a7\u0181\u01a1\u01c9\u01c2\u018c\u01a0\u01af\u01cd\u01a3\u01d5\u01b4\u01cc\u01cd\u01a4\u01ad\u01c9\u01de\u0197\u01db\u01b6\u01cc\u01ac\u01df\u01a3\u01e5\u01ac\u01ad", (byte)93, 65);
                    continue block7;
                }
                case 2: {
                    \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.C("\u0538\u0521\u053e\u0504\u053b\u04fc\u0536\u0537\u0523\u0527\u0507\u051b\u0526\u052d\u0524\u050d\u053e\u052b\u0513\u0554\u0559\u0522\u051f\u0520", (byte)93, 67);
                    continue block7;
                }
                case 4: {
                    \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u056b\u055b\u0551\u0590\u0589\u0572\u0584\u0561\u0587\u059b\u0588\u0588\u0591\u058f\u0552\u056e\u0559\u0591\u0573\u0557\u0558\u05a5\u056c\u056d", (byte)93, 69);
                }
            }
        }
    }

    @Generated
    public \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7 a() {
        return this.q;
    }
}

