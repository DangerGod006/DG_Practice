/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.json.JSONObject
 *  javax.annotation.Nonnull
 */
package com.nickuc.login;

import com.nickuc.login.lib.json.JSONObject;
import com.nickuc.login.\u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8;
import com.nickuc.login.\u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1;
import com.nickuc.login.\u03c2\u03bd\u039b\u03c9\u03a0\u03b8\u03c1\u03c0\u03c5\u03a3\u03bc\u03ba\u0393\u03a9\u03bf;
import java.util.UUID;
import javax.annotation.Nonnull;

public class \u03ba\u03a0\u03b8\u03b9\u03c3\u03a0\u03ba\u0394\u03b8\u03c8\u03c8\u03c0\u039b\u03bb
implements \u03c2\u03bd\u039b\u03c9\u03a0\u03b8\u03c1\u03c0\u03c5\u03a3\u03bc\u03ba\u0393\u03a9\u03bf<UUID> {
    public static final \u03ba\u03a0\u03b8\u03b9\u03c3\u03a0\u03ba\u0394\u03b8\u03c8\u03c8\u03c0\u039b\u03bb a = new \u03ba\u03a0\u03b8\u03b9\u03c3\u03a0\u03ba\u0394\u03b8\u03c8\u03c8\u03c0\u039b\u03bb();

    @Override
    public UUID a(@Nonnull JSONObject jSONObject) {
        String string = \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.a.a(jSONObject);
        return \u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.c(string);
    }

    @Override
    public JSONObject a(@Nonnull UUID uUID) {
        return \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.a.a((Object)\u03bb\u03a3\u03c3\u03a3\u03ba\u0393\u03b2\u03a0\u03a8.b(uUID));
    }

    @Override
    public Class<?> a() {
        return UUID.class;
    }
}

