/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3;

class \u03c1\u03c2\u03b4\u03b1\u03c8\u03b8\u03c8\u03a3\u03bf\u03a9\u0393\u03c5\u03b5 {
    private static int c;
    private static int b;
    private static int a;
    static final /* synthetic */ int[] l;

    static {
        a = 0x800000 >>> 55 | 0x800000 << -55;
        b = Integer.reverse(0x40000000);
        c = Integer.reverse(-1073741824);
        l = new int[\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3.values().length];
        try {
            \u03c1\u03c2\u03b4\u03b1\u03c8\u03b8\u03c8\u03a3\u03bf\u03a9\u0393\u03c5\u03b5.l[\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3.c.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03c1\u03c2\u03b4\u03b1\u03c8\u03b8\u03c8\u03a3\u03bf\u03a9\u0393\u03c5\u03b5.l[\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3.d.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03c1\u03c2\u03b4\u03b1\u03c8\u03b8\u03c8\u03a3\u03bf\u03a9\u0393\u03c5\u03b5.l[\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3.f.ordinal()] = c;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

