/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6;
import lombok.Generated;

public class \u03bd\u03b6\u03a0\u03a3\u03b6\u03c0\u03c7\u03b8\u03b1\u0394\u03b4\u03b8\u03c6
extends \u03bd\u03b5\u03bf\u03be\u03b3\u03b7\u03b6\u03a8\u03c1\u0393\u03a6 {
    private static final \u03bd\u03b6\u03a0\u03a3\u03b6\u03c0\u03c7\u03b8\u03b1\u0394\u03b4\u03b8\u03c6 b;
    private static int e;
    private final String aX;

    static /* synthetic */ \u03bd\u03b6\u03a0\u03a3\u03b6\u03c0\u03c7\u03b8\u03b1\u0394\u03b4\u03b8\u03c6 b() {
        return b;
    }

    @Generated
    public String K() {
        return this.aX;
    }

    static {
        e = Integer.reverse(0);
        b = new \u03bd\u03b6\u03a0\u03a3\u03b6\u03c0\u03c7\u03b8\u03b1\u0394\u03b4\u03b8\u03c6(null, e, null);
    }

    public \u03bd\u03b6\u03a0\u03a3\u03b6\u03c0\u03c7\u03b8\u03b1\u0394\u03b4\u03b8\u03c6(byte[] byArray, int n, String string) {
        super(byArray, n);
        this.aX = string;
    }
}

