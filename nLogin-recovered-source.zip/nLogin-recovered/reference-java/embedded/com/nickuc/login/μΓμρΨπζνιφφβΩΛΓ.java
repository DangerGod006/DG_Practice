/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

public interface \u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393 {
    public void a(Object var1);
}

