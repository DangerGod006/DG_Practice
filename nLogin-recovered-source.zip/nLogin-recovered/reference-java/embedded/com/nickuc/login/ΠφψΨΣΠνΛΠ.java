/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.slf4j.Logger
 */
package com.nickuc.login;

import com.nickuc.login.\u03a0\u03b6\u03a3\u03a8\u03b1\u03a9\u03c8\u03bf\u03b7\u03b9\u03b7\u0393\u0393;
import lombok.Generated;
import org.slf4j.Logger;

public class \u03a0\u03c6\u03c8\u03a8\u03a3\u03a0\u03bd\u039b\u03a0
implements \u03a0\u03b6\u03a3\u03a8\u03b1\u03a9\u03c8\u03bf\u03b7\u03b9\u03b7\u0393\u0393 {
    private final Logger b;

    @Override
    public void a(String string, Throwable throwable) {
        this.b.warn(string, throwable);
    }

    @Override
    public void r(String string) {
        this.b.warn(string);
    }

    @Override
    public <T> T c() {
        return (T)this.b;
    }

    @Generated
    public \u03a0\u03c6\u03c8\u03a8\u03a3\u03a0\u03bd\u039b\u03a0(Logger logger) {
        this.b = logger;
    }

    @Override
    public void b(String string, Throwable throwable) {
        this.b.error(string, throwable);
    }

    @Override
    public void q(String string) {
        this.b.info(string);
    }

    @Override
    public void s(String string) {
        this.b.error(string);
    }
}

