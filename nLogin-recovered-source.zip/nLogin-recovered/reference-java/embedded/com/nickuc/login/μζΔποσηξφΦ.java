/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.\u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2;
import javax.annotation.Nullable;

public interface \u03bc\u03b6\u0394\u03c0\u03bf\u03c3\u03b7\u03be\u03c6\u03a6 {
    @Nullable
    public \u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2 a();
}

