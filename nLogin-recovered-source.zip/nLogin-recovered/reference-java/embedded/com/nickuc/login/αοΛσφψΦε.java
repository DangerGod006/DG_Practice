/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.channel.Channel
 *  io.netty.util.AttributeKey
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.entity.EntityEvent
 *  org.bukkit.event.player.PlayerEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.bukkit.\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0;
import com.nickuc.login.\u0393\u03a0\u03b5\u03c8\u03c2\u03bc\u03b4\u03c2\u03a6\u03c5\u03bf\u03c1\u0393\u03c1\u03c0;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b4;
import com.nickuc.login.\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u0394;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03b4\u03be\u03c4\u03a6\u03a0\u03c9\u03c6;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u0393;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bc\u03b6\u0394\u03c0\u03bf\u03c3\u03b7\u03be\u03c6\u03a6;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import io.netty.channel.Channel;
import io.netty.util.AttributeKey;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Locale;
import java.util.Optional;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityEvent;
import org.bukkit.event.player.PlayerEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5
extends \u0393\u03a0\u03b5\u03c8\u03c2\u03bc\u03b4\u03c2\u03a6\u03c5\u03bf\u03c1\u0393\u03c1\u03c0 {
    private static int hu;
    private static int cu;
    private static int hm;
    private static int hn;
    private static int gz;
    private static long ig;
    private static int du;
    private static long al;
    private static long ah;
    private static int gv;
    private static long hw;
    private static String[] c;
    private static int et;
    private static long hx;
    private static int cm;
    private static long ho;
    private static int b;
    private static int ae;
    private static int gs;
    private static long av;
    private static int ii;
    private static long fz;
    private static int aj;
    private static int dn;
    private static long aq;
    private static int jj;
    private static int gb;
    private static long ag;
    private static long fo;
    private static int cfr_renamed_1;
    private static int q;
    private static long ay;
    private static int f;
    private static int iz;
    private static long bu;
    private static long gx;
    private static int hq;
    private static long bl;
    private static int bz;
    private static long ik;
    private static int ai;
    private static long db;
    private static int ir;
    private final boolean l;
    private static long o;
    private static int bs;
    private static int ap;
    private static int ic;
    private static int by;
    private static long ga;
    private static long fs;
    private static int iu;
    private static long hs;
    private static int dw;
    private static int em;
    private static long ia;
    private static int as;
    private static long br;
    private static int hy;
    private static long gq;
    private static int hd;
    private static long id;
    private static int fd;
    private static int bp;
    private static int gk;
    private static int ea;
    private static int cfr_renamed_0;
    private static int dj;
    private static int j;
    private static int ec;
    private static int fq;
    private static int ba;
    private static int gc;
    private static int aw;
    private static long e;
    private static int fb;
    private static long gp;
    private static int ha;
    private static int m;
    private static long ad;
    private static int ab;
    private static long in;
    private static int fm;
    private static int gr;
    private static String[] d;
    private static long n;
    private static int p;
    private static int ij;
    private static long bc;
    private static int fx;
    private static int ep;
    private static long ih;
    private static long gm;
    private static int he;
    private static int ex;
    private static int cg;
    private static long bq;
    private static int bh;
    private final nLoginBukkit d;
    private static int fa;
    private static int c;
    private static long dl;
    private static int ao;
    private static long cy;
    private static int cq;
    private static int es;
    private static long cl;
    private static int cw;
    private static long ce;
    private static int bb;
    private static int d;
    private static long dy;
    private static long fc;
    private static int gn;
    private static long bn;
    private static long ey;
    private static long h;
    private static long cv;
    private static int gj;
    private static long iw;
    private static long eq;
    private static long gl;
    private static long au;
    private static int jd;
    private static int fu;
    private static long ci;
    private static int dg;
    private static int jc;
    private static int gg;
    private static int cc;
    private static long il;
    private static long bj;
    private static long ib;
    private static int hi;
    private static int bf;
    private static long ee;
    private static int im;
    private static long cf;
    private static int jg;
    private static long ak;
    private static int bk;
    private static long io;
    private static long ie;
    private static int dr;
    private static int eg;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public String a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0) {
        long l = System.nanoTime();
        String string = \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.getName();
        try {
            if (this.l) {
                InetSocketAddress inetSocketAddress = Optional.ofNullable(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a()).orElse((InetSocketAddress)\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a.remoteAddress());
                \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = this.e.a().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, null, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.getName(), inetSocketAddress, gb != 0, gc != 0, \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0);
                if (\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a != null) {
                    \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a().b(\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a);
                }
                String string2 = null;
                return string2;
            }
            \u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b4 \u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b42 = this.e.b().a();
            String string3 = super.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a, \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.k, Optional.ofNullable(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a()).orElse((InetSocketAddress)\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a.remoteAddress()), \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.d(), (\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a || \u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b42 != null && \u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b42.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a()) ? gg : gj) != 0, \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0);
            if (string3 == null && \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a != null) {
                this.e.a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6).a().b(\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a);
            }
            String string4 = string3;
            return string4;
        }
        catch (Throwable throwable) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e80", (int)gk, (long)(gl ^ gm)) + string + (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e83", (int)gn, (long)(gp ^ gq)), throwable, new Object[gr]);
            Object object = \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e86", (int)(gs & gv), (long)gx);
            return object;
        }
        finally {
            \u03ba\u03b4\u03be\u03c4\u03a6\u03a0\u03c9\u03c6.a(\u03a8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3.c, l);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x15L;
        l ^= 0x76AA9BB788E4B19AL;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(37 + 31), (byte)(30 + 39), (byte)(48 + 35), 47, (byte)(25 + 42), (byte)(9 + 57), (byte)(51 + 16), (byte)(10 + 37), (byte)(23 + 57), (byte)(13 + 62), 67, (byte)(71 + 12), (byte)(41 + 12), (byte)(39 + 41), (byte)(40 + 57), (byte)(50 + 50), (byte)(69 + 31), (byte)(41 + 64), (byte)(23 + 87), (byte)(28 + 75)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(13 + 56), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u0580\u058d\u058c\u054f\u058f\u058b\u0586\u058f\u059a\u0589\u0556\u0594\u0598\u0591\u0594\u059a\u055c\u08df\u08ee\u08cb\u08f4\u08f8\u08fb\u08da\u08ea", (byte)120, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    private /* synthetic */ void a(Player player, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6) {
        if (player.getHealth() <= 0.0 || player.isDead()) {
            player.spigot().respawn();
            \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a().h();
        }
        if (this.l) {
            this.d.a().f(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
        } else {
            super.d(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42);
        }
    }

    public boolean a(PlayerEvent playerEvent) {
        Player player = playerEvent.getPlayer();
        return this.b(player);
    }

    public boolean c(Player player) {
        if (\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.aE) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.e((String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e80", (int)(hm & hn), (long)ho) + player.getName() + (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e83", (int)hq, (long)hs) + player.getUniqueId() + (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e86", (int)hu, (long)(hw ^ hx)) + player + (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e89", (int)hy, (long)(ia ^ ib)) + player.hashCode() + (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e8c", (int)ic, (long)(id ^ ie)) + player.getClass().getCanonicalName() + (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e8f", (int)cfr_renamed_0, (long)(ig ^ ih)), new Object[ii]);
        }
        if (player.hasMetadata((String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e92", (int)ij, (long)(ik ^ il))) || player.hasMetadata((String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e95", (int)im, (long)(in ^ io))) || player.hasMetadata((String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e98", (int)(ir & iu), (long)iw))) {
            return iz != 0;
        }
        \u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b2 \u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b22 = ((\u03bc\u03b6\u0394\u03c0\u03bf\u03c3\u03b7\u03be\u03c6\u03a6)((Object)this.e.b())).a();
        return (\u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b22 != null && \u03b4\u03ba\u03c5\u03b2\u03a6\u03a9\u03b1\u03c7\u03a9\u03b22.b((Entity)player) ? jc : jd) != 0;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void a(PlayerQuitEvent playerQuitEvent) {
        Player player = playerQuitEvent.getPlayer();
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = this.e.b().a(player);
        long l = System.nanoTime();
        \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u0394 \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942 = this.e.a();
        try {
            \u03a9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3 \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3;
            \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42;
            String string;
            if (\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.ao.ar() && (string = playerQuitEvent.getQuitMessage()) != null && string.toLowerCase(Locale.ENGLISH).contains((CharSequence)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e80", (int)bk, (long)(bl ^ bn)))) {
                playerQuitEvent.setQuitMessage(null);
            }
            if (this.c(player)) {
                return;
            }
            string = this.e.b().a(playerQuitEvent, player);
            if (string != null) {
                if (this.e.b().e(string)) {
                    return;
                }
            } else {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e83", (int)bp, (long)(bq ^ br)) + playerQuitEvent.getClass().getSimpleName() + (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e86", (int)bs, (long)bu) + \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.getName(), new Object[by]);
            }
            if ((\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)) != null && (\u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3 = (\u03a9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3)\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.d(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.g)) != null) {
                \u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u0393 \u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u03932 = (\u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u0393)this.e.b();
                \u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u03932.a().a(\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c9\u03c8\u03c4\u03c3\u03c8\u03a3\u03c1\u03b9\u03a3, bz != 0);
            }
            if (\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.x.ar()) {
                this.e.b().k(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
            }
            if (!this.l) {
                super.d(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
            }
        }
        catch (Throwable throwable) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e89", (int)cc, (long)(ce ^ cf)) + \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.getName() + (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e8c", (int)cg, (long)(ci ^ cl)), throwable, new Object[cm]);
        }
        finally {
            \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942.l(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
            \u03ba\u03b4\u03be\u03c4\u03a6\u03a0\u03c9\u03c6.a(\u03a8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3.e, l);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void a(PlayerJoinEvent playerJoinEvent) {
        String string;
        Player player = playerJoinEvent.getPlayer();
        if (this.c(player)) {
            return;
        }
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = this.e.b().a(player);
        Channel channel = this.e.b().a(playerJoinEvent, player);
        if (channel == null) {
            String[] stringArray = new String[b];
            stringArray[\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c] = \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e80", (int)(d & f), (long)h);
            stringArray[\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.j] = \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e83", (int)m, (long)(n ^ o));
            stringArray[\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.p] = (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e86", (int)(q & ab), (long)ad) + playerJoinEvent.getClass().getSimpleName() + (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e89", (int)ae, (long)(ag ^ ah));
            stringArray[\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.ai] = \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e8c", (int)aj, (long)(ak ^ al));
            stringArray[\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.ao] = \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e8f", (int)ap, (long)aq);
            \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a(\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(stringArray));
        }
        if (this.e.b().e(channel)) {
            return;
        }
        if (\u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.p && (string = this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, channel, playerJoinEvent)) != null) {
            \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a(string);
            return;
        }
        long l = System.nanoTime();
        try {
            Object object;
            if (this.e.a().b(player.getName(), player.getUniqueId())) {
                return;
            }
            if (\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.ao.ar() && (object = playerJoinEvent.getJoinMessage()) != null && ((String)object).toLowerCase(Locale.ENGLISH).contains((CharSequence)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e92", (int)as, (long)(au ^ av)))) {
                playerJoinEvent.setJoinMessage(null);
            }
            object = this.e.a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
            Runnable runnable = () -> this.a(player, (\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4)object, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
            if (\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.V()) {
                \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a().a(runnable);
            } else {
                runnable.run();
            }
        }
        catch (Throwable throwable) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e95", (int)aw, (long)ay) + \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.getName() + (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e98", (int)(ba & bb), (long)bc), throwable, new Object[bf]);
            \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a((String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e9b", (int)bh, (long)bj));
        }
        finally {
            \u03ba\u03b4\u03be\u03c4\u03a6\u03a0\u03c9\u03c6.a(\u03a8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3.d, l);
        }
    }

    private String a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, Channel channel, Object object) {
        String string = \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.getName();
        try {
            \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 = (\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0)channel.attr((AttributeKey)\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a).get();
            if (\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 == null) {
                String string2 = (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e80", (int)(cq & cu), (long)cv) + \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.getName() + (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e83", (int)cw, (long)(cy ^ db)) + object.getClass().getSimpleName() + (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e86", (int)(dg & dj), (long)dl);
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c(string2, new Object[dn]);
                String[] stringArray = new String[cfr_renamed_1];
                stringArray[\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.dr] = \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e89", (int)(du & dw), (long)dy);
                stringArray[\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.ea] = \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e8c", (int)ec, (long)ee);
                stringArray[\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.eg] = (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e8f", (int)(em & ep), (long)eq) + string2;
                stringArray[\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.es] = \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e92", (int)(et & ex), (long)ey);
                stringArray[\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.fa] = \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e95", (int)fb, (long)fc);
                return \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(stringArray);
            }
            return this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0);
        }
        catch (Throwable throwable) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e98", (int)(fd & fm), (long)fo) + string + (String)\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e9b", (int)fq, (long)fs), throwable, new Object[fu]);
            return \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.c("\u3e9e", (int)fx, (long)(fz ^ ga));
        }
    }

    public boolean b(Player player) {
        if (player == null) {
            return ha != 0;
        }
        if (this.c(player)) {
            return hd != 0;
        }
        return (!this.e.a().b(this.e.b().a(player)) ? he : hi) != 0;
    }

    static {
        b = Integer.reverse(-1610612736);
        c = Integer.reverse(0);
        d = Integer.reverse(0);
        f = Integer.reverse(-1);
        h = Long.reverse(8964353544216582933L);
        j = Integer.reverse(Integer.MIN_VALUE);
        m = Integer.reverse(Integer.MIN_VALUE);
        n = Long.reverse(-3141322254155310315L);
        o = Long.reverse(-6341068275337658368L);
        p = (65536 >>> 143 | 65536 << ~143 + 1) & 0xFFFFFFFF;
        q = Integer.reverse(0x40000000);
        ab = Integer.reverse(-1);
        ad = Long.reverse(8964353544216582933L);
        ae = Integer.reverse(-1073741824);
        ag = Long.reverse(-3141322254155310315L);
        ah = Long.reverse(-6341068275337658368L);
        ai = (0x60000000 >>> 125 | 0x60000000 << ~125 + 1) & 0xFFFFFFFF;
        aj = 524288 >>> 209 | 524288 << -209;
        ak = Long.reverse(-3141322254155310315L);
        al = Long.reverse(-6341068275337658368L);
        ao = Integer.reverse(0x20000000);
        ap = 655360 >>> 241 | 655360 << ~241 + 1;
        aq = Long.reverse(8964353544216582933L);
        as = 24 >>> 194 | 24 << ~194 + 1;
        au = Long.reverse(-3141322254155310315L);
        av = Long.reverse(-6341068275337658368L);
        aw = 3584 >>> 233 | 3584 << -233;
        ay = Long.reverse(8964353544216582933L);
        ba = Integer.reverse(0x10000000);
        bb = Integer.reverse(-1);
        bc = Long.reverse(8964353544216582933L);
        bf = 0 >>> 13 | 0 << -13;
        bh = Integer.reverse(-1879048192);
        bj = Long.reverse(8964353544216582933L);
        bk = Integer.reverse(0x50000000);
        bl = Long.reverse(-3141322254155310315L);
        bn = Long.reverse(-6341068275337658368L);
        bp = (0x60000001 >>> 253 | 0x60000001 << -253) & 0xFFFFFFFF;
        bq = Long.reverse(-3141322254155310315L);
        br = Long.reverse(-6341068275337658368L);
        bs = Integer.reverse(0x30000000);
        bu = Long.reverse(8964353544216582933L);
        by = Integer.reverse(0);
        bz = Integer.MIN_VALUE >>> 95 | Integer.MIN_VALUE << -95;
        cc = 0x340000 >>> 242 | 0x340000 << -242;
        ce = Long.reverse(-3141322254155310315L);
        cf = Long.reverse(-6341068275337658368L);
        cg = Integer.reverse(0x70000000);
        ci = Long.reverse(-3141322254155310315L);
        cl = Long.reverse(-6341068275337658368L);
        cm = Integer.reverse(0);
        cq = Integer.reverse(-268435456);
        cu = Integer.reverse(-1);
        cv = Long.reverse(8964353544216582933L);
        cw = (0x200000 >>> 49 | 0x200000 << ~49 + 1) & 0xFFFFFFFF;
        cy = Long.reverse(-3141322254155310315L);
        db = Long.reverse(-6341068275337658368L);
        dg = (136 >>> 131 | 136 << -131) & 0xFFFFFFFF;
        dj = -1 >>> 14 | -1 << -14;
        dl = Long.reverse(8964353544216582933L);
        dn = Integer.reverse(0);
        cfr_renamed_1 = 2560 >>> 169 | 2560 << ~169 + 1;
        dr = (0 >>> 97 | 0 << ~97 + 1) & 0xFFFFFFFF;
        du = (73728 >>> 76 | 73728 << -76) & 0xFFFFFFFF;
        dw = Integer.reverse(-1);
        dy = Long.reverse(8964353544216582933L);
        ea = (0x40000000 >>> 126 | 0x40000000 << ~126 + 1) & 0xFFFFFFFF;
        ec = 0x1300000 >>> 116 | 0x1300000 << ~116 + 1;
        ee = Long.reverse(8964353544216582933L);
        eg = 8192 >>> 108 | 8192 << ~108 + 1;
        em = Integer.reverse(0x28000000);
        ep = Integer.reverse(-1);
        eq = Long.reverse(8964353544216582933L);
        es = Integer.reverse(-1073741824);
        et = (-1610612734 >>> 125 | -1610612734 << ~125 + 1) & 0xFFFFFFFF;
        ex = Integer.reverse(-1);
        ey = Long.reverse(8964353544216582933L);
        fa = 1 >>> 190 | 1 << ~190 + 1;
        fb = (90112 >>> 204 | 90112 << -204) & 0xFFFFFFFF;
        fc = Long.reverse(8964353544216582933L);
        fd = (0x5C000000 >>> 58 | 0x5C000000 << -58) & 0xFFFFFFFF;
        fm = Integer.reverse(-1);
        fo = Long.reverse(8964353544216582933L);
        fq = Integer.reverse(0x18000000);
        fs = Long.reverse(8964353544216582933L);
        fu = 0 >>> 176 | 0 << -176;
        fx = Integer.reverse(-1744830464);
        fz = Long.reverse(-3141322254155310315L);
        ga = Long.reverse(-6341068275337658368L);
        gb = Integer.reverse(0);
        gc = Integer.reverse(0);
        gg = 0x400000 >>> 182 | 0x400000 << -182;
        gj = (0 >>> 59 | 0 << -59) & 0xFFFFFFFF;
        gk = 0xD00000 >>> 243 | 0xD00000 << -243;
        gl = Long.reverse(-3141322254155310315L);
        gm = Long.reverse(-6341068275337658368L);
        gn = -671088640 >>> 59 | -671088640 << -59;
        gp = Long.reverse(-3141322254155310315L);
        gq = Long.reverse(-6341068275337658368L);
        gr = 0 >>> 199 | 0 << ~199 + 1;
        gs = Integer.reverse(0x38000000);
        gv = (-1 >>> 158 | -1 << -158) & 0xFFFFFFFF;
        gx = Long.reverse(8964353544216582933L);
        gz = (0 >>> 34 | 0 << -34) & 0xFFFFFFFF;
        ha = Integer.reverse(Integer.MIN_VALUE);
        hd = Integer.reverse(0);
        he = 8192 >>> 109 | 8192 << -109;
        hi = 0 >>> 16 | 0 << -16;
        hm = 0x1D0000 >>> 208 | 0x1D0000 << -208;
        hn = Integer.reverse(-1);
        ho = Long.reverse(8964353544216582933L);
        hq = (30720 >>> 202 | 30720 << ~202 + 1) & 0xFFFFFFFF;
        hs = Long.reverse(8964353544216582933L);
        hu = Integer.reverse(-134217728);
        hw = Long.reverse(-3141322254155310315L);
        hx = Long.reverse(-6341068275337658368L);
        hy = 0x2000000 >>> 244 | 0x2000000 << ~244 + 1;
        ia = Long.reverse(-3141322254155310315L);
        ib = Long.reverse(-6341068275337658368L);
        ic = Integer.reverse(-2080374784);
        id = Long.reverse(-3141322254155310315L);
        ie = Long.reverse(-6341068275337658368L);
        cfr_renamed_0 = Integer.reverse(0x44000000);
        ig = Long.reverse(-3141322254155310315L);
        ih = Long.reverse(-6341068275337658368L);
        ii = (0 >>> 187 | 0 << ~187 + 1) & 0xFFFFFFFF;
        ij = (0x60000004 >>> 29 | 0x60000004 << -29) & 0xFFFFFFFF;
        ik = Long.reverse(-3141322254155310315L);
        il = Long.reverse(-6341068275337658368L);
        im = Integer.reverse(0x24000000);
        in = Long.reverse(-3141322254155310315L);
        io = Long.reverse(-6341068275337658368L);
        ir = Integer.reverse(-1543503872);
        iu = -1 >>> 10 | -1 << -10;
        iw = Long.reverse(8964353544216582933L);
        iz = Integer.reverse(Integer.MIN_VALUE);
        jc = (32768 >>> 15 | 32768 << -15) & 0xFFFFFFFF;
        jd = Integer.reverse(0);
        jg = (2432 >>> 38 | 2432 << -38) & 0xFFFFFFFF;
        jj = (4864 >>> 135 | 4864 << -135) & 0xFFFFFFFF;
        c = new String[jg];
        d = new String[jj];
        \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.b();
    }

    public boolean a(EntityEvent entityEvent) {
        Entity entity = entityEvent.getEntity();
        return this.a(entity);
    }

    public boolean a(Entity entity) {
        if (entity instanceof Player) {
            Player player = (Player)entity;
            return this.b(player);
        }
        return gz != 0;
    }

    private static void b() {
        int n;
        e = -6280040820081695189L;
        long l = e ^ 0x76AA9BB788E4B19AL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(7 + 61), (byte)(10 + 59), (byte)(43 + 40), 47, (byte)(3 + 64), (byte)(31 + 35), (byte)(49 + 18), 47, (byte)(66 + 14), (byte)(23 + 52), (byte)(3 + 64), (byte)(7 + 76), (byte)(5 + 48), (byte)(18 + 62), (byte)(29 + 68), (byte)(93 + 7), (byte)(59 + 41), (byte)(86 + 19), (byte)(85 + 25), (byte)(92 + 11)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(60 + 23)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u052e\u0523\u0531\u050c\u050b\u054c\u0552\u050c\u0556\u052b\u0555\u052c\u0517\u0554\u0544\u0550\u0527\u052a\u0518\u052a\u0563\u0551\u0528\u0529", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[1] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u0172\u0189\u0198\u01ba\u0185\u016f\u01be\u01b4\u01bf\u0180\u01b4\u0187", (byte)96, 66);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[2] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u0582\u0550\u056e\u0563\u0555\u0562\u0590\u0565\u055c\u0573\u0558\u0558\u055b\u0578\u05a1\u059c\u0582\u057f\u0581\u0563\u059f\u057e\u059c\u05a4\u0595\u05ad\u05a4\u05aa\u0571\u057b\u0587\u05ac\u056c\u05a6\u05ae\u056f\u05b9\u05a3\u0596\u0593\u05be\u05ad\u05bd\u057c\u05bd\u057b\u05b7\u057d\u05b1\u05a5\u05b5\u0581\u0580\u05b8\u058f\u0590", (byte)96, 70);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[3] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u053f\u0509\u0540\u052c\u050a\u052e\u052f\u054a\u0526\u0525\u0538\u051d", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[4] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.C("\u0508\u051f\u052e\u0550\u051b\u0505\u0554\u054a\u0555\u0516\u054a\u051d", (byte)96, 67);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[5] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u0550\u0593\u0554\u0562\u0558\u057b\u0586\u0566\u0567\u058b\u0559\u059d\u0561\u058c\u0562\u0579\u0575\u057e\u0593\u05a4\u05a1\u055c\u0595\u0578\u0589\u0585\u05aa\u056c\u0563\u0591\u05b1\u058c\u0584\u0575\u05ac\u05a9\u0591\u0585\u05ab\u05bb\u057c\u05b1\u058b\u0580\u05af\u0580\u05bc\u05a0\u05c5\u059c\u0597\u05b9\u0582\u05a2\u058f\u0590", (byte)96, 69);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[6] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u0547\u0524\u050f\u051b\u050c\u0547\u0526\u052e\u0534\u0534\u050a\u0530\u0523\u053a\u054a\u051c\u054e\u055f\u0561\u051c\u052f\u052b\u0528\u0529", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[7] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u016f\u01af\u01b1\u0189\u0174\u01a8\u01b1\u0193\u01bc\u01b0\u01be\u0181\u01c0\u01b1\u01b4\u01c8\u0197\u0197\u018a\u018a\u019a\u0185\u01bc\u01a1\u0198\u01c6\u01d2\u01bf\u0192\u01a7\u01cb\u01d3\u01cc\u01a7\u01b6\u0195\u0197\u01db\u01b7\u01b2\u01d1\u01e2\u01df\u01d5\u01de\u01cd\u01bd\u01e6\u01da\u019b\u019c\u01e0\u01eb\u01a6\u01ae\u01c9\u01c1\u01bb\u01c5\u01c0\u01df\u01eb\u01b1\u01e1\u01c0\u01d2\u01b6\u01e6\u01d3\u01c7\u01d3\u01ea\u01d9\u01bb\u01ce\u01c7", (byte)96, 66);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[8] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u0517\u052a\u0538\u0523\u0553\u0524\u0528\u052b\u053f\u0527\u054e\u051d", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[9] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u0575\u056a\u0578\u0553\u0552\u0593\u0599\u0553\u059d\u0572\u059a\u0571\u0571\u0598\u057c\u05a0\u057b\u05a7\u059c\u0576\u0567\u05a4\u0581\u0583\u0589\u058c\u0599\u058b\u059a\u059a\u05a8\u056b\u058b\u05b2\u05b2\u058f\u05a1\u05a8\u05ac\u0572\u05bd\u05be\u0571\u0580\u05ab\u05b2\u05ab\u059a\u05a3\u05af\u0597\u05b9\u05c1\u05b5\u05cc\u05b8\u0584\u059d\u05ad\u05c8\u0589\u0591\u05d2\u05c9\u0591\u05a5\u05b4\u05b8\u05a8\u05cf\u05d0\u05a4\u05d1\u05ad\u05d7\u05d3\u05da\u05da\u05da\u05b9\u05b3\u05bf\u05dc\u05be\u05a0\u05e0\u05c1\u05b9\u05c9\u05d8\u05db\u05da\u05ea\u05c9\u05df\u05d0", (byte)96, 69);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[10] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u0504\u0521\u0541\u051c\u0510\u053f\u052f\u0532\u0547\u0526\u0535\u0558\u0525\u0537\u054d\u0536\u0536\u0549\u054f\u054a\u0520\u0551\u0528\u0529", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[11] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u0540\u054b\u054e\u0523\u0522\u053d\u0528\u0520\u0545\u0556\u0512\u054c\u0533\u0555\u0526\u0549\u0530\u052f\u0530\u051b\u054e\u0554\u0516\u0542\u054f\u0553\u055d\u0536\u0545\u0553\u0562\u0544\u056d\u0538\u055b\u0544\u0570\u0554\u056a\u0556\u0546\u0573\u0566\u053d", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[12] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u0543\u0523\u0502\u050a\u0528\u0551\u0521\u0543\u0527\u0517\u0542\u0555\u0514\u052d\u0554\u0547\u0519\u0552\u055a\u051a\u052e\u052b\u0528\u0529", (byte)96, 67);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[13] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.C("\u0505\u0545\u0547\u051f\u050a\u053e\u0547\u0529\u0552\u0546\u0554\u0517\u0556\u0547\u054a\u055e\u052d\u052d\u0520\u0520\u0530\u051b\u0542\u055f\u0521\u0539\u0559\u053a\u0542\u0539\u0563\u054a\u055e\u0560\u056c\u0570\u054f\u055c\u054f\u0567\u054c\u0542\u054a\u052f\u0530\u0532\u0534\u0566\u057b\u0555\u053d\u0556\u0538\u055b\u0548\u0549", (byte)96, 67);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[14] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u055e\u0571\u057f\u056a\u059a\u056b\u056f\u0572\u0586\u056e\u0595\u0564", (byte)96, 70);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[15] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u0540\u054b\u054e\u0523\u0522\u053d\u0528\u0520\u0545\u0556\u0511\u0559\u052f\u0559\u0557\u0559\u052b\u052e\u054d\u054a\u0539\u0561\u0533\u055f\u0524\u0522\u0569\u0537\u056a\u0533\u0528\u0539\u056d\u055f\u0544\u055b\u0550\u0541\u052a\u0549\u0531\u0535\u0578\u0547\u0556\u0556\u054e\u0567\u055e\u054a\u0577\u053a\u0555\u057d\u053e\u0545\u0555\u0543\u055f\u0583\u0565\u056c\u055a\u055c", (byte)96, 67);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[16] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.D("\u0536\u051a\u0529\u0526\u0522\u0524\u0532\u0524\u0545\u0551\u0528\u051d", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[17] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.B("\u01ac\u0187\u016c\u01ac\u01ae\u0179\u019f\u01b7\u018e\u01b1\u01bb\u017c\u019f\u019d\u0193\u01c8\u01c0\u019f\u01c6\u01a3\u019b\u01a3\u01c2\u01c0\u01bb\u019b\u019e\u01a0\u01bd\u01d1\u01cc\u01a0\u01a3\u01d8\u01d4\u01d0\u01a5\u019d\u0197\u0195\u01d2\u01d1\u01d1\u019a\u01a3\u01c2\u01e1\u01c8\u01d9\u01a1\u01d8\u01c3\u01de\u01b5\u01b2\u01b3", (byte)96, 66);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[18] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u052e\u0523\u0531\u050c\u050b\u054c\u0552\u050c\u0556\u052b\u0555\u052c\u0517\u0554\u0544\u0550\u0527\u052a\u0518\u052a\u0563\u0551\u0528\u0529", (byte)96, 67);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[19] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u054f\u0566\u0575\u0597\u0562\u054c\u059b\u0591\u059c\u055d\u0591\u0564", (byte)96, 69);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[20] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u057e\u058f\u056e\u056f\u059a\u0589\u0586\u055a\u058c\u059a\u0573\u0564", (byte)96, 70);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[21] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u0508\u051f\u052e\u0550\u051b\u0505\u0554\u054a\u0555\u0516\u054a\u051d", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[22] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0550\u0593\u0554\u0562\u0558\u057b\u0586\u0566\u0567\u058b\u0559\u059d\u0561\u058c\u0562\u0579\u0575\u057e\u0593\u05a4\u05a1\u055c\u0595\u0578\u0589\u0585\u05aa\u056c\u0563\u0591\u05b1\u058c\u0584\u0575\u05ac\u05a9\u0591\u0585\u05ab\u05bb\u057c\u05b1\u058b\u0580\u05af\u0580\u05bc\u05a0\u05c5\u059c\u0597\u05b9\u0582\u05a2\u058f\u0590", (byte)96, 69);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[23] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u016f\u01af\u01b1\u0189\u0174\u01a8\u01b1\u0193\u01bc\u01b0\u01be\u0181\u01c0\u01b1\u01b4\u01c8\u0197\u0197\u018a\u018a\u019a\u0185\u01bc\u01a1\u0198\u01c6\u01d2\u01bf\u0192\u01a7\u01cb\u01d3\u0191\u01c1\u0196\u01a8\u01b2\u01d9\u01da\u01a8\u01d2\u01c2\u01b5\u01e3\u01d5\u01c0\u019f\u01de\u01e9\u01c8\u01e6\u01dd\u01e5\u01c5\u01b2\u01b3", (byte)96, 66);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[24] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u055e\u0571\u057f\u056a\u059a\u056b\u056f\u0572\u0586\u056e\u0595\u0564", (byte)96, 70);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[25] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.B("\u0198\u018d\u019b\u0176\u0175\u01b6\u01bc\u0176\u01c0\u0195\u01bd\u0194\u0194\u01bb\u019f\u01c3\u019e\u01ca\u01bf\u0199\u018a\u01c7\u01a4\u01a6\u01ac\u01af\u01bc\u01ae\u01bd\u01bd\u01cb\u018e\u01ae\u01d5\u01d5\u01b2\u01c4\u01cb\u01cf\u0195\u01e0\u01e1\u0194\u01a3\u01ce\u01d5\u01ce\u01bd\u01c6\u01d2\u01ba\u01dc\u01e4\u01d8\u01ef\u01db\u01a7\u01c0\u01d0\u01eb\u01ac\u01b4\u01f5\u01ec\u01b4\u01c8\u01d7\u01db\u01cb\u01f2\u01f3\u01c7\u01f4\u01d0\u01fa\u01f6\u01fd\u01fd\u01fd\u01dc\u01d6\u01e2\u01ff\u01e1\u01c3\u0203\u01e4\u01dc\u01ec\u01fb\u01fe\u01fd\u020d\u01ec\u0202\u01f3", (byte)96, 66);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[26] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u054c\u058c\u058e\u0566\u0551\u0585\u058e\u0570\u0599\u058d\u059b\u055e\u059d\u058e\u0591\u05a5\u0574\u0574\u0567\u0567\u0577\u0562\u0599\u057e\u0575\u05a3\u05af\u059c\u056f\u0584\u05a8\u05b0\u056e\u059e\u0573\u0585\u058f\u05b6\u05b7\u0585\u05af\u059f\u0592\u05c0\u05b2\u059d\u057c\u05bb\u05c6\u05a5\u05c3\u05ba\u05c2\u05a2\u058f\u0590", (byte)96, 70);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[27] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u055e\u0571\u057f\u056a\u059a\u056b\u056f\u0572\u0586\u056e\u0595\u0564", (byte)96, 69);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[28] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.D("\u052e\u0523\u0531\u050c\u050b\u054c\u0552\u050c\u0556\u052b\u0553\u052a\u052a\u0551\u0535\u0559\u0534\u0560\u0555\u052f\u0520\u055d\u053a\u053c\u0542\u0545\u0552\u0544\u0553\u0553\u0561\u0524\u0544\u056b\u056b\u0548\u055a\u0561\u0565\u052b\u0576\u0577\u052a\u0539\u0564\u056b\u0564\u0553\u055c\u0568\u0550\u0572\u057a\u056e\u0585\u0571\u053d\u0556\u0566\u0581\u0542\u054a\u058b\u0582\u054a\u055e\u056d\u0571\u0561\u0588\u0589\u055d\u058a\u0566\u0590\u058c\u0593\u0593\u0593\u0572\u056c\u0578\u0595\u0577\u0559\u0599\u057a\u0572\u0582\u0591\u0594\u0593\u05a3\u0582\u0598\u0589", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[29] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.B("\u01b2\u018c\u0177\u0172\u01a6\u017a\u01be\u01be\u017a\u019d\u019c\u018b\u01a0\u0196\u01c4\u01bc\u01c0\u01a6\u01ba\u01a0\u018a\u01aa\u01c4\u01af\u01c9\u01b9\u01c5\u01a8\u0191\u019d\u01a5\u0192\u01a3\u01d2\u01d0\u0193\u01b3\u01b9\u01b9\u019a\u01d5\u01ac\u01e0\u01a7", (byte)96, 66);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[30] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u051e\u0547\u0541\u054c\u052c\u053c\u0551\u053e\u0551\u0529\u0556\u0535\u0546\u051b\u054e\u055a\u054f\u0530\u0541\u054b\u055a\u0561\u0528\u0529", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[31] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u01ac\u01ba\u01a3\u01b0\u01b8\u01bd\u0175\u01a8\u01a1\u018c\u0192\u0187", (byte)96, 65);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[32] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.E("\u0547\u0586\u0577\u058a\u0565\u0562\u0565\u056c\u057e\u055e\u0567\u0560\u058c\u0579\u05a3\u059a\u0595\u0570\u05a5\u05a0\u0594\u0572\u056f\u0570", (byte)96, 69);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[33] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u0187\u01b6\u0196\u0192\u0188\u01b9\u018c\u01af\u017b\u01b1\u0190\u017d\u01a2\u01ad\u0196\u0192\u0186\u01a0\u01aa\u01a1\u018c\u01cb\u0192\u0193", (byte)96, 66);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[34] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0592\u0550\u0554\u0594\u054f\u0586\u0591\u0566\u057e\u0586\u058a\u0568\u057b\u0593\u058b\u056f\u0563\u0596\u0582\u055f\u0592\u05a8\u056f\u0570", (byte)96, 70);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[35] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u053f\u054e\u050d\u0525\u053d\u0526\u051d\u0553\u0513\u054f\u0534\u051d", (byte)96, 67);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[36] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.F("\u0580\u0574\u058a\u0556\u0590\u057b\u0594\u056e\u056f\u0572\u057b\u0564", (byte)96, 70);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[37] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u018a\u0199\u01b1\u01ad\u0176\u01b3\u0196\u01ad\u019f\u01b8\u01c0\u01af\u01b0\u0194\u01b6\u0198\u0199\u01a9\u01a7\u01bd\u019a\u01bb\u0192\u0193", (byte)96, 65);
                    continue block7;
                }
                case 1: {
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u0198\u018d\u019b\u0176\u0175\u01b6\u01bc\u0176\u01c0\u0195\u01bf\u01b4\u019f\u01b7\u01bb\u019f\u01b2\u0182\u01a5\u0198\u019a\u01cb\u0192\u0193", (byte)96, 66);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[1] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u0175\u0186\u018a\u0179\u018e\u0192\u0188\u01b6\u01b6\u019b\u018a\u0187", (byte)96, 65);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[2] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.E("\u0582\u0550\u056e\u0563\u0555\u0562\u0590\u0565\u055c\u0573\u0558\u0558\u055b\u0578\u05a1\u059c\u0582\u057f\u0581\u0563\u059f\u057e\u059c\u05a4\u0595\u05ad\u05a4\u05aa\u0571\u057b\u0587\u05ac\u056c\u05a6\u05ae\u056f\u05b9\u05a3\u0596\u0593\u05be\u05ad\u05bf\u05a9\u05b7\u0579\u058d\u0596\u057b\u05b3\u059f\u0583\u05bd\u0592\u058f\u0590", (byte)96, 69);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[3] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.F("\u0587\u0595\u054d\u0557\u057a\u0573\u0586\u0569\u0590\u0596\u0591\u059c\u0578\u0581\u0571\u05a3\u0575\u0576\u057e\u0575\u0564\u05a8\u056f\u0570", (byte)96, 70);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[4] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u0520\u0522\u052a\u052c\u0542\u0520\u0525\u053d\u054d\u0550\u052c\u051d", (byte)96, 67);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[5] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u0509\u054c\u050d\u051b\u0511\u0534\u053f\u051f\u0520\u0544\u0512\u0556\u051a\u0545\u051b\u0532\u052e\u0537\u054c\u055d\u055a\u0515\u054e\u0531\u0542\u053e\u0563\u0525\u051c\u054a\u056a\u0545\u053d\u052e\u0565\u0562\u054a\u053e\u0564\u0574\u0535\u056a\u0545\u0572\u0544\u0571\u0534\u0574\u0557\u0569\u0548\u057c\u057b\u055b\u0548\u0549", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[6] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u01b1\u018e\u0179\u0185\u0176\u01b1\u0190\u0198\u019e\u019e\u0174\u0180\u01af\u0192\u01c7\u01c4\u01b5\u01b1\u0185\u0181\u01ca\u0199\u01ae\u01b7\u019e\u01c7\u01ad\u01cc\u01a5\u01b4\u01aa\u01ab", (byte)96, 66);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[7] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.B("\u016f\u01af\u01b1\u0189\u0174\u01a8\u01b1\u0193\u01bc\u01b0\u01be\u0181\u01c0\u01b1\u01b4\u01c8\u0197\u0197\u018a\u018a\u019a\u0185\u01bc\u01a1\u0198\u01c6\u01d2\u01bf\u0192\u01a7\u01cb\u01d3\u01cc\u01a7\u01b6\u0195\u0197\u01db\u01b7\u01b2\u01d1\u01e2\u01df\u01d5\u01de\u01cd\u01bd\u01e6\u01da\u019b\u019c\u01e0\u01eb\u01a6\u01ae\u01c9\u01c1\u01bb\u01c5\u01c0\u01df\u01eb\u01b1\u01e1\u01e0\u01b0\u01e6\u01b7\u01ca\u01d2\u01b4\u01fe\u01d1\u0201\u01bd\u01c7", (byte)96, 66);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[8] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0553\u0574\u0578\u0569\u0563\u056b\u054d\u0552\u0593\u056d\u055e\u0564", (byte)96, 70);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[9] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u0198\u018d\u019b\u0176\u0175\u01b6\u01bc\u0176\u01c0\u0195\u01bd\u0194\u0194\u01bb\u019f\u01c3\u019e\u01ca\u01bf\u0199\u018a\u01c7\u01a4\u01a6\u01ac\u01af\u01bc\u01ae\u01bd\u01bd\u01cb\u018e\u01ae\u01d5\u01d5\u01b2\u01c4\u01cb\u01cf\u0195\u01e0\u01e1\u0194\u01a3\u01ce\u01d5\u01ce\u01bd\u01c6\u01d2\u01ba\u01dc\u01e4\u01d8\u01ef\u01db\u01a7\u01c0\u01d0\u01eb\u01ac\u01b4\u01f5\u01ec\u01b4\u01c8\u01d7\u01db\u01cb\u01f2\u01f3\u01c7\u01f4\u01d0\u01fa\u01f6\u01fd\u01fd\u01fd\u01dc\u01d6\u01e2\u01ff\u01e1\u01c3\u0204\u01d7\u01cc\u0210\u01cc\u01fd\u0209\u01fd\u01d0\u01e3\u01ee\u0211\u01e4\u01f4\u01ea\u01d2\u020c\u01d6\u01f9\u01d7\u0212\u0218\u01e7", (byte)96, 65);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[10] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0504\u0521\u0541\u051c\u0510\u053f\u052f\u0532\u0547\u0526\u0534\u0537\u0522\u0545\u054d\u052b\u053f\u0516\u0554\u054b\u053e\u053c\u0551\u0555\u0535\u055a\u0522\u0526\u053a\u054c\u0529\u055d", (byte)96, 67);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[11] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.F("\u0587\u0592\u0595\u056a\u0569\u0584\u056f\u0567\u058c\u059d\u0559\u0593\u057a\u059c\u056d\u0590\u0577\u0576\u0577\u0562\u0595\u059b\u055d\u0589\u0596\u059a\u05a4\u057d\u058c\u059a\u05a9\u058b\u05b0\u05ab\u05b4\u05a9\u05ad\u05b7\u05b0\u0596\u0575\u05a7\u058f\u0598\u05af\u05b0\u05ae\u059f\u0596\u05a1\u059b\u05b3\u05bc\u05b8\u058f\u0590", (byte)96, 70);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[12] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u0543\u0523\u0502\u050a\u0528\u0551\u0521\u0543\u0527\u0517\u0543\u052b\u0559\u054a\u051a\u0553\u0518\u052f\u0554\u0537\u055a\u053b\u0528\u0529", (byte)96, 67);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[13] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u0505\u0545\u0547\u051f\u050a\u053e\u0547\u0529\u0552\u0546\u0554\u0517\u0556\u0547\u054a\u055e\u052d\u052d\u0520\u0520\u0530\u051b\u0542\u055f\u0521\u0539\u0559\u053a\u0542\u0539\u0563\u054a\u055e\u0560\u056c\u0570\u054f\u055c\u054f\u0567\u054c\u0542\u0548\u054a\u0578\u0574\u054c\u055d\u0534\u056a\u057f\u057b\u0563\u055b\u0548\u0549", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[14] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u056f\u0584\u0554\u056b\u057a\u0552\u056d\u056f\u058f\u0595\u0556\u0564", (byte)96, 70);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[15] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u0587\u0592\u0595\u056a\u0569\u0584\u056f\u0567\u058c\u059d\u0558\u05a0\u0576\u05a0\u059e\u05a0\u0572\u0575\u0594\u0591\u0580\u05a8\u057a\u05a6\u056b\u0569\u05b0\u057e\u05b1\u057a\u056f\u0580\u05b4\u05a6\u058b\u05a2\u0597\u0588\u0571\u0590\u0578\u057c\u05bf\u058e\u059d\u059d\u0595\u05ae\u05a5\u0591\u05be\u0581\u059c\u05c6\u05c9\u05bb\u0583\u05a1\u05ae\u05bf\u05ac\u05a4\u058a\u05d4", (byte)96, 70);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[16] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.F("\u0596\u058e\u0593\u058f\u058e\u0552\u059b\u056a\u0588\u059a\u056f\u0564", (byte)96, 70);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[17] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u01ac\u0187\u016c\u01ac\u01ae\u0179\u019f\u01b7\u018e\u01b1\u01bb\u017c\u019f\u019d\u0193\u01c8\u01c0\u019f\u01c6\u01a3\u019b\u01a3\u01c2\u01c0\u01bb\u019b\u019e\u01a0\u01bd\u01d1\u01cc\u01a0\u01a3\u01d8\u01d4\u01d0\u01a5\u019d\u0197\u0195\u01d2\u01d1\u01d1\u01b4\u01e5\u01b6\u01a4\u01b8\u01b8\u01c6\u01ca\u01c5\u01ab\u01c4\u01ca\u01ea\u01e8\u01c6\u01d0\u01cc\u01aa\u01b0\u01ae\u01a9", (byte)96, 66);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[18] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u052e\u0523\u0531\u050c\u050b\u054c\u0552\u050c\u0556\u052b\u0552\u0555\u051a\u0532\u055c\u054a\u055c\u055f\u0540\u0537\u0521\u053b\u0528\u0529", (byte)96, 67);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[19] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.A("\u01a7\u016b\u0187\u01af\u019c\u01ac\u0189\u018e\u01a0\u01b6\u01c0\u0187", (byte)96, 65);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[20] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.D("\u0505\u0528\u052c\u051e\u053d\u053d\u054e\u0511\u052e\u0549\u0538\u051d", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[21] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u0563\u0556\u058d\u0567\u0591\u057a\u058d\u055b\u0568\u0567\u0591\u0564", (byte)96, 69);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[22] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u0173\u01b6\u0177\u0185\u017b\u019e\u01a9\u0189\u018a\u01ae\u017c\u01c0\u0184\u01af\u0185\u019c\u0198\u01a1\u01b6\u01c7\u01c4\u017f\u01b8\u019b\u01ac\u01a8\u01cd\u018f\u0186\u01b4\u01d4\u01af\u01a7\u0198\u01cf\u01cc\u01b4\u01a8\u01ce\u01de\u019f\u01d4\u01af\u01b8\u01d6\u01ba\u01da\u01d0\u01e6\u01d8\u01b6\u01e9\u01eb\u01b5\u01b2\u01b3", (byte)96, 66);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[23] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u0505\u0545\u0547\u051f\u050a\u053e\u0547\u0529\u0552\u0546\u0554\u0517\u0556\u0547\u054a\u055e\u052d\u052d\u0520\u0520\u0530\u051b\u0552\u0537\u052e\u055c\u0568\u0555\u0528\u053d\u0561\u0569\u0527\u0557\u052c\u053e\u0548\u056f\u0570\u053e\u0568\u0558\u0549\u0545\u056f\u0577\u0572\u0535\u0577\u0580\u0568\u056f\u057c\u0571\u0548\u0549", (byte)96, 67);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[24] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u054f\u053a\u0518\u053f\u051f\u0520\u053f\u051d\u0546\u0512\u0542\u051d", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[25] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0575\u056a\u0578\u0553\u0552\u0593\u0599\u0553\u059d\u0572\u059a\u0571\u0571\u0598\u057c\u05a0\u057b\u05a7\u059c\u0576\u0567\u05a4\u0581\u0583\u0589\u058c\u0599\u058b\u059a\u059a\u05a8\u056b\u058b\u05b2\u05b2\u058f\u05a1\u05a8\u05ac\u0572\u05bd\u05be\u0571\u0580\u05ab\u05b2\u05ab\u059a\u05a3\u05af\u0597\u05b9\u05c1\u05b5\u05cc\u05b8\u0584\u059d\u05ad\u05c8\u0589\u0591\u05d2\u05c9\u0591\u05a5\u05b4\u05b8\u05a8\u05cf\u05d0\u05a4\u05d1\u05ad\u05d7\u05d3\u05da\u05da\u05da\u05b9\u05b3\u05bf\u05dc\u05be\u05a0\u05dd\u05cc\u05a4\u05e9\u05df\u05ce\u05bd\u05a3\u05e3\u05cb\u05bf\u05ee\u05b5\u05d2\u05c1\u05b7\u05c5\u05e5\u05d2\u05e6\u05ba\u05d3\u05c4", (byte)96, 70);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[26] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u0505\u0545\u0547\u051f\u050a\u053e\u0547\u0529\u0552\u0546\u0554\u0517\u0556\u0547\u054a\u055e\u052d\u052d\u0520\u0520\u0530\u051b\u0552\u0537\u052e\u055c\u0568\u0555\u0528\u053d\u0561\u0569\u0527\u0557\u052c\u053e\u0548\u056f\u0570\u053e\u0568\u0558\u054a\u0573\u0557\u054f\u0577\u0558\u054d\u053a\u057e\u057d\u0573\u055b\u0548\u0549", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[27] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u0562\u058e\u0582\u0583\u0598\u0558\u0576\u0577\u0592\u0589\u0567\u0564", (byte)96, 69);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[28] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.B("\u0198\u018d\u019b\u0176\u0175\u01b6\u01bc\u0176\u01c0\u0195\u01bd\u0194\u0194\u01bb\u019f\u01c3\u019e\u01ca\u01bf\u0199\u018a\u01c7\u01a4\u01a6\u01ac\u01af\u01bc\u01ae\u01bd\u01bd\u01cb\u018e\u01ae\u01d5\u01d5\u01b2\u01c4\u01cb\u01cf\u0195\u01e0\u01e1\u0194\u01a3\u01ce\u01d5\u01ce\u01bd\u01c6\u01d2\u01ba\u01dc\u01e4\u01d8\u01ef\u01db\u01a7\u01c0\u01d0\u01eb\u01ac\u01b4\u01f5\u01ec\u01b4\u01c8\u01d7\u01db\u01cb\u01f2\u01f3\u01c7\u01f4\u01d0\u01fa\u01f6\u01fd\u01fd\u01fd\u01dc\u01d6\u01e2\u01ff\u01e1\u01c3\u01fb\u0202\u01c7\u01c2\u020a\u01dd\u01fb\u0215\u01ee\u020e\u020c\u01d1\u0201\u0209\u0203\u01d7\u021b\u01d0\u01da\u01d2\u01d3\u0214\u01e7", (byte)96, 66);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[29] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.C("\u0548\u0522\u050d\u0508\u053c\u0510\u0554\u0554\u0510\u0533\u0532\u0521\u0536\u052c\u055a\u0552\u0556\u053c\u0550\u0536\u0520\u0540\u055a\u0545\u055f\u054f\u055b\u053e\u0527\u0533\u053b\u0528\u0547\u0566\u053d\u0529\u0553\u0562\u054c\u0553\u0573\u0560\u0558\u053d", (byte)96, 67);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[30] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u051e\u0547\u0541\u054c\u052c\u053c\u0551\u053e\u0551\u0529\u0556\u054b\u0531\u0525\u054e\u053c\u0547\u0515\u055f\u053d\u0538\u053b\u0528\u0529", (byte)96, 67);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[31] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u052b\u0509\u054b\u0503\u051f\u051d\u0525\u0546\u053f\u0556\u0538\u051d", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[32] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.D("\u0500\u053f\u0530\u0543\u051e\u051b\u051e\u0525\u0537\u0517\u0522\u0524\u0550\u051b\u0537\u055b\u054a\u0554\u053e\u052f\u0552\u0551\u0528\u0529", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[33] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u051d\u054c\u052c\u0528\u051e\u054f\u0522\u0545\u0511\u0547\u0524\u052c\u052f\u0555\u052d\u053d\u0530\u051c\u055f\u0513\u051e\u0561\u0528\u0529", (byte)96, 67);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[34] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u01b5\u0173\u0177\u01b7\u0172\u01a9\u01b4\u0189\u01a1\u01a9\u01af\u017e\u01a0\u01b3\u01a3\u01a8\u01b5\u01a0\u01b3\u01b8\u01b9\u0195\u0192\u0193", (byte)96, 66);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[35] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.A("\u0189\u01a1\u01a2\u0185\u0194\u0187\u01b9\u0176\u019f\u018d\u018a\u01ab\u01bb\u01a5\u01c7\u01bf\u01c0\u01b2\u01c3\u0198\u01c4\u01bb\u0192\u0193", (byte)96, 65);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[36] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u054d\u052c\u0502\u0550\u0523\u0520\u051d\u052a\u0525\u0548\u0556\u051d", (byte)96, 68);
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[37] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u0520\u052f\u0547\u0543\u050c\u0549\u052c\u0543\u0535\u054e\u0556\u054c\u053b\u0525\u0548\u053d\u055c\u052b\u0540\u0556\u054b\u052b\u0528\u0529", (byte)96, 67);
                    continue block7;
                }
                case 2: {
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u0574\u055e\u0550\u0598\u0591\u0552\u0594\u0596\u0556\u058d\u0571\u0594\u0571\u0571\u0582\u055f\u057c\u0586\u0571\u0593\u059e\u0582\u056f\u0570", (byte)96, 69);
                    continue block7;
                }
                case 4: {
                    \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.d[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u0172\u01a9\u0195\u0185\u01ac\u01b3\u01bb\u018d\u01c0\u0192\u018e\u0187", (byte)96, 66);
                }
            }
        }
    }

    public \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, nLoginBukkit nLoginBukkit2, boolean bl) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6);
        this.d = nLoginBukkit2;
        this.l = bl;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.A("\u0141\u0163\u0165\u0145\u0169\u0188\u0180\u0196\u0182\u0151\u018f\u0185\u0193\u018d\u0156\u017b\u019d\u019c\u0194\u019a\u0194\u0169", (byte)77, 65), \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.D("\u04ff\u050c\u050b\u04ce\u050e\u050a\u0505\u050e\u0519\u0508\u04d5\u0513\u0517\u0510\u0513\u0519\u04db\u085e\u086d\u084a\u0873\u0877\u087a\u0859\u0869\u04ef", (byte)77, 68) + string + \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u0153", (byte)77, 66) + methodType.toString(), exception);
        }
    }
}

