/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

public interface \u03be\u03b5\u03c4\u03c6\u0394\u03bf\u03a9\u03c8\u03bd\u03b5 {
    public boolean v(String var1);

    public String w(String var1);

    public boolean i(String var1, String var2);
}

