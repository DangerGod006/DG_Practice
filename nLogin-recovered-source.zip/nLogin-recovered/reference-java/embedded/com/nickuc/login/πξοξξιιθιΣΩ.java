/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.bcrypt.BCrypt
 *  com.nickuc.login.lib.bcrypt.BCrypt$Version
 */
package com.nickuc.login;

import com.nickuc.login.lib.bcrypt.BCrypt;
import com.nickuc.login.\u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8;

public class \u03c0\u03be\u03bf\u03be\u03be\u03b9\u03b9\u03b8\u03b9\u03a3\u03a9
extends \u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8 {
    public \u03c0\u03be\u03bf\u03be\u03be\u03b9\u03b9\u03b8\u03b9\u03a3\u03a9() {
        super(BCrypt.with((BCrypt.Version)BCrypt.Version.VERSION_2Y));
    }
}

