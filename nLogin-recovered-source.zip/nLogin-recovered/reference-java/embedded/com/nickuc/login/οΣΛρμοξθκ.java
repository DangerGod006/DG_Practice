/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent
 *  com.nickuc.login.lib.packetevents.api.wrapper.play.client.WrapperPlayClientChatCommand
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent;
import com.nickuc.login.lib.packetevents.api.wrapper.play.client.WrapperPlayClientChatCommand;
import com.nickuc.login.\u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u03bd\u03bc\u03b8\u03a6\u039b\u03c8\u03bf\u03c6\u03c1\u03c4\u03b4\u03c2\u03bd\u03b7;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9;
import com.nickuc.login.\u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Locale;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bf\u03a3\u039b\u03c1\u03bc\u03bf\u03be\u03b8\u03ba
implements \u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6 {
    private static int o;
    private static long c;
    private static int n;
    private static int l;
    private static String[] a;
    private static int b;
    private static String[] b;
    private static int e;
    private static int q;
    private static int f;
    private static int m;
    private static int d;
    private static int g;
    private static int h;
    private static long i;
    final /* synthetic */ \u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393 a;
    private static int k;
    private static int r;
    private static long j;
    private static int p;
    private static int c;
    private static int a;

    static {
        a = 256 >>> 40 | 256 << -40;
        b = Integer.reverse(-201326592);
        c = Integer.reverse(Integer.MIN_VALUE);
        d = Integer.reverse(0);
        e = 47 >>> 224 | 47 << -224;
        f = Integer.reverse(Integer.MIN_VALUE);
        g = 16 >>> 196 | 16 << -196;
        h = (0 >>> 224 | 0 << -224) & 0xFFFFFFFF;
        i = Long.reverse(4018427629954163392L);
        j = Long.reverse(0x1C00000000000000L);
        k = 2048 >>> 139 | 2048 << ~139 + 1;
        l = Integer.reverse(0);
        m = 0x1000000 >>> 24 | 0x1000000 << ~24 + 1;
        n = 32768 >>> 111 | 32768 << ~111 + 1;
        o = Integer.reverse(0);
        p = 0 >>> 94 | 0 << -94;
        q = 4096 >>> 108 | 4096 << ~108 + 1;
        r = (131072 >>> 81 | 131072 << ~81 + 1) & 0xFFFFFFFF;
        a = new String[q];
        b = new String[r];
        \u03bf\u03a3\u039b\u03c1\u03bc\u03bf\u03be\u03b8\u03ba.b();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bf\u03a3\u039b\u03c1\u03bc\u03bf\u03be\u03b8\u03ba.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.D("\u03e6\u0408\u040a\u03ea\u040e\u042d\u0425\u043b\u0427\u03f6\u0434\u042a\u0438\u0432\u03fb\u0420\u0442\u0441\u0439\u043f\u0439\u040e", (byte)3, 68), \u03bf\u03a3\u039b\u03c1\u03bc\u03bf\u03be\u03b8\u03ba.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u00e8\u00f5\u00f4\u00b7\u00f7\u00f3\u00ee\u00f7\u0102\u00f1\u00be\u00fc\u0100\u00f9\u00fc\u0102\u00c4\u0455\u043a\u0433\u045a\u0456\u045a\u045a\u0455\u0458\u00d9", (byte)3, 66) + string + \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.C("\u03f8", (byte)3, 67) + methodType.toString(), exception);
        }
    }

    @Override
    public void a(PacketReceiveEvent packetReceiveEvent) {
        String[] stringArray;
        Object object = packetReceiveEvent.getPlayer();
        if (object == null) {
            return;
        }
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = \u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393.a(this.a).b().a(packetReceiveEvent.getPlayer());
        \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = \u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393.a(this.a).a().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
        if (\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 == null) {
            packetReceiveEvent.setCancelled(a != 0);
            return;
        }
        WrapperPlayClientChatCommand wrapperPlayClientChatCommand = new WrapperPlayClientChatCommand(packetReceiveEvent);
        String string = wrapperPlayClientChatCommand.getCommand().trim();
        if (string.isEmpty()) {
            return;
        }
        String string2 = \u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393.a(this.a).b().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, (char)b + string);
        if (string2 == null) {
            packetReceiveEvent.setCancelled(c != 0);
            return;
        }
        if (string2.charAt(d) == e) {
            string2 = string2.substring(f);
        }
        if (wrapperPlayClientChatCommand.getMessageSignData().getSaltSignature().getSignature().length == 0 && wrapperPlayClientChatCommand.getMessageSignData().getSaltSignature().getSalt() == 0L) {
            wrapperPlayClientChatCommand.setCommand(string2);
            packetReceiveEvent.markForReEncode(g != 0);
        }
        if ((stringArray = string.split((String)\u03bf\u03a3\u039b\u03c1\u03bc\u03bf\u03be\u03b8\u03ba.c("\u3e80", (int)h, (long)(i ^ j)))).length < k) {
            return;
        }
        \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a9 \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92 = \u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393.a(this.a).a().a(stringArray[l].toLowerCase(Locale.ENGLISH));
        if (\u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92 != null) {
            String[] stringArray2 = new String[stringArray.length - m];
            if (stringArray2.length > 0) {
                System.arraycopy(stringArray, n, stringArray2, o, stringArray2.length);
            }
            \u03b7\u03b9\u03c3\u03be\u03c0\u03b1\u03a0\u03c7\u03a92.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, stringArray[p], stringArray2);
        }
    }

    private static void b() {
        int n;
        c = 235894661066662892L;
        long l = c ^ 0x6C698AAC128A7B28L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(5 + 64), (byte)(74 + 9), (byte)(38 + 9), (byte)(39 + 28), (byte)(43 + 23), (byte)(51 + 16), (byte)(41 + 6), (byte)(72 + 8), (byte)(74 + 1), (byte)(64 + 3), (byte)(25 + 58), (byte)(36 + 17), (byte)(56 + 24), (byte)(33 + 64), 100, (byte)(32 + 68), (byte)(9 + 96), (byte)(10 + 100), (byte)(34 + 69)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(20 + 48), 69, (byte)(36 + 47)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bf\u03a3\u039b\u03c1\u03bc\u03bf\u03be\u03b8\u03ba.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u0534\u056b\u0524\u053c\u055b\u053f\u0549\u0551\u056c\u0566\u0555\u053a", (byte)54, 69);
                    continue block7;
                }
                case 1: {
                    \u03bf\u03a3\u039b\u03c1\u03bc\u03bf\u03be\u03b8\u03ba.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u014e\u0133\u011d\u014f\u011a\u013b\u0156\u0129\u0158\u0125\u0160\u0133", (byte)54, 65);
                    continue block7;
                }
                case 2: {
                    \u03bf\u03a3\u039b\u03c1\u03bc\u03bf\u03be\u03b8\u03ba.b[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u04a2\u048b\u0490\u04ce\u04b5\u04b1\u04b1\u04d1\u04b1\u04d3\u04c4\u049f", (byte)54, 68);
                    continue block7;
                }
                case 4: {
                    \u03bf\u03a3\u039b\u03c1\u03bc\u03bf\u03be\u03b8\u03ba.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u0160\u015c\u0135\u0154\u015e\u0146\u0161\u0128\u0156\u0156\u013e\u0168\u0165\u0142\u015a\u0154\u0171\u014a\u016f\u012d\u014c\u0177\u013e\u013f", (byte)54, 65);
                }
            }
        }
    }

    @Generated
    private \u03bf\u03a3\u039b\u03c1\u03bc\u03bf\u03be\u03b8\u03ba(\u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393 \u03b3\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393) {
        this.a = \u03b3\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393;
    }

    private static String a(int n, long l) {
        l ^= 0x38L;
        l ^= 0x6C698AAC128A7B28L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(24 + 44), (byte)(14 + 55), (byte)(70 + 13), (byte)(36 + 11), (byte)(49 + 18), (byte)(42 + 24), (byte)(66 + 1), (byte)(36 + 11), 80, (byte)(73 + 2), 67, (byte)(9 + 74), (byte)(46 + 7), (byte)(49 + 31), (byte)(67 + 30), (byte)(72 + 28), (byte)(10 + 90), (byte)(11 + 94), (byte)(76 + 34), (byte)(96 + 7)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(29 + 54)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u052f\u053c\u053b\u04fe\u053e\u053a\u0535\u053e\u0549\u0538\u0505\u0543\u0547\u0540\u0543\u0549\u050b\u089c\u0881\u087a\u08a1\u089d\u08a1\u08a1\u089c\u089f", (byte)93, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bf\u03a3\u039b\u03c1\u03bc\u03bf\u03be\u03b8\u03ba.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    /* synthetic */ \u03bf\u03a3\u039b\u03c1\u03bc\u03bf\u03be\u03b8\u03ba(\u0393\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393 \u03b3\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393, \u039b\u03bd\u03bc\u03b8\u03a6\u039b\u03c8\u03bf\u03c6\u03c1\u03c4\u03b4\u03c2\u03bd\u03b7 \u03bb\u03bd\u03bc\u03b8\u03a6\u039b\u03c8\u03bf\u03c6\u03c1\u03c4\u03b4\u03c2\u03bd\u03b7) {
        this(\u03b3\u03a9\u03b7\u03ba\u03c8\u03b3\u0393\u03b5\u03c2\u03c3\u03b3\u0393);
    }
}

