/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class \u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8
extends \u03a0\u03b8\u03ba\u03bf\u03bd\u03b8\u039b\u03bb\u03b1\u03c7\u03c2\u0394 {
    private static int f = 0 >>> 175 | 0 << -175;
    private static String[] h;
    private static int bc;
    private static long az;
    private static long ad;
    private static long ac;
    private static int al;
    private static String[] g;
    private static int ax;
    private static long s;
    private static int bi;
    private static long aq;
    private static int be;
    private static int bk;
    private static long bg;

    private static void b() {
        int n;
        s = 5024604091192045662L;
        long l = s ^ 0xB03483F9449ABFF9L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(34 + 34), (byte)(64 + 5), (byte)(21 + 62), 47, (byte)(8 + 59), (byte)(56 + 10), (byte)(27 + 40), (byte)(32 + 15), (byte)(29 + 51), (byte)(50 + 25), (byte)(45 + 22), (byte)(27 + 56), (byte)(51 + 2), (byte)(10 + 70), (byte)(29 + 68), (byte)(8 + 92), (byte)(24 + 76), (byte)(69 + 36), 110, (byte)(74 + 29)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(33 + 50)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.h[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u01a7\u01a6\u01cc\u01d1\u01cb\u01b9\u01ae\u01d4\u01c4\u01ca\u01b0\u01ae\u01b6\u01a1\u01d2\u01a3\u01bd\u01d2\u01b3\u01b5\u01bb\u01c1\u01ae\u01af", (byte)110, 66);
                    \u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.h[1] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u0559\u056a\u052c\u054a\u053a\u056f\u0549\u0553\u056d\u055e\u055e\u0547", (byte)110, 67);
                    \u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.h[2] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u01aa\u018e\u01d2\u01d1\u01c3\u01d4\u0194\u01a7\u01d3\u01cb\u01aa\u01a3", (byte)110, 65);
                    \u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.h[3] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u059e\u0599\u058f\u05a5\u059e\u059e\u059a\u059e\u059e\u05a2\u0579\u0572", (byte)110, 69);
                    continue block7;
                }
                case 1: {
                    \u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.h[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.C("\u054b\u054a\u0570\u0575\u056f\u055d\u0552\u0578\u0568\u056e\u0552\u053d\u054e\u0572\u0556\u0564\u0583\u0557\u0543\u058c\u058d\u0565\u0552\u0553", (byte)110, 67);
                    \u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.h[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u0583\u0584\u0571\u058f\u0586\u059a\u05a0\u05aa\u0596\u057c\u055f\u05a3\u0590\u05ae\u05a0\u05a0\u0572\u056f\u057e\u05b2\u0593\u05b6\u057d\u057e", (byte)110, 69);
                    \u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.h[2] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u01b1\u01ab\u01d5\u01c2\u01ce\u01ae\u01d6\u01b1\u01a8\u01b7\u01c8\u01a3", (byte)110, 66);
                    \u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.h[3] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u01d5\u01a3\u01c0\u0197\u01cb\u01cf\u01c5\u01cd\u01cf\u01bd\u0195\u01a3", (byte)110, 65);
                    continue block7;
                }
                case 2: {
                    \u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.h[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.F("\u05a1\u0593\u055d\u059e\u057b\u059a\u05a4\u0587\u058c\u0581\u0586\u0576\u05aa\u058e\u0588\u056f\u0572\u058c\u0580\u058e\u058c\u0580\u057d\u057e", (byte)110, 70);
                    continue block7;
                }
                case 4: {
                    \u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.h[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u0556\u0531\u057a\u0571\u0536\u0537\u0555\u0569\u057a\u057a\u057d\u0578\u055a\u0563\u0571\u053f\u0548\u0558\u0547\u055d\u053e\u0565\u0552\u0553", (byte)110, 68);
                }
            }
        }
    }

    static {
        ac = Long.reverse(8795422411171257762L);
        ad = Long.reverse(0x5A00000000000000L);
        al = Integer.reverse(Integer.MIN_VALUE);
        aq = Long.reverse(2310238947757743522L);
        ax = Integer.reverse(0x40000000);
        az = Long.reverse(2310238947757743522L);
        bc = 6144 >>> 171 | 6144 << -171;
        be = Integer.reverse(-1);
        bg = Long.reverse(2310238947757743522L);
        bi = (262144 >>> 16 | 262144 << ~16 + 1) & 0xFFFFFFFF;
        bk = Integer.reverse(0x20000000);
        g = new String[bi];
        h = new String[bk];
        \u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.b();
    }

    public \u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4.F, (String)\u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.c("\u3e80", (int)f, (long)(ac ^ ad)), (String)\u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.c("\u3e83", (int)al, (long)aq), (String)\u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.c("\u3e86", (int)ax, (long)az), (String)\u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.c("\u3e89", (int)(bc & be), (long)bg));
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u052d\u054f\u0551\u0531\u0555\u0574\u056c\u0582\u056e\u053d\u057b\u0571\u057f\u0579\u0542\u0567\u0589\u0588\u0580\u0586\u0580\u0555", (byte)73, 70), \u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u04f3\u0500\u04ff\u04c2\u0502\u04fe\u04f9\u0502\u050d\u04fc\u04c9\u0507\u050b\u0504\u0507\u050d\u04cf\u085e\u0856\u0855\u086c\u0865\u086c\u0850\u086c\u086a\u086f\u0864\u0866\u0873\u0857\u0857\u04ea", (byte)73, 68) + string + \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u04ca", (byte)73, 67) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x5AL;
        l ^= 0xB03483F9449ABFF9L;
        if (g[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(47 + 21), (byte)(59 + 10), (byte)(21 + 62), (byte)(36 + 11), (byte)(10 + 57), (byte)(28 + 38), (byte)(52 + 15), (byte)(36 + 11), (byte)(42 + 38), (byte)(42 + 33), (byte)(13 + 54), (byte)(15 + 68), (byte)(36 + 17), (byte)(61 + 19), (byte)(66 + 31), 100, (byte)(95 + 5), (byte)(41 + 64), 110, (byte)(7 + 96)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(57 + 11), 69, (byte)(60 + 23)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u051a\u0527\u0526\u04e9\u0529\u0525\u0520\u0529\u0534\u0523\u04f0\u052e\u0532\u052b\u052e\u0534\u04f6\u0885\u087d\u087c\u0893\u088c\u0893\u0877\u0893\u0891\u0896\u088b\u088d\u089a\u087e\u087e", (byte)86, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bd\u03b4\u03b2\u03c8\u03c0\u03c6\u03a9\u03c4\u03c1\u03c5\u03b9\u03ba\u03c6\u03a9\u03a8.g[n] = new String(cipher.doFinal(Base64.getDecoder().decode(h[n])), StandardCharsets.UTF_8);
        }
        return g[n];
    }
}

