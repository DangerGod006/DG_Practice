/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.enums.TwoFactorType
 *  com.nickuc.login.api.enums.event.EventEnum
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.api.enums.TwoFactorType;
import com.nickuc.login.api.enums.event.EventEnum;
import com.nickuc.login.\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a8\u03c8\u03bc\u039b\u03c1\u03bf\u03c2\u03b6;
import com.nickuc.login.\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
import com.nickuc.login.\u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b2\u03a3\u03a3\u0393\u03bd\u03b8\u03a9\u03bb\u03bd\u03bd\u03a9\u03b3\u03c5\u03b4\u03c2;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03b9\u03b9\u03b9\u03c4\u03c4\u03ba\u03b3\u03b2\u03b3\u03b2\u03c4\u03c9\u03c0;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03bc\u03bb\u03c6\u03b5\u03b1\u03bd\u03b1\u03b2\u03b4;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5;
import com.nickuc.login.\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb;
import com.nickuc.login.\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class \u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8
implements \u03a8\u03c8\u03bc\u039b\u03c1\u03bf\u03c2\u03b6,
\u03b2\u03a3\u03a3\u0393\u03bd\u03b8\u03a9\u03bb\u03bd\u03bd\u03a9\u03b3\u03c5\u03b4\u03c2 {
    private static int r;
    private static int m;
    private static int o;
    private static int l;
    private static int n;
    private final \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 ap;
    private static int a;
    private final \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5 a;
    private static int f;
    private static int s;
    private static long c;
    private static int j;
    private static long q;
    private static int e;
    private static long p;
    private static String[] a;
    private final \u03b9\u03b9\u03b9\u03c4\u03c4\u03ba\u03b3\u03b2\u03b3\u03b2\u03c4\u03c9\u03c0 b;
    private static int t;
    private static int h;
    private static int i;
    private static int u;
    private static int b;
    private static int c;
    private static int g;
    private static String[] b;
    private static long d;
    private static int v;
    private static int k;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u0189\u01ab\u01ad\u018d\u01b1\u01d0\u01c8\u01de\u01ca\u0199\u01d7\u01cd\u01db\u01d5\u019e\u01c3\u01e5\u01e4\u01dc\u01e2\u01dc\u01b1", (byte)113, 65), \u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u01c4\u01d1\u01d0\u0193\u01d3\u01cf\u01ca\u01d3\u01de\u01cd\u019a\u01d8\u01dc\u01d5\u01d8\u01de\u01a0\u0531\u053a\u053d\u052c\u0511\u0532\u053a\u0537\u0523\u0538\u0544\u01b7", (byte)113, 66) + string + \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0567", (byte)113, 70) + methodType.toString(), exception);
        }
    }

    @Override
    public boolean at() {
        return t != 0;
    }

    @Override
    public boolean c(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        return s != 0;
    }

    private static String a(int n, long l) {
        l ^= 0x76L;
        l ^= 0xD5A27CF6E95715C0L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(33 + 35), (byte)(34 + 35), (byte)(18 + 65), (byte)(46 + 1), (byte)(50 + 17), (byte)(47 + 19), 67, (byte)(39 + 8), (byte)(62 + 18), (byte)(17 + 58), 67, (byte)(68 + 15), (byte)(22 + 31), (byte)(70 + 10), (byte)(9 + 88), (byte)(20 + 80), (byte)(61 + 39), (byte)(72 + 33), (byte)(43 + 67), (byte)(72 + 31)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(31 + 37), (byte)(46 + 23), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u01ce\u01db\u01da\u019d\u01dd\u01d9\u01d4\u01dd\u01e8\u01d7\u01a4\u01e2\u01e6\u01df\u01e2\u01e8\u01aa\u053b\u0544\u0547\u0536\u051b\u053c\u0544\u0541\u052d\u0542\u054e", (byte)118, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    @Generated
    public \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 a() {
        return this.ap;
    }

    private static void b() {
        int n;
        c = 5344620630140721334L;
        long l = c ^ 0xD5A27CF6E95715C0L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(45 + 23), (byte)(44 + 25), (byte)(59 + 24), (byte)(38 + 9), (byte)(41 + 26), (byte)(4 + 62), (byte)(15 + 52), (byte)(38 + 9), 80, 75, (byte)(44 + 23), (byte)(80 + 3), (byte)(29 + 24), (byte)(2 + 78), (byte)(47 + 50), (byte)(46 + 54), (byte)(2 + 98), (byte)(19 + 86), (byte)(74 + 36), (byte)(94 + 9)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(31 + 38), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.E("\u0569\u05a2\u05ad\u0590\u059f\u05b5\u05b9\u05b0\u05ad\u05b9\u0587\u05b0\u058a\u059a\u0581\u05c0\u05b1\u05a4\u057b\u0586\u057e\u05b6\u058d\u058e", (byte)126, 69);
                    \u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8.b[1] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u057d\u05a1\u0597\u05a9\u0599\u056d\u058d\u05a3\u0583\u058c\u05ab\u0582\u058f\u05b2\u05a7\u0581\u0582\u05b9\u056c\u05a8\u05ab\u05ab\u0582\u0583", (byte)126, 67);
                    continue block7;
                }
                case 1: {
                    \u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0569\u05a2\u05ad\u0590\u059f\u05b5\u05b9\u05b0\u05ad\u05b9\u0586\u0596\u057f\u05b3\u058a\u059f\u05bb\u05b7\u05a0\u0590\u05a5\u05b4\u0589\u0594\u05c8\u059c\u05a2\u0599\u05a9\u05c3\u05ac\u05d1", (byte)126, 70);
                    \u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8.b[1] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0588\u05ac\u05a2\u05b4\u05a4\u0578\u0598\u05ae\u058e\u0597\u05b6\u05a7\u058f\u0593\u059b\u057f\u05a3\u05b8\u059a\u05c4\u0594\u05c6\u058d\u058e", (byte)126, 69);
                    continue block7;
                }
                case 2: {
                    \u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8.b[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u0595\u0583\u0576\u0569\u0582\u05a3\u0587\u058a\u057c\u05a9\u05ac\u0590\u0584\u05b5\u0582\u0575\u058e\u05a9\u0582\u0590\u05b7\u0585\u0582\u0583", (byte)126, 68);
                    continue block7;
                }
                case 4: {
                    \u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u0593\u0566\u0594\u0588\u0598\u057e\u05a5\u0577\u059f\u058b\u05a1\u05ac\u05a2\u05a5\u0573\u05a8\u0573\u0583\u0596\u0594\u05a9\u0585\u0582\u0583", (byte)126, 67);
                }
            }
        }
    }

    @Generated
    \u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8(\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4, \u03b9\u03b9\u03b9\u03c4\u03c4\u03ba\u03b3\u03b2\u03b3\u03b2\u03c4\u03c9\u03c0 \u03b9\u03b9\u03b9\u03c4\u03c4\u03ba\u03b3\u03b2\u03b3\u03b2\u03c4\u03c9\u03c02, \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5 \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c52) {
        this.ap = \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
        this.b = \u03b9\u03b9\u03b9\u03c4\u03c4\u03ba\u03b3\u03b2\u03b3\u03b2\u03c4\u03c9\u03c02;
        this.a = \u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c52;
    }

    @Override
    public \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6[] a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5 \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52) {
        \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92 = \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a();
        \u03bf\u03bc\u03bb\u03c6\u03b5\u03b1\u03bd\u03b1\u03b2\u03b4 \u03bf\u03bc\u03bb\u03c6\u03b5\u03b1\u03bd\u03b1\u03b2\u03b42 = this.b.a(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6);
        String string = this.b.b(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92);
        Object[] objectArray = new Object[i];
        objectArray[\u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8.j] = TwoFactorType.convert((Enum)this.b);
        objectArray[\u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8.k] = \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
        objectArray[\u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8.l] = string;
        \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a(EventEnum.TWO_FACTOR_REQUEST, objectArray);
        \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.A, (Object)(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.E.r() * m));
        \u03bf\u03bc\u03bb\u03c6\u03b5\u03b1\u03bd\u03b1\u03b2\u03b42.a(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
        String string2 = \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(this.a, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, new Object[n]).replace((CharSequence)\u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8.c("\u3e80", (int)o, (long)(p ^ q)), \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.ac());
        \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52.a(string2);
        return new \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6[r];
    }

    @Generated
    public \u03b9\u03b9\u03b9\u03c4\u03c4\u03ba\u03b3\u03b2\u03b3\u03b2\u03c4\u03c9\u03c0 a() {
        return this.b;
    }

    @Override
    public boolean a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42) {
        String string;
        if (!this.b.d(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)) {
            return a != 0;
        }
        \u03bf\u03bc\u03bb\u03c6\u03b5\u03b1\u03bd\u03b1\u03b2\u03b4 \u03bf\u03bc\u03bb\u03c6\u03b5\u03b1\u03bd\u03b1\u03b2\u03b42 = this.b.a(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6);
        if (!\u03bf\u03bc\u03bb\u03c6\u03b5\u03b1\u03bd\u03b1\u03b2\u03b42.aF()) {
            return b != 0;
        }
        \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92 = \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a();
        if (!\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.i((String)\u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8.c("\u3e80", (int)c, (long)d) + this.b.getName()) && ((string = \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92.k()) == null || string.equals(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.ac()))) {
            return e != 0;
        }
        if (Boolean.TRUE.equals(\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.D))) {
            return f != 0;
        }
        string = this.b.b(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92);
        return (string != null && this.b.e(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92) ? g : h) != 0;
    }

    static {
        a = Integer.reverse(0);
        b = Integer.reverse(0);
        c = Integer.reverse(0);
        d = Long.reverse(223143027161945170L);
        e = Integer.reverse(0);
        f = (0 >>> 119 | 0 << ~119 + 1) & 0xFFFFFFFF;
        g = Integer.reverse(Integer.MIN_VALUE);
        h = (0 >>> 147 | 0 << -147) & 0xFFFFFFFF;
        i = Integer.reverse(-1073741824);
        j = Integer.reverse(0);
        k = Integer.reverse(Integer.MIN_VALUE);
        l = Integer.reverse(0x40000000);
        m = Integer.reverse(-1610612736);
        n = Integer.reverse(0);
        o = 0x40000000 >>> 222 | 0x40000000 << ~222 + 1;
        p = Long.reverse(7861247995182306386L);
        q = Long.reverse(0x6E00000000000000L);
        r = 0 >>> 159 | 0 << -159;
        s = 0 >>> 45 | 0 << -45;
        t = 0x10000000 >>> 156 | 0x10000000 << -156;
        u = 512 >>> 200 | 512 << ~200 + 1;
        v = (8192 >>> 76 | 8192 << ~76 + 1) & 0xFFFFFFFF;
        a = new String[u];
        b = new String[v];
        \u03bf\u03c7\u03c9\u03b7\u039b\u03bb\u03c2\u03be\u03a9\u03bd\u03c8.b();
    }
}

