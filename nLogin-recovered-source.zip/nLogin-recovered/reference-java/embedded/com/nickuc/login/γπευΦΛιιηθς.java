/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.Server
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandMap
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.PluginCommand
 *  org.bukkit.command.SimpleCommandMap
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginManager
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.bukkit.Server;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.SimpleCommandMap;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2
implements \u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1,
CommandExecutor,
TabCompleter {
    private static long d;
    private static int s;
    private static int f;
    private static long e;
    private static long ag;
    private static long q;
    private static int m;
    private static int am;
    private static long t;
    private final Server a;
    private static int ab;
    private static long v;
    private final \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<?> b;
    private static int r;
    private static long n;
    private static int aa;
    private static int al;
    private static int y;
    private PluginCommand a;
    private static int j;
    private static long c;
    private static String[] b;
    private static long af;
    private static int z;
    private static long aj;
    private static long w;
    private static int ai;
    private static long l;
    private static int ad;
    private static long g;
    private static int ak;
    private static int i;
    private static int ac;
    private static int ah;
    private static long o;
    private static int k;
    private static int b;
    private static int p;
    private static String[] a;
    private static int ae;
    private static int x;
    private static int u;
    private static long h;
    private static int a;

    static {
        a = Integer.MIN_VALUE >>> 223 | Integer.MIN_VALUE << ~223 + 1;
        b = Integer.reverse(0);
        d = Long.reverse(-6689698594958815352L);
        e = Long.reverse(0x1000000000000000L);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Long.reverse(-6689698594958815352L);
        h = Long.reverse(0x1000000000000000L);
        i = Integer.reverse(0);
        j = Integer.reverse(0x40000000);
        k = (-1 >>> 107 | -1 << ~107 + 1) & 0xFFFFFFFF;
        l = Long.reverse(-5536777090351968376L);
        m = (0xC000000 >>> 186 | 0xC000000 << ~186 + 1) & 0xFFFFFFFF;
        n = Long.reverse(-6689698594958815352L);
        o = Long.reverse(0x1000000000000000L);
        p = (512 >>> 71 | 512 << ~71 + 1) & 0xFFFFFFFF;
        q = Long.reverse(-5536777090351968376L);
        r = Integer.reverse(-1610612736);
        s = Integer.reverse(-1);
        t = Long.reverse(-5536777090351968376L);
        u = Integer.reverse(0x60000000);
        v = Long.reverse(-6689698594958815352L);
        w = Long.reverse(0x1000000000000000L);
        x = Integer.reverse(0);
        y = (16384 >>> 141 | 16384 << -141) & 0xFFFFFFFF;
        z = (0 >>> 138 | 0 << ~138 + 1) & 0xFFFFFFFF;
        aa = 32768 >>> 111 | 32768 << ~111 + 1;
        ab = Integer.reverse(0x40000000);
        ac = (0 >>> 147 | 0 << -147) & 0xFFFFFFFF;
        ad = Integer.reverse(Integer.MIN_VALUE);
        ae = Integer.reverse(-536870912);
        af = Long.reverse(-6689698594958815352L);
        ag = Long.reverse(0x1000000000000000L);
        ah = Integer.reverse(0x10000000);
        ai = (-1 >>> 85 | -1 << -85) & 0xFFFFFFFF;
        aj = Long.reverse(-5536777090351968376L);
        ak = (0 >>> 48 | 0 << -48) & 0xFFFFFFFF;
        al = (589824 >>> 176 | 589824 << -176) & 0xFFFFFFFF;
        am = -1879048192 >>> 220 | -1879048192 << ~220 + 1;
        a = new String[al];
        b = new String[am];
        \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b();
    }

    @Generated
    public \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2(Server server, \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<?> \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be2) {
        this.a = server;
        this.b = \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be2;
    }

    public List<String> onTabComplete(CommandSender commandSender, Command command, String string, String[] stringArray) {
        return this.b.a(commandSender, commandSender.getName(), commandSender instanceof Player, string, stringArray);
    }

    private PluginCommand a() {
        try {
            Class[] classArray = new Class[y];
            classArray[\u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.z] = String.class;
            classArray[\u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.aa] = Plugin.class;
            Constructor constructor = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.b(PluginCommand.class, classArray);
            Object[] objectArray = new Object[ab];
            objectArray[\u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.ac] = this.b.aa();
            objectArray[\u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.ad] = this.b.a().b();
            PluginCommand pluginCommand = (PluginCommand)constructor.newInstance(objectArray);
            pluginCommand.setAliases(this.b.c());
            String string = this.b.ab();
            pluginCommand.setDescription((String)(string == null ? \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.c("\u3e80", (int)ae, (long)(af ^ ag)) : string));
            pluginCommand.setExecutor((CommandExecutor)this);
            pluginCommand.setTabCompleter((TabCompleter)this);
            return pluginCommand;
        }
        catch (Exception exception) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.c("\u3e83", (int)(ah & ai), (long)aj) + exception.getLocalizedMessage(), exception, new Object[ak]);
            return null;
        }
    }

    public boolean onCommand(CommandSender commandSender, Command command, String string, String[] stringArray) {
        this.b.a(commandSender, commandSender.getName(), commandSender instanceof Player, string, stringArray);
        return a != 0;
    }

    private static String a(int n, long l) {
        l ^= 8L;
        l ^= 0x6B6774D2E19CAC50L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(11 + 57), (byte)(47 + 22), (byte)(40 + 43), (byte)(44 + 3), (byte)(56 + 11), 66, (byte)(33 + 34), (byte)(35 + 12), (byte)(14 + 66), (byte)(24 + 51), (byte)(48 + 19), (byte)(66 + 17), (byte)(6 + 47), (byte)(64 + 16), (byte)(79 + 18), (byte)(52 + 48), (byte)(19 + 81), (byte)(38 + 67), 110, (byte)(64 + 39)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(6 + 77)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.C("\u0418\u0425\u0424\u03e7\u0427\u0423\u041e\u0427\u0432\u0421\u03ee\u042c\u0430\u0429\u042c\u0432\u03f4\u0779\u0787\u077d\u078e\u0770\u0766\u0785\u0786\u0785\u0787\u0792", (byte)0, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public void W() {
        this.a = this.a();
        if (this.a == null) {
            return;
        }
        try {
            PluginManager pluginManager = this.a.getPluginManager();
            Field field = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(pluginManager.getClass(), (String)\u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.c("\u3e80", (int)b, (long)(d ^ e)));
            Object object = field.get(pluginManager);
            if (object instanceof CommandMap) {
                CommandMap commandMap = (CommandMap)object;
                commandMap.register(this.b.a().q().toLowerCase(Locale.ENGLISH), (Command)this.a);
            }
        }
        catch (Exception exception) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.c("\u3e83", (int)f, (long)(g ^ h)) + exception.getLocalizedMessage(), exception, new Object[i]);
        }
    }

    @Override
    public synchronized void X() {
        if (this.a == null) {
            return;
        }
        try {
            PluginManager pluginManager = this.a.getPluginManager();
            Field field = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(pluginManager.getClass(), (String)\u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.c("\u3e80", (int)(j & k), (long)l));
            Object object = field.get(pluginManager);
            if (object instanceof CommandMap) {
                CommandMap commandMap = (CommandMap)object;
                List list = this.a.getAliases();
                this.a.setAliases(Collections.emptyList());
                this.a.unregister(commandMap);
                if (commandMap instanceof SimpleCommandMap) {
                    Field field2 = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(SimpleCommandMap.class, (String)\u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.c("\u3e83", (int)m, (long)(n ^ o)));
                    Map map = (Map)field2.get(commandMap);
                    String string = this.b.a().q().toLowerCase(Locale.ENGLISH);
                    String string2 = this.a.getName();
                    map.remove(string + (String)\u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.c("\u3e86", (int)p, (long)q) + string2);
                    map.remove(string2);
                    for (String string3 : list) {
                        map.remove(string + (String)\u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.c("\u3e89", (int)(r & s), (long)t) + string3);
                        map.remove(string3);
                    }
                }
            }
        }
        catch (Exception exception) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.c("\u3e8c", (int)u, (long)(v ^ w)) + exception.getLocalizedMessage(), exception, new Object[x]);
        }
    }

    private static void b() {
        int n;
        c = 1293430922839233733L;
        long l = c ^ 0x6B6774D2E19CAC50L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(43 + 25), (byte)(53 + 16), (byte)(12 + 71), (byte)(24 + 23), (byte)(28 + 39), (byte)(15 + 51), (byte)(64 + 3), (byte)(2 + 45), (byte)(73 + 7), 75, (byte)(60 + 7), (byte)(37 + 46), (byte)(44 + 9), (byte)(40 + 40), (byte)(48 + 49), (byte)(67 + 33), (byte)(57 + 43), 105, (byte)(67 + 43), (byte)(48 + 55)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(2 + 67), (byte)(55 + 28)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u0509\u0531\u0525\u050e\u0506\u0512\u052f\u04ec\u04f4\u052c\u0507\u0507\u050f\u0531\u0535\u053d\u052d\u0501\u0541\u051c\u0523\u0510\u050d\u050e", (byte)87, 67);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[1] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.C("\u0512\u0532\u0513\u0505\u0530\u0524\u0507\u0523\u052a\u0509\u0535\u0510\u053d\u04f8\u0540\u052c\u0541\u051f\u0532\u053c\u051f\u0523\u052a\u050a\u0518\u0538\u0515\u0504\u0528\u0541\u052e\u0527\u0511\u054d\u054d\u0535\u050e\u0520\u0556\u0549\u0511\u0526\u0553\u0522", (byte)87, 67);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[2] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.E("\u0562\u058a\u057e\u0567\u055f\u056b\u0588\u0545\u054d\u0585\u0560\u0560\u0568\u058a\u058e\u0596\u0586\u055a\u059a\u0575\u057c\u0569\u0566\u0567", (byte)87, 69);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[3] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.F("\u055b\u0548\u0576\u0588\u055d\u054c\u0561\u0585\u0589\u0586\u056f\u0550\u0578\u0584\u0577\u0551\u0579\u0577\u0559\u0589\u056d\u058f\u0566\u0567", (byte)87, 70);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[4] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.D("\u0524\u050c\u0504\u050b\u0501\u052b\u0526\u0505\u0537\u053a\u04f4\u0502", (byte)87, 68);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[5] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u057d\u0565\u055d\u0564\u055a\u0584\u057f\u055e\u0590\u0593\u054d\u055b", (byte)87, 70);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[6] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u056b\u058b\u056c\u055e\u0589\u057d\u0560\u057c\u0583\u0562\u058d\u0598\u0557\u0599\u056b\u0590\u059c\u058f\u0576\u0597\u0579\u056b\u057a\u0562\u0561\u0579\u0574\u0593\u057c\u05a8\u0572\u0588\u0587\u0565\u0568\u05af\u059f\u05a0\u056a\u0573\u05a8\u058f\u05b0\u057b", (byte)87, 70);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[7] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u0522\u0500\u0527\u0504\u0504\u04f8\u04f4\u0513\u0539\u0528\u04fa\u053a\u0530\u051b\u0515\u04fc\u0533\u0516\u0517\u053e\u0528\u0513\u0534\u0507\u0526\u054c\u051b\u051f\u053c\u0525\u0523\u0520\u052e\u0523\u0544\u0544\u0558\u0513\u0539\u0551\u054e\u0549\u054f\u055d\u052e\u0549\u0562\u051a\u051f\u0565\u0521\u0544\u053b\u055d\u0559\u0538\u0521\u0567\u055d\u0544\u055b\u0540\u053f\u0545", (byte)87, 68);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[8] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u0512\u0532\u0513\u0505\u0530\u0524\u0507\u0523\u052a\u0509\u0536\u050b\u0519\u04f6\u0536\u0510\u0531\u053d\u053c\u0516\u0505\u0548\u0518\u0548\u0538\u053f\u051b\u0544\u050e\u052a\u053e\u051c\u053c\u0528\u050c\u0508\u0547\u0525\u0554\u052e\u0537\u051b\u0547\u0522", (byte)87, 67);
                    continue block7;
                }
                case 1: {
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.B("\u017c\u01a4\u0198\u0181\u0179\u0185\u01a2\u015f\u0167\u019f\u0179\u01b2\u019e\u019d\u017d\u01ae\u017e\u016f\u0192\u0197\u0170\u0183\u0180\u0181", (byte)87, 66);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[1] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u0185\u01a5\u0186\u0178\u01a3\u0197\u017a\u0196\u019d\u017c\u01a8\u0183\u01b0\u016b\u01b3\u019f\u01b4\u0192\u01a5\u01af\u0192\u0196\u019d\u017d\u018b\u01ab\u0188\u0177\u019b\u01b4\u01a1\u019a\u01a7\u01b7\u01b9\u0183\u01a6\u01aa\u0194\u01ad\u019d\u01bc\u01be\u0195", (byte)87, 66);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u017c\u01a4\u0198\u0181\u0179\u0185\u01a2\u015f\u0167\u019f\u017a\u0167\u01a9\u017e\u018e\u01ab\u018b\u0185\u0177\u01b3\u0192\u01a9\u0180\u0181", (byte)87, 65);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[3] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.A("\u0175\u0162\u0190\u01a2\u0177\u0166\u017b\u019f\u01a3\u01a0\u0189\u0169\u0172\u016c\u01a7\u0180\u019f\u018b\u0180\u01b2\u01b2\u0193\u0180\u0181", (byte)87, 65);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[4] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u058c\u0561\u0545\u055e\u0560\u056e\u055b\u058f\u058f\u058e\u0590\u055b", (byte)87, 69);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[5] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u058a\u0555\u056d\u054a\u055a\u057d\u0573\u0592\u0561\u0584\u0551\u055b", (byte)87, 69);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[6] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.F("\u056b\u058b\u056c\u055e\u0589\u057d\u0560\u057c\u0583\u0562\u058d\u0598\u0557\u0599\u056b\u0590\u059c\u058f\u0576\u0597\u0579\u056b\u057a\u0562\u0561\u0579\u0574\u0593\u057c\u05a8\u0572\u0588\u057b\u0587\u0583\u0599\u056d\u05a9\u0593\u05a6\u0587\u0596\u057e\u058d\u05b6\u05b6\u0594\u05a4\u0593\u057a\u05b3\u05b7\u0578\u0589\u0586\u0587", (byte)87, 70);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[7] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u057b\u0559\u0580\u055d\u055d\u0551\u054d\u056c\u0592\u0581\u0553\u0593\u0589\u0574\u056e\u0555\u058c\u056f\u0570\u0597\u0581\u056c\u058d\u0560\u057f\u05a5\u0574\u0578\u0595\u057e\u057c\u0579\u0587\u057c\u059d\u059d\u05b1\u056c\u0592\u05aa\u05a7\u05a2\u05a8\u05b6\u0587\u05a2\u05bb\u0573\u0578\u05be\u057a\u059d\u0594\u05b6\u058f\u05bc\u05a2\u05bd\u0595\u059a\u057e\u05a0\u05c0\u05c7", (byte)87, 69);
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[8] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.E("\u056b\u058b\u056c\u055e\u0589\u057d\u0560\u057c\u0583\u0562\u058f\u0564\u0572\u054f\u058f\u0569\u058a\u0596\u0595\u056f\u055e\u05a1\u0571\u05a1\u0591\u0598\u0574\u059d\u0567\u0583\u0597\u0575\u0580\u056b\u0583\u05ab\u059b\u056e\u056d\u05ae\u0573\u0567\u05a8\u057b", (byte)87, 69);
                    continue block7;
                }
                case 2: {
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u0574\u057a\u057d\u0587\u0570\u057b\u0560\u0580\u054f\u0584\u0556\u0566\u0587\u056d\u0562\u058b\u0567\u059e\u057e\u0575\u0570\u0577\u0572\u059a\u05a2\u05a4\u055e\u0597\u055f\u0561\u056a\u059b", (byte)87, 69);
                    continue block7;
                }
                case 4: {
                    \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u015c\u01a1\u01a4\u01a3\u01a1\u0183\u0169\u019a\u016b\u0189\u018d\u016f\u01a8\u016a\u01a0\u01b2\u0194\u01ad\u01b5\u01b2\u01b8\u01a9\u0180\u0181", (byte)87, 65);
                }
            }
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u0543\u0565\u0567\u0547\u056b\u058a\u0582\u0598\u0584\u0553\u0591\u0587\u0595\u058f\u0558\u057d\u059f\u059e\u0596\u059c\u0596\u056b", (byte)95, 70), \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u0535\u0542\u0541\u0504\u0544\u0540\u053b\u0544\u054f\u053e\u050b\u0549\u054d\u0546\u0549\u054f\u0511\u0896\u08a4\u089a\u08ab\u088d\u0883\u08a2\u08a3\u08a2\u08a4\u08af\u0528", (byte)95, 68) + string + \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u0177", (byte)95, 65) + methodType.toString(), exception);
        }
    }
}

