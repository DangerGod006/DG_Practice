/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4;

class \u03c1\u03c1\u03b9\u03a6\u03c9\u03a9\u03b3\u03c0\u03c2\u03ba\u03c8\u03c2 {
    private static int a = (1024 >>> 234 | 1024 << ~234 + 1) & 0xFFFFFFFF;
    private static int b = 256 >>> 135 | 256 << ~135 + 1;
    private static int c = Integer.reverse(-1073741824);
    static final /* synthetic */ int[] K;

    static {
        K = new int[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.values().length];
        try {
            \u03c1\u03c1\u03b9\u03a6\u03c9\u03a9\u03b3\u03c0\u03c2\u03ba\u03c8\u03c2.K[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.b.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03c1\u03c1\u03b9\u03a6\u03c9\u03a9\u03b3\u03c0\u03c2\u03ba\u03c8\u03c2.K[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.c.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03c1\u03c1\u03b9\u03a6\u03c9\u03a9\u03b3\u03c0\u03c2\u03ba\u03c8\u03c2.K[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.d.ordinal()] = c;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

