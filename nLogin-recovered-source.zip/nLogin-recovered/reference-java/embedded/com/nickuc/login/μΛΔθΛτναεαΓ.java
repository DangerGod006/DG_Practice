/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.loader.LoaderBootstrap
 *  com.nickuc.login.loader.platform.BukkitLoader
 *  org.bukkit.Server
 *  org.bukkit.plugin.Plugin
 */
package com.nickuc.login;

import com.nickuc.login.loader.LoaderBootstrap;
import com.nickuc.login.loader.platform.BukkitLoader;
import com.nickuc.login.\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4;
import com.nickuc.login.\u0394\u03b1\u03c3\u03c2\u03a6\u03c8\u03a8\u03a9\u03c3\u03c3\u03be\u03ba\u03ba\u03bc\u03c9;
import com.nickuc.login.\u03a0\u03b6\u03a3\u03a8\u03b1\u03a9\u03c8\u03bf\u03b7\u03b9\u03b7\u0393\u0393;
import com.nickuc.login.\u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7;
import com.nickuc.login.\u03a6\u03a6\u03b4\u0393\u03b8\u03a3\u03b7\u03b5\u03a6\u03c0\u03bf\u03c7\u03b8;
import com.nickuc.login.\u03a8\u03a9\u0394\u03be\u03b4\u03ba\u039b\u03c8\u03c8\u03ba\u03c6\u03b4;
import com.nickuc.login.\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4;
import com.nickuc.login.\u03b8\u03b1\u03a9\u03a6\u03bd\u03c5\u03c8\u03b3;
import com.nickuc.login.\u03ba\u03b1\u03a6\u03b6\u03b8\u03b8\u03c5\u03c5\u03b5\u03c6\u03a6\u03b3;
import com.nickuc.login.\u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9;
import com.nickuc.login.\u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8;
import com.nickuc.login.\u03c0\u03b7\u03bb\u03a3\u03c1\u03b7\u039b\u03c1\u03bb\u03a8\u03b2\u03c7\u03bb;
import com.nickuc.login.\u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6;
import java.io.File;
import org.bukkit.Server;
import org.bukkit.plugin.Plugin;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393
implements LoaderBootstrap,
\u03a6\u03a6\u03b4\u0393\u03b8\u03a3\u03b7\u03b5\u03a6\u03c0\u03bf\u03c7\u03b8,
\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<BukkitLoader> {
    private final \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8 a;
    private static int a = Integer.reverse(Integer.MIN_VALUE);
    private final BukkitLoader a;
    final \u03c0\u03b7\u03bb\u03a3\u03c1\u03b7\u039b\u03c1\u03bb\u03a8\u03b2\u03c7\u03bb a;
    private final \u03a0\u03b6\u03a3\u03a8\u03b1\u03a9\u03c8\u03bf\u03b7\u03b9\u03b7\u0393\u0393 a;

    public void enable() {
        this.a.av();
    }

    @Override
    public /* synthetic */ Object b() {
        return this.a();
    }

    public BukkitLoader a() {
        return this.a;
    }

    @Override
    public void c() {
        if (this.N()) {
            this.a.getServer().getPluginManager().disablePlugin((Plugin)this.a);
        }
    }

    @Override
    public Object a(int n) {
        if (n == a) {
            return this.a().getPort();
        }
        return null;
    }

    @Override
    public \u03c0\u03b7\u03bb\u03a3\u03c1\u03b7\u039b\u03c1\u03bb\u03a8\u03b2\u03c7\u03bb a() {
        return this.a;
    }

    public void load() {
        this.a.au();
    }

    @Override
    public /* synthetic */ \u03b8\u03b1\u03a9\u03a6\u03bd\u03c5\u03c8\u03b3 b() {
        return this.a();
    }

    @Override
    public \u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9 b(boolean bl) {
        return this.a.b(bl);
    }

    protected void j() {
        if (this.a.am()) {
            ((\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4)this.a.a()).j();
        }
    }

    public \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7 a() {
        return (\u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7)this.a.c();
    }

    @Override
    public \u03a8\u03a9\u0394\u03be\u03b4\u03ba\u039b\u03c8\u03c8\u03ba\u03c6\u03b4 a() {
        return this.a;
    }

    protected void O() {
        if (this.a.am()) {
            ((\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4)this.a.a()).O();
        }
    }

    @Override
    public String s() {
        return this.a.bo;
    }

    @Override
    public String q() {
        return this.a.bn;
    }

    @Override
    public File c() {
        return this.a.getDataFolder();
    }

    public String toString() {
        return this.a.toString();
    }

    @Override
    public boolean N() {
        return this.a.isEnabled();
    }

    @Override
    public \u03a0\u03b6\u03a3\u03a8\u03b1\u03a9\u03c8\u03bf\u03b7\u03b9\u03b7\u0393\u0393 a() {
        return this.a;
    }

    public Server a() {
        return this.a.getServer();
    }

    public \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393(BukkitLoader bukkitLoader, String string, \u03ba\u03b1\u03a6\u03b6\u03b8\u03b8\u03c5\u03c5\u03b5\u03c6\u03a6\u03b3 \u03ba\u03b1\u03a6\u03b6\u03b8\u03b8\u03c5\u03c5\u03b5\u03c6\u03a6\u03b32) {
        this.a = bukkitLoader;
        this.a = new \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8(this);
        this.a = new \u03c0\u03b7\u03bb\u03a3\u03c1\u03b7\u039b\u03c1\u03bb\u03a8\u03b2\u03c7\u03bb(string, bukkitLoader.getVersion(), \u03ba\u03b1\u03a6\u03b6\u03b8\u03b8\u03c5\u03c5\u03b5\u03c6\u03a6\u03b32, this);
        this.a = new \u0394\u03b1\u03c3\u03c2\u03a6\u03c8\u03a8\u03a9\u03c3\u03c3\u03be\u03ba\u03ba\u03bc\u03c9(bukkitLoader.getLogger());
    }

    protected abstract \u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6[] a();

    protected void T() {
        if (this.a.am()) {
            ((\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4)this.a.a()).T();
        }
    }

    public void disable() {
        this.a.aw();
    }

    protected void i() {
        if (this.a.am()) {
            ((\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4)this.a.a()).i();
        }
    }
}

