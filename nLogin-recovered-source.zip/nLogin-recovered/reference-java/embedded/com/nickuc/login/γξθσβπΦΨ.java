/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.plugin.Plugin
 *  net.md_5.bungee.api.scheduler.ScheduledTask
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be;
import com.nickuc.login.\u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.md_5.bungee.api.plugin.Plugin;
import net.md_5.bungee.api.scheduler.ScheduledTask;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8
implements \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be {
    private static long g;
    private static int c;
    private static int m;
    private static String[] a;
    private static int n;
    private final String ar;
    private static int l;
    private static String[] b;
    private static int d;
    private static int j;
    private static int i;
    private ScheduledTask a;
    private static int b;
    private final Runnable c;
    private static long k;
    private static long e;
    private static int f;
    private boolean M;
    private static int a;
    private static long c;
    private static long h;

    \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8(\u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2 \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c22, Runnable runnable) {
        this.ar = new Exception().getStackTrace()[a].toString();
        this.c = () -> {
            try {
                \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c22.b(this);
                runnable.run();
            }
            finally {
                \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c22.c(this);
            }
        };
    }

    public \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8 a(Plugin plugin, long l, TimeUnit timeUnit) {
        if (this.a != null) {
            throw new IllegalStateException((String)\u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8.c("\u3e80", (int)f, (long)(g ^ h)));
        }
        this.a = plugin.getProxy().getScheduler().schedule(plugin, this.c, l, timeUnit);
        return this;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0556\u0578\u057a\u055a\u057e\u059d\u0595\u05ab\u0597\u0566\u05a4\u059a\u05a8\u05a2\u056b\u0590\u05b2\u05b1\u05a9\u05af\u05a9\u057e", (byte)114, 69), \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u01c6\u01d3\u01d2\u0195\u01d5\u01d1\u01cc\u01d5\u01e0\u01cf\u019c\u01da\u01de\u01d7\u01da\u01e0\u01a2\u0527\u0533\u052e\u053a\u052a\u0539\u0520\u0523\u01b6", (byte)114, 66) + string + \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u0545", (byte)114, 68) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x65L;
        l ^= 0xEC2AFF5881BD333DL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(55 + 13), (byte)(56 + 13), 83, (byte)(35 + 12), (byte)(6 + 61), (byte)(37 + 29), (byte)(52 + 15), (byte)(46 + 1), (byte)(35 + 45), (byte)(49 + 26), (byte)(35 + 32), (byte)(46 + 37), (byte)(42 + 11), (byte)(26 + 54), (byte)(66 + 31), (byte)(82 + 18), 100, (byte)(21 + 84), (byte)(85 + 25), (byte)(45 + 58)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(41 + 28), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u052c\u0539\u0538\u04fb\u053b\u0537\u0532\u053b\u0546\u0535\u0502\u0540\u0544\u053d\u0540\u0546\u0508\u088d\u0899\u0894\u08a0\u0890\u089f\u0886\u0889", (byte)13, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public void Z() {
        if (this.a != null) {
            this.a.cancel();
        }
        this.M = l;
    }

    @Override
    public boolean P() {
        return this.M;
    }

    @Override
    public <T> T c() {
        return (T)this.a;
    }

    private static void b() {
        int n;
        c = 1888369831707275874L;
        long l = c ^ 0xEC2AFF5881BD333DL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(28 + 40), (byte)(25 + 44), 83, (byte)(35 + 12), 67, (byte)(4 + 62), (byte)(59 + 8), (byte)(42 + 5), (byte)(31 + 49), (byte)(70 + 5), (byte)(29 + 38), (byte)(72 + 11), (byte)(50 + 3), (byte)(4 + 76), (byte)(86 + 11), (byte)(3 + 97), (byte)(81 + 19), (byte)(65 + 40), (byte)(97 + 13), (byte)(53 + 50)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(29 + 40), (byte)(22 + 61)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u016c\u0191\u017c\u0195\u01be\u018d\u0190\u01a2\u01aa\u01c2\u01ac\u0192\u019f\u0186\u0188\u01b4\u01a7\u0197\u01ca\u01bf\u01bb\u019c\u01a1\u01be\u01bc\u01a1\u01a7\u01d5\u019e\u01a3\u01c5\u01ce", (byte)97, 65);
                    \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8.b[1] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u0548\u056d\u0558\u0571\u059a\u0569\u056c\u057e\u0586\u059e\u0588\u056e\u057b\u0562\u0564\u0590\u0583\u0573\u05a6\u059b\u0597\u0578\u057d\u059a\u0598\u057d\u0583\u05b1\u057a\u057f\u05a1\u05aa", (byte)97, 69);
                    \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8.b[2] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u0548\u056d\u0558\u0571\u059a\u0569\u056c\u057e\u0586\u059e\u0588\u056e\u057b\u0562\u0564\u0590\u0583\u0573\u05a6\u059b\u0597\u0578\u057d\u059a\u0598\u057d\u0583\u05b1\u057a\u057f\u05a1\u05aa", (byte)97, 69);
                    continue block7;
                }
                case 1: {
                    \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8.b[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.C("\u0503\u0528\u0513\u052c\u0555\u0524\u0527\u0539\u0541\u0559\u0543\u0529\u0536\u051d\u051f\u054b\u053e\u052e\u0561\u0556\u0552\u0533\u0523\u0536\u0547\u0557\u0538\u055e\u056a\u0562\u052d\u056d\u0572\u053c\u052d\u052b\u0542\u0535\u0572\u056c\u0538\u0566\u0575\u0540", (byte)97, 67);
                    \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8.b[1] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u016c\u0191\u017c\u0195\u01be\u018d\u0190\u01a2\u01aa\u01c2\u01ac\u0192\u019f\u0186\u0188\u01b4\u01a7\u0197\u01ca\u01bf\u01bb\u01a2\u01bd\u01c1\u01c2\u01bc\u01a8\u01b2\u019e\u01c5\u01af\u0199\u01a7\u019a\u01cb\u01a5\u01d5\u019f\u019c\u0193\u01d1\u01ce\u01e2\u01a9", (byte)97, 66);
                    \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8.b[2] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u0503\u0528\u0513\u052c\u0555\u0524\u0527\u0539\u0541\u0559\u0543\u0529\u0536\u051d\u051f\u054b\u053e\u052e\u0561\u0556\u0552\u0532\u0565\u0532\u0556\u0533\u052b\u0523\u054b\u0558\u0560\u0529\u0546\u0573\u053e\u0567\u0562\u0553\u0566\u0579\u0543\u054c\u0565\u0540", (byte)97, 68);
                    continue block7;
                }
                case 2: {
                    \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u0570\u0566\u058d\u0570\u0595\u0595\u058b\u0596\u058c\u0593\u058e\u0565", (byte)97, 69);
                    continue block7;
                }
                case 4: {
                    \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.E("\u056a\u0598\u0567\u0553\u0575\u056a\u0585\u0576\u0571\u055a\u056e\u058a\u057d\u0590\u059a\u0593\u055f\u057d\u0599\u05a5\u05a4\u0573\u0570\u0571", (byte)97, 69);
                }
            }
        }
    }

    @Override
    public String t() {
        return this.ar;
    }

    public \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8 a(Plugin plugin, long l, long l2, TimeUnit timeUnit) {
        if (this.a != null) {
            throw new IllegalStateException((String)\u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8.c("\u3e80", (int)(i & j), (long)k));
        }
        this.a = plugin.getProxy().getScheduler().schedule(plugin, this.c, l, l2, timeUnit);
        return this;
    }

    \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8(\u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c2 \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c22, Consumer<\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be> consumer) {
        this.ar = new Exception().getStackTrace()[b].toString();
        this.c = () -> {
            try {
                \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c22.b(this);
                consumer.accept(this);
            }
            finally {
                \u03b8\u03c5\u03c5\u0394\u0393\u03a8\u03bd\u03b5\u03c0\u03c22.c(this);
            }
        };
    }

    static {
        a = (0x200000 >>> 52 | 0x200000 << ~52 + 1) & 0xFFFFFFFF;
        b = Integer.reverse(0x40000000);
        c = 0 >>> 104 | 0 << -104;
        d = -1 >>> 133 | -1 << -133;
        e = Long.reverse(-2283431685810082728L);
        f = 4 >>> 98 | 4 << ~98 + 1;
        g = Long.reverse(5066442906058566744L);
        h = Long.reverse(-6485183463413514240L);
        i = (0x800000 >>> 150 | 0x800000 << -150) & 0xFFFFFFFF;
        j = Integer.reverse(-1);
        k = Long.reverse(-2283431685810082728L);
        l = Integer.MIN_VALUE >>> 31 | Integer.MIN_VALUE << ~31 + 1;
        m = Integer.reverse(-1073741824);
        n = (0x60000000 >>> 93 | 0x60000000 << -93) & 0xFFFFFFFF;
        a = new String[m];
        b = new String[n];
        \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8.b();
    }

    public \u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8 a(Plugin plugin) {
        if (this.a != null) {
            throw new IllegalStateException((String)\u03b3\u03be\u03b8\u03c3\u03b2\u03c0\u03a6\u03a8.c("\u3e80", (int)(c & d), (long)e));
        }
        this.a = plugin.getProxy().getScheduler().runAsync(plugin, this.c);
        return this;
    }
}

