/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03a8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2;
import com.nickuc.login.\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3;
import com.nickuc.login.\u03c3\u03a9\u03c4\u03b2\u03c3\u03c5\u03c3\u03c8\u03a8;
import java.sql.Connection;
import java.sql.Driver;
import java.util.Properties;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03a0\u03c1\u03c0\u03bc\u03b1\u03b8\u03b4\u03b8\u03c1\u03c5\u03b8
implements \u03a8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2 {
    private final String av;
    private final Driver a;
    private final Properties a;
    private final \u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3 i;

    @Generated
    private \u03a0\u03c1\u03c0\u03bc\u03b1\u03b8\u03b4\u03b8\u03c1\u03c5\u03b8(\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3 \u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a32, Driver driver, String string, Properties properties) {
        this.i = \u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a32;
        this.a = driver;
        this.av = string;
        this.a = properties;
    }

    /* synthetic */ \u03a0\u03c1\u03c0\u03bc\u03b1\u03b8\u03b4\u03b8\u03c1\u03c5\u03b8(\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3 \u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a32, Driver driver, String string, Properties properties, \u03c3\u03a9\u03c4\u03b2\u03c3\u03c5\u03c3\u03c8\u03a8 \u03c3\u03a9\u03c4\u03b2\u03c3\u03c5\u03c3\u03c8\u03a82) {
        this(\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a32, driver, string, properties);
    }

    @Override
    public void c() {
    }

    @Override
    public Connection a() {
        return this.a.connect(this.av, this.a);
    }

    @Override
    public void a(Connection connection) {
        connection.close();
    }

    @Override
    public \u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3 a() {
        return this.i;
    }
}

