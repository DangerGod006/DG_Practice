/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c7\u03b9\u03c2\u03b6\u0393\u03b8\u03c9\u03c6\u03c1\u03bf;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba
extends \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5<\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u0393> {
    private static String[] c;
    private static int o;
    private static int p;
    private static int g;
    private static int r;
    private static int m;
    private static int s;
    private static String[] d;
    private static int b;
    private static long n;
    private static long q;
    private static long f;
    private static long e;

    private static String a(int n, long l) {
        l ^= 0x3BL;
        l ^= 0xC4B58C08278C399FL;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(66 + 2), (byte)(3 + 66), (byte)(25 + 58), 47, (byte)(35 + 32), (byte)(3 + 63), (byte)(35 + 32), (byte)(7 + 40), (byte)(78 + 2), (byte)(60 + 15), (byte)(38 + 29), (byte)(12 + 71), (byte)(4 + 49), (byte)(63 + 17), (byte)(88 + 9), (byte)(61 + 39), (byte)(50 + 50), (byte)(4 + 101), 110, (byte)(54 + 49)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(72 + 11)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u0108\u0115\u0114\u00d7\u0117\u0113\u010e\u0117\u0122\u0111\u00de\u011c\u0120\u0119\u011c\u0122\u00e4\u0467\u047e\u046c\u045f\u0462\u047d\u0482\u0460\u0484\u0462\u047a", (byte)19, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    @Override
    public void b(Object object) {
        this.a(object, null);
    }

    @Override
    public void a(Object object, Object object2) {
        if (object2 != null && !(object2 instanceof \u03c7\u03b9\u03c2\u03b6\u0393\u03b8\u03c9\u03c6\u03c1\u03bf)) {
            throw new IllegalArgumentException((String)\u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba.c("\u3e80", (int)b, (long)f) + object2.getClass().getCanonicalName());
        }
        if (!(object instanceof String)) {
            throw new IllegalArgumentException((String)\u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba.c("\u3e83", (int)(g & m), (long)n));
        }
        ((\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u0393)this.h).a().getProxy().registerChannel((String)object);
        if (object2 != null) {
            ((\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u0393)this.h).a((\u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393)object2, new \u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393[o]);
        }
    }

    static {
        b = (0 >>> 44 | 0 << ~44 + 1) & 0xFFFFFFFF;
        f = Long.reverse(746522864571775012L);
        g = Integer.reverse(Integer.MIN_VALUE);
        m = (-1 >>> 53 | -1 << -53) & 0xFFFFFFFF;
        n = Long.reverse(746522864571775012L);
        o = (0 >>> 203 | 0 << ~203 + 1) & 0xFFFFFFFF;
        p = Integer.reverse(0x40000000);
        q = Long.reverse(746522864571775012L);
        r = -2147483647 >>> 31 | -2147483647 << -31;
        s = Integer.reverse(-1073741824);
        c = new String[r];
        d = new String[s];
        \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba.b();
    }

    public \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba(\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u0393 \u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u03932) {
        super(\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u03932);
    }

    private static void b() {
        int n;
        e = 2602941981352278635L;
        long l = e ^ 0xC4B58C08278C399FL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(41 + 27), (byte)(21 + 48), (byte)(72 + 11), (byte)(9 + 38), (byte)(54 + 13), (byte)(12 + 54), (byte)(18 + 49), (byte)(30 + 17), (byte)(2 + 78), (byte)(50 + 25), (byte)(50 + 17), (byte)(78 + 5), (byte)(37 + 16), (byte)(54 + 26), (byte)(85 + 12), (byte)(24 + 76), (byte)(46 + 54), (byte)(21 + 84), (byte)(72 + 38), 103}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(32 + 51)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba.d[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u04ce\u04ce\u04ca\u04e4\u04e6\u0513\u0519\u04f4\u04ec\u04cd\u050b\u051e\u0518\u04fc\u04d9\u0519\u051f\u04ed\u04e2\u050d\u051d\u0505\u0507\u04e2\u0507\u050c\u04f6\u0500\u04e7\u04e9\u04e7\u052b", (byte)76, 68);
                    \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba.d[1] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u017f\u016e\u014e\u0161\u018a\u0193\u0174\u018a\u0196\u0171\u0172\u0172\u017d\u0189\u0174\u0169\u019d\u0157\u019f\u015c\u0180\u016d\u017d\u015f\u0165\u0180\u018a\u01a1\u01a6\u01a8\u018b\u0183\u01b0\u019e\u018d\u019c\u01ad\u01a2\u01a1\u01b8\u0195\u01a9\u0171\u017f", (byte)76, 65);
                    \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba.d[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u017f\u016e\u014e\u0161\u018a\u0193\u0174\u018a\u0196\u0171\u0172\u0172\u017d\u0189\u0174\u0169\u019d\u0157\u019f\u015c\u0180\u016d\u017d\u015f\u0165\u0180\u018a\u01a1\u01a6\u01a8\u018b\u0183\u01b0\u019e\u018d\u019c\u01ad\u01a2\u01a1\u01b8\u0195\u01a9\u0171\u017f", (byte)76, 66);
                    continue block7;
                }
                case 1: {
                    \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba.d[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.F("\u053d\u053d\u0539\u0553\u0555\u0582\u0588\u0563\u055b\u053c\u057a\u058d\u0587\u056b\u0548\u0588\u058e\u055c\u0551\u057c\u058c\u057e\u055f\u0560\u0553\u0595\u0592\u0565\u057e\u056d\u0571\u056b", (byte)76, 70);
                    \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba.d[1] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u0570\u055f\u053f\u0552\u057b\u0584\u0565\u057b\u0587\u0562\u0563\u0563\u056e\u057a\u0565\u055a\u058e\u0548\u0590\u054d\u0571\u055e\u056e\u0550\u0556\u0571\u057b\u0592\u0597\u0599\u057c\u0574\u0557\u0571\u0555\u0571\u059d\u0594\u057b\u0567\u059f\u05a6\u0583\u0570", (byte)76, 69);
                    \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba.d[2] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u017f\u016e\u014e\u0161\u018a\u0193\u0174\u018a\u0196\u0171\u0172\u0172\u017d\u0189\u0174\u0169\u019d\u0157\u019f\u015c\u0180\u016d\u017d\u015f\u0165\u0180\u018a\u01a1\u01a6\u01a8\u018b\u0183\u018a\u019a\u019c\u018b\u01a7\u0175\u0170\u01b3\u0193\u01ae\u0179\u017f", (byte)76, 65);
                    continue block7;
                }
                case 2: {
                    \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba.d[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u04ed\u0508\u04dc\u050b\u050d\u04d4\u050f\u050c\u0503\u0505\u04d3\u04ea\u051d\u04f3\u04f2\u051a\u04ea\u0519\u0516\u04f3\u04fc\u0525\u04ec\u04ed", (byte)76, 67);
                    continue block7;
                }
                case 4: {
                    \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba.d[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u04e2\u04e5\u0511\u050a\u0515\u0506\u04e7\u04d5\u04d0\u04ec\u04f4\u0517\u051d\u050b\u04fa\u0513\u051e\u0517\u0515\u0511\u04f9\u04f4\u0501\u051e\u0529\u0523\u052a\u04ec\u0528\u04e6\u0503\u0521", (byte)76, 68);
                }
            }
        }
    }

    @Override
    public void c(Object object) {
        if (!(object instanceof String)) {
            throw new IllegalArgumentException((String)\u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba.c("\u3e80", (int)p, (long)q));
        }
        ((\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u0393)this.h).a().getProxy().unregisterChannel((String)object);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.E("\u0558\u057a\u057c\u055c\u0580\u059f\u0597\u05ad\u0599\u0568\u05a6\u059c\u05aa\u05a4\u056d\u0592\u05b4\u05b3\u05ab\u05b1\u05ab\u0580", (byte)116, 69), \u03b1\u03c7\u03b4\u03a6\u03a8\u03c2\u03c6\u03a3\u03c6\u03a3\u03ba.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u01ca\u01d7\u01d6\u0199\u01d9\u01d5\u01d0\u01d9\u01e4\u01d3\u01a0\u01de\u01e2\u01db\u01de\u01e4\u01a6\u0529\u0540\u052e\u0521\u0524\u053f\u0544\u0522\u0546\u0524\u053c\u01bd", (byte)116, 66) + string + \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u01a1", (byte)116, 65) + methodType.toString(), exception);
        }
    }
}

