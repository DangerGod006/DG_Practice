/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.nLoginAPI
 */
package com.nickuc.login;

import com.nickuc.login.api.nLoginAPI;
import com.nickuc.login.proxy.velocity.nLoginVelocity;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03a0\u03c0\u03b4\u03c3\u03b7\u03b4\u03c9\u03b1\u03a0\u03b1\u0393\u03ba\u03c1;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a9\u03b4\u03c8\u03c8\u03bb\u03bf\u03c4\u03c9\u03a8\u03a3\u03c0\u03bc\u03b6\u03a9\u03a0;
import com.nickuc.login.\u03a9\u03b8\u0394\u03c6\u03c7\u03b4\u03c1\u03ba\u03c3\u03bb\u0393;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8;
import com.nickuc.login.\u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u03b8\u03b3\u039b\u03c6\u03bb\u03bc\u03b5\u03b6\u03c0\u03ba\u0393\u0393\u03b8;
import com.nickuc.login.\u03ba\u03b4\u0394\u03a6\u03c6\u03b3\u03bc\u03b4\u03be\u03a8\u03c9\u03c8\u03bf;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393;
import com.nickuc.login.\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be;
import com.nickuc.login.\u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c4\u0394\u03bb\u03a6\u03bd\u03b1\u03b1\u03c9;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8
extends \u03a9\u03b4\u03c8\u03c8\u03bb\u03bf\u03c4\u03c9\u03a8\u03a3\u03c0\u03bc\u03b6\u03a9\u03a0 {
    private static long r;
    private static int af;
    private static int n;
    private static int aj;
    private static int ac;
    private static String[] c;
    private static int ah;
    private static int b;
    private static long y;
    private static int z;
    private static long p;
    private static int ae;
    private static long x;
    private static String[] d;
    private static long ab;
    private static int o;
    private static long h;
    private static int ak;
    private static int am;
    private static long e;
    private static int q;
    private static int ai;
    private static int j;
    private static long k;
    private static int t;
    private static long aa;
    private static int w;
    private static long u;
    private static long ag;
    private static long l;
    private static int v;
    private final \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb a;
    private static int al;
    private final nLoginVelocity a;
    private static long ad;
    private static int s;
    private static long i;

    public \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8(nLoginVelocity nLoginVelocity2) {
        super(nLoginVelocity2);
        this.a = nLoginVelocity2;
        this.a = new \u03b4\u03c2\u03c3\u03c5\u03c4\u03c3\u03c6\u03c9\u03c2\u03bb\u03c6\u039b\u03a0\u03bf\u03bb(nLoginVelocity2);
    }

    @Override
    public nLoginAPI a() {
        return new \u03be\u03c2\u03b3\u039b\u03c9\u03c0\u03b5\u03a0\u03c9\u03b3\u03c0\u03c7(this.a.a());
    }

    @Override
    public void b() {
        super.b();
        if (\u03ba\u03b4\u0394\u03a6\u03c6\u03b3\u03bc\u03b4\u03be\u03a8\u03c9\u03c8\u03bf.n.ar() && this.a.a().getConfiguration().shouldPreventClientProxyConnections()) {
            String string = this.a.a().getVersion().getName();
            Object object = \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.e("\u3e80", (int)b, (long)(h ^ i));
            if (\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.j()) {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.e("\u3e83", (int)j, (long)(k ^ l)) + (String)object + (String)\u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.e("\u3e86", (int)(n & o), (long)p) + string + (String)\u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.e("\u3e89", (int)q, (long)r), new Object[s]);
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.e("\u3e8c", (int)t, (long)u), new Object[v]);
            } else {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.e("\u3e8f", (int)w, (long)(x ^ y)) + (String)object + (String)\u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.e("\u3e92", (int)z, (long)(aa ^ ab)) + string + (String)\u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.e("\u3e95", (int)ac, (long)ad), new Object[ae]);
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.e("\u3e98", (int)af, (long)ag), new Object[ah]);
            }
        }
    }

    @Override
    public void e() {
        \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394 \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u03942 = this.a.a();
        \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u03942.a(this.a.a(), this.a);
        \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u03942.a(this.a.b(), this.a);
        this.a.a(new \u03c4\u0394\u03bb\u03a6\u03bd\u03b1\u03b1\u03c9(this.a, this.a.a()), new \u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393[ai]);
        this.a.a(new \u03b9\u03b8\u03b3\u039b\u03c6\u03bb\u03bc\u03b5\u03b6\u03c0\u03ba\u0393\u0393\u03b8(this.a, this.a.a()), new \u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393[aj]);
        this.a.a(new \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be(this.a, this.a.a()), new \u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393[ak]);
    }

    private static void d() {
        int n;
        e = 8025987607086604990L;
        long l = e ^ 0x9504BD5A90ED8993L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(44 + 24), (byte)(39 + 30), (byte)(26 + 57), (byte)(13 + 34), (byte)(23 + 44), (byte)(8 + 58), (byte)(66 + 1), (byte)(8 + 39), (byte)(48 + 32), (byte)(17 + 58), 67, (byte)(27 + 56), (byte)(40 + 13), 80, (byte)(49 + 48), (byte)(20 + 80), (byte)(41 + 59), (byte)(13 + 92), (byte)(89 + 21), (byte)(53 + 50)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(42 + 41)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.F("\u0532\u0544\u0531\u0523\u0529\u0513\u0514\u0515\u0514\u0514\u053c\u055d\u053b\u054f\u052e\u0536\u053d\u054f\u0540\u0566\u0568\u055d\u055f\u053c\u0569\u055d\u056c\u052e\u056a\u0551\u0548\u054a\u055e\u056b\u054d\u0534\u0552\u056b\u0535\u0579\u052f\u0537\u053e\u053b\u0561\u057e\u0584\u056f\u0562\u0578\u0568\u057b\u0579\u0588\u054f\u0550", (byte)32, 70);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[1] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u044b\u047d\u046c\u047b\u045f\u044d\u0481\u048e\u0471\u0481\u046f\u0491\u046c\u0452\u047b\u046c\u0497\u0477\u0493\u0493\u047b\u04a1\u0468\u0469", (byte)32, 67);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[2] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.C("\u045e\u0461\u047e\u048d\u044b\u0463\u047d\u0492\u046f\u0462\u0496\u0481\u0471\u046d\u0466\u0490\u0472\u0467\u045d\u045b\u0473\u0471\u0472\u0486\u0494\u0480\u049c\u0494\u0472\u0480\u049a\u04a1\u04a1\u049a\u0499\u0485\u0490\u0488\u0495\u04a8\u0492\u0495\u04ae\u047d", (byte)32, 67);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[3] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u0107\u00f3\u0129\u0106\u00f4\u012d\u00f7\u0111\u012a\u0137\u012c\u0107", (byte)32, 65);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[4] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u044d\u0470\u0469\u044f\u0451\u0461\u0475\u047f\u046f\u046b\u0470\u0490\u0450\u046b\u0455\u044f\u049a\u0476\u0471\u047e\u04a0\u048c\u049a\u0485\u0481\u0474\u04a3\u049b\u04aa\u0495\u0482\u049b\u0477\u04aa\u046f\u04ae\u046e\u046b\u04af\u0492\u0485\u0493\u0487\u048e\u04b8\u0471\u0487\u0492\u049d\u048b\u04c1\u04bb\u04c0\u048b\u04b5\u047f\u04b1\u04b1\u04a7\u04b9\u0493\u04c1\u04c0\u048d\u048c\u04b9\u049e\u048e\u04c1\u048d\u04d0\u04a6\u04c8\u04c0\u04b2\u04a2\u04a6\u04cd\u04d3\u04db\u04dc\u04c9\u04d7\u04dc\u04ab\u04be\u04cd\u04d6\u049e\u04de\u04ba\u04a8\u04e6\u04e8\u04e7\u04ea\u04c8\u04c2\u04f1\u04cc\u04c5\u04b3\u04ec\u04d6\u04df\u04e9\u04c2\u04d9\u04ed\u04ee\u04d6\u04d2\u04fb\u04cd\u04ca\u04dc\u04fe\u04e3\u0501\u04f8\u04d6\u04e7\u04e3\u0500\u04fa\u04c2\u050a\u04c3\u04c0\u0503\u04d0\u04e9\u04e2\u04e7\u050f\u04fd\u04df\u0503\u04f7\u0505\u04e3\u04d8\u04f9\u04fb\u0518\u04fd\u0514\u0520\u04dc\u04ed\u050f\u04ef\u0514\u04f4\u051a\u0507\u04e6\u0507\u04e6\u052d", (byte)32, 67);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[5] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u0116\u0125\u0124\u0137\u0119\u0109\u0128\u012b\u00fb\u0109\u013f\u00fb\u0116\u0120\u0102\u0139\u0147\u0125\u0126\u0115\u0127\u013b\u0112\u0113", (byte)32, 65);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[6] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u047a\u0458\u047f\u046e\u0451\u0469\u046d\u0476\u0452\u0473\u0462\u0458\u0495\u0486\u0475\u0470\u047a\u046b\u0481\u048f\u0475\u0460\u04a5\u047e\u0476\u049a\u04a2\u047b\u0497\u045d\u0486\u0475", (byte)32, 68);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[7] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0460\u0479\u0485\u0489\u048c\u048a\u048e\u045e\u0480\u0482\u0498\u0452\u0498\u0463\u0454\u0493\u0495\u0495\u04a1\u045f\u049d\u047b\u0468\u0469", (byte)32, 67);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[8] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0524\u0514\u050f\u0521\u054c\u0519\u050d\u0538\u053b\u055e\u0529\u051f\u0541\u052e\u054c\u051d\u0538\u053f\u0543\u0545\u056a\u0533\u0553\u0541\u0562\u053b\u0528\u056c\u0529\u055f\u052a\u0533\u055d\u0577\u0557\u054e\u0542\u0546\u0576\u0578\u0576\u0569\u0578\u053b\u054d\u055e\u0539\u056f\u0570\u056e\u0563\u055a\u0561\u0549\u056a\u0559\u0580\u0578\u0564\u0584\u0589\u0567\u0573\u056b\u0582\u056d\u0582\u0589\u0561\u0597\u056e\u0555\u0566\u0550\u058f\u0581\u059b\u056e\u0555\u0598\u056d\u059f\u0570\u0583\u059b\u0594\u0596\u05a2\u05a9\u05ad\u059e\u057c\u056a\u058e\u05a1\u056d\u0588\u056f\u0588\u0570\u0593\u0587\u05ae\u058d\u0578\u057b\u058f\u057f\u0599\u0580\u0590\u05b0\u0597\u0595\u0593\u0599\u059d\u05ba\u05a9\u05c0\u0587\u05c5\u05cc\u05b1\u05c1\u05c1\u05a8\u05a1", (byte)32, 70);
                    continue block7;
                }
                case 1: {
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.B("\u0115\u0127\u0114\u0106\u010c\u00f6\u00f7\u00f8\u00f7\u00f7\u011f\u0140\u011e\u0132\u0111\u0119\u0120\u0132\u0123\u0149\u014b\u0140\u0142\u011f\u014c\u0140\u014f\u0111\u014d\u0134\u012b\u012d\u0141\u014e\u0130\u0117\u0135\u014e\u0118\u015c\u0112\u011a\u0114\u0138\u013d\u0133\u0162\u0159\u011e\u0128\u0149\u016a\u0139\u016b\u0132\u0133", (byte)32, 66);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[1] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.D("\u044b\u047d\u046c\u047b\u045f\u044d\u0481\u048e\u0471\u0481\u046f\u0472\u0470\u0469\u0466\u0479\u047a\u0491\u0469\u0476\u048a\u0491\u0468\u0469", (byte)32, 68);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[2] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u0525\u0528\u0545\u0554\u0512\u052a\u0544\u0559\u0536\u0529\u055d\u0548\u0538\u0534\u052d\u0557\u0539\u052e\u0524\u0522\u053a\u0538\u0539\u054d\u055b\u0547\u0563\u055b\u0539\u0547\u0561\u0568\u054e\u0536\u0576\u0538\u0538\u0538\u0533\u054e\u052f\u054e\u056b\u0538\u0554\u054e\u0583\u0579\u055c\u0560\u0554\u057b\u0574\u0578\u054f\u0550", (byte)32, 70);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[3] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.A("\u0132\u0101\u0118\u0112\u0125\u0114\u0108\u010f\u013a\u0138\u010a\u0107", (byte)32, 65);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[4] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.A("\u00f7\u011a\u0113\u00f9\u00fb\u010b\u011f\u0129\u0119\u0115\u011a\u013a\u00fa\u0115\u00ff\u00f9\u0144\u0120\u011b\u0128\u014a\u0136\u0144\u012f\u012b\u011e\u014d\u0145\u0154\u013f\u012c\u0145\u0121\u0154\u0119\u0158\u0118\u0115\u0159\u013c\u012f\u013d\u0131\u0138\u0162\u011b\u0131\u013c\u0147\u0135\u016b\u0165\u016a\u0135\u015f\u0129\u015b\u015b\u0151\u0163\u013d\u016b\u016a\u0137\u0136\u0163\u0148\u0138\u016b\u0137\u017a\u0150\u0172\u016a\u015c\u014c\u0150\u0177\u017d\u0185\u0186\u0173\u0181\u0186\u0155\u0168\u0177\u0180\u0148\u0188\u0164\u0152\u0190\u0192\u0191\u0194\u0172\u016c\u019b\u0176\u016f\u015d\u0196\u0180\u0189\u0193\u016c\u0183\u0197\u0198\u0180\u017c\u01a5\u0177\u0174\u0186\u01a8\u018d\u01ab\u01a2\u0180\u0191\u018d\u01aa\u01a4\u016c\u01b4\u016d\u016a\u01ad\u017a\u0193\u018c\u0191\u01b9\u01a7\u0189\u01ad\u01a1\u01af\u018d\u0182\u01a3\u01a5\u01c2\u01a7\u01be\u01ca\u0186\u019d\u01cf\u01a0\u019c\u01b2\u019d\u01cf\u01ad\u019e\u0194\u01d7", (byte)32, 65);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[5] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u0533\u0542\u0541\u0554\u0536\u0526\u0545\u0548\u0518\u0526\u0559\u053f\u052a\u0530\u0550\u0523\u0542\u0521\u0566\u0520\u055d\u0558\u052f\u0530", (byte)32, 69);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[6] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u0124\u0102\u0129\u0118\u00fb\u0113\u0117\u0120\u00fc\u011d\u010c\u0102\u013f\u0130\u011f\u011a\u0124\u0115\u012b\u0139\u011f\u010a\u011a\u010c\u0139\u0108\u0112\u012a\u0131\u0125\u0157\u013f", (byte)32, 66);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[7] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u0527\u0540\u054c\u0550\u0553\u0551\u0555\u0525\u0547\u0549\u055f\u0560\u0535\u0531\u0556\u0535\u053d\u0534\u054f\u0552\u0528\u053b\u0549\u056a\u0568\u0538\u056f\u055c\u0548\u0563\u053d\u0575", (byte)32, 69);
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[8] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u0524\u0514\u050f\u0521\u054c\u0519\u050d\u0538\u053b\u055e\u0529\u051f\u0541\u052e\u054c\u051d\u0538\u053f\u0543\u0545\u056a\u0533\u0553\u0541\u0562\u053b\u0528\u056c\u0529\u055f\u052a\u0533\u055d\u0577\u0557\u054e\u0542\u0546\u0576\u0578\u0576\u0569\u0578\u053b\u054d\u055e\u0539\u056f\u0570\u056e\u0563\u055a\u0561\u0549\u056a\u0559\u0580\u0578\u0564\u0584\u0589\u0567\u0573\u056b\u0582\u056d\u0582\u0589\u0561\u0597\u056e\u0555\u0566\u0550\u058f\u0581\u059b\u056e\u0555\u0598\u056d\u059f\u0570\u0583\u059b\u0594\u0596\u05a2\u05a9\u05ad\u059e\u057c\u056a\u058e\u05a1\u056d\u0588\u056f\u0588\u0570\u0593\u0587\u05ae\u058d\u0578\u057b\u058f\u057f\u0599\u0580\u0590\u05b0\u0597\u0595\u0593\u0599\u059d\u05c7\u059d\u0587\u05ab\u05ce\u05b0\u05ba\u05c2\u05ba\u05a4\u05c6\u05aa\u05ab\u05b0\u058e\u05c7\u05b3\u05bc\u05a7\u058f\u05d1\u05b3\u05a4", (byte)32, 69);
                    continue block7;
                }
                case 2: {
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.D("\u044d\u0481\u0481\u0460\u047f\u0451\u0493\u0461\u044e\u0497\u0478\u049a\u0484\u045a\u044e\u049c\u047f\u047c\u0476\u0482\u04a1\u047b\u0468\u0469", (byte)32, 68);
                    continue block7;
                }
                case 4: {
                    \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u0126\u0128\u0128\u0118\u0105\u012b\u013b\u013c\u013f\u013a\u011d\u012b\u013f\u013a\u013f\u0145\u0118\u00fb\u0107\u0129\u014c\u014b\u0112\u0113", (byte)32, 66);
                }
            }
        }
    }

    @Override
    public void f() {
        \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394 \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u03942 = this.a.a();
        \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u03942.c(this.a.a());
        \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u03942.c(this.a.b());
    }

    @Override
    public \u039b\u03a0\u03c0\u03b4\u03c3\u03b7\u03b4\u03c9\u03b1\u03a0\u03b1\u0393\u03ba\u03c1 a() {
        return new \u03b4\u03b1\u03b7\u03c2\u03bb\u03b1\u039b\u0393\u03be\u03bc\u03b8(this.a, this.a);
    }

    static {
        b = Integer.reverse(0);
        h = Long.reverse(9026805888569067254L);
        i = Long.reverse(0x6A00000000000000L);
        j = Integer.reverse(Integer.MIN_VALUE);
        k = Long.reverse(9026805888569067254L);
        l = Long.reverse(0x6A00000000000000L);
        n = Integer.reverse(0x40000000);
        o = -1 >>> 37 | -1 << -37;
        p = Long.reverse(1676931296700417782L);
        q = Integer.reverse(-1073741824);
        r = Long.reverse(1676931296700417782L);
        s = Integer.reverse(0);
        t = Integer.reverse(0x20000000);
        u = Long.reverse(1676931296700417782L);
        v = Integer.reverse(0);
        w = 2560 >>> 41 | 2560 << ~41 + 1;
        x = Long.reverse(9026805888569067254L);
        y = Long.reverse(0x6A00000000000000L);
        z = Integer.reverse(0x60000000);
        aa = Long.reverse(9026805888569067254L);
        ab = Long.reverse(0x6A00000000000000L);
        ac = Integer.reverse(-536870912);
        ad = Long.reverse(1676931296700417782L);
        ae = 0 >>> 233 | 0 << ~233 + 1;
        af = 32768 >>> 172 | 32768 << -172;
        ag = Long.reverse(1676931296700417782L);
        ah = Integer.reverse(0);
        ai = Integer.reverse(0);
        aj = 0 >>> 215 | 0 << -215;
        ak = Integer.reverse(0);
        al = Integer.reverse(-1879048192);
        am = Integer.reverse(-1879048192);
        c = new String[al];
        d = new String[am];
        \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.d();
    }

    private static Object e(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u0437\u0459\u045b\u043b\u045f\u047e\u0476\u048c\u0478\u0447\u0485\u047b\u0489\u0483\u044c\u0471\u0493\u0492\u048a\u0490\u048a\u045f", (byte)30, 68), \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u011e\u012b\u012a\u00ed\u012d\u0129\u0124\u012d\u0138\u0127\u00f4\u0132\u0136\u012f\u0132\u0138\u00fa\u048d\u0482\u0483\u048b\u0473\u049a\u049b\u049b\u010e", (byte)30, 65) + string + \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u00f5", (byte)30, 65) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x56L;
        l ^= 0x9504BD5A90ED8993L;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(50 + 18), (byte)(62 + 7), (byte)(9 + 74), (byte)(42 + 5), (byte)(15 + 52), (byte)(6 + 60), 67, (byte)(24 + 23), (byte)(15 + 65), (byte)(28 + 47), (byte)(6 + 61), (byte)(2 + 81), (byte)(4 + 49), (byte)(76 + 4), (byte)(50 + 47), (byte)(78 + 22), (byte)(51 + 49), (byte)(58 + 47), 110, (byte)(73 + 30)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(19 + 49), 69, (byte)(18 + 65)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u01b0\u01bd\u01bc\u017f\u01bf\u01bb\u01b6\u01bf\u01ca\u01b9\u0186\u01c4\u01c8\u01c1\u01c4\u01ca\u018c\u051f\u0514\u0515\u051d\u0505\u052c\u052d\u052d", (byte)103, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c1\u03b5\u03b5\u03bc\u03a3\u03c9\u03c9\u03c8.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    @Override
    public \u03a9\u03b8\u0394\u03c6\u03c7\u03b4\u03c1\u03ba\u03c3\u03bb\u0393 a() {
        return new \u03a9\u03b8\u0394\u03c6\u03c7\u03b4\u03c1\u03ba\u03c3\u03bb\u0393(this.a.a());
    }
}

