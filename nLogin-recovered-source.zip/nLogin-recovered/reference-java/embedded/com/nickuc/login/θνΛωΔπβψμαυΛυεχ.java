/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7
extends Enum<\u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7> {
    public static final /* enum */ \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7 a;
    public static final /* enum */ \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7 b;
    public static final /* enum */ \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7 c;
    private static final /* synthetic */ \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7[] a;
    private static String[] a;
    private static String[] b;
    private static long c;
    private static int a;
    private static int b;
    private static int c;
    private static int d;
    private static int e;
    private static int f;
    private static int g;
    private static int h;
    private static long i;
    private static int j;
    private static int k;
    private static long l;
    private static int m;
    private static int n;
    private static long o;
    private static long p;
    private static int q;

    public static \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7[] values() {
        return (\u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7[])a.clone();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0501\u0523\u0525\u0505\u0529\u0548\u0540\u0556\u0542\u0511\u054f\u0545\u0553\u054d\u0516\u053b\u055d\u055c\u0554\u055a\u0554\u0529", (byte)29, 70), \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u011c\u0129\u0128\u00eb\u012b\u0127\u0122\u012b\u0136\u0125\u00f2\u0130\u0134\u012d\u0130\u0136\u00f8\u0482\u0488\u0467\u0496\u0462\u048f\u0482\u0499\u048e\u0484\u0499\u0470\u049b\u048c\u049f\u0113", (byte)29, 65) + string + \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.A("\u00f3", (byte)29, 65) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x77L;
        l ^= 0xEE1115AAED7D3AB0L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(55 + 13), (byte)(6 + 63), (byte)(21 + 62), (byte)(28 + 19), (byte)(5 + 62), (byte)(43 + 23), (byte)(43 + 24), (byte)(15 + 32), (byte)(30 + 50), (byte)(7 + 68), 67, (byte)(54 + 29), (byte)(33 + 20), (byte)(34 + 46), (byte)(23 + 74), 100, (byte)(77 + 23), (byte)(66 + 39), (byte)(43 + 67), (byte)(89 + 14)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(37 + 31), (byte)(9 + 60), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u0116\u0123\u0122\u00e5\u0125\u0121\u011c\u0125\u0130\u011f\u00ec\u012a\u012e\u0127\u012a\u0130\u00f2\u047c\u0482\u0461\u0490\u045c\u0489\u047c\u0493\u0488\u047e\u0493\u046a\u0495\u0486\u0499", (byte)26, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static void b() {
        int n;
        c = -6727005462527544487L;
        long l = c ^ 0xEE1115AAED7D3AB0L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(49 + 19), (byte)(56 + 13), (byte)(43 + 40), (byte)(6 + 41), (byte)(36 + 31), (byte)(50 + 16), (byte)(22 + 45), 47, (byte)(56 + 24), (byte)(64 + 11), (byte)(64 + 3), (byte)(18 + 65), 53, (byte)(9 + 71), (byte)(27 + 70), (byte)(96 + 4), (byte)(35 + 65), (byte)(36 + 69), (byte)(14 + 96), (byte)(25 + 78)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(56 + 13), (byte)(20 + 63)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.b[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u00d1\u00f4\u00ee\u00dc\u00ee\u00fb\u00d8\u00dc\u00e4\u0108\u0100\u00dc\u00d9\u00e6\u00ee\u00cf\u00e4\u00f2\u00e3\u00fd\u010d\u00ef\u00dc\u00dd", (byte)5, 65);
                    \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.b[1] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u00d1\u00cb\u00bc\u00cf\u00fe\u0106\u00c0\u00da\u00e0\u00df\u00e4\u00d1", (byte)5, 66);
                    \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.b[2] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.F("\u04f1\u0532\u0535\u0516\u052d\u0528\u04f6\u04fe\u0540\u0532\u0520\u0545\u0540\u053b\u0539\u0507\u0513\u053f\u0545\u053e\u052f\u054d\u0514\u0515", (byte)5, 70);
                    continue block7;
                }
                case 1: {
                    \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u00d1\u00f4\u00ee\u00dc\u00ee\u00fb\u00d8\u00dc\u00e4\u0108\u0100\u0107\u00e4\u0108\u0103\u00ce\u00ee\u0107\u00ed\u00f0\u0112\u00ef\u00dc\u00dd", (byte)5, 65);
                    \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.b[1] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.E("\u0512\u0517\u051a\u0518\u0508\u04fc\u051d\u0529\u0533\u051a\u0520\u04fd\u0531\u0516\u0543\u0545\u0523\u0547\u0520\u052d\u0509\u053d\u0514\u0515", (byte)5, 69);
                    \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.b[2] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u03f4\u0435\u0438\u0419\u0430\u042b\u03f9\u0401\u0443\u0435\u0423\u0412\u041a\u0432\u03fd\u0443\u0408\u0418\u043f\u042c\u0430\u041a\u0417\u0418", (byte)5, 68);
                    continue block7;
                }
                case 2: {
                    \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u00ce\u00be\u00ef\u00de\u00ce\u00e0\u00f4\u00c1\u00c9\u00e5\u010b\u010a\u00dc\u0110\u00ce\u00e4\u00fa\u0109\u010e\u010a\u00f0\u0105\u00dc\u00dd", (byte)5, 65);
                    continue block7;
                }
                case 4: {
                    \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.b[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u042d\u042b\u041b\u03f7\u0432\u03f4\u0436\u042c\u0431\u041c\u0434\u041b\u044a\u0448\u0426\u0446\u043a\u0437\u0420\u0423\u041b\u0440\u0417\u0418", (byte)5, 67);
                }
            }
        }
    }

    static {
        a = Integer.reverse(-1073741824);
        b = (0 >>> 208 | 0 << -208) & 0xFFFFFFFF;
        c = Integer.reverse(Integer.MIN_VALUE);
        d = Integer.reverse(0x40000000);
        e = Integer.reverse(-1073741824);
        f = Integer.reverse(-1073741824);
        g = 0 >>> 192 | 0 << ~192 + 1;
        h = (-1 >>> 238 | -1 << ~238 + 1) & 0xFFFFFFFF;
        i = Long.reverse(8417077973278467397L);
        j = (0 >>> 104 | 0 << ~104 + 1) & 0xFFFFFFFF;
        k = 0x100000 >>> 20 | 0x100000 << ~20 + 1;
        l = Long.reverse(8417077973278467397L);
        m = (32 >>> 5 | 32 << -5) & 0xFFFFFFFF;
        n = 32 >>> 68 | 32 << ~68 + 1;
        o = Long.reverse(-7291477526989822651L);
        p = Long.reverse(-1297036692682702848L);
        q = Integer.reverse(0x40000000);
        a = new String[e];
        b = new String[f];
        \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.b();
        a = new \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7();
        b = new \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7();
        c = new \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7();
        a = \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.a();
    }

    private static /* synthetic */ \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7[] a() {
        \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7[] \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7Array = new \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7[a];
        \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7Array[\u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.b] = a;
        \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7Array[\u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.c] = b;
        \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7Array[\u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.d] = c;
        return \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7Array;
    }

    public static \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7 valueOf(String string) {
        return Enum.valueOf(\u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.class, string);
    }

    @Generated
    private \u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7() {
    }
}

