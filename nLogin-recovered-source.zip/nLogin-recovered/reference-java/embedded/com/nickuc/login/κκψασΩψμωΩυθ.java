/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

public interface \u03ba\u03ba\u03c8\u03b1\u03c3\u03a9\u03c8\u03bc\u03c9\u03a9\u03c5\u03b8 {
    public void sendPacket(Object var1, Object ... var2);
}

