/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import javax.annotation.Nullable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u0394\u03a8\u03bc\u03c9\u03c7\u03c9\u03a6\u03bb\u03a6\u03c0\u03a9\u03c5
implements Closeable {
    private InputStreamReader a;
    private InputStream a;
    private BufferedReader a;

    @Override
    public void close() {
        if (this.a != null) {
            this.a.close();
            this.a = null;
        }
        if (this.a != null) {
            this.a.close();
            this.a = null;
        }
        if (this.a != null) {
            this.a.close();
            this.a = null;
        }
    }

    \u0394\u03a8\u03bc\u03c9\u03c7\u03c9\u03a6\u03bb\u03a6\u03c0\u03a9\u03c5(InputStream inputStream, Charset charset) {
        this.a = inputStream;
        this.a = new InputStreamReader(inputStream, charset);
        this.a = new BufferedReader(this.a);
    }

    @Nullable
    public String ah() {
        return this.a.readLine();
    }
}

