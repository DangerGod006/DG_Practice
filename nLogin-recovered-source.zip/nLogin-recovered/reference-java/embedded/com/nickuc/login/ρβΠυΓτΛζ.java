/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3;
import com.nickuc.login.\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Collection;
import java.util.concurrent.TimeUnit;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6 {
    private static int x;
    private static String[] a;
    private static int a;
    private static long ag;
    private static int i;
    private static int m;
    private static long p;
    private static int at;
    private static long af;
    private static int e;
    private static int ae;
    private static int ai;
    private static long q;
    private static int n;
    private static int ab;
    private static int an;
    private static int al;
    private static long z;
    private static int as;
    private static int r;
    private static long d;
    private static int f;
    private static int o;
    public static int p;
    private static long am;
    private static long y;
    private static int aa;
    private static int aj;
    private static int av;
    private static int j;
    private static int h;
    private static int au;
    private static int ao;
    private static long c;
    private static int ar;
    private static long b;
    private static String[] b;
    private static int ak;
    private static int ah;
    private static int l;
    private static long t;
    private static long ac;
    private static long w;
    private static int u;
    private static long ad;
    private static int k;
    private static int v;
    private static int g;
    private static long s;
    private static int aq;
    private static long ap;

    private static String a(int n, long l) {
        l ^= 0x20L;
        l ^= 0x3B8E7B6797B442FFL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(21 + 48), (byte)(48 + 35), (byte)(37 + 10), (byte)(54 + 13), (byte)(10 + 56), (byte)(28 + 39), (byte)(37 + 10), (byte)(53 + 27), (byte)(56 + 19), 67, (byte)(33 + 50), (byte)(44 + 9), (byte)(64 + 16), (byte)(5 + 92), (byte)(40 + 60), (byte)(12 + 88), (byte)(78 + 27), (byte)(53 + 57), (byte)(56 + 47)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(61 + 8), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0569\u0576\u0575\u0538\u0578\u0574\u056f\u0578\u0583\u0572\u053f\u057d\u0581\u057a\u057d\u0583\u0545\u08d8\u08ca\u08b9\u08df\u08ae\u08e0\u08b8\u08d4", (byte)74, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.F("\u055f\u0581\u0583\u0563\u0587\u05a6\u059e\u05b4\u05a0\u056f\u05ad\u05a3\u05b1\u05ab\u0574\u0599\u05bb\u05ba\u05b2\u05b8\u05b2\u0587", (byte)123, 70), \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u0589\u0596\u0595\u0558\u0598\u0594\u058f\u0598\u05a3\u0592\u055f\u059d\u05a1\u059a\u059d\u05a3\u0565\u08f8\u08ea\u08d9\u08ff\u08ce\u0900\u08d8\u08f4\u0579", (byte)123, 67) + string + \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u01af", (byte)123, 66) + methodType.toString(), exception);
        }
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(-487542167034095638L);
        d = Long.reverse(0x400000000000000L);
        e = -1 >>> 131 | -1 << ~131 + 1;
        f = Integer.reverse(-1);
        g = (2 >>> 97 | 2 << -97) & 0xFFFFFFFF;
        h = (4096 >>> 108 | 4096 << -108) & 0xFFFFFFFF;
        i = -1 >>> 174 | -1 << -174;
        j = Integer.reverse(Integer.MIN_VALUE);
        k = Integer.reverse(Integer.MIN_VALUE);
        l = (0 >>> 162 | 0 << ~162 + 1) & 0xFFFFFFFF;
        m = (8 >>> 99 | 8 << ~99 + 1) & 0xFFFFFFFF;
        n = (0 >>> 203 | 0 << ~203 + 1) & 0xFFFFFFFF;
        o = Integer.reverse(Integer.MIN_VALUE);
        p = Long.reverse(-487542167034095638L);
        q = Long.reverse(0x400000000000000L);
        r = (0x2000000 >>> 88 | 0x2000000 << ~88 + 1) & 0xFFFFFFFF;
        s = Long.reverse(-487542167034095638L);
        t = Long.reverse(0x400000000000000L);
        u = Integer.reverse(-1073741824);
        v = Integer.reverse(-1);
        w = Long.reverse(-199311790882383894L);
        x = Integer.reverse(0x20000000);
        y = Long.reverse(-487542167034095638L);
        z = Long.reverse(0x400000000000000L);
        aa = Integer.reverse(Integer.MIN_VALUE);
        ab = 20 >>> 66 | 20 << ~66 + 1;
        ac = Long.reverse(-487542167034095638L);
        ad = Long.reverse(0x400000000000000L);
        ae = 768 >>> 39 | 768 << ~39 + 1;
        af = Long.reverse(-487542167034095638L);
        ag = Long.reverse(0x400000000000000L);
        ah = Integer.reverse(0);
        ai = (61440 >>> 43 | 61440 << ~43 + 1) & 0xFFFFFFFF;
        aj = (0x18000000 >>> 186 | 0x18000000 << ~186 + 1) & 0xFFFFFFFF;
        ak = (114688 >>> 142 | 114688 << ~142 + 1) & 0xFFFFFFFF;
        al = (-1 >>> 27 | -1 << -27) & 0xFFFFFFFF;
        am = Long.reverse(-199311790882383894L);
        an = Integer.reverse(0x10000000);
        ao = Integer.reverse(-1);
        ap = Long.reverse(-199311790882383894L);
        aq = (0 >>> 154 | 0 << ~154 + 1) & 0xFFFFFFFF;
        ar = -2147483641 >>> 94 | -2147483641 << -94;
        as = 98304 >>> 142 | 98304 << -142;
        at = 18 >>> 161 | 18 << ~161 + 1;
        au = Integer.reverse(-1879048192);
        av = -1 >>> 21 | -1 << ~21 + 1;
        a = new String[at];
        b = new String[au];
        \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b();
        p = av;
    }

    private static void b() {
        int n;
        c = 6334619703518420127L;
        long l = c ^ 0x3B8E7B6797B442FFL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(37 + 31), (byte)(4 + 65), (byte)(21 + 62), (byte)(19 + 28), (byte)(37 + 30), 66, (byte)(33 + 34), (byte)(25 + 22), (byte)(69 + 11), (byte)(31 + 44), (byte)(53 + 14), (byte)(18 + 65), (byte)(25 + 28), (byte)(73 + 7), (byte)(86 + 11), 100, (byte)(83 + 17), (byte)(37 + 68), (byte)(49 + 61), (byte)(41 + 62)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(27 + 42), (byte)(26 + 57)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u015a\u0168\u0148\u0181\u0151\u0184\u018d\u014f\u0178\u0172\u0168\u016f\u016b\u0198\u019d\u018b\u018e\u017f\u017e\u01a1\u0183\u0191\u0171\u0166\u017d\u0195\u0178\u0167\u016b\u018c\u0169\u0187\u0162\u01a3\u016e\u01b4\u016c\u01b6\u0172\u018e\u01b4\u0173\u018e\u017f", (byte)76, 66);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[1] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u0580\u054b\u054d\u055b\u0542\u057f\u055b\u0563\u0563\u0579\u0581\u0559\u056d\u0586\u0541\u0580\u0590\u0565\u0584\u0584\u0571\u0589\u058e\u0557\u0578\u0591\u0568\u0592\u058b\u057c\u055c\u0556\u057f\u0597\u0598\u0595\u0598\u0576\u0574\u0565\u059e\u059b\u0583\u0570", (byte)76, 69);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[2] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0559\u055d\u055c\u054d\u0584\u057c\u0556\u053f\u0553\u0541\u0587\u055b\u0565\u0568\u054b\u0560\u057f\u056d\u0583\u058e\u0568\u056e\u055b\u055c", (byte)76, 70);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[3] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u04c4\u04e7\u0512\u04d2\u0505\u04f1\u04f4\u050a\u050b\u04f6\u0508\u0517\u0509\u04f6\u0516\u04f2\u0520\u0501\u0513\u0501\u051c\u0503\u0516\u0507\u04fb\u0526\u0526\u0509\u04fe\u04ff\u051f\u04e8", (byte)76, 67);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[4] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u0582\u053e\u055d\u0536\u0551\u053f\u0545\u0558\u0587\u0582\u0575\u0550", (byte)76, 70);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[5] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u056a\u057b\u054e\u053a\u0540\u057b\u057f\u0544\u0589\u057d\u0585\u0550", (byte)76, 70);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[6] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u0164\u0179\u0189\u0186\u014d\u0186\u0188\u016a\u016e\u0191\u0190\u015f", (byte)76, 65);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[7] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u0559\u055d\u055c\u054d\u0584\u057c\u0556\u053f\u0553\u0541\u0587\u055b\u0565\u0568\u054b\u0560\u057f\u056d\u0583\u058e\u0568\u056e\u055b\u055c", (byte)76, 70);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[8] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u017d\u017e\u017f\u0192\u0168\u0167\u018b\u0163\u0199\u0158\u0156\u0156\u0168\u018f\u016d\u0171\u016a\u0194\u016b\u0197\u018c\u01a5\u01a2\u015f\u017c\u019c\u01a7\u01a9\u0162\u017d\u017d\u018a", (byte)76, 65);
                    continue block7;
                }
                case 1: {
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.A("\u015a\u0168\u0148\u0181\u0151\u0184\u018d\u014f\u0178\u0172\u0168\u016f\u016b\u0198\u019d\u018b\u018e\u017f\u017e\u01a1\u0183\u0191\u0171\u0166\u017d\u0195\u0178\u0167\u016b\u018c\u0169\u0187\u016e\u01ad\u018e\u017f\u0187\u0180\u0194\u01ad\u0192\u0185\u01ba\u0198\u01b2\u0198\u0199\u017c\u0198\u0180\u01b9\u01c3\u0197\u018d\u018a\u018b", (byte)76, 65);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[1] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u0580\u054b\u054d\u055b\u0542\u057f\u055b\u0563\u0563\u0579\u0581\u0559\u056d\u0586\u0541\u0580\u0590\u0565\u0584\u0584\u0571\u0589\u058e\u0557\u0578\u0591\u0568\u0592\u058b\u057c\u055c\u0556\u058e\u0573\u0599\u0564\u0577\u059a\u0562\u057e\u05a5\u0595\u0581\u0588\u0564\u0565\u058c\u058d\u059d\u0585\u0594\u05ab\u0575\u05a4\u057b\u057c", (byte)76, 70);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[2] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u04ea\u04ee\u04ed\u04de\u0515\u050d\u04e7\u04d0\u04e4\u04d2\u0516\u04fd\u04f7\u04ed\u0510\u04ea\u04fb\u0501\u04f4\u04f6\u04fe\u0523\u0529\u04e6\u0502\u0527\u04f7\u04fb\u04e0\u0520\u0507\u04ee", (byte)76, 68);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[3] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u0533\u0556\u0581\u0541\u0574\u0560\u0563\u0579\u057a\u0565\u0577\u0586\u0578\u0565\u0585\u0561\u058f\u0570\u0582\u0570\u058b\u056e\u058b\u0574\u0552\u0585\u0591\u055b\u0599\u059c\u0568\u059e\u0572\u059c\u059c\u0593\u0563\u0577\u0574\u0566\u05a6\u0567\u05a9\u0570", (byte)76, 70);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[4] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u04de\u0504\u04dc\u0503\u0507\u0509\u0519\u04d4\u04e6\u0511\u04e4\u04e1", (byte)76, 68);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[5] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u0539\u055a\u0552\u0579\u0571\u0576\u0552\u0553\u0541\u0555\u0565\u0542\u0563\u055b\u055c\u054a\u054d\u0551\u057b\u0585\u056b\u0594\u055b\u055c", (byte)76, 69);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[6] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u054b\u054e\u056d\u0570\u0577\u057e\u0540\u0566\u0582\u0547\u053d\u0559\u0558\u0567\u056e\u0560\u0543\u0561\u0553\u0581\u0552\u0594\u055b\u055c", (byte)76, 69);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[7] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u04ea\u04ee\u04ed\u04de\u0515\u050d\u04e7\u04d0\u04e4\u04d2\u0518\u04e6\u0515\u04d6\u04d6\u0514\u04fb\u0512\u04f4\u04f5\u04f7\u0521\u0526\u04df\u04dc\u04e2\u0520\u04f9\u04fc\u052e\u04e8\u0508", (byte)76, 67);
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[8] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u056e\u056f\u0570\u0583\u0559\u0558\u057c\u0554\u058a\u0549\u0547\u0547\u0559\u0580\u055e\u0562\u055b\u0585\u055c\u0588\u057d\u0595\u0554\u0567\u0555\u055a\u0598\u0552\u0595\u058f\u0572\u0557", (byte)76, 70);
                    continue block7;
                }
                case 2: {
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.F("\u057d\u054e\u0557\u054e\u053d\u0582\u0581\u0575\u058a\u0565\u0544\u057c\u0579\u0583\u0565\u056a\u056d\u058a\u0573\u057d\u0589\u0561\u0581\u0565\u0571\u055a\u056e\u054e\u054f\u059e\u057f\u055f", (byte)76, 70);
                    continue block7;
                }
                case 4: {
                    \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.b[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u0159\u0182\u016d\u0183\u017d\u0186\u017f\u0191\u018e\u0162\u0162\u0164\u0175\u0165\u0167\u018a\u015f\u0174\u019b\u0194\u0178\u01a3\u016a\u016b", (byte)76, 65);
                }
            }
        }
    }

    public static void a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, int n) {
        if (n <= 0) {
            throw new IllegalArgumentException((String)\u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.c("\u3e80", (int)a, (long)(b ^ d)));
        }
        if (p != e) {
            p = f;
            return;
        }
        p = n + g;
        \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.b(h != 0).a(\u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be2 -> {
            if (!\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.N()) {
                \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be2.Z();
                return;
            }
            Collection<\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6> collection = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.b().c();
            if (p == i) {
                collection.forEach(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 -> \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a((String)\u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.c("\u3e80", (int)(ak & al), (long)am), (String)\u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.c("\u3e83", (int)(an & ao), (long)ap), aq, ar, as));
                \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be2.Z();
                return;
            }
            if (p > 0) {
                p -= j;
            }
            int n = p == 0 ? k : l;
            int n2 = ((\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3)\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.b()).a() == \u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.b ? m : \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.n;
            for (\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a62 : collection) {
                if (n != 0) {
                    if (n2 != 0) {
                        try {
                            ((Player)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a62.c()).closeInventory();
                        }
                        catch (Exception exception) {
                            // empty catch block
                        }
                    }
                    \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a62.a((String)\u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.c("\u3e80", (int)o, (long)(p ^ q)));
                    continue;
                }
                \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a62.a((String)\u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.c("\u3e83", (int)r, (long)(s ^ t)), (String)\u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.c("\u3e86", (int)(u & v), (long)w) + p + (String)\u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.c("\u3e89", (int)x, (long)(y ^ z)) + (String)(p == aa ? \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.c("\u3e8c", (int)ab, (long)(ac ^ ad)) : \u03c1\u03b2\u03a0\u03c5\u0393\u03c4\u039b\u03b6.c("\u3e8f", (int)ae, (long)(af ^ ag))), ah, ai, aj);
            }
            if (n != 0) {
                \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.b().c();
                \u03b1\u03c0\u03bd\u03b7\u03b2\u03b7\u03c8\u03b8\u03c3\u03a3\u03b3\u03bf\u03be2.Z();
            }
        }, 0L, 1L, TimeUnit.SECONDS);
    }
}

