/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.enums.DatabaseType
 *  com.nickuc.login.lib.json.JSONObject
 *  javax.annotation.Nonnull
 */
package com.nickuc.login;

import com.nickuc.login.api.enums.DatabaseType;
import com.nickuc.login.lib.json.JSONObject;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c2\u03bd\u039b\u03c9\u03a0\u03b8\u03c1\u03c0\u03c5\u03a3\u03bc\u03ba\u0393\u03a9\u03bf;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.annotation.Nonnull;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bc\u03bf\u03c7\u03c8\u03c7\u03b6\u03ba\u03c6
implements \u03c2\u03bd\u039b\u03c9\u03a0\u03b8\u03c1\u03c0\u03c5\u03a3\u03bc\u03ba\u0393\u03a9\u03bf<DatabaseType> {
    private static int i;
    private static long g;
    private static int a;
    public static final \u03bc\u03bf\u03c7\u03c8\u03c7\u03b6\u03ba\u03c6 a;
    private static long f;
    private static String[] b;
    private static long d;
    private static long c;
    private static String[] a;
    private static int h;
    private static int e;
    private static int b;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bc\u03bf\u03c7\u03c8\u03c7\u03b6\u03ba\u03c6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.A("\u0161\u0183\u0185\u0165\u0189\u01a8\u01a0\u01b6\u01a2\u0171\u01af\u01a5\u01b3\u01ad\u0176\u019b\u01bd\u01bc\u01b4\u01ba\u01b4\u0189", (byte)93, 65), \u03bc\u03bf\u03c7\u03c8\u03c7\u03b6\u03ba\u03c6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u052f\u053c\u053b\u04fe\u053e\u053a\u0535\u053e\u0549\u0538\u0505\u0543\u0547\u0540\u0543\u0549\u050b\u0899\u089d\u08a6\u08a8\u08a8\u0898\u089d\u08aa\u051f", (byte)93, 68) + string + \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u0173", (byte)93, 66) + methodType.toString(), exception);
        }
    }

    @Override
    public DatabaseType a(@Nonnull JSONObject jSONObject) {
        return (DatabaseType)jSONObject.getEnum(DatabaseType.class, (String)\u03bc\u03bf\u03c7\u03c8\u03c7\u03b6\u03ba\u03c6.c("\u3e80", (int)e, (long)(f ^ g)));
    }

    @Override
    public JSONObject a(@Nonnull DatabaseType databaseType) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put((String)\u03bc\u03bf\u03c7\u03c8\u03c7\u03b6\u03ba\u03c6.c("\u3e80", (int)(a & b), (long)d), (Object)databaseType);
        return jSONObject;
    }

    private static void b() {
        int n;
        c = 5346641799245934202L;
        long l = c ^ 0x7A69D6928D144F03L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(66 + 2), (byte)(21 + 48), (byte)(67 + 16), 47, (byte)(12 + 55), (byte)(51 + 15), (byte)(52 + 15), (byte)(27 + 20), (byte)(41 + 39), (byte)(49 + 26), (byte)(44 + 23), (byte)(79 + 4), (byte)(4 + 49), (byte)(72 + 8), (byte)(66 + 31), (byte)(35 + 65), (byte)(57 + 43), 105, (byte)(108 + 2), (byte)(45 + 58)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(14 + 55), (byte)(81 + 2)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bc\u03bf\u03c7\u03c8\u03c7\u03b6\u03ba\u03c6.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.D("\u0577\u0541\u0570\u053b\u0572\u057b\u0586\u0555\u0549\u055d\u0581\u0550", (byte)113, 68);
                    \u03bc\u03bf\u03c7\u03c8\u03c7\u03b6\u03ba\u03c6.b[1] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u01d0\u019a\u01c9\u0194\u01cb\u01d4\u01df\u01ae\u01a2\u01b6\u01da\u01a9", (byte)113, 66);
                    continue block7;
                }
                case 1: {
                    \u03bc\u03bf\u03c7\u03c8\u03c7\u03b6\u03ba\u03c6.b[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.E("\u057e\u055d\u0586\u059a\u05a2\u0575\u0577\u057a\u05af\u0578\u05a5\u05a9\u056e\u056d\u0586\u0593\u058c\u05a2\u05a7\u05a5\u05a4\u05a9\u0580\u0581", (byte)113, 69);
                    \u03bc\u03bf\u03c7\u03c8\u03c7\u03b6\u03ba\u03c6.b[1] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u0556\u056d\u0564\u0560\u055a\u0558\u0587\u0587\u055e\u056b\u058c\u057a\u0558\u0583\u057f\u0588\u057f\u057a\u058d\u0587\u0568\u0584\u055b\u055c", (byte)113, 68);
                    continue block7;
                }
                case 2: {
                    \u03bc\u03bf\u03c7\u03c8\u03c7\u03b6\u03ba\u03c6.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.B("\u0199\u01d1\u019b\u01c7\u01de\u01a9\u01c8\u01da\u01ab\u01e3\u019f\u019d\u01b0\u01d8\u01b3\u01e4\u01aa\u01aa\u01df\u01a3\u01ec\u01da\u01c8\u01cc\u01d0\u01ef\u01be\u01c1\u01ef\u01bf\u01c3\u01f8", (byte)113, 66);
                    continue block7;
                }
                case 4: {
                    \u03bc\u03bf\u03c7\u03c8\u03c7\u03b6\u03ba\u03c6.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u055d\u0581\u0574\u05aa\u055c\u056b\u059d\u058e\u058d\u0569\u059a\u059c\u05ae\u058c\u0586\u05ae\u058d\u05a4\u0592\u0581\u05a4\u0571\u0584\u0598\u0576\u05b3\u05aa\u0595\u05b8\u05c0\u057a\u0585", (byte)113, 69);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x4DL;
        l ^= 0x7A69D6928D144F03L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(34 + 34), (byte)(10 + 59), (byte)(65 + 18), (byte)(43 + 4), (byte)(20 + 47), (byte)(13 + 53), (byte)(19 + 48), (byte)(18 + 29), (byte)(58 + 22), (byte)(36 + 39), (byte)(20 + 47), (byte)(79 + 4), (byte)(12 + 41), (byte)(50 + 30), (byte)(53 + 44), (byte)(3 + 97), 100, (byte)(47 + 58), 110, (byte)(20 + 83)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(33 + 50)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u0565\u0572\u0571\u0534\u0574\u0570\u056b\u0574\u057f\u056e\u053b\u0579\u057d\u0576\u0579\u057f\u0541\u08cf\u08d3\u08dc\u08de\u08de\u08ce\u08d3\u08e0", (byte)111, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bc\u03bf\u03c7\u03c8\u03c7\u03b6\u03ba\u03c6.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = Integer.reverse(0);
        b = -1 >>> 227 | -1 << ~227 + 1;
        d = Long.reverse(-1408234144266662830L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Long.reverse(6806331576057121874L);
        g = Long.reverse(-5620492334958379008L);
        h = 0x200000 >>> 148 | 0x200000 << ~148 + 1;
        i = Integer.reverse(0x40000000);
        a = new String[h];
        b = new String[i];
        \u03bc\u03bf\u03c7\u03c8\u03c7\u03b6\u03ba\u03c6.b();
        a = new \u03bc\u03bf\u03c7\u03c8\u03c7\u03b6\u03ba\u03c6();
    }

    @Override
    public Class<?> a() {
        return DatabaseType.class;
    }
}

