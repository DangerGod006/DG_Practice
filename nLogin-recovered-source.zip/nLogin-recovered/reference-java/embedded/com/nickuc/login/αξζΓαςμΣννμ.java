/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7;

class \u03b1\u03be\u03b6\u0393\u03b1\u03c2\u03bc\u03a3\u03bd\u03bd\u03bc {
    private static int b;
    private static int a;
    static final /* synthetic */ int[] t;

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = Integer.reverse(0x40000000);
        t = new int[\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.values().length];
        try {
            \u03b1\u03be\u03b6\u0393\u03b1\u03c2\u03bc\u03a3\u03bd\u03bd\u03bc.t[\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.a.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b1\u03be\u03b6\u0393\u03b1\u03c2\u03bc\u03a3\u03bd\u03bd\u03bc.t[\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7.b.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

