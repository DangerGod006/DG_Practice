/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03b4\u03a6\u03c3\u03c9\u03c0\u03b7\u03bf\u03b5\u03c2\u03b2\u03bf\u03c6\u039b\u03c4;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bb\u03a8\u03a3\u03c1\u03a6\u03c1\u03bb\u03c1\u039b\u03c0\u03bb\u03c3\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3;
import com.nickuc.login.\u03c1\u03b7\u03c4\u03bf\u03bb\u03b5\u03bf\u0394\u03b5\u03b3;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.io.File;
import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2
implements \u03c1\u03b7\u03c4\u03bf\u03bb\u03b5\u03bf\u0394\u03b5\u03b3 {
    private static int u;
    private static int q;
    private static long e;
    private static int i;
    private static int o;
    private static String[] a;
    private static long l;
    private static long h;
    private static long b;
    private static int s;
    public static final \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2 a;
    private static long p;
    private static long j;
    private static long c;
    private static int r;
    private static int d;
    private static int a;
    private static int c;
    private static long g;
    private static int k;
    private static int f;
    private static int t;
    private static int n;
    private static String[] b;
    private static int v;
    private static long m;

    @Override
    public void c(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4 \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4 = \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4.f;
        \u03a9\u03b4\u03a6\u03c3\u03c9\u03c0\u03b7\u03bf\u03b5\u03c2\u03b2\u03bf\u03c6\u039b\u03c4 \u03c9\u03b4\u03a6\u03c3\u03c9\u03c0\u03b7\u03bf\u03b5\u03c2\u03b2\u03bf\u03c6\u039b\u03c4 = \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4.a();
        File file = new File(((\u03bb\u03a8\u03a3\u03c1\u03a6\u03c1\u03bb\u03c1\u039b\u03c0\u03bb\u03c3\u03be)\u03c9\u03b4\u03a6\u03c3\u03c9\u03c0\u03b7\u03bf\u03b5\u03c2\u03b2\u03bf\u03c6\u039b\u03c4).b(), (String)\u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.c("\u3e80", (int)(c & d), (long)e));
        if (file.exists()) {
            return;
        }
        \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.e(\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.j() ? (String)\u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.c("\u3e83", (int)f, (long)(g ^ h)) + \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4.getName() + (String)\u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.c("\u3e86", (int)i, (long)j) : (String)\u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.c("\u3e89", (int)k, (long)(l ^ m)) + \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4.getName() + (String)\u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.c("\u3e8c", (int)(n & o), (long)p), new Object[q]);
        \u03c9\u03b4\u03a6\u03c3\u03c9\u03c0\u03b7\u03bf\u03b5\u03c2\u03b2\u03bf\u03c6\u039b\u03c4.a(null, r != 0);
        try {
            \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b(file);
        }
        catch (IOException iOException) {
            throw new RuntimeException(iOException);
        }
    }

    @Override
    public String q() {
        return \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.c("\u3e80", (int)a, (long)b);
    }

    private static String a(int n, long l) {
        l ^= 0x1CL;
        l ^= 0xDF0F139A7184AA0EL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(24 + 44), (byte)(24 + 45), (byte)(40 + 43), (byte)(24 + 23), 67, (byte)(62 + 4), (byte)(7 + 60), (byte)(44 + 3), (byte)(68 + 12), (byte)(27 + 48), (byte)(40 + 27), (byte)(79 + 4), (byte)(48 + 5), (byte)(7 + 73), (byte)(70 + 27), (byte)(98 + 2), (byte)(25 + 75), (byte)(51 + 54), (byte)(64 + 46), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(39 + 30), (byte)(67 + 16)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.E("\u0531\u053e\u053d\u0500\u0540\u053c\u0537\u0540\u054b\u053a\u0507\u0545\u0549\u0542\u0545\u054b\u050d\u0897\u0873\u0897\u089c\u0883\u08a7\u089c\u0889\u08ae\u0891\u087c\u08ab\u08a1\u087f\u089f", (byte)18, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static void b() {
        int n;
        c = 137761996043641319L;
        long l = c ^ 0xDF0F139A7184AA0EL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(42 + 26), (byte)(15 + 54), (byte)(45 + 38), (byte)(38 + 9), (byte)(4 + 63), (byte)(40 + 26), (byte)(49 + 18), (byte)(43 + 4), (byte)(46 + 34), (byte)(39 + 36), (byte)(50 + 17), 83, 53, (byte)(55 + 25), (byte)(57 + 40), (byte)(51 + 49), (byte)(33 + 67), (byte)(81 + 24), (byte)(35 + 75), (byte)(5 + 98)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(39 + 29), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u0175\u01a4\u01b8\u01a9\u01a6\u0198\u01a5\u018e\u019a\u01af\u0180\u01b8\u0178\u019b\u018f\u01ad\u01bf\u01af\u0187\u019d\u0183\u0189\u0195\u01be\u01cb\u0189\u01aa\u0199\u0192\u01b2\u019f\u01c0", (byte)95, 65);
                    \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.b[1] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.C("\u053f\u0517\u04ff\u0547\u054b\u0543\u0540\u052c\u052b\u0529\u054b\u0544\u0515\u0537\u0525\u0522\u0548\u0526\u0556\u0518\u0555\u055e\u0525\u0526", (byte)95, 67);
                    \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.b[2] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u0591\u0586\u0548\u058d\u0569\u0568\u0571\u0556\u057c\u0592\u055b\u0596\u0590\u0594\u0596\u055f\u0584\u0564\u059b\u0587\u05a1\u0571\u05ab\u058c\u0574\u058e\u0587\u0589\u058d\u0583\u059c\u05a3\u0594\u058a\u05b7\u0576\u0593\u0572\u05b9\u05b5\u0572\u05b3\u057d\u0583", (byte)95, 70);
                    \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.b[3] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u055f\u056e\u0572\u0566\u056a\u0568\u058c\u0590\u0572\u0586\u057a\u0563", (byte)95, 69);
                    \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.b[4] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u054a\u0529\u054e\u051e\u054f\u0550\u0503\u0533\u052e\u0554\u0532\u0525\u054a\u0559\u0541\u055b\u0539\u0519\u0539\u054d\u051c\u0557\u052c\u0535\u0535\u052e\u0557\u0524\u0521\u0542\u0542\u0569", (byte)95, 67);
                    \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.b[5] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u053c\u0543\u0540\u054e\u054c\u050a\u054b\u0548\u054f\u0542\u0545\u054f\u0547\u052c\u0515\u052e\u0547\u0544\u0557\u0548\u0532\u0538\u0525\u0526", (byte)95, 67);
                    continue block7;
                }
                case 1: {
                    \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.b[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.E("\u0553\u0582\u0596\u0587\u0584\u0576\u0583\u056c\u0578\u058d\u055e\u0596\u0556\u0579\u056d\u058b\u059d\u058d\u0565\u057b\u0561\u0560\u05a2\u0582\u0579\u057e\u0583\u05ab\u0583\u0599\u05a1\u058b", (byte)95, 69);
                    \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.b[1] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u053f\u0517\u04ff\u0547\u054b\u0543\u0540\u052c\u052b\u0529\u054d\u0531\u0558\u054f\u0545\u052a\u0549\u053d\u053c\u0550\u0515\u051b\u053a\u054b\u052f\u0516\u0553\u0525\u0523\u0533\u0524\u054b", (byte)95, 68);
                    \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.b[2] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u0591\u0586\u0548\u058d\u0569\u0568\u0571\u0556\u057c\u0592\u055b\u0596\u0590\u0594\u0596\u055f\u0584\u0564\u059b\u0587\u05a1\u0571\u05ab\u058c\u0574\u058e\u0587\u0589\u058d\u0583\u059c\u05a3\u0585\u05af\u05b6\u0595\u0595\u0579\u058b\u057b\u05bb\u058e\u059e\u0583", (byte)95, 70);
                    \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.b[3] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.A("\u0174\u019f\u0199\u01ae\u0199\u01a9\u01af\u01be\u01bf\u01b7\u0188\u0185", (byte)95, 65);
                    \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.b[4] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u01b5\u0194\u01b9\u0189\u01ba\u01bb\u016e\u019e\u0199\u01bf\u019d\u0190\u01b5\u01c4\u01ac\u01c6\u01a4\u0184\u01a4\u01b8\u0187\u01c8\u017e\u01bd\u018c\u0199\u01a0\u01a4\u018c\u01bb\u01d0\u018b", (byte)95, 66);
                    \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.b[5] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.A("\u01a7\u01ae\u01ab\u01b9\u01b7\u0175\u01b6\u01b3\u01ba\u01ad\u01b1\u0195\u0190\u0179\u01ad\u0182\u0180\u01a1\u017e\u0198\u01c2\u019c\u01b5\u01bd\u01a1\u01c3\u01af\u0191\u019a\u01c6\u01cf\u019f", (byte)95, 65);
                    continue block7;
                }
                case 2: {
                    \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.A("\u016c\u0170\u018b\u01b7\u01a3\u01b9\u01ac\u01aa\u01b5\u0197\u018e\u0199\u017f\u01b3\u01b7\u017b\u0190\u01b2\u0198\u0181\u01a2\u01c3\u01a3\u018b\u019f\u0188\u01cb\u01aa\u01cd\u019f\u01a3\u01cc", (byte)95, 65);
                    continue block7;
                }
                case 4: {
                    \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.b[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u01b0\u0183\u0199\u018c\u01af\u0174\u0194\u01b2\u0179\u0190\u01a9\u01b6\u0192\u019c\u0196\u0180\u0180\u01bf\u019c\u019f\u01ca\u0193\u0190\u0191", (byte)95, 65);
                }
            }
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0537\u0559\u055b\u053b\u055f\u057e\u0576\u058c\u0578\u0547\u0585\u057b\u0589\u0583\u054c\u0571\u0593\u0592\u058a\u0590\u058a\u055f", (byte)83, 70), \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u0511\u051e\u051d\u04e0\u0520\u051c\u0517\u0520\u052b\u051a\u04e7\u0525\u0529\u0522\u0525\u052b\u04ed\u0877\u0853\u0877\u087c\u0863\u0887\u087c\u0869\u088e\u0871\u085c\u088b\u0881\u085f\u087f\u0508", (byte)83, 67) + string + \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u0549", (byte)83, 70) + methodType.toString(), exception);
        }
    }

    static {
        a = 0 >>> 94 | 0 << ~94 + 1;
        b = Long.reverse(-2339798486138579072L);
        c = 16384 >>> 238 | 16384 << -238;
        d = (-1 >>> 208 | -1 << -208) & 0xFFFFFFFF;
        e = Long.reverse(-2339798486138579072L);
        f = Integer.reverse(0x40000000);
        g = Long.reverse(-1763337733835155584L);
        h = Long.reverse(0x3800000000000000L);
        i = (-1073741824 >>> 94 | -1073741824 << -94) & 0xFFFFFFFF;
        j = Long.reverse(-2339798486138579072L);
        k = Integer.reverse(0x20000000);
        l = Long.reverse(-1763337733835155584L);
        m = Long.reverse(0x3800000000000000L);
        n = (0x14000000 >>> 122 | 0x14000000 << ~122 + 1) & 0xFFFFFFFF;
        o = (-1 >>> 232 | -1 << ~232 + 1) & 0xFFFFFFFF;
        p = Long.reverse(-2339798486138579072L);
        q = Integer.reverse(0);
        r = Integer.reverse(Integer.MIN_VALUE);
        s = 1024 >>> 234 | 1024 << -234;
        t = Integer.reverse(0);
        u = Integer.reverse(0x60000000);
        v = 0xC00000 >>> 53 | 0xC00000 << -53;
        a = new String[u];
        b = new String[v];
        \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2.b();
        a = new \u03b8\u0393\u03b6\u03ba\u03a0\u03c3\u03b7\u03a3\u03c7\u03a9\u0393\u03c1\u03b6\u0393\u03b2();
    }

    @Override
    public boolean a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4 \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4 = \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4.f;
        \u03a9\u03b4\u03a6\u03c3\u03c9\u03c0\u03b7\u03bf\u03b5\u03c2\u03b2\u03bf\u03c6\u039b\u03c4 \u03c9\u03b4\u03a6\u03c3\u03c9\u03c0\u03b7\u03bf\u03b5\u03c2\u03b2\u03bf\u03c6\u039b\u03c4 = \u03b3\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4.a();
        return (\u03c9\u03b4\u03a6\u03c3\u03c9\u03c0\u03b7\u03bf\u03b5\u03c2\u03b2\u03bf\u03c6\u039b\u03c4 != null && \u03c9\u03b4\u03a6\u03c3\u03c9\u03c0\u03b7\u03bf\u03b5\u03c2\u03b2\u03bf\u03c6\u039b\u03c4.isAvailable() ? s : t) != 0;
    }
}

