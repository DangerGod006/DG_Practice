/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.player.PlayerCommandSendEvent
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Collection;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.player.PlayerCommandSendEvent;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6
implements \u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8 {
    private static int g;
    private static int f;
    private static long k;
    private static long h;
    private static long e;
    private static long d;
    private static int l;
    private static int c;
    private final nLoginBukkit h;
    private static int a;
    private static long c;
    private static int m;
    private static long b;
    private static String[] a;
    private static int i;
    private static long j;
    private static String[] b;

    static {
        a = (0 >>> 234 | 0 << -234) & 0xFFFFFFFF;
        b = Long.reverse(-2197027389654843544L);
        c = (2048 >>> 107 | 2048 << -107) & 0xFFFFFFFF;
        d = Long.reverse(6305768706820652904L);
        e = Long.reverse(-5332261958806667264L);
        f = (64 >>> 5 | 64 << -5) & 0xFFFFFFFF;
        g = Integer.reverse(-1);
        h = Long.reverse(-2197027389654843544L);
        i = (0x6000000 >>> 25 | 0x6000000 << -25) & 0xFFFFFFFF;
        j = Long.reverse(6305768706820652904L);
        k = Long.reverse(-5332261958806667264L);
        l = 1024 >>> 40 | 1024 << ~40 + 1;
        m = Integer.reverse(0x20000000);
        a = new String[l];
        b = new String[m];
        \u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.b();
    }

    private static String a(int n, long l) {
        l ^= 0x6DL;
        l ^= 0xDE4C33293E312891L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(47 + 21), (byte)(53 + 16), (byte)(69 + 14), (byte)(45 + 2), (byte)(47 + 20), (byte)(52 + 14), (byte)(33 + 34), (byte)(9 + 38), (byte)(24 + 56), 75, (byte)(36 + 31), 83, (byte)(47 + 6), (byte)(63 + 17), (byte)(64 + 33), (byte)(47 + 53), (byte)(13 + 87), (byte)(25 + 80), (byte)(35 + 75), (byte)(11 + 92)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(68 + 1), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u01ac\u01b9\u01b8\u017b\u01bb\u01b7\u01b2\u01bb\u01c6\u01b5\u0182\u01c0\u01c4\u01bd\u01c0\u01c6\u0188\u0519\u0513\u0515\u04fd\u0504\u0522\u051e\u0517", (byte)101, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u0518\u053a\u053c\u051c\u0540\u055f\u0557\u056d\u0559\u0528\u0566\u055c\u056a\u0564\u052d\u0552\u0574\u0573\u056b\u0571\u056b\u0540", (byte)105, 67), \u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.E("\u0588\u0595\u0594\u0557\u0597\u0593\u058e\u0597\u05a2\u0591\u055e\u059c\u05a0\u0599\u059c\u05a2\u0564\u08f5\u08ef\u08f1\u08d9\u08e0\u08fe\u08fa\u08f3\u0578", (byte)105, 69) + string + \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.F("\u055f", (byte)105, 70) + methodType.toString(), exception);
        }
    }

    @Generated
    public \u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6(nLoginBukkit nLoginBukkit2) {
        this.h = nLoginBukkit2;
    }

    private static void b() {
        int n;
        c = 1656633883366081002L;
        long l = c ^ 0xDE4C33293E312891L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(20 + 48), (byte)(14 + 55), (byte)(33 + 50), (byte)(16 + 31), (byte)(18 + 49), (byte)(10 + 56), (byte)(30 + 37), (byte)(18 + 29), 80, (byte)(71 + 4), (byte)(27 + 40), (byte)(43 + 40), (byte)(15 + 38), (byte)(56 + 24), (byte)(34 + 63), (byte)(5 + 95), (byte)(67 + 33), (byte)(51 + 54), (byte)(37 + 73), (byte)(96 + 7)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(7 + 62), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u0183\u01a1\u01ac\u0191\u0171\u01b5\u0189\u0182\u0183\u01b1\u01bd\u01b3\u01b1\u0193\u019c\u01ae\u01b9\u01c1\u01a3\u017e\u0195\u01b0\u01a5\u0193\u01a0\u0185\u0199\u01c2\u01b9\u0185\u019e\u01a8", (byte)93, 66);
                    \u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.b[1] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0533\u0543\u051c\u0541\u0541\u0536\u0514\u0519\u0523\u0528\u0507\u0502\u0545\u050a\u0549\u050d\u0507\u052e\u052b\u0531\u0512\u0522\u051f\u0520", (byte)93, 67);
                    \u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.b[2] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u058e\u0564\u0553\u0566\u0577\u0588\u0599\u0585\u058b\u0574\u0586\u0561", (byte)93, 69);
                    \u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.b[3] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u0541\u0517\u0506\u0519\u052a\u053b\u054c\u0538\u053e\u0527\u0539\u0514", (byte)93, 68);
                    continue block7;
                }
                case 1: {
                    \u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u0563\u0581\u058c\u0571\u0551\u0595\u0569\u0562\u0563\u0591\u059d\u0593\u0591\u0573\u057c\u058e\u0599\u05a1\u0583\u055e\u0575\u0588\u05a7\u05aa\u057c\u0566\u057c\u058c\u057e\u0561\u0587\u05a4\u05a4\u058e\u0591\u0585\u0597\u05b4\u05b9\u05b0\u0591\u057b\u058c\u0581", (byte)93, 70);
                    \u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.b[1] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u0580\u0590\u0569\u058e\u058e\u0583\u0561\u0566\u0570\u0575\u0556\u0573\u0557\u0575\u056f\u0572\u059c\u055a\u056e\u0557\u05a1\u057f\u0575\u0563\u0574\u0588\u05a6\u05a4\u0589\u057b\u05a1\u057d", (byte)93, 69);
                    \u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.b[2] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u0571\u055b\u056e\u0566\u0562\u0556\u0597\u0590\u0583\u056b\u0597\u0586\u055b\u057c\u055f\u056f\u0578\u0571\u0592\u05a6\u0571\u056f\u056c\u056d", (byte)93, 69);
                    \u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.b[3] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u01a1\u0182\u0189\u016d\u0174\u0186\u01a0\u0176\u018b\u01b5\u01b6\u018f\u0187\u01b3\u0192\u019f\u01c1\u0196\u0183\u01c6\u017c\u019f\u018c\u018d", (byte)93, 65);
                    continue block7;
                }
                case 2: {
                    \u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.C("\u0537\u053b\u0539\u053c\u052a\u0512\u0526\u051a\u0517\u051d\u0520\u0541\u0527\u0522\u0545\u0552\u050d\u050d\u0527\u054b\u0554\u0548\u051f\u0520", (byte)93, 67);
                    continue block7;
                }
                case 4: {
                    \u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u0571\u054a\u058f\u058d\u0586\u0572\u0582\u0593\u056c\u0595\u0597\u0588\u0579\u0558\u055b\u0595\u0559\u055b\u0595\u0591\u05a0\u056f\u056c\u056d", (byte)93, 69);
                }
            }
        }
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void a(PlayerCommandSendEvent playerCommandSendEvent) {
        if (this.h.i()) {
            return;
        }
        Player player = playerCommandSendEvent.getPlayer();
        if (player.hasPermission((String)\u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.c("\u3e80", (int)a, (long)b)) || player.hasPermission((String)\u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.c("\u3e83", (int)c, (long)(d ^ e)))) {
            return;
        }
        Collection collection = playerCommandSendEvent.getCommands();
        if (collection.stream().noneMatch(((String)\u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.c("\u3e86", (int)(f & g), (long)h))::equalsIgnoreCase)) {
            collection.add(\u03bf\u03b8\u03b9\u03a0\u03a6\u03c3\u03be\u03b6.c("\u3e89", (int)i, (long)(j ^ k)));
        }
    }
}

