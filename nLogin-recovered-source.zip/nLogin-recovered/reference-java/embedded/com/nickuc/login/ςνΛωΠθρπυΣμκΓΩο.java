/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.json.JSONObject
 *  javax.annotation.Nonnull
 */
package com.nickuc.login;

import com.nickuc.login.lib.json.JSONObject;
import javax.annotation.Nonnull;

public interface \u03c2\u03bd\u039b\u03c9\u03a0\u03b8\u03c1\u03c0\u03c5\u03a3\u03bc\u03ba\u0393\u03a9\u03bf<T> {
    public JSONObject a(@Nonnull T var1);

    public T a(@Nonnull JSONObject var1);

    public Class<?> a();
}

