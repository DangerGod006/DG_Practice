/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  net.md_5.bungee.api.ChatMessageType
 *  net.md_5.bungee.api.CommandSender
 *  net.md_5.bungee.api.ProxyServer
 *  net.md_5.bungee.api.chat.BaseComponent
 *  net.md_5.bungee.api.chat.TextComponent
 *  net.md_5.bungee.api.connection.ProxiedPlayer
 *  net.md_5.bungee.api.connection.Server
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a0\u03c7\u03b8\u03c4\u03b3\u03c0\u03c6\u03a8\u03bb\u03c3;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4;
import com.nickuc.login.\u03b5\u03c4\u03c2\u03b6\u03bf\u03b6\u03b7\u03c5\u03b3\u03c2;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03ba\u03c8\u03b1\u03c3\u03a9\u03c8\u03bc\u03c9\u03a9\u03c5\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.connection.Server;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6
implements \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 {
    private static long ad;
    private static long c;
    private static long o;
    private static long af;
    private static int h;
    private static long am;
    private static long ag;
    private static long d;
    private static long bi;
    private static int ai;
    private static int as;
    private static int j;
    private static int x;
    private final \u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u0393 b;
    private static int ay;
    private static int w;
    private static int aj;
    private static long be;
    private static long g;
    private static long at;
    private static int b;
    private static long ac;
    private static int ba;
    private static int az;
    private static long ap;
    private static long au;
    private static int bg;
    private static int aa;
    private static int ax;
    private final ProxiedPlayer a;
    private final boolean R;
    private static int c;
    private static int al;
    private static int m;
    private static String[] b;
    static final Map<ProxiedPlayer, \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6> c;
    private static long l;
    private static long aw;
    private static int bn;
    private static long bb;
    private static long bj;
    private static int q;
    private static int ab;
    private static int ae;
    private static int bd;
    private static int ar;
    private static long bf;
    private static long ak;
    private static int av;
    private static int ah;
    private static String[] a;
    private static int p;
    private final UUID e = UUID.randomUUID();
    private static int aq;
    private static int y;
    private static int bh;
    private static int u;
    private static int bk;
    private static int r;
    private static int bo;
    private static int bs;
    private \u03ba\u03ba\u03c8\u03b1\u03c3\u03a9\u03c8\u03bc\u03c9\u03a9\u03c5\u03b8 a;
    private static long bm;
    private static int f;
    private static int bc;
    private static long e;
    private static int bp;
    private static int s;
    private static int bl;
    private static int bq;
    private final ProxyServer c;
    private static int an;
    private static int br;
    private static int i;
    private static int n;
    private static int a;
    private static int z;
    private static int v;
    private static int t;
    private static long ao;
    private static int k;

    public boolean equals(Object object) {
        if (object == null || this.getClass() != object.getClass()) {
            return v != 0;
        }
        \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6 \u03b3\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6 = (\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6)object;
        return (Objects.equals(this.e, \u03b3\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.e) && Objects.equals(this.a, \u03b3\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.a) ? w : x) != 0;
    }

    @Override
    public void d(Object object) {
        if (object instanceof String) {
            this.a.sendMessage(TextComponent.fromLegacyText((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.f((String)object, b != 0)));
        } else if (object instanceof TextComponent) {
            this.a.sendMessage((BaseComponent)((TextComponent)object));
        } else {
            throw new IllegalArgumentException((String)\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.c("\u3e80", (int)c, (long)(d ^ e)) + object + (String)\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.c("\u3e83", (int)f, (long)g) + object.getClass().getCanonicalName());
        }
    }

    @Override
    public void a(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?> \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b7 \u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b72, Object object, byte[] byArray) {
        if (!(object instanceof String)) {
            throw new IllegalArgumentException((String)\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.c("\u3e80", (int)(j & k), (long)l));
        }
        if (!this.a.isConnected()) {
            return;
        }
        switch (\u03b5\u03c4\u03c2\u03b6\u03bf\u03b6\u03b7\u03c5\u03b3\u03c2.q[\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b72.ordinal()]) {
            case 1: {
                this.a.sendData((String)object, byArray);
                break;
            }
            case 2: {
                Server server = this.a.getServer();
                if (server == null) break;
                server.sendData((String)object, byArray);
                break;
            }
            default: {
                throw new IllegalArgumentException((String)\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.c("\u3e83", (int)(m & n), (long)o) + (Object)((Object)\u03b3\u03a6\u03a0\u03c5\u03c1\u03c1\u03c1\u03c0\u03b72));
            }
        }
    }

    @Override
    public \u03ba\u03ba\u03c8\u03b1\u03c3\u03a9\u03c8\u03bc\u03c9\u03a9\u03c5\u03b8 a() {
        if (this.a == null) {
            this.a = new \u03a0\u03c7\u03b8\u03c4\u03b3\u03c0\u03c6\u03a8\u03bb\u03c3(this);
        }
        return this.a;
    }

    @Override
    public int h() {
        return this.a.getPing();
    }

    public static \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6 a(\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u0393 \u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u03932, ProxyServer proxyServer, Object object) {
        if (object instanceof String) {
            String string = ((String)object).toLowerCase(Locale.ENGLISH);
            ProxiedPlayer proxiedPlayer = proxyServer.getPlayer(string);
            if (proxiedPlayer == null) {
                return null;
            }
            return \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.a(\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u03932, proxyServer, proxiedPlayer);
        }
        if (object instanceof ProxiedPlayer) {
            return \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.a(\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u03932, proxyServer, (ProxiedPlayer)object);
        }
        throw new IllegalArgumentException((String)\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.c("\u3e80", (int)(ai & aj), (long)ak) + object + (String)\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.c("\u3e83", (int)al, (long)am) + (String)(object != null ? object.getClass().getCanonicalName() : \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.c("\u3e86", (int)an, (long)(ao ^ ap))));
    }

    @Override
    public void o(String string) {
        this.a.sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.f(string, h != 0)));
    }

    @Override
    public String getName() {
        return this.a.getName();
    }

    public int hashCode() {
        Object[] objectArray = new Object[y];
        objectArray[\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.z] = this.e;
        objectArray[\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.aa] = this.a;
        return Objects.hash(objectArray);
    }

    @Override
    public void p(String string) {
        this.a.chat(string);
    }

    private static \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6 a(\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u0393 \u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u03932, ProxyServer proxyServer, ProxiedPlayer proxiedPlayer) {
        \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6 \u03b3\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6 = (\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6)c.get(proxiedPlayer);
        if (\u03b3\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6 != null) {
            return \u03b3\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6;
        }
        if (\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.aj()) {
            StackTraceElement[] stackTraceElementArray = new Exception().getStackTrace();
            Object object = stackTraceElementArray.length > 0 ? stackTraceElementArray[Math.min(aq, stackTraceElementArray.length - ar)].toString() : \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.c("\u3e80", (int)as, (long)(at ^ au));
            Object[] objectArray = new Object[ax];
            objectArray[\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.ay] = proxiedPlayer.getName();
            objectArray[\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.az] = object;
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.c("\u3e83", (int)av, (long)aw), objectArray);
        }
        return \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b(\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u03932, proxyServer, proxiedPlayer);
    }

    @Override
    public <T> T c() {
        return (T)this.a;
    }

    @Generated
    private \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6(\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u0393 \u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u03932, ProxiedPlayer proxiedPlayer, ProxyServer proxyServer, boolean bl) {
        this.b = \u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u03932;
        this.a = proxiedPlayer;
        this.c = proxyServer;
        this.R = bl;
    }

    @Override
    @Generated
    public boolean S() {
        return this.R;
    }

    private static void b() {
        int n;
        c = 4410753709114333256L;
        long l = c ^ 0xF6BA2EAA48BFBBB6L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(24 + 44), (byte)(2 + 67), (byte)(64 + 19), (byte)(36 + 11), (byte)(37 + 30), (byte)(30 + 36), (byte)(28 + 39), 47, (byte)(58 + 22), (byte)(59 + 16), (byte)(12 + 55), (byte)(26 + 57), (byte)(39 + 14), (byte)(72 + 8), (byte)(76 + 21), (byte)(83 + 17), (byte)(81 + 19), 105, (byte)(24 + 86), (byte)(98 + 5)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(29 + 40), (byte)(6 + 77)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.E("\u053b\u053c\u0544\u0534\u0561\u054f\u056b\u054c\u056e\u0530\u0562\u055f\u0542\u0569\u056a\u0543\u0568\u0571\u0550\u0569\u054b\u0547\u0536\u053b\u054c\u053d\u054f\u0573\u057f\u0574\u0577\u055c\u0548\u0566\u0544\u0556\u057a\u058b\u0547\u0590\u054e\u055e\u0589\u0558", (byte)52, 69);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[1] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.D("\u04c7\u04c5\u0497\u0499\u04cd\u049b\u0489\u04c2\u04c2\u04c3\u048f\u0499", (byte)52, 68);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[2] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u0137\u011b\u011f\u011f\u0134\u0137\u015d\u013c\u0157\u0166\u013d\u0136\u0161\u013f\u0137\u0166\u015a\u0166\u012b\u0141\u014d\u013e\u015f\u0130\u0176\u0159\u0177\u0152\u0153\u0158\u017a\u0175\u0159\u0171\u0142\u017d\u0174\u017e\u013d\u0160\u0162\u0154\u0184\u014f", (byte)52, 65);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[3] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u0132\u0133\u013b\u012b\u0158\u0146\u0162\u0143\u0165\u0127\u0159\u0142\u0139\u0161\u0141\u012d\u012e\u0150\u016d\u0144\u0172\u013e\u0168\u012e\u016a\u012b\u0153\u0165\u013a\u013c\u0179\u016b", (byte)52, 66);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[4] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u04c1\u04c7\u04c1\u0486\u04ab\u0497\u049e\u04a8\u04bd\u04ac\u048d\u04c0\u048f\u0494\u04a9\u04cc\u04c5\u04cf\u04dc\u0496\u04d2\u04d8\u04d5\u04aa\u04ad\u04d7\u049d\u04c4\u04d9\u04b5\u04a5\u04a2\u04bc\u04bd\u04b7\u04cc\u04c2\u04cd\u04d0\u04bc\u04f3\u04ea\u04ea\u04b9", (byte)52, 68);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[5] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u0533\u055b\u052b\u0554\u054b\u054b\u052c\u056d\u0563\u0568\u055e\u0566\u0540\u0531\u052d\u054e\u0549\u0545\u0564\u053b\u0578\u057c\u0543\u0544", (byte)52, 69);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[6] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u0132\u0133\u013b\u012b\u0158\u0146\u0162\u0143\u0165\u0127\u0158\u013a\u0169\u0163\u014b\u0162\u014a\u0144\u015a\u016c\u0168\u016d\u012c\u0156\u0177\u0138\u0138\u0150\u0150\u016b\u0157\u015e\u017f\u017c\u017a\u017f\u0173\u014f\u0183\u0160\u0142\u0180\u016a\u014f", (byte)52, 66);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[7] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.C("\u04c7\u04c5\u0497\u0499\u04cd\u049b\u0489\u04c2\u04c2\u04c3\u048f\u0499", (byte)52, 67);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[8] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u04a7\u04cb\u04ab\u04b5\u04cc\u0487\u04b8\u049e\u0484\u04ca\u04c6\u0499", (byte)52, 68);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[9] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u013b\u012f\u012b\u0154\u0139\u015f\u0136\u0131\u0168\u0127\u013a\u012f", (byte)52, 65);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[10] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u0563\u0547\u0522\u0568\u053c\u055f\u0537\u0567\u053d\u0545\u056c\u0564\u0541\u0532\u0568\u054c\u0544\u054e\u0548\u0567\u056d\u0570\u056d\u055d\u0575\u053b\u0578\u0554\u0544\u0567\u0572\u0585\u057e\u0564\u0561\u058d\u0582\u0580\u056d\u057e\u054a\u054c\u0561\u0564\u0553\u0577\u0572\u0557\u0593\u0565\u0572\u054e\u0565\u058e\u0596\u058a\u058c\u05a1\u0561\u0593\u059a\u0571\u05a3\u05a2\u0581\u0579\u056b\u0594\u05ae\u05af\u058d\u05ac\u05b2\u056b\u05a3\u056b\u0582\u056f\u05b7\u0571\u058b\u05b0\u05b3\u0594\u0585\u0577\u05b8\u05b0\u0578\u05b3\u059d\u0583\u0595\u0595\u0579\u0596", (byte)52, 69);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[11] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u04c3\u04c0\u0486\u049b\u04b8\u0488\u048f\u04a5\u04be\u048d\u048b\u04a4\u04af\u048e\u04c9\u04d3\u0492\u04cc\u04a8\u04ba\u04d7\u04cd\u04a4\u04a5", (byte)52, 67);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[12] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.D("\u0494\u04c3\u048b\u04a3\u04a5\u04cf\u04a1\u0491\u04c6\u04b3\u0492\u04be\u048c\u04c7\u04b1\u04ca\u04c3\u04a7\u0495\u04c9\u04df\u04cd\u04a4\u04a5", (byte)52, 68);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[13] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u0566\u0532\u055c\u055d\u052a\u056d\u0539\u0544\u053a\u0529\u0541\u0532\u0551\u052e\u054c\u0553\u054e\u0543\u054e\u052e\u0578\u056c\u0543\u0544", (byte)52, 69);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[14] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.C("\u04c4\u04c4\u04b5\u04ca\u04ce\u04a7\u0490\u049d\u04cf\u049b\u04cc\u0492\u04c6\u04b5\u04a2\u04d9\u04a6\u04aa\u04b9\u04db\u0498\u04cd\u04a4\u04a5", (byte)52, 67);
                    continue block7;
                }
                case 1: {
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.B("\u0132\u0133\u013b\u012b\u0158\u0146\u0162\u0143\u0165\u0127\u0159\u0156\u0139\u0160\u0161\u013a\u015f\u0168\u0147\u0160\u0142\u013e\u012d\u0132\u0143\u0134\u0146\u016a\u0176\u016b\u016e\u0153\u0148\u0137\u0170\u014f\u016f\u0176\u0180\u015e\u013f\u0172\u0184\u014f", (byte)52, 66);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[1] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u0538\u055f\u0565\u0542\u056a\u0563\u0539\u0566\u054b\u056e\u0565\u0538", (byte)52, 69);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[2] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u04a1\u0485\u0489\u0489\u049e\u04a1\u04c7\u04a6\u04c1\u04d0\u04a7\u04a0\u04cb\u04a9\u04a1\u04d0\u04c4\u04d0\u0495\u04ab\u04b7\u04a8\u04c9\u049a\u04e0\u04c3\u04e1\u04bc\u04bd\u04c2\u04e4\u04df\u04e2\u04b9\u04e5\u04c9\u04d9\u04c5\u04ba\u04b1\u04ef\u04f3\u04af\u04b9", (byte)52, 68);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[3] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.F("\u053b\u053c\u0544\u0534\u0561\u054f\u056b\u054c\u056e\u0530\u0562\u054b\u0542\u056a\u054a\u0536\u0537\u0559\u0576\u054d\u057b\u054b\u0536\u0538\u053b\u0571\u0555\u055b\u0565\u054e\u053f\u0553\u0543\u057f\u0573\u055c\u0589\u0576\u0557\u057e\u057f\u056f\u0563\u0558", (byte)52, 70);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[4] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.E("\u0560\u0566\u0560\u0525\u054a\u0536\u053d\u0547\u055c\u054b\u052c\u055f\u052e\u0533\u0548\u056b\u0564\u056e\u057b\u0535\u0571\u0577\u0574\u0549\u054c\u0576\u053c\u0563\u0578\u0554\u0544\u0541\u055d\u0541\u0567\u0586\u0566\u0582\u0579\u0547\u055e\u056e\u057d\u0558", (byte)52, 69);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[5] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u012a\u0152\u0122\u014b\u0142\u0142\u0123\u0164\u015a\u015f\u0154\u0156\u0122\u012d\u013b\u0143\u0144\u0170\u0169\u016b\u0130\u014d\u013a\u013b", (byte)52, 65);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[6] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.E("\u053b\u053c\u0544\u0534\u0561\u054f\u056b\u054c\u056e\u0530\u0561\u0543\u0572\u056c\u0554\u056b\u0553\u054d\u0563\u0575\u0571\u0576\u0535\u055f\u0580\u0541\u0541\u0559\u0559\u0574\u0560\u0567\u0573\u0563\u0565\u0559\u0586\u057d\u056b\u055e\u0567\u058c\u054e\u0558", (byte)52, 69);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[7] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u0551\u0523\u054b\u0547\u056c\u0561\u056c\u0570\u052a\u056f\u0547\u0538", (byte)52, 70);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[8] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u04a3\u04cc\u04be\u04a1\u04ca\u04c6\u049c\u04c4\u04bc\u048e\u04b0\u0499", (byte)52, 68);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[9] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u0484\u048a\u04a8\u04c1\u04ba\u04a2\u04b8\u04c8\u04d0\u04a3\u0486\u04cd\u049e\u04a0\u04b3\u04ca\u04ad\u0493\u048e\u04cb\u04b2\u04cd\u04a4\u04a5", (byte)52, 67);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[10] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u015a\u013e\u0119\u015f\u0133\u0156\u012e\u015e\u0134\u013c\u0163\u015b\u0138\u0129\u015f\u0143\u013b\u0145\u013f\u015e\u0164\u0167\u0164\u0154\u016c\u0132\u016f\u014b\u013b\u015e\u0169\u017c\u0175\u015b\u0158\u0184\u0179\u0177\u0164\u0175\u0141\u0143\u0158\u015b\u014a\u016e\u0169\u014e\u018a\u015c\u0169\u0145\u015c\u0185\u018d\u0181\u0183\u0198\u0158\u018a\u0191\u0168\u019a\u0199\u0178\u0170\u0162\u018b\u01a5\u01a6\u0184\u01a3\u01a9\u0162\u019a\u0162\u0179\u0166\u01ae\u0168\u0182\u01a7\u01aa\u018b\u017c\u01b4\u0191\u01a3\u01a9\u018e\u0170\u01ab\u01ad\u01b3\u01ba\u017e\u017b\u0191\u017a\u0194\u0191\u017d\u0180\u01a2\u01bf\u0181\u0189\u018f", (byte)52, 66);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[11] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u0159\u0156\u011c\u0131\u014e\u011e\u0125\u013b\u0154\u0123\u0121\u0158\u0122\u015d\u0149\u012b\u0158\u0142\u0172\u0145\u0126\u014e\u0150\u013f\u0150\u0134\u0155\u016c\u0148\u0150\u015b\u0178", (byte)52, 66);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[12] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.D("\u0494\u04c3\u048b\u04a3\u04a5\u04cf\u04a1\u0491\u04c6\u04b3\u0490\u04ab\u04d6\u04d6\u04ab\u04da\u04d5\u04b6\u04c7\u049d\u04ac\u049f\u04d5\u04d0\u04b3\u04ac\u04ce\u04cd\u04a6\u04e8\u04e3\u04a2", (byte)52, 68);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[13] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u04c7\u0493\u04bd\u04be\u048b\u04ce\u049a\u04a5\u049b\u048a\u04a1\u0494\u04bf\u04d3\u0493\u04c1\u04b0\u04d6\u048e\u048f\u04aa\u04dd\u04a4\u04a5", (byte)52, 67);
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[14] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u0563\u0563\u0554\u0569\u056d\u0546\u052f\u053c\u056e\u053a\u056b\u0571\u054f\u0576\u052d\u0555\u0533\u0537\u0555\u0556\u0577\u0571\u055c\u0536\u0556\u057b\u0575\u056e\u0561\u0565\u0582\u0550", (byte)52, 69);
                    continue block7;
                }
                case 2: {
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u0495\u04c7\u04cc\u048d\u0498\u04c3\u04a7\u049d\u04bd\u048e\u0492\u049e\u04c4\u04b4\u04b4\u04cb\u04b9\u0496\u0497\u04b2\u04cc\u04d8\u04e1\u04cf\u04aa\u04ad\u049c\u04b9\u04b3\u04b5\u04c6\u04b8", (byte)52, 67);
                    continue block7;
                }
                case 4: {
                    \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u0152\u014a\u014c\u0138\u0151\u0160\u0135\u0122\u0169\u0166\u0124\u0146\u016a\u0169\u014d\u0146\u0141\u0129\u016d\u0145\u0172\u014d\u013a\u013b", (byte)52, 66);
                }
            }
        }
    }

    @Override
    public void a(String string, String string2, int n, int n2, int n3) {
        this.a.sendTitle(this.c.createTitle().title(TextComponent.fromLegacyText((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.f(string, t != 0))).subTitle(TextComponent.fromLegacyText((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.f(string2, u != 0))).fadeIn(n).fadeOut(n3).stay(n2));
    }

    private static String a(int n, long l) {
        l ^= 0x3EL;
        l ^= 0xF6BA2EAA48BFBBB6L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(37 + 31), 69, 83, (byte)(3 + 44), (byte)(25 + 42), (byte)(47 + 19), (byte)(58 + 9), (byte)(46 + 1), (byte)(7 + 73), (byte)(46 + 29), (byte)(53 + 14), (byte)(36 + 47), (byte)(41 + 12), (byte)(75 + 5), (byte)(53 + 44), (byte)(74 + 26), (byte)(15 + 85), (byte)(91 + 14), (byte)(84 + 26), (byte)(78 + 25)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(11 + 57), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.A("\u00f2\u00ff\u00fe\u00c1\u0101\u00fd\u00f8\u0101\u010c\u00fb\u00c8\u0106\u010a\u0103\u0106\u010c\u00ce\u0433\u045b\u0467\u0461\u0465\u046c\u0461\u045a\u0460\u046a\u046c\u0451", (byte)8, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public String toString() {
        return (String)\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.c("\u3e80", (int)ab, (long)(ac ^ ad)) + this.e + (String)\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.c("\u3e83", (int)ae, (long)(af ^ ag)) + this.a + (char)ah;
    }

    @Override
    public InetSocketAddress a() {
        try {
            return (InetSocketAddress)this.a.getSocketAddress();
        }
        catch (NoSuchMethodError noSuchMethodError) {
            return this.a.getAddress();
        }
    }

    @Override
    public \u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9 a() {
        return this.b.a(a != 0);
    }

    /*
     * Exception decompiling
     */
    static \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6 b(\u03c0\u03c1\u03b3\u03b7\u03c0\u03bd\u03c0\u03c4\u03a8\u03b6\u03be\u03c3\u0393\u0393 var0, ProxyServer var1_1, ProxiedPlayer var2_2) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter$TooOptimisticMatchException
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.getString(SwitchStringRewriter.java:404)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.access$600(SwitchStringRewriter.java:53)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter$SwitchStringMatchResultCollector.collectMatches(SwitchStringRewriter.java:368)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest.match(ResetAfterTest.java:24)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.KleeneN.match(KleeneN.java:24)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.MatchSequence.match(MatchSequence.java:26)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.matchutil.ResetAfterTest.match(ResetAfterTest.java:23)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.rewriteComplex(SwitchStringRewriter.java:201)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.op4rewriters.SwitchStringRewriter.rewrite(SwitchStringRewriter.java:73)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:881)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public Optional<String> a() {
        return Optional.ofNullable(this.a.getLocale()).map(Locale::toLanguageTag);
    }

    @Override
    public String u() {
        return this.a.getDisplayName();
    }

    @Override
    public void ad() {
        this.a.sendTitle(this.c.createTitle().reset());
    }

    @Override
    public UUID a() {
        return this.a.getUniqueId();
    }

    @Override
    public void n(String string) {
        this.a.setDisplayName(string);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u0545\u0567\u0569\u0549\u056d\u058c\u0584\u059a\u0586\u0555\u0593\u0589\u0597\u0591\u055a\u057f\u05a1\u05a0\u0598\u059e\u0598\u056d", (byte)120, 67), \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.D("\u0580\u058d\u058c\u054f\u058f\u058b\u0586\u058f\u059a\u0589\u0556\u0594\u0598\u0591\u0594\u059a\u055c\u08c1\u08e9\u08f5\u08ef\u08f3\u08fa\u08ef\u08e8\u08ee\u08f8\u08fa\u08df\u0574", (byte)120, 68) + string + \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u01a9", (byte)120, 66) + methodType.toString(), exception);
        }
    }

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = (4 >>> 98 | 4 << ~98 + 1) & 0xFFFFFFFF;
        c = (0 >>> 86 | 0 << ~86 + 1) & 0xFFFFFFFF;
        d = Long.reverse(1304072366734994620L);
        e = Long.reverse(0x7C00000000000000L);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Long.reverse(7933371018224364732L);
        h = Integer.reverse(Integer.MIN_VALUE);
        i = 0x400000 >>> 182 | 0x400000 << ~182 + 1;
        j = 262144 >>> 209 | 262144 << -209;
        k = Integer.reverse(-1);
        l = Long.reverse(7933371018224364732L);
        m = Integer.reverse(-1073741824);
        n = (-1 >>> 143 | -1 << ~143 + 1) & 0xFFFFFFFF;
        o = Long.reverse(7933371018224364732L);
        p = Integer.reverse(0x40000000);
        q = Integer.reverse(0);
        r = (752 >>> 164 | 752 << -164) & 0xFFFFFFFF;
        s = 0x400000 >>> 214 | 0x400000 << ~214 + 1;
        t = (0x2000000 >>> 153 | 0x2000000 << ~153 + 1) & 0xFFFFFFFF;
        u = Integer.reverse(Integer.MIN_VALUE);
        v = (0 >>> 62 | 0 << ~62 + 1) & 0xFFFFFFFF;
        w = 1024 >>> 10 | 1024 << -10;
        x = Integer.reverse(0);
        y = 524288 >>> 82 | 524288 << ~82 + 1;
        z = 0 >>> 201 | 0 << -201;
        aa = (0x10000000 >>> 156 | 0x10000000 << -156) & 0xFFFFFFFF;
        ab = Integer.reverse(0x20000000);
        ac = Long.reverse(1304072366734994620L);
        ad = Long.reverse(0x7C00000000000000L);
        ae = Integer.reverse(-1610612736);
        af = Long.reverse(1304072366734994620L);
        ag = Long.reverse(0x7C00000000000000L);
        ah = 1073741855 >>> 126 | 1073741855 << -126;
        ai = (192 >>> 133 | 192 << -133) & 0xFFFFFFFF;
        aj = -1 >>> 140 | -1 << ~140 + 1;
        ak = Long.reverse(7933371018224364732L);
        al = 28672 >>> 172 | 28672 << -172;
        am = Long.reverse(7933371018224364732L);
        an = Integer.reverse(0x10000000);
        ao = Long.reverse(1304072366734994620L);
        ap = Long.reverse(0x7C00000000000000L);
        aq = 12288 >>> 204 | 12288 << ~204 + 1;
        ar = Integer.reverse(Integer.MIN_VALUE);
        as = Integer.reverse(-1879048192);
        at = Long.reverse(1304072366734994620L);
        au = Long.reverse(0x7C00000000000000L);
        av = 327680 >>> 15 | 327680 << ~15 + 1;
        aw = Long.reverse(7933371018224364732L);
        ax = Integer.reverse(0x40000000);
        ay = (0 >>> 31 | 0 << ~31 + 1) & 0xFFFFFFFF;
        az = Integer.reverse(Integer.MIN_VALUE);
        ba = Integer.reverse(-805306368);
        bb = Long.reverse(7933371018224364732L);
        bc = (-1 >>> 92 | -1 << -92) & 0xFFFFFFFF;
        bd = Integer.reverse(0x30000000);
        be = Long.reverse(1304072366734994620L);
        bf = Long.reverse(0x7C00000000000000L);
        bg = (0 >>> 39 | 0 << -39) & 0xFFFFFFFF;
        bh = Integer.reverse(-1342177280);
        bi = Long.reverse(1304072366734994620L);
        bj = Long.reverse(0x7C00000000000000L);
        bk = Integer.reverse(Integer.MIN_VALUE);
        bl = Integer.reverse(0x70000000);
        bm = Long.reverse(7933371018224364732L);
        bn = (32768 >>> 142 | 32768 << ~142 + 1) & 0xFFFFFFFF;
        bo = Integer.MIN_VALUE >>> 31 | Integer.MIN_VALUE << ~31 + 1;
        bp = Integer.reverse(0);
        bq = Integer.reverse(0);
        br = -536870911 >>> 29 | -536870911 << -29;
        bs = Integer.reverse(-268435456);
        a = new String[br];
        b = new String[bs];
        \u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.b();
        c = (long)new ConcurrentHashMap();
    }

    @Override
    public void l(String string) {
        if (string.length() >= p && string.charAt(q) == r) {
            string = string.substring(s);
        }
        this.c.getPluginManager().dispatchCommand((CommandSender)this.a, string);
    }

    @Override
    public boolean i(String string) {
        return this.a.hasPermission(string);
    }

    static /* synthetic */ ProxiedPlayer a(\u0393\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6 \u03b3\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6) {
        return \u03b3\u03ba\u03c5\u03be\u03c1\u03c7\u03bb\u03b3\u03b8\u03c1\u03c2\u03a6.a;
    }

    @Override
    public CompletableFuture<Void> a(String string) {
        CompletableFuture<Void> completableFuture = new CompletableFuture<Void>();
        this.a.disconnect(TextComponent.fromLegacyText((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.f(string, i != 0)));
        completableFuture.complete(null);
        return completableFuture;
    }

    @Override
    public boolean R() {
        return this.a.isConnected();
    }
}

