/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

class \u03b8\u039b\u03a3\u03c7\u03b1\u03c5\u03b8\u03b4\u03c4\u03b7\u03be\u03b5\u03bb\u03b1\u03b3 {
}

