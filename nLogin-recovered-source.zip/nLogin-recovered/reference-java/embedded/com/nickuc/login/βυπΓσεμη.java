/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7 {
    public static final int an;
    private static long j;
    public static final int ap;
    private static int m;
    private static long k;
    private static int l;
    public static final String cl;
    private static int p;
    private static int c;
    public static final int av;
    private static int f;
    private static int o;
    private static int r;
    private static int i;
    public static final String cj;
    public static final int as;
    public static final int aq;
    public static final int at;
    private static int d;
    private static long g;
    private static int n;
    public static final String ck;
    private static long c;
    private static int q;
    private static long h;
    public static final int ar;
    public static final int au;
    private static String[] a;
    public static final int ao;
    private static long e;
    private static int s;
    private static int a;
    private static int b;
    private static String[] b;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u0549\u056b\u056d\u054d\u0571\u0590\u0588\u059e\u058a\u0559\u0597\u058d\u059b\u0595\u055e\u0583\u05a5\u05a4\u059c\u05a2\u059c\u0571", (byte)101, 70), \u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u0547\u0554\u0553\u0516\u0556\u0552\u054d\u0556\u0561\u0550\u051d\u055b\u055f\u0558\u055b\u0561\u0523\u08a7\u08bb\u08b7\u088b\u08bc\u08af\u08b7\u08b3\u0537", (byte)101, 67) + string + \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u051e", (byte)101, 67) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x2CL;
        l ^= 0xCF1B567172A87296L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(13 + 55), (byte)(16 + 53), (byte)(24 + 59), (byte)(14 + 33), (byte)(21 + 46), (byte)(36 + 30), (byte)(44 + 23), 47, (byte)(36 + 44), 75, (byte)(27 + 40), (byte)(67 + 16), (byte)(44 + 9), (byte)(12 + 68), (byte)(52 + 45), (byte)(59 + 41), (byte)(68 + 32), (byte)(101 + 4), (byte)(80 + 30), (byte)(29 + 74)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(60 + 23)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u01b6\u01c3\u01c2\u0185\u01c5\u01c1\u01bc\u01c5\u01d0\u01bf\u018c\u01ca\u01ce\u01c7\u01ca\u01d0\u0192\u0516\u052a\u0526\u04fa\u052b\u051e\u0526\u0522", (byte)106, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = Integer.reverse(-1073741824);
        b = 0x180000 >>> 83 | 0x180000 << ~83 + 1;
        c = (0 >>> 157 | 0 << -157) & 0xFFFFFFFF;
        d = Integer.reverse(0);
        e = Long.reverse(-1820741297887031016L);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Long.reverse(-3261893178645589736L);
        h = Long.reverse(0x3400000000000000L);
        i = 0x2000000 >>> 88 | 0x2000000 << -88;
        j = Long.reverse(-3261893178645589736L);
        k = Long.reverse(0x3400000000000000L);
        l = (10 >>> 33 | 10 << ~33 + 1) & 0xFFFFFFFF;
        m = -1 >>> 39 | -1 << ~39 + 1;
        n = 786432 >>> 146 | 786432 << ~146 + 1;
        o = (0x180000 >>> 114 | 0x180000 << ~114 + 1) & 0xFFFFFFFF;
        p = Integer.reverse(-536870912);
        q = (1024 >>> 9 | 1024 << ~9 + 1) & 0xFFFFFFFF;
        r = (4 >>> 160 | 4 << ~160 + 1) & 0xFFFFFFFF;
        s = 0x2000000 >>> 121 | 0x2000000 << -121;
        a = new String[a];
        b = new String[b];
        \u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7.b();
        ao = c;
        ck = \u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7.c("\u3e80", (int)d, (long)e);
        cj = \u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7.c("\u3e83", (int)f, (long)(g ^ h));
        cl = \u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7.c("\u3e86", (int)i, (long)(j ^ k));
        at = l;
        an = m;
        ar = n;
        au = o;
        av = p;
        aq = q;
        as = r;
        ap = s;
    }

    private static void b() {
        int n;
        c = 1768491842404801867L;
        long l = c ^ 0xCF1B567172A87296L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(41 + 27), (byte)(37 + 32), (byte)(77 + 6), (byte)(36 + 11), (byte)(36 + 31), 66, (byte)(26 + 41), (byte)(14 + 33), (byte)(27 + 53), (byte)(42 + 33), (byte)(42 + 25), 83, (byte)(34 + 19), (byte)(53 + 27), (byte)(80 + 17), (byte)(54 + 46), (byte)(70 + 30), (byte)(92 + 13), (byte)(28 + 82), (byte)(73 + 30)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(9 + 59), (byte)(22 + 47), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.F("\u0566\u054c\u0589\u0575\u058e\u0576\u0592\u0597\u0594\u059d\u058b\u0562", (byte)94, 70);
                    \u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7.b[1] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u0542\u0517\u053d\u051a\u052b\u0515\u051c\u054d\u0524\u054d\u052e\u0517", (byte)94, 67);
                    \u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7.b[2] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u053b\u0520\u0519\u053d\u0521\u054d\u054e\u053c\u0549\u052b\u052f\u053c\u0529\u054f\u0522\u0546\u052d\u0536\u0542\u0514\u052a\u0535\u0522\u0523", (byte)94, 67);
                    continue block7;
                }
                case 1: {
                    \u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7.b[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u054d\u058c\u0568\u0574\u0589\u0590\u0558\u056f\u0575\u0552\u058f\u0562", (byte)94, 70);
                    \u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7.b[1] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.F("\u0583\u0554\u056f\u054e\u0584\u0554\u056b\u0596\u0559\u0584\u0571\u0599\u0573\u0594\u0593\u0574\u0590\u0570\u0590\u0579\u0598\u0580\u056d\u056e", (byte)94, 70);
                    \u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7.b[2] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.C("\u053b\u0520\u0519\u053d\u0521\u054d\u054e\u053c\u0549\u052b\u052e\u052b\u0540\u051d\u050c\u050d\u0523\u0537\u0526\u0552\u051b\u055b\u0522\u0523", (byte)94, 67);
                    continue block7;
                }
                case 2: {
                    \u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0535\u0533\u0541\u054a\u0539\u051b\u051b\u052f\u0528\u050e\u0527\u051d\u050d\u0514\u0527\u0551\u0554\u052b\u0532\u054a\u055c\u0535\u0522\u0523", (byte)94, 67);
                    continue block7;
                }
                case 4: {
                    \u03b2\u03c5\u03c0\u0393\u03c3\u03b5\u03bc\u03b7.b[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.A("\u0192\u0174\u01b2\u018d\u0188\u01ae\u01a4\u018c\u0174\u01b0\u019b\u019e\u01a0\u0198\u01b1\u0179\u01a0\u018e\u0178\u01a6\u01c9\u01c4\u0194\u0199\u019f\u01ae\u01cb\u01c6\u0182\u0190\u018e\u01a4", (byte)94, 65);
                }
            }
        }
    }
}

