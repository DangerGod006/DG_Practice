/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.enums.SpawnType
 *  com.nickuc.login.lib.json.JSONObject
 *  javax.annotation.Nonnull
 */
package com.nickuc.login;

import com.nickuc.login.api.enums.SpawnType;
import com.nickuc.login.lib.json.JSONObject;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c2\u03bd\u039b\u03c9\u03a0\u03b8\u03c1\u03c0\u03c5\u03a3\u03bc\u03ba\u0393\u03a9\u03bf;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.annotation.Nonnull;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b2\u03c2\u03c0\u03c4\u03c7\u03b6\u03ba\u03b7\u03c0\u03b2\u03bd
implements \u03c2\u03bd\u039b\u03c9\u03a0\u03b8\u03c1\u03c0\u03c5\u03a3\u03bc\u03ba\u0393\u03a9\u03bf<SpawnType> {
    private static int a = Integer.reverse(0);
    public static final \u03b2\u03c2\u03c0\u03c4\u03c7\u03b6\u03ba\u03b7\u03c0\u03b2\u03bd a;
    private static long g;
    private static int b;
    private static int e;
    private static String[] b;
    private static long d;
    private static int i;
    private static int h;
    private static String[] a;
    private static long c;
    private static long f;

    @Override
    public Class<?> a() {
        return SpawnType.class;
    }

    @Override
    public JSONObject a(@Nonnull SpawnType spawnType) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put((String)\u03b2\u03c2\u03c0\u03c4\u03c7\u03b6\u03ba\u03b7\u03c0\u03b2\u03bd.c("\u3e80", (int)(a & b), (long)d), (Object)spawnType);
        return jSONObject;
    }

    static {
        b = (-1 >>> 75 | -1 << ~75 + 1) & 0xFFFFFFFF;
        d = Long.reverse(-5830765585098694405L);
        e = 0x400000 >>> 22 | 0x400000 << -22;
        f = Long.reverse(5266103896742207739L);
        g = Long.reverse(-1873497444986126336L);
        h = Integer.reverse(0x40000000);
        i = (2 >>> 32 | 2 << ~32 + 1) & 0xFFFFFFFF;
        a = new String[h];
        b = new String[i];
        \u03b2\u03c2\u03c0\u03c4\u03c7\u03b6\u03ba\u03b7\u03c0\u03b2\u03bd.b();
        a = new \u03b2\u03c2\u03c0\u03c4\u03c7\u03b6\u03ba\u03b7\u03c0\u03b2\u03bd();
    }

    private static void b() {
        int n;
        c = -2376359311662176110L;
        long l = c ^ 0x70883307AD081FFFL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(13 + 55), 69, (byte)(29 + 54), (byte)(20 + 27), (byte)(56 + 11), (byte)(56 + 10), (byte)(10 + 57), (byte)(27 + 20), (byte)(77 + 3), (byte)(7 + 68), (byte)(17 + 50), (byte)(38 + 45), (byte)(7 + 46), 80, (byte)(25 + 72), (byte)(68 + 32), (byte)(11 + 89), (byte)(80 + 25), (byte)(59 + 51), (byte)(52 + 51)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(25 + 58)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b2\u03c2\u03c0\u03c4\u03c7\u03b6\u03ba\u03b7\u03c0\u03b2\u03bd.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u00c9\u00cd\u00be\u00ed\u00f1\u00dc\u00d5\u00e5\u00bd\u00fa\u00fe\u00cd", (byte)3, 65);
                    \u03b2\u03c2\u03c0\u03c4\u03c7\u03b6\u03ba\u03b7\u03c0\u03b2\u03bd.b[1] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u0402\u0406\u03f7\u0426\u042a\u0415\u040e\u041e\u03f6\u0433\u0437\u0406", (byte)3, 68);
                    continue block7;
                }
                case 1: {
                    \u03b2\u03c2\u03c0\u03c4\u03c7\u03b6\u03ba\u03b7\u03c0\u03b2\u03bd.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u04f2\u0504\u052c\u0536\u04f8\u0519\u04fd\u051c\u0513\u04f3\u053f\u0524\u052e\u0535\u0541\u0545\u051b\u0528\u0546\u0503\u0527\u0515\u0512\u0513", (byte)3, 69);
                    \u03b2\u03c2\u03c0\u03c4\u03c7\u03b6\u03ba\u03b7\u03c0\u03b2\u03bd.b[1] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u040f\u0427\u0405\u0419\u03f3\u0412\u0411\u042f\u0429\u040f\u0419\u0406", (byte)3, 67);
                    continue block7;
                }
                case 2: {
                    \u03b2\u03c2\u03c0\u03c4\u03c7\u03b6\u03ba\u03b7\u03c0\u03b2\u03bd.b[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.C("\u0417\u040d\u03f4\u0436\u0434\u0431\u0409\u03f6\u042e\u041e\u0436\u03fd\u0413\u0443\u0401\u0440\u0440\u0435\u0435\u0424\u0422\u0414\u0411\u0412", (byte)3, 67);
                    continue block7;
                }
                case 4: {
                    \u03b2\u03c2\u03c0\u03c4\u03c7\u03b6\u03ba\u03b7\u03c0\u03b2\u03bd.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u00cd\u00f0\u00f1\u00f1\u00d6\u00ec\u00f5\u00d7\u00fb\u00d6\u00c6\u00e9\u00ca\u00d5\u0104\u00db\u00fd\u00db\u00eb\u010d\u00e1\u00eb\u00d8\u00d9", (byte)3, 66);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x67L;
        l ^= 0x70883307AD081FFFL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(3 + 66), (byte)(44 + 39), (byte)(10 + 37), (byte)(55 + 12), (byte)(43 + 23), (byte)(13 + 54), (byte)(41 + 6), (byte)(58 + 22), (byte)(28 + 47), (byte)(42 + 25), (byte)(68 + 15), 53, (byte)(13 + 67), (byte)(81 + 16), (byte)(42 + 58), (byte)(29 + 71), (byte)(3 + 102), (byte)(55 + 55), (byte)(24 + 79)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(7 + 62), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.A("\u0138\u0145\u0144\u0107\u0147\u0143\u013e\u0147\u0152\u0141\u010e\u014c\u0150\u0149\u014c\u0152\u0114\u0498\u04a9\u04a8\u04ad\u04b1\u04a1\u04a6\u04a4\u04ae\u04a1\u04ad", (byte)43, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b2\u03c2\u03c0\u03c4\u03c7\u03b6\u03ba\u03b7\u03c0\u03b2\u03bd.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public SpawnType a(@Nonnull JSONObject jSONObject) {
        return (SpawnType)jSONObject.getEnum(SpawnType.class, (String)\u03b2\u03c2\u03c0\u03c4\u03c7\u03b6\u03ba\u03b7\u03c0\u03b2\u03bd.c("\u3e80", (int)e, (long)(f ^ g)));
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b2\u03c2\u03c0\u03c4\u03c7\u03b6\u03ba\u03b7\u03c0\u03b2\u03bd.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u04c7\u04e9\u04eb\u04cb\u04ef\u050e\u0506\u051c\u0508\u04d7\u0515\u050b\u0519\u0513\u04dc\u0501\u0523\u0522\u051a\u0520\u051a\u04ef", (byte)78, 68), \u03b2\u03c2\u03c0\u03c4\u03c7\u03b6\u03ba\u03b7\u03c0\u03b2\u03bd.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.E("\u056d\u057a\u0579\u053c\u057c\u0578\u0573\u057c\u0587\u0576\u0543\u0581\u0585\u057e\u0581\u0587\u0549\u08cd\u08de\u08dd\u08e2\u08e6\u08d6\u08db\u08d9\u08e3\u08d6\u08e2\u0560", (byte)78, 69) + string + \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.E("\u0544", (byte)78, 69) + methodType.toString(), exception);
        }
    }
}

