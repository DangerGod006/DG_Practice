/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.snakeyaml.LoaderOptions
 *  com.nickuc.login.lib.snakeyaml.Yaml
 *  com.nickuc.login.lib.snakeyaml.constructor.BaseConstructor
 *  com.nickuc.login.lib.snakeyaml.constructor.Constructor
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.lib.snakeyaml.LoaderOptions;
import com.nickuc.login.lib.snakeyaml.Yaml;
import com.nickuc.login.lib.snakeyaml.constructor.BaseConstructor;
import com.nickuc.login.lib.snakeyaml.constructor.Constructor;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.io.File;
import java.io.InputStream;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Collections;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5 {
    private static int au;
    private static long g;
    private static int at;
    private static int i;
    private static long ar;
    private static long j;
    private static String[] a;
    private static int y;
    private static long ad;
    private static String[] b;
    private static int ae;
    private static int v;
    private static int ao;
    private static long m;
    private static int f;
    private static int u;
    private static int n;
    private static int ah;
    private static int d;
    private static long p;
    private static int as;
    private static int ap;
    private static int ab;
    private static long x;
    private static int ai;
    private static int o;
    private static long aa;
    private static int r;
    private static long ac;
    private static final long s = 2592000000L;
    private static int e;
    private static int am;
    private static long al;
    private static int a;
    private static int c;
    private static long q;
    private static int k;
    private static long c;
    private static int ak;
    private static final Yaml a;
    private static long ag;
    private static int z;
    private static long aj;
    private static long an;
    private static int h;
    private static long l;
    private static int b;
    private static long t;
    private static int w;
    private static long aq;
    private static long af;

    public static void c(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?> \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, File file) {
        \u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4 \u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b42 = \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42.b().a();
        Object object = \u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b42 == \u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.c ? \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.c("\u3e80", (int)o, (long)(p ^ q)) : \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.c("\u3e83", (int)r, (long)t);
        String string = \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42.a().f().getName();
        try {
            File[] fileArray = file.listFiles();
            if (fileArray == null) {
                return;
            }
            File[] fileArray2 = fileArray;
            int n = fileArray2.length;
            for (int i = u; i < n; ++i) {
                String string2;
                File file2 = fileArray2[i];
                if (file2.isDirectory() || string.equals(string2 = file2.getName()) || !string2.endsWith((String)\u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.c("\u3e86", (int)(v & w), (long)x))) continue;
                try {
                    Map<String, Object> map = \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.a(file2, (String)object);
                    if (map == null) continue;
                    String string3 = (String)map.get(\u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.c("\u3e89", (int)(y & z), (long)aa));
                    if (!\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42.q().equals(string3) || file2.delete()) continue;
                    if (\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.as()) {
                        \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.d((String)\u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.c("\u3e8c", (int)ab, (long)(ac ^ ad)) + string2 + (String)\u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.c("\u3e8f", (int)ae, (long)(af ^ ag)), new Object[ah]);
                    }
                    file2.deleteOnExit();
                    continue;
                }
                catch (Throwable throwable) {
                    if (!\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.as()) continue;
                    \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.c("\u3e92", (int)ai, (long)aj) + throwable.getMessage() + (String)\u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.c("\u3e95", (int)ak, (long)al) + string2 + (String)\u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.c("\u3e98", (int)am, (long)an), throwable, new Object[ao]);
                }
            }
        }
        catch (Exception exception) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.a(exception);
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.d((String)\u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.c("\u3e9b", (int)ap, (long)(aq ^ ar)), new Object[as]);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x67L;
        l ^= 0xE06214C9B4A92D0FL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(34 + 34), (byte)(32 + 37), 83, (byte)(27 + 20), (byte)(37 + 30), (byte)(48 + 18), (byte)(28 + 39), (byte)(26 + 21), 80, (byte)(52 + 23), (byte)(29 + 38), (byte)(39 + 44), (byte)(7 + 46), (byte)(45 + 35), (byte)(77 + 20), (byte)(17 + 83), (byte)(5 + 95), (byte)(6 + 99), (byte)(17 + 93), (byte)(66 + 37)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(20 + 49), (byte)(60 + 23)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u0541\u054e\u054d\u0510\u0550\u054c\u0547\u0550\u055b\u054a\u0517\u0555\u0559\u0552\u0555\u055b\u051d\u08a9\u0899\u0899\u0892\u089b\u08ad\u08be\u08b3\u08ac", (byte)99, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = (0 >>> 108 | 0 << ~108 + 1) & 0xFFFFFFFF;
        b = Integer.reverse(0);
        c = (0 >>> 189 | 0 << ~189 + 1) & 0xFFFFFFFF;
        d = Integer.reverse(0);
        e = (0 >>> 188 | 0 << ~188 + 1) & 0xFFFFFFFF;
        f = (0 >>> 61 | 0 << -61) & 0xFFFFFFFF;
        g = Long.reverse(5486945274691584L);
        h = Integer.reverse(0);
        i = Integer.reverse(-1);
        j = Long.reverse(1150280430015173127L);
        k = (16384 >>> 238 | 16384 << ~238 + 1) & 0xFFFFFFFF;
        l = Long.reverse(-1587908143426088441L);
        m = Long.reverse(-1873497444986126336L);
        n = Integer.reverse(0);
        o = Integer.reverse(0x40000000);
        p = Long.reverse(-1587908143426088441L);
        q = Long.reverse(-1873497444986126336L);
        r = 12 >>> 2 | 12 << -2;
        t = Long.reverse(1150280430015173127L);
        u = Integer.reverse(0);
        v = Integer.reverse(0x20000000);
        w = Integer.reverse(-1);
        x = Long.reverse(1150280430015173127L);
        y = Integer.reverse(-1610612736);
        z = Integer.reverse(-1);
        aa = Long.reverse(1150280430015173127L);
        ab = Integer.reverse(0x60000000);
        ac = Long.reverse(-1587908143426088441L);
        ad = Long.reverse(-1873497444986126336L);
        ae = (0x1C0000 >>> 114 | 0x1C0000 << -114) & 0xFFFFFFFF;
        af = Long.reverse(-1587908143426088441L);
        ag = Long.reverse(-1873497444986126336L);
        ah = 0 >>> 163 | 0 << -163;
        ai = Integer.reverse(0x10000000);
        aj = Long.reverse(1150280430015173127L);
        ak = 9216 >>> 138 | 9216 << ~138 + 1;
        al = Long.reverse(1150280430015173127L);
        am = 0x40000001 >>> 125 | 0x40000001 << ~125 + 1;
        an = Long.reverse(1150280430015173127L);
        ao = Integer.reverse(0);
        ap = Integer.reverse(-805306368);
        aq = Long.reverse(-1587908143426088441L);
        ar = Long.reverse(-1873497444986126336L);
        as = Integer.reverse(0);
        at = Integer.reverse(0x30000000);
        au = (3 >>> 30 | 3 << ~30 + 1) & 0xFFFFFFFF;
        a = new String[at];
        b = new String[au];
        \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b();
        a = new Yaml((BaseConstructor)new Constructor(new LoaderOptions()));
    }

    public static void b(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?> \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, File file) {
        if (file.isDirectory()) {
            \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.a(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, file);
            return;
        }
        if (!\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.a(file, g)) {
            return;
        }
        if (\u03bf\u03a3\u03bd\u03b4\u03a0\u03be\u0393\u03c2\u03b7\u03bb.as()) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.b((String)\u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.c("\u3e80", (int)(h & i), (long)j) + file + (String)\u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.c("\u3e83", (int)k, (long)(l ^ m)), new Object[n]);
        }
        if (!file.delete()) {
            file.deleteOnExit();
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u054b\u056d\u056f\u054f\u0573\u0592\u058a\u05a0\u058c\u055b\u0599\u058f\u059d\u0597\u0560\u0585\u05a7\u05a6\u059e\u05a4\u059e\u0573", (byte)103, 69), \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u0586\u0593\u0592\u0555\u0595\u0591\u058c\u0595\u05a0\u058f\u055c\u059a\u059e\u0597\u059a\u05a0\u0562\u08ee\u08de\u08de\u08d7\u08e0\u08f2\u0903\u08f8\u08f1\u0577", (byte)103, 69) + string + \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.C("\u0524", (byte)103, 67) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = -2284797363719934057L;
        long l = c ^ 0xE06214C9B4A92D0FL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(38 + 30), (byte)(9 + 60), (byte)(42 + 41), (byte)(24 + 23), (byte)(65 + 2), (byte)(29 + 37), (byte)(6 + 61), (byte)(40 + 7), 80, (byte)(9 + 66), (byte)(53 + 14), (byte)(71 + 12), (byte)(50 + 3), (byte)(41 + 39), (byte)(74 + 23), (byte)(13 + 87), (byte)(46 + 54), (byte)(84 + 21), (byte)(67 + 43), 103}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(51 + 17), (byte)(46 + 23), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.B("\u01d9\u01c2\u01e9\u01b7\u01ea\u01ee\u01a6\u01bb\u01cb\u01dc\u01a8\u01bf\u01ae\u01e3\u01d3\u01e7\u01e9\u01e8\u01d1\u01fc\u01bc\u01fe\u01d1\u01fd\u01fe\u01ba\u01cb\u01e4\u01e3\u01df\u01d7\u01d1", (byte)120, 66);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[1] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u05ac\u056b\u057e\u0578\u0587\u0580\u0585\u05a7\u057f\u058a\u05b5\u057c", (byte)120, 70);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[2] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u01b9\u01c8\u01ba\u01c1\u01bd\u01c7\u01cf\u01a9\u01c1\u01c1\u01c4\u01b3\u01cc\u01b1\u01f3\u01d8\u01b0\u01b0\u01ea\u01b3\u01d8\u01eb\u01c2\u01c3", (byte)120, 65);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[3] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.B("\u01da\u01d8\u01d7\u01d9\u01d6\u01e0\u01e7\u01a5\u01de\u01b1\u01e5\u01df\u01bc\u01f4\u01c1\u01e0\u01ce\u01f3\u01cb\u01e4\u01d5\u01eb\u01c2\u01c3", (byte)120, 66);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[4] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u0576\u0578\u0582\u058a\u058e\u0573\u0575\u0566\u058f\u0556\u055f\u0565", (byte)120, 68);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[5] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u0583\u056a\u0591\u058e\u0559\u057c\u058f\u0569\u057b\u057e\u0592\u0565", (byte)120, 67);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[6] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u05ab\u0564\u059a\u0568\u05a4\u0581\u05ae\u05af\u0571\u05aa\u056f\u058b\u05a5\u058d\u05ac\u0578\u05bb\u05b0\u0598\u057e\u058d\u05bb\u05bc\u05a3\u05ad\u058e\u05a2\u05a3\u0599\u059d\u05a1\u059a\u05cc\u05c6\u05ca\u05ca\u05cc\u05c9\u05ac\u05cd\u05b6\u05b2\u05ce\u05b9\u05d5\u0591\u05da\u05ce\u0594\u05b3\u0596\u05de\u05cb\u05ac\u05e1\u05e3\u05ce\u05c5\u05c6\u05d4\u05e3\u05da\u05b6\u05a6\u05d7\u05ec\u05a8\u05cc\u05aa\u05ec\u05c4\u05c3\u05ea\u05e0\u05af\u05d9\u05b7\u05c2\u05f0\u05e5\u05b6\u05d5\u05e8\u05be\u05de\u05ca\u05f1\u0600\u0605\u05c4\u05d8\u05c0\u05c2\u05c3\u05bd\u05e2\u05e2\u0608\u060d\u05f0\u0607\u060a\u05cf\u05e7\u05df\u05d3\u05d7\u05e3\u05e7\u05d3\u05d1\u05d8\u060b\u05f1\u05f9\u060a\u05ef\u05fa\u05e7\u05e8", (byte)120, 70);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[7] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u05a8\u05a7\u0561\u058d\u05ab\u0589\u057c\u057f\u059d\u05af\u05b5\u057c", (byte)120, 69);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[8] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u0594\u054d\u0583\u0551\u058d\u056a\u0597\u0598\u055a\u0593\u0558\u0574\u058e\u0576\u0595\u0561\u05a4\u0599\u0581\u0567\u0576\u05a4\u05a5\u058c\u0596\u0577\u058b\u058c\u0582\u0586\u058a\u0583\u05b5\u05af\u05b3\u05b3\u05b5\u05b2\u0595\u05b6\u059f\u059b\u05b7\u05a2\u05be\u057a\u05c3\u05b7\u057d\u059c\u057f\u05c7\u05b4\u059e\u05c2\u05b5\u05a6\u05a7\u05a7\u0591\u05c8\u05d3\u058f\u05a8", (byte)120, 67);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[9] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.F("\u0563\u05a8\u057a\u059a\u05a7\u059d\u0594\u0587\u059f\u0580\u05b2\u05a8\u0590\u0576\u0598\u05ae\u0593\u05ba\u0599\u0588\u05b4\u0581\u058e\u0596\u05a2\u0593\u05b3\u0593\u05a9\u05a9\u05a5\u059b", (byte)120, 70);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[10] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u01e3\u01e2\u019c\u01c8\u01e6\u01c4\u01b7\u01ba\u01d8\u01ea\u01f0\u01b7", (byte)120, 65);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[11] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.D("\u0594\u054d\u0583\u0551\u058d\u056a\u0597\u0598\u055a\u0593\u0558\u0574\u058e\u0576\u0595\u0561\u05a4\u0599\u0581\u0567\u0576\u05a4\u05a5\u058c\u0596\u0577\u058b\u058c\u0582\u0586\u058a\u0583\u05b5\u05af\u05b3\u05b3\u05b5\u05b2\u0595\u05b6\u059f\u059b\u05b7\u05a2\u05be\u057a\u05c3\u05b7\u057d\u059c\u057f\u05c7\u05b4\u0593\u05b4\u058a\u05bc\u05ca\u05cd\u05c8\u05ac\u059c\u05cb\u058f", (byte)120, 68);
                    continue block7;
                }
                case 1: {
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u0587\u0570\u0597\u0565\u0598\u059c\u0554\u0569\u0579\u058a\u0556\u056d\u055c\u0591\u0581\u0595\u0597\u0596\u057f\u05aa\u056a\u0568\u055e\u05a4\u059d\u058a\u057b\u0591\u0583\u0585\u0583\u058f\u059e\u058b\u0594\u058b\u0587\u05af\u0584\u05ba\u05ad\u05bc\u05aa\u0585", (byte)120, 68);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[1] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u0579\u058f\u0582\u058b\u0584\u05b2\u0589\u05a1\u0581\u0596\u058f\u057c", (byte)120, 70);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[2] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u0567\u0576\u0568\u056f\u056b\u0575\u057d\u0557\u056f\u056f\u0571\u055c\u055f\u0562\u055f\u0576\u0581\u0576\u059c\u0577\u058b\u0573\u0570\u0571", (byte)120, 67);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[3] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u01da\u01d8\u01d7\u01d9\u01d6\u01e0\u01e7\u01a5\u01de\u01b1\u01e4\u01ee\u01f2\u01ec\u01b2\u01ad\u01f4\u01eb\u01b3\u01b8\u01b9\u01d5\u01c2\u01c3", (byte)120, 65);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[4] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.A("\u01dd\u01df\u01e9\u01ab\u01a9\u01e4\u01d9\u01ea\u01be\u01e7\u01e1\u01aa\u01e5\u01e9\u01b0\u01c6\u01ea\u01ce\u01f0\u01d7\u01d7\u01eb\u01c2\u01c3", (byte)120, 65);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[5] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.D("\u0592\u0577\u056d\u058b\u0591\u0553\u0596\u058e\u0588\u0587\u057d\u059f\u058e\u058f\u0560\u0584\u05a7\u0580\u057b\u0597\u059c\u05a9\u0570\u0571", (byte)120, 68);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[6] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u01e6\u019f\u01d5\u01a3\u01df\u01bc\u01e9\u01ea\u01ac\u01e5\u01aa\u01c6\u01e0\u01c8\u01e7\u01b3\u01f6\u01eb\u01d3\u01b9\u01c8\u01f6\u01f7\u01de\u01e8\u01c9\u01dd\u01de\u01d4\u01d8\u01dc\u01d5\u0207\u0201\u0205\u0205\u0207\u0204\u01e7\u0208\u01f1\u01ed\u0209\u01f4\u0210\u01cc\u0215\u0209\u01cf\u01ee\u01d1\u0219\u0206\u01e7\u021c\u021e\u0209\u0200\u0201\u020f\u021e\u0215\u01f1\u01e1\u0212\u0227\u01e3\u0207\u01e5\u0227\u01ff\u01fe\u0225\u021b\u01ea\u0214\u01f2\u01fd\u022b\u0220\u01f1\u0210\u0223\u01f9\u0219\u0205\u022c\u023b\u0240\u01ff\u0213\u01fb\u01fd\u01fe\u01f8\u021d\u021d\u0243\u0248\u022b\u0242\u0245\u020a\u0222\u021a\u020e\u0211\u0212\u0227\u0223\u0215\u024b\u0257\u0236\u0257\u0259\u025d\u0225\u0222\u0223", (byte)120, 66);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[7] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.A("\u01be\u01da\u01be\u01c4\u01d5\u01ea\u01ab\u01c1\u01ad\u01e6\u01dc\u01b7", (byte)120, 65);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[8] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.D("\u0594\u054d\u0583\u0551\u058d\u056a\u0597\u0598\u055a\u0593\u0558\u0574\u058e\u0576\u0595\u0561\u05a4\u0599\u0581\u0567\u0576\u05a4\u05a5\u058c\u0596\u0577\u058b\u058c\u0582\u0586\u058a\u0583\u05b5\u05af\u05b3\u05b3\u05b5\u05b2\u0595\u05b6\u059f\u059b\u05b7\u05a2\u05be\u057a\u05c3\u05b7\u057d\u059c\u057f\u05c7\u05b4\u0597\u057e\u0596\u05aa\u05cc\u05ba\u05c8\u0589\u059b\u05b0\u05b0", (byte)120, 68);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[9] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u054c\u0591\u0563\u0583\u0590\u0586\u057d\u0570\u0588\u0569\u059b\u0591\u0579\u055f\u0581\u0597\u057c\u05a3\u0582\u0571\u059d\u056a\u057d\u05a0\u056a\u056e\u059d\u05a9\u0592\u0572\u059c\u05aa", (byte)120, 68);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[10] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0567\u05af\u0583\u0590\u0563\u0569\u05a7\u05a9\u059f\u05ac\u057f\u057c", (byte)120, 69);
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[11] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u05ab\u0564\u059a\u0568\u05a4\u0581\u05ae\u05af\u0571\u05aa\u056f\u058b\u05a5\u058d\u05ac\u0578\u05bb\u05b0\u0598\u057e\u058d\u05bb\u05bc\u05a3\u05ad\u058e\u05a2\u05a3\u0599\u059d\u05a1\u059a\u05cc\u05c6\u05ca\u05ca\u05cc\u05c9\u05ac\u05cd\u05b6\u05b2\u05ce\u05b9\u05d5\u0591\u05da\u05ce\u0594\u05b3\u0596\u05de\u05cb\u05b0\u05b5\u05b4\u05dc\u05a1\u05a0\u05c0\u05bb\u05da\u05cc\u05bf", (byte)120, 70);
                    continue block7;
                }
                case 2: {
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u01bf\u01d2\u01a1\u01dd\u01d7\u01c8\u01bd\u01e2\u01a2\u01e8\u01d3\u01b0\u01be\u01c8\u01e9\u01c1\u01ca\u01f9\u01f0\u01e7\u01f0\u01fe\u01ec\u01ef\u01e0\u01f2\u01f5\u01d3\u01be\u01f8\u01da\u01f0", (byte)120, 66);
                    continue block7;
                }
                case 4: {
                    \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u05ad\u059a\u059a\u0578\u0599\u0564\u0569\u05a0\u05aa\u058d\u057f\u0583\u05a5\u0577\u05b4\u0575\u05b2\u058a\u059a\u05a0\u0577\u05b0\u0587\u0588", (byte)120, 70);
                }
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Nullable
    public static Map<String, Object> a(File file, String string) {
        block9: {
            if (string != null) {
                JarFile jarFile = new JarFile(file);
                try {
                    Map map;
                    block10: {
                        JarEntry jarEntry = jarFile.getJarEntry(string);
                        if (jarEntry == null) break block9;
                        InputStream inputStream = jarFile.getInputStream(jarEntry);
                        try {
                            map = (Map)a.load(inputStream);
                            if (Collections.singletonList(inputStream).get(a) == null) break block10;
                        }
                        catch (Throwable throwable) {
                            if (Collections.singletonList(inputStream).get(c) != null) {
                                inputStream.close();
                            }
                            throw throwable;
                        }
                        inputStream.close();
                    }
                    return map;
                }
                finally {
                    if (Collections.singletonList(jarFile).get(b) != null) {
                        jarFile.close();
                    }
                }
            }
        }
        return null;
    }

    private static void a(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?> \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, File file) {
        File[] fileArray = file.listFiles();
        if (fileArray == null) {
            return;
        }
        File[] fileArray2 = fileArray;
        int n = fileArray2.length;
        for (int i = f; i < n; ++i) {
            File file2 = fileArray2[i];
            \u03ba\u03a9\u03a8\u03a0\u03a8\u03b9\u03c9\u03bd\u03b5.b(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42, file2);
        }
    }
}

