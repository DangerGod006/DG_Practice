/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03c4\u03a9\u03c7\u03b9\u03b2\u03bf\u03a0\u03c3\u03a9\u03c2\u03bf;
import com.nickuc.login.\u03c8\u03bd\u03c1\u03c9\u03ba\u03bb\u03b1\u0393\u03c2\u03c3\u03bb\u03b6\u03c2\u03a3;

public interface \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba
extends \u03c8\u03bd\u03c1\u03c9\u03ba\u03bb\u03b1\u0393\u03c2\u03c3\u03bb\u03b6\u03c2\u03a3 {
    public boolean i(String var1);

    public String getName();

    public void k(String var1);

    default public void g(String string, Object ... objectArray) {
        this.k(String.format(string, objectArray));
    }

    default public \u03c4\u03a9\u03c7\u03b9\u03b2\u03bf\u03a0\u03c3\u03a9\u03c2\u03bf a() {
        return this instanceof \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 ? \u03c4\u03a9\u03c7\u03b9\u03b2\u03bf\u03a0\u03c3\u03a9\u03c2\u03bf.a : \u03c4\u03a9\u03c7\u03b9\u03b2\u03bf\u03a0\u03c3\u03a9\u03c2\u03bf.b;
    }
}

