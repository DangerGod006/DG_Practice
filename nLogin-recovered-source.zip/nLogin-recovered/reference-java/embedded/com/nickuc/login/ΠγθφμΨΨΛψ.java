/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03b3\u03c4\u0393\u03be\u03b2\u03bc\u03a0\u03a3\u03c5\u03c7;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03bb\u03b9\u03bc\u03c1\u03b9\u03b3\u03b4\u03b2\u03c8;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8
implements \u03bb\u03b9\u03bc\u03c1\u03b9\u03b3\u03b4\u03b2\u03c8 {
    private static int n;
    private static int l;
    private static int p;
    private static long q;
    private static long d;
    private static int s;
    private static int a;
    private static int i;
    private static long f;
    private static int m;
    private static int r;
    private static int o;
    private static int h;
    private static long j;
    private static int v;
    private static int e;
    private static long g;
    private static long c;
    private static String[] a;
    private static int t;
    private static long b;
    private static String[] b;
    private static int u;
    private static long k;

    private String A(String string) {
        return ((\u03b7\u03a9\u03c1\u03b5\u03c8\u03c9\u039b\u0394\u03ba\u03b9\u03bb)\u03b3\u03c4\u0393\u03be\u03b2\u03bc\u03a0\u03a3\u03c5\u03c7.i.a()).E(string);
    }

    private static void b() {
        int n;
        c = -8138687460906093698L;
        long l = c ^ 0x5C98F82112011B80L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(19 + 49), (byte)(45 + 24), (byte)(47 + 36), (byte)(25 + 22), (byte)(26 + 41), 66, (byte)(58 + 9), (byte)(19 + 28), (byte)(30 + 50), (byte)(59 + 16), 67, (byte)(61 + 22), (byte)(25 + 28), (byte)(69 + 11), (byte)(50 + 47), (byte)(28 + 72), (byte)(77 + 23), (byte)(18 + 87), (byte)(37 + 73), (byte)(22 + 81)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(13 + 55), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u0154\u016a\u013d\u014d\u012e\u0148\u0145\u0140\u013e\u0169\u012b\u0139", (byte)57, 66);
                    \u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.b[1] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0558\u056e\u0541\u0551\u0532\u054c\u0549\u0544\u0542\u056d\u052f\u053d", (byte)57, 70);
                    \u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.b[2] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u04a1\u04a6\u04c5\u04d9\u0494\u04af\u04ca\u04cb\u04df\u04ad\u04bb\u04a8", (byte)57, 68);
                    \u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.b[3] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u04d8\u04bb\u04cd\u04d2\u04a7\u04b5\u04aa\u049a\u04a1\u0498\u04cd\u04a8", (byte)57, 68);
                    continue block7;
                }
                case 1: {
                    \u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u0142\u0143\u0127\u0140\u016e\u012d\u0168\u0171\u012d\u016a\u0148\u0139", (byte)57, 65);
                    \u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.b[1] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u04d6\u04b1\u04d2\u0496\u04d4\u04d4\u04ab\u04b5\u04d5\u04dc\u04cd\u04a8", (byte)57, 68);
                    \u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.b[2] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.A("\u0125\u0166\u0137\u0155\u013d\u013d\u015f\u0160\u014e\u0133\u012f\u0139", (byte)57, 65);
                    \u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.b[3] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u056c\u054a\u0558\u0547\u054f\u0551\u0566\u0546\u055e\u054b\u056a\u053d", (byte)57, 70);
                    continue block7;
                }
                case 2: {
                    \u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.F("\u0557\u0537\u0522\u0559\u0564\u0564\u0534\u054a\u0557\u0549\u0533\u0573\u0534\u0559\u054d\u056d\u057c\u053e\u0539\u055f\u0542\u0571\u0548\u0549", (byte)57, 70);
                    continue block7;
                }
                case 4: {
                    \u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.A("\u0156\u014b\u0125\u012a\u0145\u013e\u0147\u016b\u0149\u012c\u012c\u0165\u014a\u014d\u0140\u0157\u0154\u0165\u015d\u015e\u0151\u0147\u0144\u0145", (byte)57, 65);
                }
            }
        }
    }

    @Override
    public boolean i(String string, String string2) {
        String[] stringArray;
        if (string2.contains((CharSequence)\u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.c("\u3e80", (int)a, (long)(b ^ d)))) {
            string2 = string2.split((String)\u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.c("\u3e83", (int)e, (long)(f ^ g)))[h];
        }
        if ((stringArray = string2.split((String)\u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.c("\u3e86", (int)i, (long)(j ^ k)))).length != l) {
            return m != 0;
        }
        if (!stringArray[n].equalsIgnoreCase((String)\u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.c("\u3e89", (int)(o & p), (long)q))) {
            return r != 0;
        }
        String string3 = stringArray[s];
        String string4 = stringArray[t];
        return string4.equals(this.A(this.A(string) + string3));
    }

    static {
        a = 0 >>> 219 | 0 << ~219 + 1;
        b = Long.reverse(9136716639172669681L);
        d = Long.reverse(0x5000000000000000L);
        e = 4 >>> 34 | 4 << -34;
        f = Long.reverse(9136716639172669681L);
        g = Long.reverse(0x5000000000000000L);
        h = Integer.reverse(0);
        i = (0x8000000 >>> 26 | 0x8000000 << ~26 + 1) & 0xFFFFFFFF;
        j = Long.reverse(9136716639172669681L);
        k = Long.reverse(0x5000000000000000L);
        l = 0x400000 >>> 180 | 0x400000 << ~180 + 1;
        m = (0 >>> 110 | 0 << ~110 + 1) & 0xFFFFFFFF;
        n = 32768 >>> 175 | 32768 << -175;
        o = 1536 >>> 9 | 1536 << -9;
        p = -1 >>> 11 | -1 << -11;
        q = Long.reverse(3372109116138434801L);
        r = 0 >>> 99 | 0 << -99;
        s = Integer.MIN_VALUE >>> 62 | Integer.MIN_VALUE << -62;
        t = 192 >>> 230 | 192 << -230;
        u = Integer.reverse(0x20000000);
        v = Integer.reverse(0x20000000);
        a = new String[u];
        b = new String[v];
        \u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.b();
    }

    private static String a(int n, long l) {
        l ^= 0xAL;
        l ^= 0x5C98F82112011B80L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(58 + 10), (byte)(17 + 52), (byte)(47 + 36), (byte)(28 + 19), (byte)(37 + 30), (byte)(18 + 48), 67, (byte)(27 + 20), (byte)(59 + 21), 75, (byte)(33 + 34), (byte)(14 + 69), (byte)(2 + 51), (byte)(69 + 11), (byte)(86 + 11), (byte)(40 + 60), (byte)(42 + 58), (byte)(27 + 78), (byte)(56 + 54), (byte)(58 + 45)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(45 + 38)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.D("\u048d\u049a\u0499\u045c\u049c\u0498\u0493\u049c\u04a7\u0496\u0463\u04a1\u04a5\u049e\u04a1\u04a7\u0469\u07db\u07ef\u07f5\u0804\u07fb\u07e8\u07e9\u07dd\u080b", (byte)39, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u0127\u0149\u014b\u012b\u014f\u016e\u0166\u017c\u0168\u0137\u0175\u016b\u0179\u0173\u013c\u0161\u0183\u0182\u017a\u0180\u017a\u014f", (byte)64, 65), \u03a0\u03b3\u03b8\u03c6\u03bc\u03a8\u03a8\u039b\u03c8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u055f\u056c\u056b\u052e\u056e\u056a\u0565\u056e\u0579\u0568\u0535\u0573\u0577\u0570\u0573\u0579\u053b\u08ad\u08c1\u08c7\u08d6\u08cd\u08ba\u08bb\u08af\u08dd\u0550", (byte)64, 70) + string + \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u04af", (byte)64, 68) + methodType.toString(), exception);
        }
    }
}

