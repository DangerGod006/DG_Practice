/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03b8\u03bc\u03a9\u03b8\u03bf\u03bf\u03be\u03c1\u03bc;
import lombok.Generated;

class \u03b5\u03b3\u03c8\u0393\u0393\u03b2\u0394\u03c1\u03bf {
    private final boolean D;
    private final boolean C;
    private final long m;

    @Generated
    private \u03b5\u03b3\u03c8\u0393\u0393\u03b2\u0394\u03c1\u03bf(long l, boolean bl, boolean bl2) {
        this.m = l;
        this.C = bl;
        this.D = bl2;
    }

    static /* synthetic */ boolean b(\u03b5\u03b3\u03c8\u0393\u0393\u03b2\u0394\u03c1\u03bf \u03b5\u03b3\u03c8\u0393\u0393\u03b2\u0394\u03c1\u03bf2) {
        return \u03b5\u03b3\u03c8\u0393\u0393\u03b2\u0394\u03c1\u03bf2.C;
    }

    static /* synthetic */ boolean a(\u03b5\u03b3\u03c8\u0393\u0393\u03b2\u0394\u03c1\u03bf \u03b5\u03b3\u03c8\u0393\u0393\u03b2\u0394\u03c1\u03bf2) {
        return \u03b5\u03b3\u03c8\u0393\u0393\u03b2\u0394\u03c1\u03bf2.D;
    }

    static /* synthetic */ long a(\u03b5\u03b3\u03c8\u0393\u0393\u03b2\u0394\u03c1\u03bf \u03b5\u03b3\u03c8\u0393\u0393\u03b2\u0394\u03c1\u03bf2) {
        return \u03b5\u03b3\u03c8\u0393\u0393\u03b2\u0394\u03c1\u03bf2.m;
    }

    /* synthetic */ \u03b5\u03b3\u03c8\u0393\u0393\u03b2\u0394\u03c1\u03bf(long l, boolean bl, boolean bl2, \u03b8\u03bc\u03a9\u03b8\u03bf\u03bf\u03be\u03c1\u03bc \u03b8\u03bc\u03a9\u03b8\u03bf\u03bf\u03be\u03c1\u03bc2) {
        this(l, bl, bl2);
    }
}

