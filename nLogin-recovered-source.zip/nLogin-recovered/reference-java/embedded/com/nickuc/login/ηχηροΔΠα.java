/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;

class \u03b7\u03c7\u03b7\u03c1\u03bf\u0394\u03a0\u03b1 {
    private static int b;
    static final /* synthetic */ int[] x;
    private static int a;

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = 2 >>> 96 | 2 << ~96 + 1;
        x = new int[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.values().length];
        try {
            \u03b7\u03c7\u03b7\u03c1\u03bf\u0394\u03a0\u03b1.x[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.m.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b7\u03c7\u03b7\u03c1\u03bf\u0394\u03a0\u03b1.x[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.n.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

