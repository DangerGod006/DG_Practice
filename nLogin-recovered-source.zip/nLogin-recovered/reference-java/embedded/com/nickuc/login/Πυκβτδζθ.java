/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  lombok.Generated
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.TextComponent
 *  net.kyori.adventure.text.event.ClickEvent
 *  net.kyori.adventure.text.event.HoverEvent
 *  net.kyori.adventure.text.event.HoverEventSource
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b3\u03be\u03c4\u03a9\u039b\u03c7\u03a3\u0393\u03c0\u03bc\u03a0\u03c3\u0393\u03b3\u03c6;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5;
import com.nickuc.login.\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.event.HoverEventSource;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8
implements \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5 {
    private static int t;
    private static String[] a;
    private static final TextComponent a;
    private static int a;
    private final \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 a;
    private static long p;
    private static int q;
    private static int c;
    private static int w;
    private static int v;
    private static int o;
    private static long c;
    private static long k;
    private static long n;
    private static int u;
    private static int r;
    private static String[] b;
    private static int e;
    private static int i;
    private final \u03b3\u03be\u03c4\u03a9\u039b\u03c7\u03a3\u0393\u03c0\u03bc\u03a0\u03c3\u0393\u03b3\u03c6 a;
    private static int g;
    private static int l;
    private static int m;
    private static int s;
    private final \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 b;
    private static int f;
    private static long j;
    private static long h;
    private static int b;
    private static long x;
    private static int d;

    @Override
    public void c(String string, String string2) {
        this.d(string, null, string2);
    }

    static {
        a = (0x2000000 >>> 121 | 0x2000000 << -121) & 0xFFFFFFFF;
        b = (0 >>> 218 | 0 << -218) & 0xFFFFFFFF;
        c = Integer.reverse(0);
        d = 24641536 >>> 147 | 24641536 << ~147 + 1;
        e = Integer.reverse(-201326592);
        f = Integer.reverse(0x40000000);
        g = (0 >>> 68 | 0 << ~68 + 1) & 0xFFFFFFFF;
        h = Long.reverse(3852004812222675694L);
        i = Integer.reverse(Integer.MIN_VALUE);
        j = Long.reverse(8319575642574207726L);
        k = Long.reverse(0x4600000000000000L);
        l = Integer.reverse(0x40000000);
        m = Integer.reverse(-1);
        n = Long.reverse(3852004812222675694L);
        o = (768 >>> 104 | 768 << -104) & 0xFFFFFFFF;
        p = Long.reverse(3852004812222675694L);
        q = 0 >>> 159 | 0 << -159;
        r = Integer.reverse(0);
        s = (0 >>> 156 | 0 << ~156 + 1) & 0xFFFFFFFF;
        t = (10 >>> 97 | 10 << -97) & 0xFFFFFFFF;
        u = 80 >>> 68 | 80 << ~68 + 1;
        v = Integer.reverse(0x20000000);
        w = Integer.reverse(-1);
        x = Long.reverse(3852004812222675694L);
        a = new String[t];
        b = new String[u];
        \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.b();
        a = Component.text((String)\u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.c("\u3e80", (int)(v & w), (long)x));
    }

    @Override
    public \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 a() {
        return this.b;
    }

    @Generated
    \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03b3\u03be\u03c4\u03a9\u039b\u03c7\u03a3\u0393\u03c0\u03bc\u03a0\u03c3\u0393\u03b3\u03c6 \u03b3\u03be\u03c4\u03a9\u039b\u03c7\u03a3\u0393\u03c0\u03bc\u03a0\u03c3\u0393\u03b3\u03c62) {
        this.b = \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
        this.a = \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42;
        this.a = \u03b3\u03be\u03c4\u03a9\u039b\u03c7\u03a3\u0393\u03c0\u03bc\u03a0\u03c3\u0393\u03b3\u03c62;
    }

    @Override
    public void a(String string, @Nullable String string2, @Nullable String string3, @Nullable String string4, @Nullable String string5) {
        TextComponent textComponent = this.a(string, a != 0);
        if (string2 != null) {
            textComponent = textComponent.hoverEvent((HoverEventSource)HoverEvent.showText((Component)this.a(string2, b != 0)));
        }
        if (string3 != null) {
            textComponent = textComponent.clickEvent(ClickEvent.suggestCommand((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.m(string3)));
        } else if (string4 != null) {
            if (!(string4 = \u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.m(string4)).isEmpty()) {
                char c = string4.charAt(\u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.c);
                if (c != d) {
                    string4 = (char)e + string4;
                }
                textComponent = textComponent.clickEvent(ClickEvent.runCommand((String)string4));
            }
        } else if (string5 != null) {
            textComponent = textComponent.clickEvent(ClickEvent.openUrl((String)\u03c2\u03b2\u03b9\u03ba\u03b4\u03c0\u03c6\u03b4\u03a3\u03ba.m(string5)));
        }
        this.a.a(this.b, (Component)textComponent);
    }

    @Override
    public void a(int n, \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6[] \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6Array) {
        if (\u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6Array.length == 0) {
            return;
        }
        if (\u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6Array.length > f) {
            throw new IllegalArgumentException((String)\u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.c("\u3e80", (int)g, (long)h) + \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6Array.length);
        }
        TextComponent textComponent = Component.text((String)\u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.c("\u3e83", (int)i, (long)(j ^ k)));
        String string = (String)\u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.c("\u3e86", (int)(l & m), (long)\u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.n) + n + (String)\u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.c("\u3e89", (int)o, (long)p);
        for (int i = q; i < \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6Array.length; ++i) {
            if (i > 0) {
                textComponent = (TextComponent)((TextComponent)((TextComponent)textComponent.append((Component)a)).append((Component)a)).append((Component)a);
            }
            \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6 \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a62 = \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6Array[i];
            \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2 \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b22 = \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a62.a();
            Component component = this.a(\u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b22.ar(), r != 0).clickEvent(ClickEvent.runCommand((String)(string + \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a62.a().v())));
            String string2 = \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b22.as();
            if (string2 != null) {
                component = component.hoverEvent((HoverEventSource)HoverEvent.showText((Component)this.a(string2, s != 0)));
            }
            textComponent = (TextComponent)textComponent.append(component);
        }
        try {
            textComponent = (TextComponent)textComponent.appendNewline();
        }
        catch (NoSuchMethodError noSuchMethodError) {
            textComponent = (TextComponent)textComponent.append((Component)Component.newline());
        }
        this.a.a(this.b, (Component)textComponent);
    }

    private static void b() {
        int n;
        c = 8601036996284559054L;
        long l = c ^ 0x375D8D0E292FF9DFL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(59 + 9), (byte)(26 + 43), (byte)(76 + 7), (byte)(11 + 36), 67, (byte)(53 + 13), (byte)(47 + 20), (byte)(2 + 45), (byte)(78 + 2), (byte)(43 + 32), (byte)(63 + 4), (byte)(65 + 18), (byte)(39 + 14), (byte)(52 + 28), (byte)(56 + 41), (byte)(86 + 14), 100, (byte)(97 + 8), (byte)(77 + 33), (byte)(23 + 80)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(61 + 8), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u0493\u04b6\u04d7\u04cf\u04a3\u0497\u04d0\u04d6\u04ae\u0498\u04bc\u04ab\u04db\u04c4\u049f\u04cf\u04a0\u04ba\u04de\u04a1\u04dd\u04c5\u04bc\u04ee\u04c2\u04dc\u04cf\u04e8\u04f1\u04ca\u04e6\u04f4", (byte)56, 67);
                    \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.b[1] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.B("\u013d\u015d\u011c\u0121\u013d\u013e\u0140\u013c\u0138\u013d\u0129\u0137", (byte)56, 66);
                    \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.b[2] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u04c9\u048e\u04c9\u04c3\u04ab\u04cd\u04d2\u04a6\u04dc\u04d3\u04ba\u04db\u04de\u04d7\u04da\u04b2\u04d5\u04bc\u04b8\u04bc\u04c2\u04e8\u04e7\u04ca\u04d6\u04aa\u04a9\u04b1\u04d2\u04ea\u04be\u04cd\u04ac\u04f3\u04f8\u04ce\u04f4\u04db\u04e8\u04b9\u04b6\u04fe\u04e0\u04c5", (byte)56, 68);
                    \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.b[3] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.B("\u0142\u015b\u0143\u0121\u013f\u0140\u016b\u0140\u015c\u0130\u0131\u0137", (byte)56, 66);
                    \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.b[4] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u0542\u0562\u0521\u0526\u0542\u0543\u0545\u0541\u053d\u0542\u052e\u053c", (byte)56, 69);
                    continue block7;
                }
                case 1: {
                    \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.b[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.C("\u0493\u04b6\u04d7\u04cf\u04a3\u0497\u04d0\u04d6\u04ae\u0498\u04bc\u04ab\u04db\u04c4\u049f\u04cf\u04a0\u04ba\u04de\u04a1\u04dd\u04c9\u04b6\u04c3\u04a4\u04d9\u04b0\u04e6\u04e9\u04f2\u04c6\u04c1", (byte)56, 67);
                    \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.b[1] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u013a\u0151\u0127\u0162\u0136\u0158\u012b\u0169\u0171\u014a\u014e\u0137", (byte)56, 65);
                    \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.b[2] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.D("\u04c9\u048e\u04c9\u04c3\u04ab\u04cd\u04d2\u04a6\u04dc\u04d3\u04ba\u04db\u04de\u04d7\u04da\u04b2\u04d5\u04bc\u04b8\u04bc\u04c2\u04e8\u04e7\u04ca\u04d6\u04aa\u04a9\u04b1\u04d2\u04ea\u04be\u04cd\u04f6\u04e6\u04c6\u04b2\u04cf\u04c8\u04d6\u04b7\u04da\u04bb\u04f2\u04c5", (byte)56, 68);
                    \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.b[3] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.E("\u056a\u055f\u052e\u055c\u0531\u0546\u0533\u0544\u0527\u0560\u0543\u053c", (byte)56, 69);
                    \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.b[4] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.D("\u04c6\u04d4\u04a9\u04a8\u04d7\u04d5\u04bb\u04b2\u0490\u0491\u04c0\u04a5", (byte)56, 68);
                    continue block7;
                }
                case 2: {
                    \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u04d5\u04b5\u048f\u04ca\u04c3\u04a7\u04a9\u04d4\u04d1\u04d6\u04ca\u04b2\u04d6\u04d8\u049e\u049d\u04bb\u04b2\u04d6\u04dc\u04bf\u04c3\u04b0\u04b1", (byte)56, 67);
                    continue block7;
                }
                case 4: {
                    \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.b[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.E("\u0526\u0520\u055c\u054d\u054c\u0572\u0572\u053c\u0576\u0570\u0561\u0560\u0558\u053a\u0532\u057d\u0565\u0558\u057b\u053d\u054c\u0570\u0547\u0548", (byte)56, 69);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x62L;
        l ^= 0x375D8D0E292FF9DFL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(54 + 14), (byte)(22 + 47), 83, (byte)(13 + 34), (byte)(27 + 40), (byte)(44 + 22), (byte)(25 + 42), (byte)(27 + 20), (byte)(59 + 21), (byte)(25 + 50), (byte)(27 + 40), (byte)(63 + 20), (byte)(32 + 21), (byte)(52 + 28), (byte)(74 + 23), (byte)(79 + 21), (byte)(63 + 37), (byte)(19 + 86), (byte)(12 + 98), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(16 + 53), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.B("\u014e\u015b\u015a\u011d\u015d\u0159\u0154\u015d\u0168\u0157\u0124\u0162\u0166\u015f\u0162\u0168\u012a\u049c\u04c2\u04b8\u04b1\u04c4\u04b5\u04b8\u04bb", (byte)54, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u0525\u0547\u0549\u0529\u054d\u056c\u0564\u057a\u0566\u0535\u0573\u0569\u0577\u0571\u053a\u055f\u0581\u0580\u0578\u057e\u0578\u054d", (byte)65, 70), \u03a0\u03c5\u03ba\u03b2\u03c4\u03b4\u03b6\u03b8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.D("\u04db\u04e8\u04e7\u04aa\u04ea\u04e6\u04e1\u04ea\u04f5\u04e4\u04b1\u04ef\u04f3\u04ec\u04ef\u04f5\u04b7\u0829\u084f\u0845\u083e\u0851\u0842\u0845\u0848\u04cb", (byte)65, 68) + string + \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u0537", (byte)65, 70) + methodType.toString(), exception);
        }
    }

    private TextComponent a(String string, boolean bl) {
        return \u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.b(string, bl);
    }
}

