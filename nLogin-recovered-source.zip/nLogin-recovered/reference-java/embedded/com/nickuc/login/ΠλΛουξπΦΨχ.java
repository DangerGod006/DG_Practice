/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.loader.platform.BukkitLoader
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.messaging.Messenger
 *  org.bukkit.plugin.messaging.PluginMessageListener
 */
package com.nickuc.login;

import com.nickuc.login.loader.platform.BukkitLoader;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393;
import com.nickuc.login.\u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.messaging.Messenger;
import org.bukkit.plugin.messaging.PluginMessageListener;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7
extends \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5<\u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393> {
    private static long e;
    private static int r;
    private static long h;
    private static int g;
    private static int s;
    private static int m;
    private static long n;
    private static long f;
    private static String[] d;
    private static int p;
    private static long q;
    private static int b;
    private static long o;
    private static String[] c;
    private static int d;

    @Override
    public void a(Object object, Object object2) {
        if (object2 == null) {
            throw new IllegalArgumentException((String)\u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.c("\u3e80", (int)(b & d), (long)f));
        }
        if (!(object2 instanceof PluginMessageListener)) {
            throw new IllegalArgumentException((String)\u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.c("\u3e83", (int)g, (long)h) + object2.getClass().getCanonicalName());
        }
        if (!(object instanceof String)) {
            throw new IllegalArgumentException((String)\u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.c("\u3e86", (int)m, (long)(n ^ o)));
        }
        String string = (String)object;
        BukkitLoader bukkitLoader = ((\u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393)this.h).a();
        Messenger messenger = bukkitLoader.getServer().getMessenger();
        if (!messenger.isOutgoingChannelRegistered((Plugin)bukkitLoader, string)) {
            messenger.registerOutgoingPluginChannel((Plugin)bukkitLoader, string);
        }
        if (!messenger.isIncomingChannelRegistered((Plugin)bukkitLoader, string)) {
            messenger.registerIncomingPluginChannel((Plugin)bukkitLoader, string, (PluginMessageListener)object2);
        }
    }

    @Override
    public void c(Object object) {
        if (!(object instanceof String)) {
            throw new IllegalArgumentException((String)\u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.c("\u3e80", (int)p, (long)q));
        }
        String string = (String)object;
        BukkitLoader bukkitLoader = ((\u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393)this.h).a();
        Messenger messenger = bukkitLoader.getServer().getMessenger();
        messenger.unregisterIncomingPluginChannel((Plugin)bukkitLoader, string);
        messenger.unregisterOutgoingPluginChannel((Plugin)bukkitLoader, string);
    }

    private static String a(int n, long l) {
        l ^= 0x58L;
        l ^= 0x2C414BB0C2754B6AL;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(34 + 34), (byte)(14 + 55), (byte)(45 + 38), (byte)(28 + 19), (byte)(34 + 33), (byte)(52 + 14), (byte)(29 + 38), (byte)(4 + 43), (byte)(39 + 41), 75, (byte)(40 + 27), (byte)(12 + 71), (byte)(27 + 26), (byte)(16 + 64), (byte)(73 + 24), (byte)(56 + 44), (byte)(62 + 38), 105, (byte)(60 + 50), (byte)(99 + 4)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(30 + 38), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u0592\u059f\u059e\u0561\u05a1\u059d\u0598\u05a1\u05ac\u059b\u0568\u05a6\u05aa\u05a3\u05a6\u05ac\u056e\u08e0\u08fc\u08dd\u0902\u0909\u0903\u0906\u08ed\u08f0\u0910", (byte)126, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    static {
        b = Integer.reverse(0);
        d = Integer.reverse(-1);
        f = Long.reverse(8220996430055807795L);
        g = 8 >>> 3 | 8 << ~3 + 1;
        h = Long.reverse(8220996430055807795L);
        m = (512 >>> 8 | 512 << ~8 + 1) & 0xFFFFFFFF;
        n = Long.reverse(7500420489676528435L);
        o = Long.reverse(0x1A00000000000000L);
        p = Integer.reverse(-1073741824);
        q = Long.reverse(8220996430055807795L);
        r = (8192 >>> 75 | 8192 << -75) & 0xFFFFFFFF;
        s = (Integer.MIN_VALUE >>> 157 | Integer.MIN_VALUE << -157) & 0xFFFFFFFF;
        c = new String[r];
        d = new String[s];
        \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.b();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.A("\u00cf\u00f1\u00f3\u00d3\u00f7\u0116\u010e\u0124\u0110\u00df\u011d\u0113\u0121\u011b\u00e4\u0109\u012b\u012a\u0122\u0128\u0122\u00f7", (byte)20, 65), \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u0533\u0540\u053f\u0502\u0542\u053e\u0539\u0542\u054d\u053c\u0509\u0547\u054b\u0544\u0547\u054d\u050f\u0881\u089d\u087e\u08a3\u08aa\u08a4\u08a7\u088e\u0891\u08b1\u0525", (byte)20, 70) + string + \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u00e1", (byte)20, 65) + methodType.toString(), exception);
        }
    }

    @Override
    public void b(Object object) {
        throw new UnsupportedOperationException();
    }

    private static void b() {
        int n;
        e = -3685953774085773290L;
        long l = e ^ 0x2C414BB0C2754B6AL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(43 + 25), (byte)(63 + 6), (byte)(17 + 66), 47, (byte)(40 + 27), (byte)(22 + 44), (byte)(36 + 31), (byte)(4 + 43), (byte)(66 + 14), 75, (byte)(26 + 41), (byte)(72 + 11), (byte)(46 + 7), (byte)(9 + 71), (byte)(92 + 5), (byte)(27 + 73), (byte)(42 + 58), (byte)(71 + 34), (byte)(9 + 101), (byte)(93 + 10)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(24 + 44), (byte)(27 + 42), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.d[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u04a7\u048c\u0484\u0475\u0492\u04ac\u0494\u048a\u04a2\u04a4\u0497\u04b3\u04b4\u04b3\u04bf\u049c\u0492\u04b5\u04b9\u04a5\u04b9\u0491\u049f\u04c0\u04b7\u04b3\u04bd\u04c5\u04bd\u04a5\u04d1\u04ba\u048c\u0493\u04d3\u04b1\u0490\u048e\u04c1\u04d4\u04a4\u049a\u04b4\u04a1", (byte)44, 68);
                    \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.d[1] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.B("\u0148\u0125\u0151\u014f\u014d\u0115\u0142\u012d\u0150\u0124\u015b\u0137\u0147\u014e\u014c\u015b\u0156\u0129\u0163\u0154\u0120\u0146\u0140\u0125\u0168\u0131\u0137\u0122\u0125\u015d\u0156\u014d", (byte)44, 66);
                    \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.d[2] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u047e\u0484\u0483\u046e\u04b1\u04b4\u048e\u04ad\u04a4\u049b\u048a\u0495\u0495\u04bc\u04b0\u0496\u0478\u0498\u048f\u048f\u04a7\u04b5\u04c4\u04b1\u04aa\u04c6\u04b4\u04cc\u048c\u04a9\u049f\u049d\u04d0\u049c\u04c6\u04a2\u04aa\u049f\u0494\u04b1\u0497\u04d0\u04d2\u04a1", (byte)44, 67);
                    \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.d[3] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u052d\u0533\u0532\u051d\u0560\u0563\u053d\u055c\u0553\u054a\u0539\u0544\u0544\u056b\u055f\u0545\u0527\u0547\u053e\u053e\u0556\u0564\u0573\u0560\u0559\u0575\u0563\u057b\u053b\u0558\u054e\u054c\u057f\u054b\u0575\u0551\u0559\u054e\u0543\u0560\u0546\u057f\u0581\u0550", (byte)44, 69);
                    continue block7;
                }
                case 1: {
                    \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.d[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u04a7\u048c\u0484\u0475\u0492\u04ac\u0494\u048a\u04a2\u04a4\u0497\u04b3\u04b4\u04b3\u04bf\u049c\u0492\u04b5\u04b9\u04a5\u04b9\u0491\u049f\u04c0\u04b7\u04b3\u04bd\u04c5\u04bd\u04a5\u04d1\u04ba\u04c1\u04ab\u04d0\u049f\u0491\u04d7\u048f\u0499\u04d7\u04d3\u04d2\u04a1", (byte)44, 67);
                    \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.d[1] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u04aa\u0487\u04b3\u04b1\u04af\u0477\u04a4\u048f\u04b2\u0486\u04bd\u0499\u04a9\u04b0\u04ae\u04bd\u04b8\u048b\u04c5\u04b6\u0482\u04a5\u04bb\u04c1\u04bc\u04a5\u04cb\u0496\u049a\u04a3\u0486\u0483", (byte)44, 67);
                    \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.d[2] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u052d\u0533\u0532\u051d\u0560\u0563\u053d\u055c\u0553\u054a\u0539\u0544\u0544\u056b\u055f\u0545\u0527\u0547\u053e\u053e\u0556\u0564\u0573\u0560\u0559\u0575\u0563\u057b\u053b\u0558\u054e\u054c\u056e\u054d\u0561\u0556\u057c\u053e\u0556\u0580\u058a\u057e\u0575\u0550", (byte)44, 69);
                    \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.d[3] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u011c\u0122\u0121\u010c\u014f\u0152\u012c\u014b\u0142\u0139\u0128\u0133\u0133\u015a\u014e\u0134\u0116\u0136\u012d\u012d\u0145\u0153\u0162\u014f\u0148\u0164\u0152\u016a\u012a\u0147\u013d\u013b\u012a\u0167\u013e\u0169\u0151\u015d\u0134\u0154\u0148\u0168\u0146\u013f", (byte)44, 66);
                    continue block7;
                }
                case 2: {
                    \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.d[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.A("\u0131\u014b\u0151\u0111\u0148\u012e\u0148\u0156\u0154\u0143\u012b\u0147\u0119\u0137\u013f\u0151\u0135\u0152\u0161\u0134\u0120\u011c\u012e\u0156\u0120\u0148\u0120\u0165\u0160\u0162\u0138\u0140", (byte)44, 65);
                    continue block7;
                }
                case 4: {
                    \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7.d[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u04a5\u0482\u04a6\u04a6\u04b5\u04a3\u04b2\u048e\u04a2\u04a5\u04a7\u0491\u04b7\u04ae\u0489\u04b7\u049a\u0497\u04b0\u04c0\u047d\u04b5\u048c\u048d", (byte)44, 68);
                }
            }
        }
    }

    public \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7(\u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393 \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u03932) {
        super(\u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u03932);
    }
}

