/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent
 *  com.nickuc.login.lib.packetevents.api.wrapper.common.client.WrapperCommonClientSettings
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent;
import com.nickuc.login.lib.packetevents.api.wrapper.common.client.WrapperCommonClientSettings;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a3;
import com.nickuc.login.\u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb;
import lombok.Generated;

public class \u039b\u03b3\u03c8\u039b\u03b5\u03a6\u03b3\u03c4\u03a9\u03b1\u03b1\u03b3\u03bf\u03be\u03c7
implements \u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6 {
    private final nLoginBukkit s;

    @Override
    public void a(PacketReceiveEvent packetReceiveEvent) {
        Object object = packetReceiveEvent.getPlayer();
        if (object == null) {
            return;
        }
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = this.s.b().a(object);
        \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = this.s.a().a().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
        if (\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 == null) {
            return;
        }
        WrapperCommonClientSettings wrapperCommonClientSettings = new WrapperCommonClientSettings(packetReceiveEvent);
        \u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a3 \u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a32 = \u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a3.c(wrapperCommonClientSettings.getLocale());
        if (\u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a32 != null) {
            \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.i, (Object)\u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a32);
        }
    }

    @Generated
    public \u039b\u03b3\u03c8\u039b\u03b5\u03a6\u03b3\u03c4\u03a9\u03b1\u03b1\u03b3\u03bf\u03be\u03c7(nLoginBukkit nLoginBukkit2) {
        this.s = nLoginBukkit2;
    }
}

