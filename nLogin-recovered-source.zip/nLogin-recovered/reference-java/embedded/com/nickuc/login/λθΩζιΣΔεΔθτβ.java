/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2 {
    private static long g;
    private static int e;
    private static long b;
    @Nullable
    private final String bV;
    private static int f;
    private static int a;
    private static int c;
    private static long c;
    private static int i;
    private final String bU;
    private static String[] b;
    private static int h;
    private static long d;
    private static String[] a;

    private static void b() {
        int n;
        c = 822724405042290837L;
        long l = c ^ 0xE5C03D7C84F634EL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(34 + 34), (byte)(47 + 22), (byte)(74 + 9), (byte)(31 + 16), (byte)(23 + 44), (byte)(24 + 42), (byte)(7 + 60), (byte)(17 + 30), (byte)(6 + 74), (byte)(38 + 37), (byte)(3 + 64), (byte)(11 + 72), 53, (byte)(36 + 44), (byte)(73 + 24), (byte)(88 + 12), 100, (byte)(104 + 1), (byte)(54 + 56), (byte)(92 + 11)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(58 + 25)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u01ab\u01c1\u01d4\u01a6\u01cc\u01ae\u01a9\u0191\u01da\u01aa\u0197\u01b6\u01dc\u01e1\u01dc\u01be\u0196\u01c2\u01a0\u01c0\u01c1\u01e3\u01d3\u01cc\u01e1\u01dd\u01eb\u01e6\u01dc\u01a9\u01dc\u01e2\u01e6\u01d0\u01e8\u01f4\u01e1\u01b7\u01b0\u01c8\u01f5\u01d3\u01d7\u01f5\u01ea\u01d3\u0200\u01da\u01c1\u01d6\u01ee\u01c1\u0207\u01d1\u01ce\u01cf", (byte)110, 65);
                    \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2.b[1] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.F("\u057e\u0591\u055e\u058e\u055e\u0577\u0572\u0569\u0595\u056b\u057c\u05a0\u05ac\u058d\u057a\u0587\u056c\u056a\u058e\u05ab\u056e\u05a6\u057d\u057e", (byte)110, 70);
                    \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2.b[2] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u01d1\u01a5\u01cb\u01a6\u01a8\u01b1\u0198\u01d7\u01b8\u019b\u01cc\u01a3", (byte)110, 66);
                    continue block7;
                }
                case 1: {
                    \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u057a\u0590\u05a3\u0575\u059b\u057d\u0578\u0560\u05a9\u0579\u0566\u0585\u05ab\u05b0\u05ab\u058d\u0565\u0591\u056f\u058f\u0590\u05b2\u05a2\u059b\u05b0\u05ac\u05ba\u05b5\u05ab\u0578\u05ab\u05b1\u05b5\u059f\u05b7\u05c3\u05b0\u0586\u057f\u0597\u05c4\u05a2\u05a8\u05bd\u059a\u0590\u05c7\u05a2\u05d1\u05be\u05d2\u0593\u05d4\u05d6\u059d\u059e", (byte)110, 70);
                    \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2.b[1] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.C("\u0553\u0566\u0533\u0563\u0533\u054c\u0547\u053e\u056a\u0540\u0550\u0572\u0542\u0551\u0542\u0574\u0580\u0557\u0553\u0577\u0580\u058b\u0552\u0553", (byte)110, 67);
                    \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2.b[2] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u01cd\u0192\u01c3\u01a0\u01d9\u018f\u01b6\u01cb\u01b2\u019a\u019d\u01a3", (byte)110, 66);
                    continue block7;
                }
                case 2: {
                    \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u01be\u0187\u01d2\u01d2\u01b4\u0195\u01d3\u01d9\u0197\u01a6\u01dc\u01a3", (byte)110, 66);
                    continue block7;
                }
                case 4: {
                    \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.B("\u01a4\u01d3\u01c2\u01c1\u01ae\u01b3\u019a\u01ad\u01b3\u01b4\u01ad\u01ca\u01b9\u01a1\u01b7\u01d3\u01b5\u01cd\u01ae\u01c5\u01d0\u01dd\u01b8\u01eb\u01ca\u01ce\u01a8\u01cc\u01c1\u01c9\u01b1\u01ef", (byte)110, 66);
                }
            }
        }
    }

    static {
        a = 0 >>> 235 | 0 << -235;
        b = Long.reverse(-2088287714726684976L);
        c = 0x20000000 >>> 125 | 0x20000000 << -125;
        d = Long.reverse(-2088287714726684976L);
        e = (16384 >>> 141 | 16384 << -141) & 0xFFFFFFFF;
        f = (-1 >>> 128 | -1 << -128) & 0xFFFFFFFF;
        g = Long.reverse(-2088287714726684976L);
        h = (0xC00000 >>> 214 | 0xC00000 << -214) & 0xFFFFFFFF;
        i = (-2147483647 >>> 31 | -2147483647 << -31) & 0xFFFFFFFF;
        a = new String[h];
        b = new String[i];
        \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2.b();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.D("\u050c\u052e\u0530\u0510\u0534\u0553\u054b\u0561\u054d\u051c\u055a\u0550\u055e\u0558\u0521\u0546\u0568\u0567\u055f\u0565\u055f\u0534", (byte)101, 68), \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.F("\u0584\u0591\u0590\u0553\u0593\u058f\u058a\u0593\u059e\u058d\u055a\u0598\u059c\u0595\u0598\u059e\u0560\u08ed\u08eb\u08dd\u08eb\u08ef\u08da\u08cc\u08ee\u08ce\u08f3\u0900\u08ef\u0578", (byte)101, 70) + string + \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.A("\u0183", (byte)101, 65) + methodType.toString(), exception);
        }
    }

    @Generated
    public String ar() {
        return this.bU;
    }

    @Nullable
    @Generated
    public String as() {
        return this.bV;
    }

    @Generated
    public String toString() {
        return (String)\u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2.c("\u3e80", (int)a, (long)b) + this.ar() + (String)\u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2.c("\u3e83", (int)c, (long)d) + this.as() + (String)\u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2.c("\u3e86", (int)(e & f), (long)g);
    }

    private static String a(int n, long l) {
        l ^= 0x52L;
        l ^= 0xE5C03D7C84F634EL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(35 + 33), (byte)(33 + 36), (byte)(39 + 44), (byte)(9 + 38), (byte)(34 + 33), 66, (byte)(11 + 56), (byte)(2 + 45), (byte)(58 + 22), (byte)(8 + 67), (byte)(18 + 49), (byte)(82 + 1), (byte)(51 + 2), (byte)(5 + 75), (byte)(4 + 93), (byte)(73 + 27), 100, (byte)(59 + 46), (byte)(104 + 6), (byte)(10 + 93)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(10 + 58), (byte)(18 + 51), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.E("\u0532\u053f\u053e\u0501\u0541\u053d\u0538\u0541\u054c\u053b\u0508\u0546\u054a\u0543\u0546\u054c\u050e\u089b\u0899\u088b\u0899\u089d\u0888\u087a\u089c\u087c\u08a1\u08ae\u089d", (byte)19, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Generated
    public \u03bb\u03b8\u03a9\u03b6\u03b9\u03a3\u0394\u03b5\u0394\u03b8\u03c4\u03b2(String string, @Nullable String string2) {
        this.bU = string;
        this.bV = string2;
    }
}

