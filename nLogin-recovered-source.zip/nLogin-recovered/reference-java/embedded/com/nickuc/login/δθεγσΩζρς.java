/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a3\u03bc\u03c2\u03a0\u0394\u03c5\u03c3\u03b8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Locale;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2
extends \u03a3\u03bc\u03c2\u03a0\u0394\u03c5\u03c3\u03b8 {
    private static final String G;
    private static int bp;
    private static long bg;
    private static long bw;
    private static long aq;
    private static int bc;
    private static final String H;
    private static int bt;
    private static long bv;
    private static long q;
    private static int bk;
    private static int bi;
    private static String[] f;
    private static long br;
    private static long ar;
    private static String[] e;
    private static long az;
    private static int ag;
    private static long r;
    private static long ba;
    private static int bn;
    private static int d;
    private static long bd;
    private static long p;
    private static int ax;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.F("\u0537\u0559\u055b\u053b\u055f\u057e\u0576\u058c\u0578\u0547\u0585\u057b\u0589\u0583\u054c\u0571\u0593\u0592\u058a\u0590\u058a\u055f", (byte)83, 70), \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.B("\u0188\u0195\u0194\u0157\u0197\u0193\u018e\u0197\u01a2\u0191\u015e\u019c\u01a0\u0199\u019c\u01a2\u0164\u04ea\u04ef\u04ed\u04ec\u04fd\u04e4\u04f2\u04fe\u0500\u0179", (byte)83, 66) + string + \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u04e8", (byte)83, 67) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        p = -6991682361532183267L;
        long l = p ^ 0xF74F484C94D7447CL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(7 + 61), (byte)(30 + 39), (byte)(32 + 51), (byte)(7 + 40), (byte)(46 + 21), (byte)(5 + 61), (byte)(64 + 3), (byte)(17 + 30), (byte)(53 + 27), (byte)(30 + 45), (byte)(48 + 19), (byte)(11 + 72), (byte)(26 + 27), (byte)(57 + 23), (byte)(86 + 11), (byte)(55 + 45), (byte)(97 + 3), 105, 110, (byte)(82 + 21)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(48 + 20), 69, (byte)(58 + 25)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.f[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u056f\u0585\u056a\u0581\u054a\u0555\u0580\u056b\u054d\u056e\u056d\u058e\u057b\u0568\u0570\u0594\u0567\u0572\u0565\u0554\u056e\u0574\u0561\u0562", (byte)82, 70);
                    \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.f[1] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u050c\u0522\u0507\u051e\u04e7\u04f2\u051d\u0508\u04ea\u050b\u050b\u050a\u0500\u0500\u0525\u04f0\u04fe\u0527\u0514\u04ef\u050f\u0527\u04fe\u04ff", (byte)82, 67);
                    \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.f[2] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u04ef\u04dd\u04f1\u050f\u04da\u0506\u0519\u04f8\u051c\u0500\u050a\u04f3", (byte)82, 68);
                    \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.f[3] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.B("\u018a\u0176\u0193\u016d\u0180\u0172\u0162\u017d\u0196\u0186\u0198\u016b", (byte)82, 66);
                    \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.f[4] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.C("\u0512\u04fe\u051b\u04f5\u0508\u04fa\u04ea\u0505\u051e\u050e\u0520\u04f3", (byte)82, 67);
                    \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.f[5] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u0167\u0155\u0169\u0187\u0152\u017e\u0191\u0170\u0194\u0178\u0182\u016b", (byte)82, 65);
                    continue block7;
                }
                case 1: {
                    \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.f[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.F("\u056f\u0585\u056a\u0581\u054a\u0555\u0580\u056b\u054d\u056e\u056d\u0549\u056f\u0584\u0580\u0572\u0557\u0569\u0582\u0565\u059a\u059a\u0561\u0562", (byte)82, 70);
                    \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.f[1] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u056f\u0585\u056a\u0581\u054a\u0555\u0580\u056b\u054d\u056e\u056d\u0565\u0594\u0589\u057e\u0574\u0564\u0563\u0584\u0587\u0573\u0564\u0561\u0562", (byte)82, 69);
                    \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.f[2] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u04f0\u04ef\u04e2\u04f3\u0513\u0529\u0505\u0525\u04e3\u051b\u051c\u04f3", (byte)82, 67);
                    \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.f[3] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u0176\u016f\u0199\u018f\u0189\u017c\u0179\u0177\u0160\u017d\u019c\u016b", (byte)82, 66);
                    \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.f[4] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u0512\u051d\u04e5\u04fe\u0501\u04e2\u04fa\u04e5\u04e7\u0517\u051c\u04f3", (byte)82, 67);
                    \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.f[5] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u0565\u0582\u0555\u057b\u0562\u0544\u057e\u057f\u0547\u0547\u0583\u0556", (byte)82, 69);
                    continue block7;
                }
                case 2: {
                    \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.f[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0550\u0557\u0555\u057b\u0566\u0569\u054a\u055b\u0559\u0550\u0587\u055e\u054c\u0561\u0574\u057f\u0573\u0571\u0563\u0572\u058f\u0595\u055b\u058f\u0595\u0594\u0592\u059d\u0562\u0573\u056e\u0579", (byte)82, 69);
                    continue block7;
                }
                case 4: {
                    \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.f[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u04f7\u0516\u0522\u0500\u0516\u0514\u0521\u04fb\u04e8\u0519\u0505\u0526\u0520\u0505\u050e\u04fe\u051e\u050c\u04ff\u04e9\u0505\u0511\u04fe\u04ff", (byte)82, 68);
                }
            }
        }
    }

    static {
        d = (0 >>> 73 | 0 << ~73 + 1) & 0xFFFFFFFF;
        q = Long.reverse(-5138253879549288583L);
        r = Long.reverse(0x1800000000000000L);
        ag = Integer.reverse(Integer.MIN_VALUE);
        aq = Long.reverse(-5138253879549288583L);
        ar = Long.reverse(0x1800000000000000L);
        ax = Integer.reverse(0x40000000);
        az = Long.reverse(-5138253879549288583L);
        ba = Long.reverse(0x1800000000000000L);
        bc = 196608 >>> 176 | 196608 << -176;
        bd = Long.reverse(-5138253879549288583L);
        bg = Long.reverse(0x1800000000000000L);
        bi = Integer.reverse(0x60000000);
        bk = Integer.reverse(0x60000000);
        bn = (2 >>> 31 | 2 << ~31 + 1) & 0xFFFFFFFF;
        bp = Integer.reverse(-1);
        br = Long.reverse(-6867636136459559047L);
        bt = Integer.reverse(-1610612736);
        bv = Long.reverse(-5138253879549288583L);
        bw = Long.reverse(0x1800000000000000L);
        e = new String[bi];
        f = new String[bk];
        \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.b();
        G = \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.c("\u3e80", (int)(bn & bp), (long)br);
        H = \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.c("\u3e83", (int)bt, (long)(bv ^ bw));
    }

    @Override
    protected void a(\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2 \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22, String string, String string2) {
        String string3 = \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.b(string2 + (String)\u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.c("\u3e80", (int)ax, (long)(az ^ ba)));
        if (string3 != null) {
            String string4 = \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.b(string2 + (String)\u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.c("\u3e83", (int)bc, (long)(bd ^ bg)));
            \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7 \u03bb\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7 = \u039b\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.valueOf(string3.toUpperCase(Locale.ENGLISH));
            this.a(string, \u03bb\u03b7\u03b1\u03ba\u03c8\u03a8\u03b7\u03be\u03b7.e(string4), null, null);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x18L;
        l ^= 0xF74F484C94D7447CL;
        if (e[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(61 + 7), (byte)(33 + 36), (byte)(36 + 47), (byte)(22 + 25), (byte)(63 + 4), (byte)(60 + 6), (byte)(2 + 65), (byte)(29 + 18), (byte)(45 + 35), (byte)(17 + 58), (byte)(35 + 32), (byte)(64 + 19), (byte)(13 + 40), (byte)(25 + 55), (byte)(82 + 15), (byte)(53 + 47), (byte)(2 + 98), 105, 110, (byte)(73 + 30)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(40 + 43)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u0575\u0582\u0581\u0544\u0584\u0580\u057b\u0584\u058f\u057e\u054b\u0589\u058d\u0586\u0589\u058f\u0551\u08d7\u08dc\u08da\u08d9\u08ea\u08d1\u08df\u08eb\u08ed", (byte)86, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.e[n] = new String(cipher.doFinal(Base64.getDecoder().decode(f[n])), StandardCharsets.UTF_8);
        }
        return e[n];
    }

    public \u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        super(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u0393\u03b5\u03bf\u03ba\u03c0\u03bd\u03a8\u03c9\u03c0\u03c4.C, (String)\u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.c("\u3e80", (int)d, (long)(q ^ r)), (String)\u03b4\u03b8\u03b5\u03b3\u03c3\u03a9\u03b6\u03c1\u03c2.c("\u3e83", (int)ag, (long)(aq ^ ar)));
    }
}

