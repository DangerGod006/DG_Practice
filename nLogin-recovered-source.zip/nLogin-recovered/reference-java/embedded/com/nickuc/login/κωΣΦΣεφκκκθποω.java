/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9
extends Enum<\u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9> {
    public static final /* enum */ \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9 a;
    public static final /* enum */ \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9 b;
    private final boolean aR;
    private static final /* synthetic */ \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9[] a;
    private static String[] a;
    private static String[] b;
    private static long c;
    private static int a;
    private static int b;
    private static int c;
    private static int d;
    private static int e;
    private static int f;
    private static long g;
    private static int h;
    private static int i;
    private static int j;
    private static long k;
    private static long l;
    private static int m;
    private static int n;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u0461\u0483\u0485\u0465\u0489\u04a8\u04a0\u04b6\u04a2\u0471\u04af\u04a5\u04b3\u04ad\u0476\u049b\u04bd\u04bc\u04b4\u04ba\u04b4\u0489", (byte)44, 67), \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.E("\u054b\u0558\u0557\u051a\u055a\u0556\u0551\u055a\u0565\u0554\u0521\u055f\u0563\u055c\u055f\u0565\u0527\u08b3\u08c3\u089e\u08a2\u08a0\u08b3\u08c5\u08ba\u08bb\u08bc\u08bb\u08c4\u08c4\u08cf\u0541", (byte)44, 69) + string + \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u0473", (byte)44, 67) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = -8784892309061848241L;
        long l = c ^ 0xA5C423D603775B4BL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(20 + 48), (byte)(27 + 42), (byte)(4 + 79), (byte)(40 + 7), (byte)(38 + 29), (byte)(52 + 14), (byte)(30 + 37), 47, 80, (byte)(56 + 19), (byte)(13 + 54), (byte)(55 + 28), (byte)(28 + 25), (byte)(76 + 4), (byte)(9 + 88), (byte)(33 + 67), (byte)(38 + 62), (byte)(49 + 56), (byte)(39 + 71), (byte)(27 + 76)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(74 + 9)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.D("\u051e\u0528\u0521\u0530\u0502\u04fc\u052f\u0510\u051b\u051e\u0519\u050e", (byte)91, 68);
                    \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9.b[1] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.B("\u01ad\u01ab\u0179\u017e\u0187\u019f\u0182\u01b6\u0172\u018b\u018c\u017d", (byte)91, 66);
                    continue block7;
                }
                case 1: {
                    \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9.b[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u058f\u0583\u054c\u0553\u057c\u0550\u0567\u0560\u0550\u0553\u0594\u055f", (byte)91, 70);
                    \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9.b[1] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.B("\u0168\u0168\u017b\u01ab\u018a\u0193\u01ae\u0196\u018c\u0177\u0185\u0188\u0186\u01b3\u0186\u01b7\u0188\u01bf\u01b0\u0178\u019f\u01c1\u0188\u0189", (byte)91, 66);
                    continue block7;
                }
                case 2: {
                    \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9.b[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u0507\u052f\u053d\u0520\u051b\u0513\u0524\u051f\u0533\u0519\u0504\u051b\u0548\u0520\u0503\u0549\u050c\u051a\u051f\u0527\u0547\u0506\u0543\u053f\u0553\u052d\u0523\u0535\u055a\u0526\u0552\u0547", (byte)91, 67);
                    continue block7;
                }
                case 4: {
                    \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u0587\u0591\u0591\u0586\u058c\u0585\u0571\u054e\u056c\u0569\u0590\u0579\u0588\u0557\u058c\u058c\u056e\u059a\u0559\u058c\u0570\u05a3\u056a\u056b", (byte)91, 70);
                }
            }
        }
    }

    static {
        a = 8 >>> 130 | 8 << ~130 + 1;
        b = (0 >>> 144 | 0 << ~144 + 1) & 0xFFFFFFFF;
        c = Integer.reverse(Integer.MIN_VALUE);
        d = Integer.reverse(0x40000000);
        e = 1024 >>> 233 | 1024 << -233;
        f = (0 >>> 103 | 0 << -103) & 0xFFFFFFFF;
        g = Long.reverse(-2536245659014289311L);
        h = Integer.reverse(0);
        i = (65536 >>> 112 | 65536 << -112) & 0xFFFFFFFF;
        j = Integer.reverse(Integer.MIN_VALUE);
        k = Long.reverse(-950978590179874719L);
        l = Long.reverse(0x2E00000000000000L);
        m = (64 >>> 230 | 64 << ~230 + 1) & 0xFFFFFFFF;
        n = 0 >>> 167 | 0 << -167;
        a = new String[d];
        b = new String[e];
        \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9.b();
        a = new \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9(i != 0);
        b = new \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9(n != 0);
        a = \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9.a();
    }

    public static \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9 valueOf(String string) {
        return Enum.valueOf(\u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9.class, string);
    }

    private static /* synthetic */ \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9[] a() {
        \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9[] \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9Array = new \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9[a];
        \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9Array[\u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9.b] = a;
        \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9Array[\u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9.c] = b;
        return \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9Array;
    }

    private static String a(int n, long l) {
        l ^= 0x74L;
        l ^= 0xA5C423D603775B4BL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(50 + 18), 69, (byte)(34 + 49), (byte)(3 + 44), (byte)(39 + 28), (byte)(41 + 25), (byte)(17 + 50), (byte)(23 + 24), 80, (byte)(26 + 49), (byte)(21 + 46), (byte)(78 + 5), (byte)(32 + 21), (byte)(28 + 52), (byte)(53 + 44), (byte)(3 + 97), (byte)(65 + 35), (byte)(6 + 99), (byte)(57 + 53), (byte)(98 + 5)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(80 + 3)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u0580\u058d\u058c\u054f\u058f\u058b\u0586\u058f\u059a\u0589\u0556\u0594\u0598\u0591\u0594\u059a\u055c\u08e8\u08f8\u08d3\u08d7\u08d5\u08e8\u08fa\u08ef\u08f0\u08f1\u08f0\u08f9\u08f9\u0904", (byte)97, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Generated
    private \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9(boolean bl) {
        this.aR = bl;
    }

    @Generated
    public boolean aQ() {
        return this.aR;
    }

    public static \u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9[] values() {
        return (\u03ba\u03c9\u03a3\u03a6\u03a3\u03b5\u03c6\u03ba\u03ba\u03ba\u03b8\u03c0\u03bf\u03c9[])a.clone();
    }
}

