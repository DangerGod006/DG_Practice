/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.velocitypowered.api.command.CommandSource
 *  com.velocitypowered.api.proxy.ConsoleCommandSource
 *  com.velocitypowered.api.proxy.ProxyServer
 *  lombok.Generated
 *  net.kyori.adventure.text.Component
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0;
import com.nickuc.login.\u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.proxy.ConsoleCommandSource;
import com.velocitypowered.api.proxy.ProxyServer;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import net.kyori.adventure.text.Component;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bd\u03c9\u03b4\u03a0\u039b\u03c3\u03bc\u03bc\u03c6\u03b6\u03ba\u03a0
implements \u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a8 {
    private static long f;
    private static int h;
    private static int e;
    private static long g;
    private static int i;
    private final ConsoleCommandSource a;
    private static String[] b;
    private static String[] a;
    private static long c;
    private static int b;
    private final ProxyServer b;
    private static int a;
    private static int c;
    private static int d;

    @Override
    public void l(String string) {
        if (string.length() >= a && string.charAt(b) == c) {
            string = string.substring(d);
        }
        this.b.getCommandManager().executeImmediatelyAsync((CommandSource)this.a, string);
    }

    @Override
    public <T> T c() {
        return (T)this.a;
    }

    @Override
    public void k(String string) {
        this.a.sendMessage((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a(string));
    }

    public static \u03bd\u03c9\u03b4\u03a0\u039b\u03c3\u03bc\u03bc\u03c6\u03b6\u03ba\u03a0 a(ProxyServer proxyServer, ConsoleCommandSource consoleCommandSource) {
        return new \u03bd\u03c9\u03b4\u03a0\u039b\u03c3\u03bc\u03bc\u03c6\u03b6\u03ba\u03a0(proxyServer, consoleCommandSource);
    }

    private static String a(int n, long l) {
        l ^= 0x52L;
        l ^= 0xC808A7B0047BC306L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(32 + 36), 69, (byte)(8 + 75), (byte)(25 + 22), (byte)(19 + 48), (byte)(35 + 31), (byte)(47 + 20), (byte)(29 + 18), (byte)(39 + 41), (byte)(3 + 72), (byte)(7 + 60), (byte)(79 + 4), (byte)(29 + 24), (byte)(73 + 7), (byte)(29 + 68), (byte)(83 + 17), (byte)(95 + 5), (byte)(78 + 27), 110, (byte)(67 + 36)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(20 + 49), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.A("\u014e\u015b\u015a\u011d\u015d\u0159\u0154\u015d\u0168\u0157\u0124\u0162\u0166\u015f\u0162\u0168\u012a\u04b9\u04c6\u04b2\u049f\u049b\u04c4\u04be\u04bf\u04ca\u04bb\u04c0\u04a7", (byte)54, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bd\u03c9\u03b4\u03a0\u039b\u03c3\u03bc\u03bc\u03c6\u03b6\u03ba\u03a0.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public String getName() {
        return \u03bd\u03c9\u03b4\u03a0\u039b\u03c3\u03bc\u03bc\u03c6\u03b6\u03ba\u03a0.c("\u3e80", (int)e, (long)(f ^ g));
    }

    static {
        a = 8 >>> 98 | 8 << -98;
        b = Integer.reverse(0);
        c = Integer.reverse(-201326592);
        d = 1024 >>> 202 | 1024 << -202;
        e = Integer.reverse(0);
        f = Long.reverse(2060466883185926535L);
        g = Long.reverse(0x4A00000000000000L);
        h = Integer.reverse(Integer.MIN_VALUE);
        i = 32 >>> 197 | 32 << ~197 + 1;
        a = new String[h];
        b = new String[i];
        \u03bd\u03c9\u03b4\u03a0\u039b\u03c3\u03bc\u03bc\u03c6\u03b6\u03ba\u03a0.b();
    }

    private static void b() {
        int n;
        c = -2195782146831148744L;
        long l = c ^ 0xC808A7B0047BC306L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(25 + 44), (byte)(63 + 20), (byte)(16 + 31), (byte)(15 + 52), (byte)(27 + 39), (byte)(48 + 19), (byte)(40 + 7), (byte)(57 + 23), (byte)(15 + 60), (byte)(61 + 6), (byte)(48 + 35), (byte)(11 + 42), (byte)(6 + 74), (byte)(92 + 5), (byte)(26 + 74), (byte)(57 + 43), (byte)(49 + 56), (byte)(30 + 80), (byte)(79 + 24)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(48 + 20), (byte)(23 + 46), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bd\u03c9\u03b4\u03a0\u039b\u03c3\u03bc\u03bc\u03c6\u03b6\u03ba\u03a0.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u04dc\u04ca\u050a\u04e6\u0511\u04ce\u04ec\u04e5\u04e6\u04e9\u04cd\u04db", (byte)74, 67);
                    continue block7;
                }
                case 1: {
                    \u03bd\u03c9\u03b4\u03a0\u039b\u03c3\u03bc\u03bc\u03c6\u03b6\u03ba\u03a0.b[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u055e\u0557\u055e\u057f\u053a\u0558\u0570\u054f\u0574\u0558\u0551\u0566\u0586\u0569\u0579\u0547\u0564\u0571\u0588\u0593\u0570\u055c\u0559\u055a", (byte)74, 70);
                    continue block7;
                }
                case 2: {
                    \u03bd\u03c9\u03b4\u03a0\u039b\u03c3\u03bc\u03bc\u03c6\u03b6\u03ba\u03a0.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u0574\u056a\u0577\u0555\u054b\u0577\u0580\u0560\u054f\u0557\u0573\u054e", (byte)74, 69);
                    continue block7;
                }
                case 4: {
                    \u03bd\u03c9\u03b4\u03a0\u039b\u03c3\u03bc\u03bc\u03c6\u03b6\u03ba\u03a0.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u0579\u053c\u0538\u056d\u053f\u053e\u0566\u0544\u0578\u057e\u0583\u0545\u0545\u0555\u056b\u056d\u0588\u055a\u0586\u057f\u0592\u0582\u0559\u055a", (byte)74, 70);
                }
            }
        }
    }

    @Generated
    private \u03bd\u03c9\u03b4\u03a0\u039b\u03c3\u03bc\u03bc\u03c6\u03b6\u03ba\u03a0(ProxyServer proxyServer, ConsoleCommandSource consoleCommandSource) {
        this.b = proxyServer;
        this.a = consoleCommandSource;
    }

    @Override
    public boolean i(String string) {
        return this.a.hasPermission(string);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bd\u03c9\u03b4\u03a0\u039b\u03c3\u03bc\u03bc\u03c6\u03b6\u03ba\u03a0.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.D("\u0443\u0465\u0467\u0447\u046b\u048a\u0482\u0498\u0484\u0453\u0491\u0487\u0495\u048f\u0458\u047d\u049f\u049e\u0496\u049c\u0496\u046b", (byte)34, 68), \u03bd\u03c9\u03b4\u03a0\u039b\u03c3\u03bc\u03bc\u03c6\u03b6\u03ba\u03a0.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u047e\u048b\u048a\u044d\u048d\u0489\u0484\u048d\u0498\u0487\u0454\u0492\u0496\u048f\u0492\u0498\u045a\u07e9\u07f6\u07e2\u07cf\u07cb\u07f4\u07ee\u07ef\u07fa\u07eb\u07f0\u07d7\u0472", (byte)34, 67) + string + \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u00fd", (byte)34, 66) + methodType.toString(), exception);
        }
    }
}

