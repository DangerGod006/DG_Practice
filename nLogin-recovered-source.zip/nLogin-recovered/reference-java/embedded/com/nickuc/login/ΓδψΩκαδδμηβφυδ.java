/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03a0\u03b6\u03a3\u03a8\u03b1\u03a9\u03c8\u03bf\u03b7\u03b9\u03b7\u0393\u0393;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u03a9\u0394\u03be\u03b4\u03ba\u039b\u03c8\u03c8\u03ba\u03c6\u03b4;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4;
import com.nickuc.login.\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3;
import com.nickuc.login.\u03b8\u03b1\u03a9\u03a6\u03bd\u03c5\u03c8\u03b3;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be;
import com.nickuc.login.\u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03b7\u03bb\u03a3\u03c1\u03b7\u039b\u03c1\u03bb\u03a8\u03b2\u03c7\u03bb;
import com.nickuc.login.\u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u03bd\u03c1\u03c9\u03ba\u03bb\u03b1\u0393\u03c2\u03c3\u03bb\u03b6\u03c2\u03a3;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.io.File;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4
implements \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<Object>,
\u03c8\u03bd\u03c1\u03c9\u03ba\u03bb\u03b1\u0393\u03c2\u03c3\u03bb\u03b6\u03c2\u03a3 {
    private static long k;
    private static long e;
    private static int l;
    private static long h;
    private static int g;
    private static int f;
    private static long c;
    private static String[] b;
    private static int a;
    private static long j;
    private static String[] a;
    private static int c;
    private static int i;
    private static int d;
    private static int m;
    private static long b;
    protected \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?> a;

    public void j() {
    }

    public void i() {
    }

    public void T() {
    }

    @Override
    public \u03c0\u03b7\u03bb\u03a3\u03c1\u03b7\u039b\u03c1\u03bb\u03a8\u03b2\u03c7\u03bb a() {
        return this.a.a();
    }

    public void O() {
    }

    @Override
    public \u03b8\u03b1\u03a9\u03a6\u03bd\u03c5\u03c8\u03b3 b() {
        return this.a.b();
    }

    @Override
    public <T> T c() {
        return this.a;
    }

    public \u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6[] a() {
        return this.a().a();
    }

    @Override
    public void a(\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<?> \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be2, \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<?> ... \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03beArray) {
        this.a.a(\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be2, \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03beArray);
    }

    @Override
    public void a(\u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393 \u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u03932, \u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393 ... \u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393Array) {
        this.a.a(\u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u03932, \u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393Array);
    }

    private static void b() {
        int n;
        c = 6810531326901206061L;
        long l = c ^ 0x2750A45576D22C46L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(35 + 34), (byte)(65 + 18), (byte)(11 + 36), (byte)(11 + 56), (byte)(30 + 36), (byte)(6 + 61), (byte)(34 + 13), (byte)(65 + 15), (byte)(5 + 70), (byte)(24 + 43), (byte)(62 + 21), (byte)(47 + 6), (byte)(41 + 39), (byte)(41 + 56), 100, (byte)(87 + 13), (byte)(43 + 62), (byte)(98 + 12), (byte)(71 + 32)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(17 + 52), (byte)(34 + 49)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.b[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u01ae\u01b7\u01dd\u01d5\u019d\u01dc\u01af\u01d7\u01a0\u01da\u01b2\u01ab", (byte)114, 66);
                    \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.b[1] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.E("\u057f\u0589\u0596\u055c\u0576\u0562\u05a2\u059c\u0589\u0591\u059b\u0576", (byte)114, 69);
                    \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.b[2] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.E("\u0572\u0596\u0593\u057d\u0582\u0578\u059d\u058e\u056a\u0582\u056a\u0564\u058c\u05b4\u0596\u05a6\u058c\u0577\u0576\u05b6\u059b\u05ba\u0581\u0582", (byte)114, 69);
                    \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.b[3] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u0582\u0582\u0552\u0575\u0562\u0571\u0549\u0560\u0568\u054a\u0562\u0553", (byte)114, 67);
                    continue block7;
                }
                case 1: {
                    \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u0551\u0561\u057d\u0550\u0563\u0580\u0553\u056c\u0583\u056a\u0562\u0553", (byte)114, 67);
                    \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.b[1] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u05a5\u05a7\u0577\u0592\u058c\u0589\u0564\u057a\u0598\u05b0\u058d\u0576", (byte)114, 70);
                    \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.b[2] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u054f\u0573\u0570\u055a\u055f\u0555\u057a\u056b\u0547\u055f\u0545\u0569\u0548\u0560\u058d\u055f\u0568\u0567\u058a\u0597\u056f\u0597\u055e\u055f", (byte)114, 67);
                    \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.b[3] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u0581\u055f\u057b\u0570\u057e\u055d\u0547\u0541\u0565\u0556\u057c\u0553", (byte)114, 67);
                    continue block7;
                }
                case 2: {
                    \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u0594\u0584\u0583\u0599\u059f\u0595\u059e\u059e\u05ad\u057b\u056b\u05b2\u0582\u0574\u0595\u05b0\u0593\u05aa\u0577\u0586\u0591\u05a6\u05a5\u057a\u05b4\u05ae\u05ae\u059a\u0597\u05b5\u0581\u0594", (byte)114, 69);
                    continue block7;
                }
                case 4: {
                    \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u0570\u053d\u0575\u0553\u0585\u0540\u0584\u0565\u0566\u0548\u0566\u058a\u0549\u0562\u056f\u0568\u056d\u0582\u0581\u0554\u0556\u0571\u055e\u055f", (byte)114, 67);
                }
            }
        }
    }

    @Override
    public <T extends \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4> T b() {
        return (T)this;
    }

    @Override
    public \u03a8\u03a9\u0394\u03be\u03b4\u03ba\u039b\u03c8\u03c8\u03ba\u03c6\u03b4 a() {
        return this.a.a();
    }

    @Override
    public \u03a0\u03b6\u03a3\u03a8\u03b1\u03a9\u03c8\u03bf\u03b7\u03b9\u03b7\u0393\u0393 a() {
        return this.a.a();
    }

    @Override
    public String q() {
        return this.a.q();
    }

    @Override
    public void c() {
        this.a.c();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u0548\u056a\u056c\u054c\u0570\u058f\u0587\u059d\u0589\u0558\u0596\u058c\u059a\u0594\u055d\u0582\u05a4\u05a3\u059b\u05a1\u059b\u0570", (byte)100, 69), \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u0583\u0590\u058f\u0552\u0592\u058e\u0589\u0592\u059d\u058c\u0559\u0597\u059b\u0594\u0597\u059d\u055f\u08c4\u08e6\u08fb\u08dd\u08ef\u08e7\u08eb\u08ec\u08f5\u08f1\u08ed\u0902\u0902\u08f2\u0579", (byte)100, 70) + string + \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u051b", (byte)100, 68) + methodType.toString(), exception);
        }
    }

    void a(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?> \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42) {
        this.a = (int)\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42;
    }

    private static String a(int n, long l) {
        l ^= 0x3BL;
        l ^= 0x2750A45576D22C46L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(47 + 21), (byte)(17 + 52), (byte)(45 + 38), (byte)(24 + 23), (byte)(43 + 24), (byte)(57 + 9), 67, 47, (byte)(38 + 42), (byte)(9 + 66), (byte)(4 + 63), (byte)(2 + 81), (byte)(51 + 2), (byte)(16 + 64), (byte)(65 + 32), (byte)(37 + 63), (byte)(57 + 43), (byte)(40 + 65), (byte)(40 + 70), (byte)(75 + 28)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(34 + 49)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.D("\u04d2\u04df\u04de\u04a1\u04e1\u04dd\u04d8\u04e1\u04ec\u04db\u04a8\u04e6\u04ea\u04e3\u04e6\u04ec\u04ae\u0813\u0835\u084a\u082c\u083e\u0836\u083a\u083b\u0844\u0840\u083c\u0851\u0851\u0841", (byte)62, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public boolean N() {
        return this.a.N();
    }

    @Generated
    public \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4() {
    }

    @Override
    public \u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9 b(boolean bl) {
        return this.a.b(bl);
    }

    @Override
    public Object b() {
        return this.a.b();
    }

    @Override
    public \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3 b() {
        return this.a.b();
    }

    @Override
    public Object a(int n) {
        return this.a.a(n);
    }

    @Override
    public File c() {
        return this.a.c();
    }

    public String toString() {
        return this.a.q() + (String)\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.c("\u3e80", (int)a, (long)b) + this.a.s() + (String)(this.a.a() == null ? \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.c("\u3e83", (int)(c & d), (long)e) : (String)\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.c("\u3e86", (int)(f & g), (long)h) + this.a.a().G() + (String)\u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.c("\u3e89", (int)i, (long)(j ^ k)));
    }

    @Override
    public String s() {
        return this.a.s();
    }

    static {
        a = 0 >>> 92 | 0 << ~92 + 1;
        b = Long.reverse(7511364185720865146L);
        c = Integer.reverse(Integer.MIN_VALUE);
        d = Integer.reverse(-1);
        e = Long.reverse(7511364185720865146L);
        f = 32 >>> 196 | 32 << ~196 + 1;
        g = (-1 >>> 122 | -1 << ~122 + 1) & 0xFFFFFFFF;
        h = Long.reverse(7511364185720865146L);
        i = Integer.reverse(-1073741824);
        j = Long.reverse(-5459002741106163334L);
        k = Long.reverse(-2594073385365405696L);
        l = (8 >>> 33 | 8 << ~33 + 1) & 0xFFFFFFFF;
        m = (1 >>> 30 | 1 << -30) & 0xFFFFFFFF;
        a = new String[l];
        b = new String[m];
        \u0393\u03b4\u03c8\u03a9\u03ba\u03b1\u03b4\u03b4\u03bc\u03b7\u03b2\u03c6\u03c5\u03b4.b();
    }
}

