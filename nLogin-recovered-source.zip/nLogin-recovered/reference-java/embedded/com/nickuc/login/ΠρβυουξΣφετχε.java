/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  lombok.Generated
 *  org.bukkit.Server
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginDescriptionFile
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6;
import com.nickuc.login.\u03a3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b5\u03b7\u03b7\u03bd\u03bc\u03b3\u03c5\u03a9\u03b1\u03b3;
import com.nickuc.login.\u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2;
import com.nickuc.login.\u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a8;
import com.nickuc.login.\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be;
import com.nickuc.login.\u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393;
import com.nickuc.login.\u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1;
import com.nickuc.login.\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3;
import com.nickuc.login.\u03c9\u0394\u03c4\u03b6\u03c7\u03b9\u03b1\u03c5\u0394\u03c4;
import com.nickuc.login.\u03c9\u039b\u03c3\u03a6\u0394\u03c4\u03b2\u03c9\u03c5\u03c5\u03c4\u03b8\u03b8\u0393\u03c5;
import java.nio.file.Path;
import java.util.Collection;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import lombok.Generated;
import org.bukkit.Server;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginDescriptionFile;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03a0\u03c1\u03b2\u03c5\u03bf\u03c5\u03be\u03a3\u03c6\u03b5\u03c4\u03c7\u03b5
implements \u03c9\u0394\u03c4\u03b6\u03c7\u03b9\u03b1\u03c5\u0394\u03c4 {
    private final \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393 d;
    private final \u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a8 a;
    private static int b;
    private static int d;
    private static int a;
    private static int c;
    private final Server f;

    @Override
    public \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 a(Object object) {
        return \u03a8\u03b5\u03b7\u03b7\u03bd\u03bc\u03b3\u03c5\u03a9\u03b1\u03b3.a(this.d, this.f, object);
    }

    @Override
    public <T> T c() {
        return (T)this.f;
    }

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = Integer.reverse(0);
        c = (0 >>> 60 | 0 << ~60 + 1) & 0xFFFFFFFF;
        d = (0 >>> 200 | 0 << ~200 + 1) & 0xFFFFFFFF;
    }

    @Override
    @Nullable
    public \u03c9\u039b\u03c3\u03a6\u0394\u03c4\u03b2\u03c9\u03c5\u03c5\u03c4\u03b8\u03b8\u0393\u03c5 a(String string) {
        Plugin plugin = this.f.getPluginManager().getPlugin(string);
        if (plugin == null) {
            return null;
        }
        PluginDescriptionFile pluginDescriptionFile = plugin.getDescription();
        return new \u03c9\u039b\u03c3\u03a6\u0394\u03c4\u03b2\u03c9\u03c5\u03c5\u03c4\u03b8\u03b8\u0393\u03c5(plugin.getName(), pluginDescriptionFile != null ? pluginDescriptionFile.getVersion() : null, plugin);
    }

    @Override
    public Collection<\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6> c() {
        return \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.d().stream().map(this::a).collect(Collectors.toList());
    }

    @Override
    public \u03a3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4[] a() {
        Plugin[] pluginArray = this.f.getPluginManager().getPlugins();
        \u03a3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4[] \u03c3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4Array = new \u03a3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4[pluginArray.length];
        int n = c;
        Plugin[] pluginArray2 = pluginArray;
        int n2 = pluginArray2.length;
        for (int i = d; i < n2; ++i) {
            Path path;
            Plugin plugin = pluginArray2[i];
            PluginDescriptionFile pluginDescriptionFile = plugin.getDescription();
            try {
                path = \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.a(plugin.getClass()).toPath();
            }
            catch (Exception exception) {
                path = null;
            }
            \u03c3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4Array[n++] = new \u03a3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4(plugin.getName(), pluginDescriptionFile.getVersion(), pluginDescriptionFile.getAuthors(), path);
        }
        return \u03c3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4Array;
    }

    @Generated
    public \u03a0\u03c1\u03b2\u03c5\u03bf\u03c5\u03be\u03a3\u03c6\u03b5\u03c4\u03c7\u03b5(\u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393 \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u03932, Server server, \u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a8 \u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a82) {
        this.d = \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u03932;
        this.f = server;
        this.a = \u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a82;
    }

    @Override
    public boolean j(String string) {
        return (this.f.getPluginManager().getPlugin(string) != null ? a : b) != 0;
    }

    @Override
    public \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 a(String string) {
        return \u03a8\u03b5\u03b7\u03b7\u03bd\u03bc\u03b3\u03c5\u03a9\u03b1\u03b3.a(this.d, this.f, string);
    }

    @Override
    public \u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1 a(\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<?> \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be2) {
        return new \u03b3\u03c0\u03b5\u03c5\u03a6\u039b\u03b9\u03b9\u03b7\u03b8\u03c2(this.f, \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be2);
    }

    @Override
    public \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 a(UUID uUID) {
        Player player = this.f.getPlayer(uUID);
        return player != null ? this.a(player) : null;
    }

    @Override
    @Generated
    public \u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a8 a() {
        return this.a;
    }

    @Override
    public void c() {
        this.f.shutdown();
    }
}

