/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03b9\u03a8\u03c6\u03b1\u03c1\u03b5\u03bb\u03a3\u03b6\u03a0\u0394\u03a9;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b6\u039b\u03b6\u03ba\u03b5\u03a3\u0394\u03c1\u03b2
implements \u03b9\u03a8\u03c6\u03b1\u03c1\u03b5\u03bb\u03a3\u03b6\u03a0\u0394\u03a9,
\u03ba\u0393\u03a6\u03bd\u03ba\u03c7\u03b2\u03b4 {
    private static String[] a;
    private static long c;
    private static int c;
    private static int h;
    private static int f;
    private static int e;
    private static String[] b;
    private final \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 X;
    private static int a;
    private static int b;
    private static long d;
    private static int g;

    static {
        a = 0x20000000 >>> 253 | 0x20000000 << -253;
        b = Integer.reverse(0);
        c = 0 >>> 166 | 0 << ~166 + 1;
        d = Long.reverse(2203358734602896728L);
        e = (32768 >>> 239 | 32768 << -239) & 0xFFFFFFFF;
        f = 0 >>> 135 | 0 << ~135 + 1;
        g = 0x200000 >>> 149 | 0x200000 << -149;
        h = Integer.reverse(Integer.MIN_VALUE);
        a = new String[g];
        b = new String[h];
        \u03b6\u039b\u03b6\u03ba\u03b5\u03a3\u0394\u03c1\u03b2.b();
    }

    private static String a(int n, long l) {
        l ^= 0x77L;
        l ^= 0xB84CBA936E8DA50L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(30 + 38), (byte)(61 + 8), (byte)(55 + 28), 47, (byte)(37 + 30), (byte)(53 + 13), (byte)(51 + 16), (byte)(11 + 36), (byte)(23 + 57), (byte)(17 + 58), (byte)(24 + 43), (byte)(12 + 71), (byte)(43 + 10), (byte)(75 + 5), (byte)(31 + 66), (byte)(93 + 7), (byte)(39 + 61), (byte)(50 + 55), (byte)(97 + 13), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(9 + 59), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.C("\u050e\u051b\u051a\u04dd\u051d\u0519\u0514\u051d\u0528\u0517\u04e4\u0522\u0526\u051f\u0522\u0528\u04ea\u0872\u0858\u0874\u0879\u0875\u0864\u0856\u0884\u0876", (byte)82, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b6\u039b\u03b6\u03ba\u03b5\u03a3\u0394\u03c1\u03b2.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public boolean a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42) {
        return \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6.a().p();
    }

    private static void b() {
        int n;
        c = 1918888609703250191L;
        long l = c ^ 0xB84CBA936E8DA50L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(51 + 17), (byte)(10 + 59), (byte)(75 + 8), (byte)(27 + 20), (byte)(48 + 19), 66, (byte)(31 + 36), (byte)(31 + 16), (byte)(59 + 21), (byte)(27 + 48), (byte)(29 + 38), (byte)(74 + 9), (byte)(35 + 18), (byte)(48 + 32), (byte)(8 + 89), 100, (byte)(90 + 10), (byte)(25 + 80), (byte)(60 + 50), (byte)(7 + 96)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(67 + 1), (byte)(66 + 3), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b6\u039b\u03b6\u03ba\u03b5\u03a3\u0394\u03c1\u03b2.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.D("\u04ea\u04c4\u04b2\u04e5\u04be\u04eb\u04df\u04e9\u04d5\u04ec\u04f4\u04d9\u04e9\u04ea\u04cd\u04bc\u04bd\u04f2\u04e4\u04fc\u04d6\u04f6\u04d0\u04e8\u04f4\u04f7\u04c5\u04c4\u04e1\u0501\u0502\u0510", (byte)65, 68);
                    continue block7;
                }
                case 1: {
                    \u03b6\u039b\u03b6\u03ba\u03b5\u03a3\u0394\u03c1\u03b2.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.A("\u0173\u014d\u013b\u016e\u0147\u0174\u0168\u0172\u015e\u0175\u017d\u0162\u0172\u0173\u0156\u0145\u0146\u017b\u016d\u0185\u015f\u018c\u014b\u0186\u0163\u0145\u016a\u016d\u014d\u0156\u018a\u0150\u0193\u0198\u0198\u0193\u016b\u019a\u0196\u0195\u0161\u015d\u019e\u0169", (byte)65, 65);
                    continue block7;
                }
                case 2: {
                    \u03b6\u039b\u03b6\u03ba\u03b5\u03a3\u0394\u03c1\u03b2.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u054c\u0554\u0576\u0573\u0565\u0567\u055b\u053b\u0535\u0569\u0554\u0572\u053e\u056d\u0571\u056e\u057e\u0551\u0576\u0559\u0561\u0553\u0550\u0551", (byte)65, 70);
                    continue block7;
                }
                case 4: {
                    \u03b6\u039b\u03b6\u03ba\u03b5\u03a3\u0394\u03c1\u03b2.b[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u0534\u0544\u0574\u0565\u0555\u0536\u0532\u0574\u0575\u0550\u053b\u0545", (byte)65, 69);
                }
            }
        }
    }

    @Override
    public \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6[] a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c5 \u03c0\u03b1\u03b1\u0394\u03a3\u03bd\u03a8\u03b3\u03bd\u03b8\u03c52) {
        Object[] objectArray = new Object[a];
        objectArray[\u03b6\u039b\u03b6\u03ba\u03b5\u03a3\u0394\u03c1\u03b2.b] = \u03b6\u039b\u03b6\u03ba\u03b5\u03a3\u0394\u03c1\u03b2.c("\u3e80", (int)c, (long)d);
        \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b5\u03c5\u03c4\u03b2\u03c0\u03b1\u03c8\u03c9.v, objectArray);
        \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[] \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array = new \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7[e];
        \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array[\u03b6\u039b\u03b6\u03ba\u03b5\u03a3\u0394\u03c1\u03b2.f] = \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.a;
        return \u03b1\u03a0\u03b1\u03b2\u03c3\u03a0\u03c4\u03a6.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7Array);
    }

    @Generated
    public \u03b6\u039b\u03b6\u03ba\u03b5\u03a3\u0394\u03c1\u03b2(\u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4) {
        this.X = \u03c9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4;
    }

    @Override
    @Generated
    public \u03a9\u03b3\u039b\u03be\u03b9\u03c7\u03b3\u03c4 a() {
        return this.X;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b6\u039b\u03b6\u03ba\u03b5\u03a3\u0394\u03c1\u03b2.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0473\u0495\u0497\u0477\u049b\u04ba\u04b2\u04c8\u04b4\u0483\u04c1\u04b7\u04c5\u04bf\u0488\u04ad\u04cf\u04ce\u04c6\u04cc\u04c6\u049b", (byte)50, 67), \u03b6\u039b\u03b6\u03ba\u03b5\u03a3\u0394\u03c1\u03b2.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u0551\u055e\u055d\u0520\u0560\u055c\u0557\u0560\u056b\u055a\u0527\u0565\u0569\u0562\u0565\u056b\u052d\u08b5\u089b\u08b7\u08bc\u08b8\u08a7\u0899\u08c7\u08b9\u0542", (byte)50, 69) + string + \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u011d", (byte)50, 65) + methodType.toString(), exception);
        }
    }
}

