/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.velocitypowered.api.proxy.ProxyServer
 *  com.velocitypowered.api.proxy.server.ServerInfo
 *  com.velocitypowered.api.util.ProxyVersion
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a0\u03b5\u03b7\u03a0\u03b3\u03b1\u03c2\u03b3\u03c4\u03b6\u03bb\u03c7\u03c6\u03be;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u03a9\u0394\u03be\u03b4\u03ba\u039b\u03c8\u03c8\u03ba\u03c6\u03b4;
import com.nickuc.login.\u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394;
import com.nickuc.login.\u03b2\u039b\u03b2\u03b5\u03bb\u039b\u03c7\u03b9\u03c9;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b6\u03b8\u03c7\u03b6\u03bd\u0393\u03b6\u03c2\u03b4\u03b6\u03b8\u03b1\u03a9;
import com.nickuc.login.\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3;
import com.nickuc.login.\u03b8\u03b1\u03a9\u03a6\u03bd\u03c5\u03c8\u03b3;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9;
import com.nickuc.login.\u03bd\u03c9\u03b4\u03a0\u039b\u03c3\u03bc\u03bc\u03c6\u03b6\u03ba\u03a0;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c8\u0394\u03c6\u03a3\u03a6\u03a6\u03a9\u03c0\u03b7\u03b3\u03bf\u03a0\u03b6;
import com.nickuc.login.\u03c9\u0394\u03c4\u03b6\u03c7\u03b9\u03b1\u03c5\u0394\u03c4;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.server.ServerInfo;
import com.velocitypowered.api.util.ProxyVersion;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc
implements \u03a8\u03a9\u0394\u03be\u03b4\u03ba\u039b\u03c8\u03c8\u03ba\u03c6\u03b4 {
    private static String[] a;
    private static int o;
    private static long c;
    private static int a;
    private static String[] b;
    private static int r;
    private final \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9 a;
    private static int k;
    private static int c;
    private static long l;
    private static int d;
    private static long m;
    private static int n;
    private static long e;
    private static int q;
    private static int f;
    private static int h;
    private static long j;
    private static int b;
    private static int i;
    private static long g;
    private static long p;

    @Override
    public void U() {
        \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.a(this.a, a != 0, b != 0);
    }

    @Override
    public \u03c9\u0394\u03c4\u03b6\u03c7\u03b9\u03b1\u03c5\u0394\u03c4 a() {
        ProxyServer proxyServer = this.a.a();
        return new \u03a0\u03b5\u03b7\u03a0\u03b3\u03b1\u03c2\u03b3\u03c4\u03b6\u03bb\u03c7\u03c6\u03be(this.a, proxyServer, \u03bd\u03c9\u03b4\u03a0\u039b\u03c3\u03bc\u03bc\u03c6\u03b6\u03ba\u03a0.a(proxyServer, proxyServer.getConsoleCommandSource()));
    }

    @Override
    public void i() {
        this.a.i();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u0145\u0167\u0169\u0149\u016d\u018c\u0184\u019a\u0186\u0155\u0193\u0189\u0197\u0191\u015a\u017f\u01a1\u01a0\u0198\u019e\u0198\u016d", (byte)79, 66), \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u0505\u0512\u0511\u04d4\u0514\u0510\u050b\u0514\u051f\u050e\u04db\u0519\u051d\u0516\u0519\u051f\u04e1\u0868\u0866\u086d\u0871\u086a\u0853\u0880\u0871\u0877\u04f6", (byte)79, 67) + string + \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u0545", (byte)79, 69) + methodType.toString(), exception);
        }
    }

    @Override
    public \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3 a() {
        ProxyVersion proxyVersion = this.a.a().getVersion();
        return new \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3(proxyVersion.getName(), proxyVersion.getVersion(), proxyVersion.getVersion() + (String)\u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.c("\u3e80", (int)(c & d), (long)e) + proxyVersion.getVendor() + (String)\u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.c("\u3e83", (int)f, (long)g), \u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.d, h != 0);
    }

    @Override
    public void j() {
        this.a.j();
    }

    private static void b() {
        int n;
        c = -1333270030331653612L;
        long l = c ^ 0xC18F805408BD73DBL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(42 + 26), (byte)(56 + 13), (byte)(59 + 24), (byte)(7 + 40), (byte)(52 + 15), (byte)(44 + 22), 67, (byte)(24 + 23), 80, (byte)(43 + 32), (byte)(10 + 57), (byte)(19 + 64), (byte)(4 + 49), (byte)(46 + 34), (byte)(20 + 77), (byte)(20 + 80), (byte)(96 + 4), (byte)(53 + 52), (byte)(9 + 101), (byte)(98 + 5)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(57 + 26)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u014f\u014f\u0168\u014d\u0156\u0176\u017f\u0174\u0175\u017d\u0186\u014d", (byte)67, 66);
                    \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.b[1] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u0158\u013c\u015b\u0139\u0180\u0171\u0183\u0160\u0181\u0186\u0150\u014d", (byte)67, 65);
                    \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.b[2] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.B("\u015c\u017f\u015f\u0175\u0151\u016e\u013b\u015b\u0153\u0163\u015c\u0151\u0176\u0159\u014b\u018d\u015b\u015a\u0148\u0161\u014a\u016b\u0158\u0159", (byte)67, 66);
                    \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.b[3] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.C("\u04a9\u04c9\u04f5\u04ba\u04cf\u04eb\u04f6\u04cb\u04c7\u04ea\u04cd\u04c6", (byte)67, 67);
                    \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.b[4] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.D("\u04ec\u04e6\u04f0\u04ee\u04fc\u04b9\u04fc\u04fe\u04ed\u04df\u04bc\u04c6", (byte)67, 68);
                    continue block7;
                }
                case 1: {
                    \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u0577\u0536\u0565\u054f\u052e\u055e\u0551\u055c\u0553\u054d\u055a\u0547", (byte)67, 69);
                    \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.b[1] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u04e0\u04e7\u04d6\u04d9\u04d3\u04e9\u04fd\u04ff\u04d0\u0501\u04b8\u04c6", (byte)67, 67);
                    \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.b[2] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.B("\u015c\u017f\u015f\u0175\u0151\u016e\u013b\u015b\u0153\u0163\u015e\u0160\u0149\u0158\u016d\u018a\u0156\u0157\u017b\u016d\u015a\u016b\u0158\u0159", (byte)67, 66);
                    \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.b[3] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.C("\u04c7\u04d8\u04e9\u04cb\u04c9\u04b6\u04d8\u04c7\u04d2\u04d1\u04ef\u04c6", (byte)67, 67);
                    \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.b[4] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.B("\u013d\u014d\u0180\u0138\u015d\u0139\u0157\u015c\u017a\u0183\u0186\u014d", (byte)67, 66);
                    continue block7;
                }
                case 2: {
                    \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.b[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0548\u0548\u0563\u052d\u053c\u055c\u053e\u057c\u0571\u054c\u056b\u0573\u0551\u0556\u0585\u0577\u0558\u055e\u054a\u057a\u058a\u0564\u0548\u0578\u0581\u0589\u055d\u0565\u0574\u0594\u0575\u057f", (byte)67, 70);
                    continue block7;
                }
                case 4: {
                    \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u054b\u0553\u0568\u0534\u054e\u0536\u0578\u0579\u0536\u055f\u0580\u0547", (byte)67, 69);
                }
            }
        }
    }

    @Override
    public \u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6[] a() {
        return this.a.a();
    }

    @Override
    public \u03b8\u03b1\u03a9\u03a6\u03bd\u03c5\u03c8\u03b3 a() {
        return new \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394(this.a);
    }

    @Override
    public \u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393 b() {
        return new \u03b6\u03b8\u03c7\u03b6\u03bd\u0393\u03b6\u03c2\u03b4\u03b6\u03b8\u03b1\u03a9(this.a, this.a.a());
    }

    @Override
    public boolean e(String string) {
        return n != 0;
    }

    @Generated
    public \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc(\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9 \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a92) {
        this.a = \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a92;
    }

    static {
        a = (0 >>> 25 | 0 << -25) & 0xFFFFFFFF;
        b = 0 >>> 127 | 0 << ~127 + 1;
        c = 0 >>> 248 | 0 << ~248 + 1;
        d = Integer.reverse(-1);
        e = Long.reverse(-7761366590399775049L);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Long.reverse(-7761366590399775049L);
        h = 0 >>> 203 | 0 << ~203 + 1;
        i = (65536 >>> 47 | 65536 << -47) & 0xFFFFFFFF;
        j = Long.reverse(-7761366590399775049L);
        k = Integer.reverse(-1073741824);
        l = Long.reverse(2903157327213559479L);
        m = Long.reverse(-4899916394579099648L);
        n = 0 >>> 46 | 0 << -46;
        o = (Integer.MIN_VALUE >>> 189 | Integer.MIN_VALUE << -189) & 0xFFFFFFFF;
        p = Long.reverse(-7761366590399775049L);
        q = 20 >>> 226 | 20 << ~226 + 1;
        r = Integer.reverse(-1610612736);
        a = new String[q];
        b = new String[r];
        \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.b();
    }

    @Override
    public void V() {
        try {
            Collection collection = this.a.a().getAllServers();
            if (collection != null && !collection.isEmpty()) {
                List list = collection.stream().map(registeredServer -> {
                    ServerInfo serverInfo = registeredServer.getServerInfo();
                    return serverInfo.getName() + (String)\u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.c("\u3e80", (int)o, (long)p) + serverInfo.getAddress();
                }).collect(Collectors.toList());
                this.a.c.a().a().a((String)\u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.c("\u3e80", (int)i, (long)j), String.join((CharSequence)\u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.c("\u3e83", (int)k, (long)(l ^ m)), list));
            }
        }
        catch (NoSuchMethodError noSuchMethodError) {
            // empty catch block
        }
    }

    private static String a(int n, long l) {
        l ^= 0x3DL;
        l ^= 0xC18F805408BD73DBL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(64 + 4), (byte)(53 + 16), (byte)(62 + 21), (byte)(38 + 9), (byte)(54 + 13), 66, (byte)(65 + 2), (byte)(33 + 14), (byte)(71 + 9), (byte)(39 + 36), (byte)(19 + 48), (byte)(36 + 47), (byte)(50 + 3), 80, (byte)(86 + 11), (byte)(26 + 74), (byte)(70 + 30), (byte)(83 + 22), (byte)(34 + 76), (byte)(94 + 9)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(8 + 60), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.F("\u054e\u055b\u055a\u051d\u055d\u0559\u0554\u055d\u0568\u0557\u0524\u0562\u0566\u055f\u0562\u0568\u052a\u08b1\u08af\u08b6\u08ba\u08b3\u089c\u08c9\u08ba\u08c0", (byte)47, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b5\u03b2\u03b8\u03bb\u03b3\u039b\u03c7\u03b7\u03bc.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public void T() {
        this.a.T();
    }

    @Override
    public \u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9 a(boolean bl) {
        return new \u03b2\u039b\u03b2\u03b5\u03bb\u039b\u03c7\u03b9\u03c9(this.a.a());
    }

    @Override
    public \u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393 a() {
        return new \u03c8\u0394\u03c6\u03a3\u03a6\u03a6\u03a9\u03c0\u03b7\u03b3\u03bf\u03a0\u03b6(this.a);
    }

    @Override
    public void O() {
        this.a.O();
    }
}

