/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03be\u03b5\u03c4\u03c6\u0394\u03bf\u03a9\u03c8\u03bd\u03b5;

public interface \u03bb\u03b9\u03bc\u03c1\u03b9\u03b3\u03b4\u03b2\u03c8
extends \u03be\u03b5\u03c4\u03c6\u0394\u03bf\u03a9\u03c8\u03bd\u03b5 {
    @Override
    default public boolean v(String string) {
        return false;
    }

    @Override
    default public String w(String string) {
        throw new UnsupportedOperationException();
    }
}

