/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.CheckReturnValue
 *  javax.annotation.Nullable
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.annotation.CheckReturnValue;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bf\u03a8\u03b7\u03bc\u03b6\u03be\u03be\u03bd\u03c2 {
    private static String[] b;
    private static long b;
    private static long c;
    private static int f;
    private static int a;
    private static int e;
    private static String[] a;
    private static long d;

    static {
        a = Integer.reverse(0);
        b = Long.reverse(-4256075588424761561L);
        d = Long.reverse(-864691128455135232L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Integer.reverse(Integer.MIN_VALUE);
        a = new String[e];
        b = new String[f];
        \u03bf\u03a8\u03b7\u03bc\u03b6\u03be\u03be\u03bd\u03c2.b();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bf\u03a8\u03b7\u03bc\u03b6\u03be\u03be\u03bd\u03c2.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u052c\u054e\u0550\u0530\u0554\u0573\u056b\u0581\u056d\u053c\u057a\u0570\u057e\u0578\u0541\u0566\u0588\u0587\u057f\u0585\u057f\u0554", (byte)72, 69), \u03bf\u03a8\u03b7\u03bc\u03b6\u03be\u03be\u03bd\u03c2.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.F("\u0567\u0574\u0573\u0536\u0576\u0572\u056d\u0576\u0581\u0570\u053d\u057b\u057f\u0578\u057b\u0581\u0543\u08d4\u08be\u08ce\u08d4\u08cf\u08d8\u08d9\u08d9\u08df\u0558", (byte)72, 70) + string + \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.D("\u04c7", (byte)72, 68) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x2FL;
        l ^= 0xB67902286D937C6AL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(4 + 64), (byte)(11 + 58), (byte)(26 + 57), 47, (byte)(63 + 4), (byte)(42 + 24), (byte)(5 + 62), (byte)(44 + 3), (byte)(37 + 43), (byte)(34 + 41), (byte)(23 + 44), 83, (byte)(29 + 24), (byte)(37 + 43), (byte)(41 + 56), (byte)(76 + 24), (byte)(28 + 72), (byte)(77 + 28), (byte)(106 + 4), (byte)(13 + 90)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(23 + 60)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.A("\u01c6\u01d3\u01d2\u0195\u01d5\u01d1\u01cc\u01d5\u01e0\u01cf\u019c\u01da\u01de\u01d7\u01da\u01e0\u01a2\u0533\u051d\u052d\u0533\u052e\u0537\u0538\u0538\u053e", (byte)114, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bf\u03a8\u03b7\u03bc\u03b6\u03be\u03be\u03bd\u03c2.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static void b() {
        int n;
        c = -1945733766781143261L;
        long l = c ^ 0xB67902286D937C6AL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(31 + 37), (byte)(27 + 42), (byte)(18 + 65), (byte)(28 + 19), (byte)(19 + 48), (byte)(52 + 14), (byte)(33 + 34), (byte)(5 + 42), (byte)(25 + 55), (byte)(37 + 38), (byte)(51 + 16), (byte)(71 + 12), (byte)(26 + 27), 80, (byte)(64 + 33), 100, (byte)(79 + 21), (byte)(7 + 98), (byte)(100 + 10), (byte)(58 + 45)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(65 + 4), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bf\u03a8\u03b7\u03bc\u03b6\u03be\u03be\u03bd\u03c2.b[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u053c\u057c\u058b\u057f\u0557\u0546\u0548\u0549\u054b\u055c\u0583\u0572\u0597\u0585\u0550\u0596\u0562\u0566\u0577\u0589\u0572\u059d\u0564\u0565", (byte)85, 70);
                    continue block7;
                }
                case 1: {
                    \u03bf\u03a8\u03b7\u03bc\u03b6\u03be\u03be\u03bd\u03c2.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.C("\u04df\u051f\u052e\u0522\u04fa\u04e9\u04eb\u04ec\u04ee\u04ff\u0527\u050b\u0536\u0512\u0535\u052b\u04ef\u0518\u0540\u050d\u050b\u050e\u0522\u0540\u052d\u0523\u0531\u053e\u0518\u0500\u0536\u051a", (byte)85, 67);
                    continue block7;
                }
                case 2: {
                    \u03bf\u03a8\u03b7\u03bc\u03b6\u03be\u03be\u03bd\u03c2.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u04e8\u0528\u04e8\u04fb\u04fd\u050a\u04eb\u0504\u04f0\u052f\u050f\u04fc", (byte)85, 67);
                    continue block7;
                }
                case 4: {
                    \u03bf\u03a8\u03b7\u03bc\u03b6\u03be\u03be\u03bd\u03c2.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.C("\u04fe\u052d\u050d\u0520\u050c\u051b\u051d\u0534\u0501\u0506\u0503\u0513\u0505\u051a\u0533\u04fb\u053b\u050e\u04fc\u0520\u0531\u051a\u0507\u0508", (byte)85, 67);
                }
            }
        }
    }

    @CheckReturnValue
    @Nullable
    public Location a(DataInputStream dataInputStream) {
        String string = dataInputStream.readUTF();
        double d = dataInputStream.readDouble();
        double d2 = dataInputStream.readDouble();
        double d3 = dataInputStream.readDouble();
        float f = dataInputStream.readFloat();
        float f2 = dataInputStream.readFloat();
        World world = Bukkit.getServer().getWorld(string);
        return world != null ? new Location(world, d, d2, d3, f, f2) : null;
    }

    public void a(Location location, DataOutputStream dataOutputStream) {
        World world = location.getWorld();
        if (world == null) {
            throw new IllegalArgumentException((String)\u03bf\u03a8\u03b7\u03bc\u03b6\u03be\u03be\u03bd\u03c2.c("\u3e80", (int)a, (long)(b ^ d)));
        }
        dataOutputStream.writeUTF(world.getName());
        dataOutputStream.writeDouble(location.getX());
        dataOutputStream.writeDouble(location.getY());
        dataOutputStream.writeDouble(location.getZ());
        dataOutputStream.writeFloat(location.getYaw());
        dataOutputStream.writeFloat(location.getPitch());
    }
}

