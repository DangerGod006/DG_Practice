/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7;

class \u03bc\u03b7\u03c3\u03b2\u03b2\u03bd\u03a3\u03bd\u03bd {
    private static int b;
    static final /* synthetic */ int[] ae;
    private static int a;

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = Integer.reverse(0x40000000);
        ae = new int[\u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.values().length];
        try {
            \u03bc\u03b7\u03c3\u03b2\u03b2\u03bd\u03a3\u03bd\u03bd.ae[\u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.b.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03bc\u03b7\u03c3\u03b2\u03b2\u03bd\u03a3\u03bd\u03bd.ae[\u03b8\u03bd\u039b\u03c9\u0394\u03c0\u03b2\u03c8\u03bc\u03b1\u03c5\u039b\u03c5\u03b5\u03c7.c.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

