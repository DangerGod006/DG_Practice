/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent
 *  com.nickuc.login.lib.packetevents.api.event.PacketSendEvent
 *  io.netty.channel.Channel
 */
package com.nickuc.login;

import com.nickuc.login.lib.packetevents.api.event.PacketReceiveEvent;
import com.nickuc.login.lib.packetevents.api.event.PacketSendEvent;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a0\u03b2\u03c0\u03c0\u0393\u03c9\u039b\u03a6\u03c5\u03b2\u03a9\u03bc\u0394;
import com.nickuc.login.\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bc\u03b8\u03bf\u03b4\u03b7\u03bf\u03a0\u03bd\u03a6\u039b\u03bd\u03be\u039b;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4;
import io.netty.channel.Channel;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5
implements \u03b8\u03b2\u03bf\u03c1\u039b\u03c4\u03b7\u03b1\u03c4\u03b8\u03a8\u03c4\u03a0\u03c4\u03a6,
\u03bc\u03b8\u03bf\u03b4\u03b7\u03bf\u03a0\u03bd\u03a6\u039b\u03bd\u03be\u039b {
    private static long c;
    private static int q;
    private static long h;
    private static long p;
    private static long e;
    private static int f;
    private static int i;
    private static int n;
    private static long r;
    private static String[] a;
    private static String[] b;
    private static int ab;
    private static int s;
    private static int a;
    private static long o;
    private static long d;
    private static int ac;
    private static int m;
    private static long v;
    private static long g;
    private static int b;
    private static int aa;
    private static long y;
    private static int w;
    private static int t;
    private static int j;
    private static int z;
    private static long l;
    private static int x;
    private static int u;
    private static long k;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u052a\u054c\u054e\u052e\u0552\u0571\u0569\u057f\u056b\u053a\u0578\u056e\u057c\u0576\u053f\u0564\u0586\u0585\u057d\u0583\u057d\u0552", (byte)111, 67), \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.A("\u01c0\u01cd\u01cc\u018f\u01cf\u01cb\u01c6\u01cf\u01da\u01c9\u0196\u01d4\u01d8\u01d1\u01d4\u01da\u019c\u052c\u0530\u0518\u0536\u0538\u0528\u052c\u052a\u0528\u0534\u053c\u0536\u052b\u051e\u0541\u01b7", (byte)111, 65) + string + \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u0565", (byte)111, 70) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = -6692472129246260525L;
        long l = c ^ 0xF06E52368289C19AL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(55 + 13), (byte)(9 + 60), (byte)(7 + 76), (byte)(46 + 1), (byte)(20 + 47), (byte)(50 + 16), (byte)(11 + 56), (byte)(29 + 18), (byte)(60 + 20), 75, (byte)(16 + 51), (byte)(37 + 46), (byte)(25 + 28), (byte)(34 + 46), (byte)(24 + 73), (byte)(39 + 61), (byte)(47 + 53), (byte)(3 + 102), (byte)(53 + 57), 103}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(43 + 26), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u051c\u0531\u0511\u0525\u054c\u0537\u0527\u0515\u0557\u0553\u0518\u052c\u0548\u0540\u0530\u052f\u051f\u0542\u0533\u0559\u0526\u055f\u0562\u0520\u0561\u0567\u0522\u056e\u0545\u052c\u056b\u0567\u0541\u0567\u053e\u0565\u0557\u0536\u0533\u052f\u056e\u056c\u0570\u0567\u0578\u0580\u0550\u0549\u0542\u0557\u054f\u0540\u0553\u057e\u0562\u0549\u0554\u0555\u0558\u0562\u058a\u058f\u055a\u058f", (byte)29, 70);
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[1] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0459\u0442\u0462\u047f\u0488\u0473\u0462\u0444\u0456\u0489\u0448\u0465\u0450\u0473\u0489\u048e\u0468\u0474\u0451\u0479\u0454\u0486\u0491\u0489\u0471\u0475\u0458\u045d\u046a\u0493\u0473\u04a2\u0497\u047a\u0475\u04a7\u049e\u04a3\u0494\u048c\u0488\u047d\u0481\u04ae\u047e\u04b2\u048b\u0488\u04a9\u0471\u04a5\u04a1\u04b1\u048d\u0496\u04b1\u04af\u0474\u0478\u048c\u049f\u04b4\u04c0\u04c2", (byte)29, 67);
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[2] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u051c\u0531\u0511\u0525\u054c\u0537\u0527\u0515\u0557\u0553\u0518\u0554\u0518\u0551\u053b\u0520\u0539\u054d\u051a\u0530\u053c\u053c\u053b\u0556\u0541\u0522\u0539\u0565\u055c\u0566\u0567\u056a\u0548\u053f\u0534\u053d\u0552\u056d\u054a\u0539\u053a\u0544\u056c\u0573\u053e\u055c\u0554\u0582\u0557\u054e\u0550\u0555\u0540\u0560\u0572\u0567\u0578\u055e\u0564\u054d\u0558\u0541\u0564\u055b\u058e\u058f\u0588\u056a\u055f\u0578\u0558\u0598\u0588\u0591\u0574\u058a\u0569\u0570\u0578\u0576\u055f\u059e\u0564\u056d\u05a3\u05a0\u057f\u0563\u0584\u0574\u0578\u057e\u05a7\u0598\u05b0\u056f\u0570\u0589\u0591\u05a2\u05a0\u05b0\u0598\u058a\u0574\u05a7\u0594\u058a\u05be\u0575\u059d\u058b\u05b0\u05ac\u058c\u059f\u057f\u059e\u05bc\u05a1\u0593\u05ab\u0596\u057f\u059f\u058b\u05c0\u05c5\u05a1\u0589\u05ad\u05cd\u0596\u05c6\u05ae\u05b9\u0593\u058d\u05c7\u05b5\u05cc\u05b8\u059b\u05bc\u05ad\u05b5\u05a4\u05b9\u059c\u05d5\u05ac\u05ad", (byte)29, 70);
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[3] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u047b\u045f\u0441\u0473\u0475\u047d\u045b\u0446\u0456\u0484\u044a\u0454", (byte)29, 67);
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[4] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u00ec\u0108\u0110\u0114\u0115\u012d\u0120\u0129\u0115\u00f9\u0104\u0101", (byte)29, 66);
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[5] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u044f\u0464\u0444\u0458\u047f\u046a\u045a\u0448\u048a\u0486\u044a\u0446\u0490\u048f\u0468\u0446\u0494\u0456\u0450\u0463\u0492\u049a\u0469\u047d\u046b\u0477\u048a\u049a\u045a\u048f\u046d\u048c\u04a5\u049d\u0495\u04a5\u047d\u0462\u0479\u0495\u04a4\u04a3\u049d\u0474", (byte)29, 67);
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[6] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u0442\u047e\u044f\u0444\u045e\u0455\u0467\u047e\u046c\u0447\u048b\u048d\u044e\u044a\u045e\u048b\u0486\u0485\u044e\u0491\u047a\u0488\u045f\u0460", (byte)29, 67);
                    continue block7;
                }
                case 1: {
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u044f\u0464\u0444\u0458\u047f\u046a\u045a\u0448\u048a\u0486\u044b\u045f\u047b\u0473\u0463\u0462\u0452\u0475\u0466\u048c\u0459\u0492\u0495\u0453\u0494\u049a\u0455\u04a1\u0478\u045f\u049e\u049a\u0474\u049a\u0471\u0498\u048a\u0469\u0466\u0462\u04a1\u049f\u04a3\u049a\u04ab\u04b3\u0483\u047c\u0475\u048a\u0482\u0473\u0486\u04aa\u046d\u04a9\u049a\u048b\u0477\u0495\u0489\u0478\u0495\u04bd\u0490\u04a0\u04c4\u0499\u04ba\u0498\u0488\u0487\u04ab\u0498\u04ab\u0494", (byte)29, 67);
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[1] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.C("\u0459\u0442\u0462\u047f\u0488\u0473\u0462\u0444\u0456\u0489\u0448\u0465\u0450\u0473\u0489\u048e\u0468\u0474\u0451\u0479\u0454\u0486\u0491\u0489\u0471\u0475\u0458\u045d\u046a\u0493\u0473\u04a2\u0497\u047a\u0475\u04a7\u049e\u04a3\u0494\u048c\u0488\u047d\u0481\u04ae\u047e\u04b2\u048b\u0488\u04a9\u0471\u04a5\u04a1\u04b1\u048c\u049b\u04b3\u0475\u0492\u0499\u0477\u04aa\u048d\u047b\u04b9", (byte)29, 67);
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[2] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u00fc\u0111\u00f1\u0105\u012c\u0117\u0107\u00f5\u0137\u0133\u00f8\u0134\u00f8\u0131\u011b\u0100\u0119\u012d\u00fa\u0110\u011c\u011c\u011b\u0136\u0121\u0102\u0119\u0145\u013c\u0146\u0147\u014a\u0128\u011f\u0114\u011d\u0132\u014d\u012a\u0119\u011a\u0124\u014c\u0153\u011e\u013c\u0134\u0162\u0137\u012e\u0130\u0135\u0120\u0140\u0152\u0147\u0158\u013e\u0144\u012d\u0138\u0121\u0144\u013b\u016e\u016f\u0168\u014a\u013f\u0158\u0138\u0178\u0168\u0171\u0154\u016a\u0149\u0150\u0158\u0156\u013f\u017e\u0144\u014d\u0183\u0180\u015f\u0143\u0164\u0154\u0158\u015e\u0187\u0178\u0190\u014f\u0150\u0169\u0171\u0182\u0180\u0190\u0178\u016a\u0154\u0187\u0174\u016a\u019e\u0155\u017d\u016b\u0190\u018c\u016c\u017f\u015f\u017e\u019c\u0181\u0173\u018b\u0176\u015f\u017f\u016b\u01a0\u01a5\u0181\u0169\u018d\u01ad\u0176\u01a6\u018e\u0199\u0173\u016d\u01a8\u018e\u01b0\u0190\u01b1\u019c\u019a\u01c1\u019c\u019b\u01c4\u01c7\u01a7\u01a9\u01c6\u0181\u01c9\u01ab\u01ce\u01aa\u01c4\u01c4", (byte)29, 66);
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[3] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u0472\u0458\u0445\u0442\u043b\u0447\u048c\u0469\u0446\u047a\u0489\u048e\u044a\u045a\u0487\u048f\u0450\u0481\u0465\u0499\u0455\u0462\u045f\u0460", (byte)29, 68);
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[4] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.B("\u0125\u0101\u0122\u0114\u0137\u00f3\u0109\u0123\u0137\u0138\u00f3\u0101", (byte)29, 66);
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[5] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u051c\u0531\u0511\u0525\u054c\u0537\u0527\u0515\u0557\u0553\u0517\u0513\u055d\u055c\u0535\u0513\u0561\u0523\u051d\u0530\u055f\u0567\u0536\u054a\u0538\u0544\u0557\u0567\u0527\u055c\u053a\u0559\u052b\u054a\u053f\u0534\u0570\u0567\u054c\u0573\u0567\u054f\u0551\u055d\u055c\u056d\u0557\u0554\u055f\u053d\u056d\u0550\u055c\u0585\u054c\u054d", (byte)29, 70);
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[6] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u00ef\u012b\u00fc\u00f1\u010b\u0102\u0114\u012b\u0119\u00f4\u0139\u0114\u00fa\u00ff\u0113\u013b\u0133\u010d\u013d\u0133\u012f\u010f\u010c\u010d", (byte)29, 66);
                    continue block7;
                }
                case 2: {
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[0] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u0106\u010c\u0130\u00f5\u0120\u0128\u012c\u0125\u00ec\u012e\u0126\u0117\u012c\u0116\u010d\u00f8\u0123\u0124\u00fd\u0137\u0111\u0145\u010c\u010d", (byte)29, 66);
                    continue block7;
                }
                case 4: {
                    \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u0460\u047c\u0460\u047c\u046a\u047a\u0456\u0456\u0448\u045f\u045f\u0483\u046a\u0444\u047d\u045d\u0485\u045f\u0489\u046d\u0498\u0479\u049c\u0498\u046b\u0492\u0458\u048b\u0453\u04a1\u0474\u0499", (byte)29, 67);
                }
            }
        }
    }

    static {
        a = (0x800000 >>> 54 | 0x800000 << ~54 + 1) & 0xFFFFFFFF;
        b = Integer.reverse(0);
        d = Long.reverse(-3798565552553068347L);
        e = Long.reverse(0x1600000000000000L);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Long.reverse(-3798565552553068347L);
        h = Long.reverse(0x1600000000000000L);
        i = (0 >>> 126 | 0 << ~126 + 1) & 0xFFFFFFFF;
        j = 8 >>> 2 | 8 << -2;
        k = Long.reverse(-3798565552553068347L);
        l = Long.reverse(0x1600000000000000L);
        m = Integer.reverse(0);
        n = 49152 >>> 142 | 49152 << ~142 + 1;
        o = Long.reverse(-3798565552553068347L);
        p = Long.reverse(0x1600000000000000L);
        q = Integer.reverse(0x20000000);
        r = Long.reverse(-2501528859870365499L);
        s = (0 >>> 244 | 0 << -244) & 0xFFFFFFFF;
        t = Integer.reverse(-1610612736);
        u = (-1 >>> 197 | -1 << -197) & 0xFFFFFFFF;
        v = Long.reverse(-2501528859870365499L);
        w = Integer.reverse(0x60000000);
        x = (-1 >>> 255 | -1 << ~255 + 1) & 0xFFFFFFFF;
        y = Long.reverse(-2501528859870365499L);
        z = Integer.reverse(0);
        aa = Integer.reverse(0x40000000);
        ab = Integer.reverse(-536870912);
        ac = (0x1C000000 >>> 250 | 0x1C000000 << -250) & 0xFFFFFFFF;
        a = new String[ab];
        b = new String[ac];
        \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.b();
    }

    @Override
    public void a(PacketReceiveEvent packetReceiveEvent) {
        if (\u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3.a() != \u03a0\u03b2\u03c0\u03c0\u0393\u03c9\u039b\u03a6\u03c5\u03b2\u03a9\u03bc\u0394.c) {
            return;
        }
        Channel channel = (Channel)packetReceiveEvent.getChannel();
        if (!channel.hasAttr(\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4.c)) {
            return;
        }
        \u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4 \u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b42 = (\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4)channel.attr(\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4.c).get();
        if (\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b42 == null) {
            return;
        }
        if (\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b42.f == a) {
            channel.attr(\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4.c).set(null);
            \u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3.a(\u03a0\u03b2\u03c0\u03c0\u0393\u03c9\u039b\u03a6\u03c5\u03b2\u03a9\u03bc\u0394.d);
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.c("\u3e80", (int)b, (long)(d ^ e)) + (Object)((Object)\u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3.a()) + (String)\u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.c("\u3e83", (int)f, (long)(g ^ h)), new Object[i]);
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.c("\u3e86", (int)j, (long)(k ^ l)) + \u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.al.a().a()[m] + (String)\u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.c("\u3e89", (int)n, (long)(o ^ p)) + (Object)((Object)\u03a0\u03b2\u03c0\u03c0\u0393\u03c9\u039b\u03a6\u03c5\u03b2\u03a9\u03bc\u0394.d) + (String)\u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.c("\u3e8c", (int)q, (long)r), new Object[s]);
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.c("\u3e8f", (int)(t & u), (long)v) + (Object)((Object)\u03a0\u03b2\u03c0\u03c0\u0393\u03c9\u039b\u03a6\u03c5\u03b2\u03a9\u03bc\u0394.d) + (String)\u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.c("\u3e92", (int)(w & x), (long)y), new Object[z]);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x68L;
        l ^= 0xF06E52368289C19AL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(48 + 21), (byte)(56 + 27), (byte)(41 + 6), 67, (byte)(26 + 40), (byte)(4 + 63), (byte)(4 + 43), (byte)(6 + 74), (byte)(51 + 24), (byte)(38 + 29), (byte)(16 + 67), (byte)(13 + 40), (byte)(46 + 34), (byte)(83 + 14), (byte)(46 + 54), (byte)(37 + 63), (byte)(50 + 55), (byte)(44 + 66), (byte)(49 + 54)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(44 + 39)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u01a2\u01af\u01ae\u0171\u01b1\u01ad\u01a8\u01b1\u01bc\u01ab\u0178\u01b6\u01ba\u01b3\u01b6\u01bc\u017e\u050e\u0512\u04fa\u0518\u051a\u050a\u050e\u050c\u050a\u0516\u051e\u0518\u050d\u0500\u0523", (byte)96, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03be\u03c1\u03a8\u03c5\u03c6\u03b5\u03b8\u03b5\u03b2\u03bd\u03c4\u03bd\u03b1\u03a3\u03c5.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public void a(PacketSendEvent packetSendEvent) {
        if (\u03b2\u03b4\u0394\u03c6\u03bc\u03c0\u03b8\u03b8\u03b3.a() != \u03a0\u03b2\u03c0\u03c0\u0393\u03c9\u039b\u03a6\u03c5\u03b2\u03a9\u03bc\u0394.c) {
            return;
        }
        Channel channel = (Channel)packetSendEvent.getChannel();
        if (!channel.hasAttr(\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4.c)) {
            return;
        }
        \u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4 \u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b42 = (\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4)channel.attr(\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b4.c).get();
        if (\u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b42 == null) {
            return;
        }
        \u03c9\u03a9\u03bc\u03a9\u03c7\u03b4\u03bf\u03c9\u03b4\u0394\u03a0\u0394\u03b42.f = (byte)aa;
    }
}

