/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u0393\u03c7\u03bf\u03b8\u03c8\u03a6\u03c5\u03c8\u03c9\u03b6\u03c3\u03c3;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.zip.GZIPOutputStream;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3 {
    private static long h;
    private static String[] a;
    private static int a;
    private static String[] b;
    private static int t;
    private static long p;
    private static long k;
    private static int ac;
    private static long s;
    private static long ad;
    private static int f;
    private static long d;
    private static long aa;
    private static int l;
    private static int af;
    private static long v;
    private static long q;
    private static int g;
    private static long e;
    private static int o;
    private static int ag;
    private static long ae;
    private static int z;
    private static int r;
    private static int i;
    private static long ab;
    private static long u;
    private static long x;
    private static long c;
    private static int b;
    private static long n;
    private static int m;
    private static long j;
    private static int w;
    private static long y;

    static {
        a = 2 >>> 32 | 2 << -32;
        b = 0 >>> 155 | 0 << ~155 + 1;
        d = Long.reverse(-3173367030649638800L);
        e = Long.reverse(0x7000000000000000L);
        f = 0 >>> 96 | 0 << ~96 + 1;
        g = Integer.reverse(Integer.MIN_VALUE);
        h = Long.reverse(-6632131544470179728L);
        i = 8192 >>> 140 | 8192 << ~140 + 1;
        j = Long.reverse(-3173367030649638800L);
        k = Long.reverse(0x7000000000000000L);
        l = Integer.reverse(-1073741824);
        m = Integer.reverse(-1);
        n = Long.reverse(-6632131544470179728L);
        o = (0x100000 >>> 18 | 0x100000 << -18) & 0xFFFFFFFF;
        p = Long.reverse(-3173367030649638800L);
        q = Long.reverse(0x7000000000000000L);
        r = (40 >>> 195 | 40 << ~195 + 1) & 0xFFFFFFFF;
        s = Long.reverse(-6632131544470179728L);
        t = Integer.reverse(0x60000000);
        u = Long.reverse(-3173367030649638800L);
        v = Long.reverse(0x7000000000000000L);
        w = 0x380000 >>> 19 | 0x380000 << ~19 + 1;
        x = Long.reverse(-3173367030649638800L);
        y = Long.reverse(0x7000000000000000L);
        z = Integer.reverse(0x10000000);
        aa = Long.reverse(-3173367030649638800L);
        ab = Long.reverse(0x7000000000000000L);
        ac = -1879048192 >>> 188 | -1879048192 << ~188 + 1;
        ad = Long.reverse(-3173367030649638800L);
        ae = Long.reverse(0x7000000000000000L);
        af = (0x2800000 >>> 246 | 0x2800000 << -246) & 0xFFFFFFFF;
        ag = (1280 >>> 135 | 1280 << -135) & 0xFFFFFFFF;
        a = new String[af];
        b = new String[ag];
        \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b();
    }

    private static String a(int n, long l) {
        l ^= 0xEL;
        l ^= 0xC03F127178D30AE0L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(29 + 39), 69, (byte)(81 + 2), (byte)(25 + 22), (byte)(24 + 43), (byte)(60 + 6), (byte)(57 + 10), (byte)(23 + 24), 80, (byte)(7 + 68), (byte)(17 + 50), (byte)(2 + 81), (byte)(37 + 16), (byte)(66 + 14), (byte)(25 + 72), (byte)(44 + 56), (byte)(89 + 11), (byte)(44 + 61), (byte)(44 + 66), (byte)(13 + 90)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(57 + 11), (byte)(13 + 56), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u014c\u0159\u0158\u011b\u015b\u0157\u0152\u015b\u0166\u0155\u0122\u0160\u0164\u015d\u0160\u0166\u0128\u04b3\u04b3\u04bd\u04b5\u04a6\u04c2\u04b5\u04a1\u04b7\u04a3\u04c7", (byte)53, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static byte[] a(\u0393\u03c7\u03bf\u03b8\u03c8\u03a6\u03c5\u03c8\u03c9\u03b6\u03c3\u03c3 \u03b3\u03c7\u03bf\u03b8\u03c8\u03a6\u03c5\u03c8\u03c9\u03b6\u03c3\u03c3, byte[] byArray) {
        \u03b3\u03c7\u03bf\u03b8\u03c8\u03a6\u03c5\u03c8\u03c9\u03b6\u03c3\u03c3.k((String)\u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.c("\u3e80", (int)w, (long)(x ^ y)), (String)\u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.c("\u3e83", (int)z, (long)(aa ^ ab)));
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            try (GZIPOutputStream gZIPOutputStream = new GZIPOutputStream(byteArrayOutputStream);){
                gZIPOutputStream.write(byArray);
            }
            return byteArrayOutputStream.toByteArray();
        }
        catch (IOException iOException) {
            throw new RuntimeException((String)\u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.c("\u3e86", (int)ac, (long)(ad ^ ae)), iOException);
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.B("\u016b\u018d\u018f\u016f\u0193\u01b2\u01aa\u01c0\u01ac\u017b\u01b9\u01af\u01bd\u01b7\u0180\u01a5\u01c7\u01c6\u01be\u01c4\u01be\u0193", (byte)98, 66), \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u053e\u054b\u054a\u050d\u054d\u0549\u0544\u054d\u0558\u0547\u0514\u0552\u0556\u054f\u0552\u0558\u051a\u08a5\u08a5\u08af\u08a7\u0898\u08b4\u08a7\u0893\u08a9\u0895\u08b9\u0531", (byte)98, 67) + string + \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.A("\u017d", (byte)98, 65) + methodType.toString(), exception);
        }
    }

    public static byte[] a(Object ... objectArray) {
        if (objectArray.length % a != 0) {
            throw new IllegalArgumentException((String)\u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.c("\u3e80", (int)b, (long)(d ^ e)));
        }
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = f; i < objectArray.length; ++i) {
            Object object;
            if (stringBuilder.length() > 0) {
                stringBuilder.append((String)\u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.c("\u3e83", (int)g, (long)h));
            }
            if ((object = objectArray[i++]) == null) {
                throw new IllegalArgumentException((String)\u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.c("\u3e86", (int)\u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.i, (long)(j ^ k)));
            }
            Object object2 = objectArray[i];
            try {
                stringBuilder.append(URLEncoder.encode(object.toString(), (String)\u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.c("\u3e89", (int)(l & m), (long)n))).append((String)\u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.c("\u3e8c", (int)o, (long)(p ^ q))).append(URLEncoder.encode((String)(object2 == null ? \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.c("\u3e8f", (int)r, (long)s) : object2.toString()), (String)\u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.c("\u3e92", (int)t, (long)(u ^ v))));
                continue;
            }
            catch (UnsupportedEncodingException unsupportedEncodingException) {
                throw new RuntimeException(unsupportedEncodingException);
            }
        }
        return stringBuilder.toString().getBytes(StandardCharsets.UTF_8);
    }

    private static void b() {
        int n;
        c = 1012338145430581195L;
        long l = c ^ 0xC03F127178D30AE0L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(67 + 1), (byte)(5 + 64), (byte)(60 + 23), (byte)(29 + 18), 67, (byte)(48 + 18), (byte)(6 + 61), (byte)(20 + 27), (byte)(66 + 14), (byte)(73 + 2), (byte)(44 + 23), (byte)(14 + 69), (byte)(21 + 32), (byte)(41 + 39), (byte)(73 + 24), (byte)(95 + 5), (byte)(93 + 7), 105, (byte)(108 + 2), (byte)(55 + 48)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(57 + 12), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u052f\u0525\u0511\u0506\u053d\u052a\u04f6\u0534\u053f\u0539\u050d\u0544\u04fc\u051e\u0543\u053b\u0524\u0526\u0538\u0506\u0521\u0541\u052e\u053b\u050a\u050a\u0549\u050c\u052a\u0512\u0537\u0558\u050f\u054b\u0554\u055c\u051d\u0539\u053b\u0559\u053e\u0542\u0550\u0544\u0562\u052e\u055c\u0535\u055d\u0567\u0548\u0563\u0555\u0546\u0533\u0534", (byte)89, 67);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[1] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u0197\u018a\u0180\u0186\u01a3\u0165\u0180\u016a\u01ae\u01a3\u0190\u0179", (byte)89, 66);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[2] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u0163\u017b\u0178\u0198\u0176\u01a9\u0181\u01a1\u0188\u018b\u017d\u01a8\u01a6\u0191\u0195\u0173\u0197\u0172\u0188\u018c\u0175\u01ad\u0191\u01bf\u01b1\u0199\u0181\u01a1\u0178\u0179\u01a7\u019a", (byte)89, 66);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[3] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u019e\u01a3\u01aa\u019d\u01a7\u017d\u017e\u0188\u01b3\u0193\u016b\u0179", (byte)89, 66);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[4] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.A("\u01a9\u0187\u01a1\u019b\u019b\u0168\u0167\u01a2\u0169\u0169\u01a6\u0179", (byte)89, 65);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[5] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0505\u04f3\u04fa\u051b\u04fc\u052b\u0507\u051b\u0513\u0535\u051f\u0508", (byte)89, 67);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[6] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u0582\u0587\u058e\u0581\u058b\u0561\u0562\u056c\u0597\u0577\u054f\u055d", (byte)89, 69);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[7] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u0517\u0524\u04f9\u052a\u0511\u053c\u04f6\u050e\u050c\u04fa\u04fe\u0501\u04ff\u053a\u0542\u053f\u0514\u053c\u053c\u0528\u0522\u0504\u052e\u054c\u0528\u0523\u054e\u0551\u0551\u0508\u0515\u0536", (byte)89, 67);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[8] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u017d\u0197\u018d\u0179\u01aa\u01a6\u017e\u0167\u01a9\u0186\u01a6\u0179", (byte)89, 66);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[9] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u04f6\u053b\u052f\u0513\u0530\u052c\u0520\u0531\u053d\u053f\u04fc\u051a\u0542\u0539\u0540\u0500\u0515\u052b\u0505\u050b\u050c\u0524\u0549\u052e\u052b\u050c\u0542\u054c\u0511\u0516\u0527\u054f\u0548\u054b\u0550\u0550\u0553\u0536\u0548\u0529\u051e\u0537\u0543\u0528", (byte)89, 67);
                    continue block7;
                }
                case 1: {
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u052f\u0525\u0511\u0506\u053d\u052a\u04f6\u0534\u053f\u0539\u050d\u0544\u04fc\u051e\u0543\u053b\u0524\u0526\u0538\u0506\u0521\u0541\u052e\u053b\u050a\u050a\u0549\u050c\u052a\u0512\u0537\u0558\u050f\u054b\u0554\u055c\u051d\u0539\u053b\u0559\u053e\u0542\u054f\u052d\u055e\u0520\u0522\u0530\u053f\u0539\u0547\u0528\u0566\u0565\u0547\u052f\u0539\u053b\u0565\u0570\u0552\u056c\u0566\u0531", (byte)89, 68);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[1] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.E("\u0580\u0561\u0565\u057f\u0570\u058c\u0575\u0593\u0567\u0592\u056c\u055d", (byte)89, 69);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[2] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u0547\u055f\u055c\u057c\u055a\u058d\u0565\u0585\u056c\u056f\u0561\u058c\u058a\u0575\u0579\u0557\u057b\u0556\u056c\u0570\u0559\u0597\u0572\u0577\u05a3\u0563\u0581\u059b\u0583\u05a3\u05a8\u0579", (byte)89, 69);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[3] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u0175\u01aa\u0164\u01ae\u0169\u0168\u01ae\u0163\u018c\u018b\u0184\u01a5\u0182\u01b7\u0177\u01b6\u0182\u0193\u0193\u01b4\u018a\u0187\u0184\u0185", (byte)89, 65);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[4] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u0559\u0586\u057f\u0589\u0586\u057e\u0572\u0575\u0592\u0590\u0568\u055d", (byte)89, 69);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[5] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u017a\u017f\u0188\u017c\u01a0\u019b\u0190\u01a3\u016a\u019c\u016b\u0179", (byte)89, 66);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[6] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u0535\u04f6\u0505\u0517\u0515\u052c\u051a\u04f2\u053a\u0536\u051b\u04fc\u050f\u0545\u0513\u0536\u0522\u0509\u0517\u0540\u053e\u0526\u0513\u0514", (byte)89, 68);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[7] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u0188\u0195\u016a\u019b\u0182\u01ad\u0167\u017f\u017d\u016b\u016f\u0172\u0170\u01ab\u01b3\u01b0\u0185\u01ad\u01ad\u0199\u0193\u0175\u0189\u01b1\u0198\u01b6\u0180\u018d\u0198\u0199\u0194\u019d", (byte)89, 66);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[8] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.B("\u0194\u0188\u01ab\u016a\u01a0\u0188\u019f\u017c\u0190\u016a\u0188\u0179", (byte)89, 66);
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[9] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u04f6\u053b\u052f\u0513\u0530\u052c\u0520\u0531\u053d\u053f\u04fc\u051a\u0542\u0539\u0540\u0500\u0515\u052b\u0505\u050b\u050c\u0524\u0549\u052e\u052b\u050c\u0542\u054c\u0511\u0516\u0527\u054f\u0511\u0557\u0533\u0512\u0553\u054d\u0558\u0520\u052e\u053e\u0557\u051f\u0530\u053b\u0563\u0535\u055f\u0525\u0556\u0526\u055b\u0536\u0533\u0534", (byte)89, 68);
                    continue block7;
                }
                case 2: {
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.C("\u0531\u052c\u04f7\u04fa\u0508\u0535\u052e\u04ff\u053f\u0536\u0535\u0531\u0521\u0501\u051f\u0535\u0524\u054a\u051b\u0515\u0527\u053c\u0513\u0514", (byte)89, 67);
                    continue block7;
                }
                case 4: {
                    \u03b9\u03b8\u03c1\u03b8\u03a8\u03c3\u03b5\u03a0\u03b5\u03a0\u03c3.b[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.E("\u0583\u0578\u058a\u0581\u0581\u0581\u056e\u054b\u0552\u0571\u058c\u0559\u059a\u056f\u059d\u057e\u055b\u055a\u058a\u0578\u056d\u0591\u0568\u0569", (byte)89, 69);
                }
            }
        }
    }
}

