/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
final class \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8
extends Enum<\u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8> {
    public static final /* enum */ \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8 b;
    public static final /* enum */ \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8 c;
    public static final /* enum */ \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8 d;
    public static final /* enum */ \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8 e;
    private static final /* synthetic */ \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8[] a;
    private static String[] a;
    private static String[] b;
    private static long c;
    private static int a;
    private static int b;
    private static int c;
    private static int d;
    private static int e;
    private static int f;
    private static int g;
    private static int h;
    private static long i;
    private static long j;
    private static int k;
    private static int l;
    private static long m;
    private static int n;
    private static int o;
    private static int p;
    private static long q;
    private static int r;
    private static int s;
    private static long t;
    private static long u;
    private static int v;

    private static void b() {
        int n;
        c = 2750146177755603657L;
        long l = c ^ 0x91C298C4334DFB68L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(20 + 48), (byte)(7 + 62), (byte)(44 + 39), (byte)(15 + 32), (byte)(6 + 61), 66, (byte)(4 + 63), (byte)(23 + 24), (byte)(60 + 20), (byte)(52 + 23), (byte)(46 + 21), (byte)(20 + 63), (byte)(2 + 51), (byte)(72 + 8), 97, (byte)(4 + 96), (byte)(12 + 88), (byte)(17 + 88), (byte)(92 + 18), (byte)(89 + 14)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(51 + 32)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.b[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u041a\u0457\u0425\u0443\u0459\u0468\u046b\u0464\u0447\u0457\u045c\u0433", (byte)18, 67);
                    \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.b[1] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.C("\u041d\u0453\u0442\u0419\u0467\u0452\u0429\u0446\u0428\u046a\u0442\u0433", (byte)18, 67);
                    \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.b[2] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u043c\u0459\u041f\u0455\u0448\u0455\u0460\u0421\u045c\u043a\u0468\u0433", (byte)18, 67);
                    \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.b[3] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u042d\u041d\u041f\u041f\u0463\u0451\u0425\u042a\u0422\u044d\u0462\u042c\u046a\u0459\u0465\u0468\u0471\u044f\u046d\u0451\u0470\u0451\u043e\u043f", (byte)18, 67);
                    continue block7;
                }
                case 1: {
                    \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u0452\u042f\u0420\u0443\u0426\u045d\u046b\u0424\u0456\u043b\u044e\u0433", (byte)18, 68);
                    \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.b[1] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.E("\u0534\u051f\u0533\u0501\u0505\u0528\u0505\u053d\u0528\u054e\u0519\u0516", (byte)18, 69);
                    \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.b[2] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.A("\u010d\u00d9\u00f3\u00d9\u00f7\u00f2\u0103\u00f3\u00dc\u0102\u011a\u0116\u00da\u0119\u0126\u00fe\u011a\u0118\u0128\u0105\u010c\u011f\u00f6\u00f7", (byte)18, 65);
                    \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.b[3] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u0510\u0500\u0502\u0502\u0546\u0534\u0508\u050d\u0505\u0530\u0545\u053d\u052c\u0554\u054e\u0520\u0554\u0556\u0553\u0513\u0524\u055a\u0521\u0522", (byte)18, 69);
                    continue block7;
                }
                case 2: {
                    \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.b[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u0420\u0434\u041d\u0436\u0435\u045f\u0424\u046b\u0467\u0443\u0425\u0433", (byte)18, 68);
                    continue block7;
                }
                case 4: {
                    \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.A("\u00ed\u00eb\u00de\u00d9\u00de\u00ea\u00fc\u00fc\u0118\u00f0\u0123\u0121\u011e\u0105\u00fc\u0119\u012a\u00ed\u00e4\u0117\u012a\u012f\u00f6\u00f7", (byte)18, 65);
                }
            }
        }
    }

    private static /* synthetic */ \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8[] a() {
        \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8[] \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8Array = new \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8[a];
        \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8Array[\u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.b] = b;
        \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8Array[\u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.c] = c;
        \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8Array[\u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.d] = d;
        \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8Array[\u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.e] = e;
        return \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8Array;
    }

    public static \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8 valueOf(String string) {
        return Enum.valueOf(\u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.class, string);
    }

    public static \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8[] values() {
        return (\u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8[])a.clone();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u012d\u014f\u0151\u0131\u0155\u0174\u016c\u0182\u016e\u013d\u017b\u0171\u017f\u0179\u0142\u0167\u0189\u0188\u0180\u0186\u0180\u0155", (byte)67, 66), \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u0168\u0175\u0174\u0137\u0177\u0173\u016e\u0177\u0182\u0171\u013e\u017c\u0180\u0179\u017c\u0182\u0144\u04d3\u04c8\u04cc\u04d9\u04dd\u04d1\u04dd\u04d8\u04d2\u04e7\u015a", (byte)67, 66) + string + \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u04b8", (byte)67, 68) + methodType.toString(), exception);
        }
    }

    static {
        a = Integer.reverse(0x20000000);
        b = 0 >>> 6 | 0 << ~6 + 1;
        c = Integer.reverse(Integer.MIN_VALUE);
        d = (128 >>> 38 | 128 << ~38 + 1) & 0xFFFFFFFF;
        e = Integer.reverse(-1073741824);
        f = 0x2000000 >>> 183 | 0x2000000 << -183;
        g = 0x800000 >>> 21 | 0x800000 << -21;
        h = Integer.reverse(0);
        i = Long.reverse(-7834396737247751068L);
        j = Long.reverse(-6485183463413514240L);
        k = Integer.reverse(0);
        l = Integer.reverse(Integer.MIN_VALUE);
        m = Long.reverse(3838933496896574564L);
        n = 65536 >>> 48 | 65536 << -48;
        o = Integer.reverse(0x40000000);
        p = Integer.reverse(-1);
        q = Long.reverse(3838933496896574564L);
        r = Integer.reverse(0x40000000);
        s = Integer.reverse(-1073741824);
        t = Long.reverse(-7834396737247751068L);
        u = Long.reverse(-6485183463413514240L);
        v = Integer.reverse(-1073741824);
        a = new String[f];
        b = new String[g];
        \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.b();
        b = new \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8();
        c = new \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8();
        d = new \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8();
        e = new \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8();
        a = \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.a();
    }

    private static String a(int n, long l) {
        l ^= 0x65L;
        l ^= 0x91C298C4334DFB68L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(57 + 11), (byte)(60 + 9), (byte)(10 + 73), 47, (byte)(30 + 37), (byte)(37 + 29), (byte)(23 + 44), (byte)(46 + 1), (byte)(32 + 48), (byte)(5 + 70), (byte)(34 + 33), (byte)(6 + 77), (byte)(34 + 19), (byte)(9 + 71), (byte)(60 + 37), (byte)(97 + 3), (byte)(33 + 67), (byte)(98 + 7), (byte)(89 + 21), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(33 + 35), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u0517\u0524\u0523\u04e6\u0526\u0522\u051d\u0526\u0531\u0520\u04ed\u052b\u052f\u0528\u052b\u0531\u04f3\u0882\u0877\u087b\u0888\u088c\u0880\u088c\u0887\u0881\u0896", (byte)85, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bd\u03b1\u03b4\u03c0\u03c3\u03b6\u03c1\u03bb\u03b4\u03c8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }
}

