/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.CheckReturnValue
 */
package com.nickuc.login;

import com.nickuc.login.\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import javax.annotation.CheckReturnValue;

public class \u03b2\u03b9\u03a0\u03c1\u03c8\u03bc\u03c0\u0394\u03b2\u03a0\u03b4 {
    private static int e;
    private static int a;
    private static int h;
    private static int k;
    private static int i;
    private static int l;
    private static int g;
    private static int c;
    private static int d;
    private static int b;
    private static int f;
    private static int j;

    @CheckReturnValue
    public static PrintWriter a(File file, Charset charset, boolean bl) {
        return new PrintWriter((Writer)new BufferedWriter(new OutputStreamWriter((OutputStream)new FileOutputStream(file, e != 0), charset)), bl);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static boolean a(File file, Charset charset, String ... stringArray) {
        if (stringArray.length == 0) {
            return f != 0;
        }
        if (!\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b(file)) {
            return g != 0;
        }
        PrintWriter printWriter = \u03b2\u03b9\u03a0\u03c1\u03c8\u03bc\u03c0\u0394\u03b2\u03a0\u03b4.a(file, charset, h != 0);
        try {
            String[] stringArray2 = stringArray;
            int n = stringArray2.length;
            for (int i = \u03b2\u03b9\u03a0\u03c1\u03c8\u03bc\u03c0\u0394\u03b2\u03a0\u03b4.i; i < n; ++i) {
                String string = stringArray2[i];
                if (string.isEmpty()) {
                    printWriter.println();
                    continue;
                }
                printWriter.println(string);
            }
            printWriter.flush();
            boolean bl = j;
            return bl;
        }
        finally {
            if (Collections.singletonList(printWriter).get(k) != null) {
                printWriter.close();
            }
        }
    }

    static {
        a = 2048 >>> 139 | 2048 << ~139 + 1;
        b = Integer.reverse(0);
        c = (0 >>> 202 | 0 << ~202 + 1) & 0xFFFFFFFF;
        d = 0 >>> 108 | 0 << -108;
        e = (32 >>> 229 | 32 << ~229 + 1) & 0xFFFFFFFF;
        f = (0 >>> 9 | 0 << ~9 + 1) & 0xFFFFFFFF;
        g = Integer.reverse(0);
        h = Integer.reverse(Integer.MIN_VALUE);
        i = Integer.reverse(0);
        j = Integer.reverse(Integer.MIN_VALUE);
        k = Integer.reverse(0);
        l = 0 >>> 205 | 0 << -205;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static boolean a(File file, byte[] byArray) {
        if (\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b(file)) {
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byArray);
            try {
                \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.a(byteArrayInputStream, file);
                boolean bl = a;
                return bl;
            }
            finally {
                if (Collections.singletonList(byteArrayInputStream).get(b) != null) {
                    ((InputStream)byteArrayInputStream).close();
                }
            }
        }
        return d != 0;
    }

    public static boolean a(File file, String ... stringArray) {
        return \u03b2\u03b9\u03a0\u03c1\u03c8\u03bc\u03c0\u0394\u03b2\u03a0\u03b4.a(file, StandardCharsets.UTF_8, stringArray);
    }
}

