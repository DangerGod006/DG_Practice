/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6
implements \u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6 {
    private static int al;
    private static long j;
    private static int ar;
    private static int i;
    private static long n;
    private static int v;
    private static int u;
    private static int g;
    private static long e;
    private static int x;
    private static int ad;
    private static long d;
    private final String aD;
    private static int af;
    private static int ai;
    private final boolean U;
    private static long m;
    @Nullable
    private final String aG;
    private static int l;
    private static int ah;
    private static int ap;
    private static int ak;
    private static long h;
    private static int an;
    private static int b;
    private static int am;
    private static int as;
    private static int f;
    private static int z;
    private static int ao;
    private final String aE;
    private static String[] b;
    private static int o;
    private static int y;
    private static int ac;
    private static int t;
    private static long k;
    private static int ab;
    private static int aj;
    private final boolean T;
    private static int a;
    private static int c;
    private static int ae;
    private static int ag;
    private static int p;
    private static int r;
    private static long c;
    private static String[] a;
    private static int aq;
    private static int s;
    private static int aa;
    private static int q;
    private final String aF;
    private final List<\u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7> h;
    private static int w;

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = 0x800000 >>> 183 | 0x800000 << ~183 + 1;
        c = (0 >>> 156 | 0 << -156) & 0xFFFFFFFF;
        d = Long.reverse(-2841107844608905982L);
        e = Long.reverse(0x6200000000000000L);
        f = 65536 >>> 176 | 65536 << ~176 + 1;
        g = -1 >>> 19 | -1 << ~19 + 1;
        h = Long.reverse(-5002835665746744062L);
        i = Integer.reverse(0x40000000);
        j = Long.reverse(-2841107844608905982L);
        k = Long.reverse(0x6200000000000000L);
        l = Integer.reverse(-1073741824);
        m = Long.reverse(-2841107844608905982L);
        n = Long.reverse(0x6200000000000000L);
        o = (128 >>> 7 | 128 << -7) & 0xFFFFFFFF;
        p = (0 >>> 128 | 0 << ~128 + 1) & 0xFFFFFFFF;
        q = Integer.reverse(0);
        r = (0 >>> 159 | 0 << -159) & 0xFFFFFFFF;
        s = (0 >>> 119 | 0 << ~119 + 1) & 0xFFFFFFFF;
        t = (0 >>> 115 | 0 << -115) & 0xFFFFFFFF;
        u = Integer.reverse(0);
        v = (0 >>> 67 | 0 << ~67 + 1) & 0xFFFFFFFF;
        w = Integer.reverse(0);
        x = Integer.reverse(0);
        y = (64 >>> 230 | 64 << -230) & 0xFFFFFFFF;
        z = Integer.reverse(-603979776);
        aa = 0x400000 >>> 246 | 0x400000 << ~246 + 1;
        ab = Integer.reverse(-603979776);
        ac = -536870903 >>> 93 | -536870903 << -93;
        ad = 0x8000003 >>> 187 | 0x8000003 << ~187 + 1;
        ae = Integer.reverse(-603979776);
        af = Integer.reverse(-234881024);
        ag = 0xC20000 >>> 145 | 0xC20000 << ~145 + 1;
        ah = Integer.reverse(-603979776);
        ai = Integer.reverse(-738197504);
        aj = (-671088639 >>> 123 | -671088639 << -123) & 0xFFFFFFFF;
        ak = Integer.reverse(-738197504);
        al = Integer.reverse(-603979776);
        am = (-1073741814 >>> 126 | -1073741814 << -126) & 0xFFFFFFFF;
        an = (241664 >>> 108 | 241664 << ~108 + 1) & 0xFFFFFFFF;
        ao = (-1073741814 >>> 190 | -1073741814 << ~190 + 1) & 0xFFFFFFFF;
        ap = 118 >>> 161 | 118 << -161;
        aq = (-2147483627 >>> 223 | -2147483627 << -223) & 0xFFFFFFFF;
        ar = Integer.reverse(0x20000000);
        as = (0x2000000 >>> 183 | 0x2000000 << ~183 + 1) & 0xFFFFFFFF;
        a = new String[ar];
        b = new String[as];
        \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.b();
    }

    public \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6(String string, String string2, String string3, @Nullable String string4, \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7 ... \u03b4\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7Array) {
        this(string, string2, string3, string4, a != 0, b != 0, \u03b4\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7Array);
    }

    private static String a(int n, long l) {
        l ^= 0x46L;
        l ^= 0xDEE73674CC416037L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(45 + 23), (byte)(45 + 24), (byte)(47 + 36), (byte)(45 + 2), (byte)(25 + 42), (byte)(21 + 45), (byte)(37 + 30), (byte)(2 + 45), (byte)(33 + 47), (byte)(48 + 27), (byte)(18 + 49), (byte)(50 + 33), (byte)(22 + 31), 80, (byte)(28 + 69), (byte)(78 + 22), 100, (byte)(35 + 70), (byte)(106 + 4), (byte)(84 + 19)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(31 + 37), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u01b8\u01c5\u01c4\u0187\u01c7\u01c3\u01be\u01c7\u01d2\u01c1\u018e\u01cc\u01d0\u01c9\u01cc\u01d2\u0194\u0517\u0528\u0508\u050f\u0505\u0520\u0527\u052f\u0517\u0537\u0526", (byte)107, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Generated
    public boolean equals(Object object) {
        if (object == this) {
            return o != 0;
        }
        if (!(object instanceof \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6)) {
            return p != 0;
        }
        \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6 \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b62 = (\u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6)object;
        if (!\u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b62.b(this)) {
            return q != 0;
        }
        if (this.b() != \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b62.b()) {
            return r != 0;
        }
        if (this.c() != \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b62.c()) {
            return s != 0;
        }
        String string = this.a();
        String string2 = \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b62.a();
        if (string == null ? string2 != null : !string.equals(string2)) {
            return t != 0;
        }
        String string3 = this.b();
        String string4 = \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b62.b();
        if (string3 == null ? string4 != null : !string3.equals(string4)) {
            return u != 0;
        }
        String string5 = this.getVersion();
        String string6 = \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b62.getVersion();
        if (string5 == null ? string6 != null : !string5.equals(string6)) {
            return v != 0;
        }
        String string7 = this.c();
        String string8 = \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b62.c();
        if (string7 == null ? string8 != null : !string7.equals(string8)) {
            return w != 0;
        }
        List<\u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7> list = this.a();
        List<\u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7> list2 = \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b62.a();
        if (list == null ? list2 != null : !((Object)list).equals(list2)) {
            return x != 0;
        }
        return y != 0;
    }

    @Override
    @Generated
    public String a() {
        return this.aD;
    }

    @Override
    @Generated
    public boolean b() {
        return this.T;
    }

    @Override
    @Generated
    public String b() {
        return this.aE;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u053c\u055e\u0560\u0540\u0564\u0583\u057b\u0591\u057d\u054c\u058a\u0580\u058e\u0588\u0551\u0576\u0598\u0597\u058f\u0595\u058f\u0564", (byte)117, 68), \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.D("\u0577\u0584\u0583\u0546\u0586\u0582\u057d\u0586\u0591\u0580\u054d\u058b\u058f\u0588\u058b\u0591\u0553\u08d6\u08e7\u08c7\u08ce\u08c4\u08df\u08e6\u08ee\u08d6\u08f6\u08e5\u056a", (byte)117, 68) + string + \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u01a3", (byte)117, 65) + methodType.toString(), exception);
        }
    }

    @Override
    @Generated
    public boolean c() {
        return this.U;
    }

    public \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6(String string, String string2, String string3, @Nullable String string4, boolean bl, boolean bl2, \u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7 ... \u03b4\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7Array) {
        this.aD = string.replace((CharSequence)\u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.c("\u3e80", (int)c, (long)(d ^ e)), (CharSequence)\u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.c("\u3e83", (int)(f & g), (long)h));
        this.aE = string2.replace((CharSequence)\u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.c("\u3e86", (int)i, (long)(j ^ k)), (CharSequence)\u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.c("\u3e89", (int)l, (long)(m ^ n)));
        this.aF = string3;
        this.aG = string4;
        this.T = bl;
        this.U = bl2;
        this.h = (long)Arrays.asList(\u03b4\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7Array);
    }

    @Generated
    public int hashCode() {
        int n = z;
        int n2 = aa;
        n2 = n2 * ab + (this.b() ? ac : ad);
        n2 = n2 * ae + (this.c() ? af : ag);
        String string = this.a();
        n2 = n2 * ah + (string == null ? ai : string.hashCode());
        String string2 = this.b();
        n2 = n2 * aj + (string2 == null ? ak : string2.hashCode());
        String string3 = this.getVersion();
        n2 = n2 * al + (string3 == null ? am : string3.hashCode());
        String string4 = this.c();
        n2 = n2 * an + (string4 == null ? ao : string4.hashCode());
        List<\u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7> list = this.a();
        n2 = n2 * ap + (list == null ? aq : ((Object)list).hashCode());
        return n2;
    }

    @Generated
    protected boolean b(Object object) {
        return object instanceof \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6;
    }

    @Override
    @Generated
    public String getVersion() {
        return this.aF;
    }

    @Override
    @Generated
    public List<\u0394\u03a3\u03bb\u03c5\u0393\u03a8\u0393\u03b2\u03b8\u03c2\u03be\u03b7> a() {
        return this.h;
    }

    @Override
    @Nullable
    @Generated
    public String c() {
        return this.aG;
    }

    private static void b() {
        int n;
        c = 4662705127195035931L;
        long l = c ^ 0xDEE73674CC416037L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(64 + 4), (byte)(49 + 20), (byte)(69 + 14), (byte)(32 + 15), (byte)(13 + 54), (byte)(63 + 3), (byte)(56 + 11), (byte)(22 + 25), (byte)(31 + 49), 75, (byte)(36 + 31), (byte)(68 + 15), (byte)(45 + 8), (byte)(60 + 20), (byte)(37 + 60), (byte)(58 + 42), (byte)(48 + 52), (byte)(38 + 67), 110, (byte)(13 + 90)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(17 + 66)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u0163\u016d\u016a\u0155\u016b\u012f\u0158\u016f\u0167\u0156\u016c\u0143", (byte)62, 65);
                    \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.b[1] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.D("\u04a8\u04d1\u04a0\u049d\u04bc\u04a8\u04c0\u04d8\u04bf\u04a8\u04ad\u04b7", (byte)62, 68);
                    \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.b[2] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u0562\u056c\u0569\u0554\u056a\u052e\u0557\u056e\u0566\u0555\u056b\u0542", (byte)62, 70);
                    \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.b[3] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u0533\u055c\u052b\u0528\u0547\u0533\u054b\u0563\u054a\u0533\u0538\u0542", (byte)62, 70);
                    continue block7;
                }
                case 1: {
                    \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.b[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u013c\u0151\u0140\u0134\u0131\u014b\u014a\u0132\u015a\u0174\u0168\u0143", (byte)62, 65);
                    \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.b[1] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u04e7\u04b6\u04e5\u04ba\u04a5\u04df\u04ae\u04c7\u04a7\u04a8\u04b1\u04b7", (byte)62, 68);
                    \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.b[2] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.E("\u056c\u0546\u0533\u056d\u0577\u0533\u0537\u0553\u0553\u0545\u0545\u0542", (byte)62, 69);
                    \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.b[3] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u04b8\u04e4\u04a1\u04d5\u04e2\u04da\u04b6\u04e3\u04a9\u04e8\u04e8\u04b7", (byte)62, 67);
                    continue block7;
                }
                case 2: {
                    \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u013e\u0160\u0171\u0142\u0141\u0145\u016f\u0168\u015c\u0137\u013d\u014e\u017e\u0155\u0161\u0155\u0162\u0166\u0183\u0181\u015d\u0151\u014e\u014f", (byte)62, 65);
                    continue block7;
                }
                case 4: {
                    \u03b1\u03c1\u03a0\u03a6\u039b\u03b5\u03bb\u03c2\u03a9\u03c8\u03b6.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u0166\u014e\u0168\u0168\u0157\u0146\u0133\u012d\u0164\u0147\u0178\u0143", (byte)62, 65);
                }
            }
        }
    }
}

