/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.json.JSONObject
 *  javax.annotation.Nonnull
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.lib.json.JSONObject;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03bd\u039b\u03c9\u03a0\u03b8\u03c1\u03c0\u03c5\u03a3\u03bc\u03ba\u0393\u03a9\u03bf;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.annotation.Nonnull;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1<T>
implements \u03c2\u03bd\u039b\u03c9\u03a0\u03b8\u03c1\u03c0\u03c5\u03a3\u03bc\u03ba\u0393\u03a9\u03bf<T> {
    private final Class<T> c;
    private static int c;
    private final Class<?> b;
    private static long i;
    public static \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1<Boolean> c;
    private static long b;
    public static \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1<Long> d;
    private static int e;
    private static long g;
    private static int h;
    private static int k;
    private static String[] b;
    private static long d;
    public static \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1<String> a;
    private static long f;
    private static int j;
    private static long c;
    private static int a;
    public static \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1<Integer> b;
    private static String[] a;

    @Override
    public T a(@Nonnull JSONObject jSONObject) {
        Object object = jSONObject.get((String)\u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.c("\u3e80", (int)c, (long)d));
        if (this.c.isInstance(object)) {
            return this.c.cast(object);
        }
        throw new IllegalArgumentException((String)\u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.c("\u3e83", (int)e, (long)(f ^ g)) + object.getClass() + (String)\u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.c("\u3e86", (int)h, (long)i) + this.c);
    }

    @Override
    public JSONObject a(@Nonnull Object object) {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put((String)\u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.c("\u3e80", (int)a, (long)b), object);
        return jSONObject;
    }

    @Generated
    public Class<T> b() {
        return this.c;
    }

    @Override
    @Generated
    public Class<?> a() {
        return this.b;
    }

    static {
        a = (0 >>> 158 | 0 << ~158 + 1) & 0xFFFFFFFF;
        b = Long.reverse(5243620515865848044L);
        c = (0x200000 >>> 213 | 0x200000 << -213) & 0xFFFFFFFF;
        d = Long.reverse(5243620515865848044L);
        e = Integer.reverse(0x40000000);
        f = Long.reverse(7549463525079541996L);
        g = Long.reverse(0x2000000000000000L);
        h = Integer.reverse(-1073741824);
        i = Long.reverse(5243620515865848044L);
        j = Integer.reverse(0x20000000);
        k = 0x8000000 >>> 121 | 0x8000000 << -121;
        a = new String[j];
        b = new String[k];
        \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.b();
        a = new \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1<String>(String.class, String.class);
        b = new \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1<Integer>(Integer.TYPE, Integer.class);
        c = new \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1<Boolean>(Boolean.TYPE, Boolean.class);
        d = new \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1<Long>(Long.TYPE, Long.class);
    }

    private static void b() {
        int n;
        c = 3969435523091047190L;
        long l = c ^ 0x31BC532AD75EB9F5L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(8 + 60), (byte)(66 + 3), (byte)(55 + 28), (byte)(11 + 36), (byte)(61 + 6), (byte)(42 + 24), (byte)(34 + 33), (byte)(11 + 36), (byte)(33 + 47), (byte)(60 + 15), (byte)(13 + 54), 83, (byte)(5 + 48), (byte)(58 + 22), (byte)(58 + 39), (byte)(46 + 54), (byte)(61 + 39), (byte)(20 + 85), (byte)(32 + 78), 103}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(21 + 47), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u016a\u0161\u0138\u017a\u015b\u0174\u0177\u0178\u015d\u0141\u014e\u0147", (byte)64, 65);
                    \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.b[1] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u0567\u055e\u0535\u0577\u0558\u0571\u0574\u0575\u055a\u053e\u054b\u0544", (byte)64, 70);
                    \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.b[2] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.A("\u0161\u0141\u0130\u0138\u0134\u0176\u0150\u0173\u016c\u0133\u015d\u013a\u0140\u0140\u0164\u015d\u0165\u0157\u0168\u017e\u0187\u014b\u0156\u0170\u0170\u0190\u016a\u0180\u0151\u0184\u0177\u016f", (byte)64, 65);
                    \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.b[3] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u052f\u0564\u0529\u0530\u0542\u054b\u0577\u056b\u0574\u0536\u055e\u0574\u0552\u0555\u0564\u054c\u0585\u0544\u0547\u0579\u0585\u0588\u054f\u0550", (byte)64, 70);
                    continue block7;
                }
                case 1: {
                    \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u04ee\u04d7\u04cd\u04e8\u04dc\u04bb\u04d3\u04c8\u04b0\u04d2\u04e1\u04c7\u04b2\u04dc\u04e7\u04cb\u04f2\u04fd\u04bf\u04da\u04ee\u04cb\u04c8\u04c9", (byte)64, 68);
                    \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.b[1] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.F("\u052c\u0557\u056b\u0568\u052b\u0534\u0554\u0547\u0550\u0535\u0567\u0561\u056a\u0550\u0559\u0579\u0570\u0538\u0564\u0550\u0578\u0578\u054f\u0550", (byte)64, 70);
                    \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.b[2] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u055e\u053e\u052d\u0535\u0531\u0573\u054d\u0570\u0569\u0530\u055a\u0537\u053d\u053d\u0561\u055a\u0562\u0554\u0565\u057b\u0584\u0542\u0556\u0543\u0548\u057e\u0563\u0550\u0592\u056e\u0567\u0584", (byte)64, 70);
                    \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.b[3] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u04a8\u04dd\u04a2\u04a9\u04bb\u04c4\u04f0\u04e4\u04ed\u04af\u04d6\u04f6\u04d4\u04ed\u04d5\u04db\u04c9\u04bf\u04e8\u04f5\u04f8\u0501\u04c8\u04c9", (byte)64, 67);
                    continue block7;
                }
                case 2: {
                    \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u04d6\u04d8\u04c2\u04c3\u04e0\u04de\u04e8\u04b1\u04e9\u04e1\u04c8\u04bd", (byte)64, 68);
                    continue block7;
                }
                case 4: {
                    \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.A("\u0151\u0172\u014a\u0166\u016a\u0148\u014a\u0175\u0161\u0138\u013d\u0153\u017f\u0180\u0170\u0150\u0186\u0145\u0179\u0185\u017d\u0155\u0152\u0153", (byte)64, 65);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 4L;
        l ^= 0x31BC532AD75EB9F5L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(37 + 31), (byte)(4 + 65), (byte)(53 + 30), (byte)(18 + 29), (byte)(18 + 49), (byte)(25 + 41), (byte)(54 + 13), (byte)(4 + 43), (byte)(41 + 39), (byte)(39 + 36), 67, (byte)(76 + 7), (byte)(29 + 24), (byte)(78 + 2), (byte)(81 + 16), (byte)(46 + 54), (byte)(7 + 93), 105, (byte)(83 + 27), (byte)(64 + 39)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(3 + 66), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.A("\u0178\u0185\u0184\u0147\u0187\u0183\u017e\u0187\u0192\u0181\u014e\u018c\u0190\u0189\u018c\u0192\u0154\u04e2\u04e2\u04f1\u04d1\u04de\u04d4\u04cf\u04c1\u04df", (byte)75, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u0536\u0558\u055a\u053a\u055e\u057d\u0575\u058b\u0577\u0546\u0584\u057a\u0588\u0582\u054b\u0570\u0592\u0591\u0589\u058f\u0589\u055e", (byte)82, 69), \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.D("\u050e\u051b\u051a\u04dd\u051d\u0519\u0514\u051d\u0528\u0517\u04e4\u0522\u0526\u051f\u0522\u0528\u04ea\u0878\u0878\u0887\u0867\u0874\u086a\u0865\u0857\u0875\u04ff", (byte)82, 68) + string + \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u015d", (byte)82, 66) + methodType.toString(), exception);
        }
    }

    @Generated
    public \u03bc\u03bb\u03c9\u03a8\u03b4\u03a9\u03a3\u0394\u03b1(Class<?> clazz, Class<T> clazz2) {
        this.b = clazz;
        this.c = clazz2;
    }
}

