/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b6\u03c3\u03b5\u03c6\u03c0\u03b1\u03c0\u03c5\u03c2\u03a8\u03a0\u03a6\u03c9\u03bb;
import com.nickuc.login.\u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0;
import com.nickuc.login.\u03c5\u03b1\u03b1\u03c8\u03c8\u03b3\u03be\u0394\u03c8\u03b5\u03a0\u03b1\u03b8\u03c5\u03ba;
import com.nickuc.login.\u03c9\u03c5\u03b2\u03b2\u03b1\u03ba\u03c3\u03b4\u03c4\u03b9\u03a0\u03a3\u03bd;

public class \u03c0\u03b9\u03bc\u03a6\u03b6\u03a9\u03c4\u03c7\u03b2\u03a6\u03b3\u03c5\u03be\u039b {
    private static \u03c9\u03c5\u03b2\u03b2\u03b1\u03ba\u03c3\u03b4\u03c4\u03b9\u03a0\u03a3\u03bd a;

    static \u03c9\u03c5\u03b2\u03b2\u03b1\u03ba\u03c3\u03b4\u03c4\u03b9\u03a0\u03a3\u03bd a() {
        return a;
    }

    static {
        try {
            a = new \u03c5\u03b1\u03b1\u03c8\u03c8\u03b3\u03be\u0394\u03c8\u03b5\u03a0\u03b1\u03b8\u03c5\u03ba();
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            // empty catch block
        }
        try {
            if (a == null) {
                a = new \u03c1\u03bc\u03c2\u03c7\u03a6\u03b2\u03bd\u03b4\u03b9\u03b4\u03a6\u03c0();
            }
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            // empty catch block
        }
        if (a == null) {
            a = new \u03b6\u03c3\u03b5\u03c6\u03c0\u03b1\u03c0\u03c5\u03c2\u03a8\u03a0\u03a6\u03c9\u03bb();
        }
    }
}

