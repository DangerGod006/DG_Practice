/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.loader.platform.BukkitLoader
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.loader.platform.BukkitLoader;
import com.nickuc.login.\u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u0394;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7 {
    private static int o;
    private static int a;
    private static long g;
    private static long q;
    private static int f;
    private static final boolean k;
    private static long p;
    private static int n;
    private static int i;
    private static int t;
    private static int u;
    private static int e;
    private static long h;
    private static long k;
    private static int v;
    private static long b;
    private static long d;
    private static String[] b;
    private static int c;
    private static String[] a;
    private static int l;
    private static int s;
    private static int m;
    private static int r;
    private static long c;
    private static long j;

    static {
        a = 0 >>> 8 | 0 << -8;
        b = Long.reverse(6733081285429602738L);
        c = 32 >>> 5 | 32 << -5;
        d = Long.reverse(6733081285429602738L);
        e = Integer.reverse(0);
        f = (524288 >>> 18 | 524288 << -18) & 0xFFFFFFFF;
        g = Long.reverse(1112588950471223730L);
        h = Long.reverse(0x5200000000000000L);
        i = Integer.reverse(-1073741824);
        j = Long.reverse(1112588950471223730L);
        k = Long.reverse(0x5200000000000000L);
        l = Integer.reverse(0);
        m = Integer.reverse(-1610612736);
        n = Integer.reverse(-1610612736);
        o = (0x400000 >>> 212 | 0x400000 << -212) & 0xFFFFFFFF;
        p = Long.reverse(1112588950471223730L);
        q = Long.reverse(0x5200000000000000L);
        r = Integer.reverse(0x40000000);
        s = 0 >>> 254 | 0 << -254;
        t = Integer.reverse(Integer.MIN_VALUE);
        u = Integer.reverse(Integer.MIN_VALUE);
        v = Integer.reverse(0);
        a = new String[m];
        b = new String[n];
        \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b();
        Class[] classArray = new Class[r];
        classArray[\u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.s] = Plugin.class;
        classArray[\u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.t] = Player.class;
        k = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(Player.class, (String)\u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.c("\u3e80", (int)o, (long)(p ^ q)), classArray) != null ? u : v;
    }

    public static void a(nLoginBukkit nLoginBukkit2, Player player) {
        try {
            BukkitLoader bukkitLoader = nLoginBukkit2.a();
            for (\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 : nLoginBukkit2.b().c()) {
                if (\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.S()) continue;
                Player player2 = (Player)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.c();
                \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.a((Plugin)bukkitLoader, player2, player);
                \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.a((Plugin)bukkitLoader, player, player2);
            }
        }
        catch (Exception exception) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.c("\u3e80", (int)a, (long)b) + player.getName() + (String)\u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.c("\u3e83", (int)c, (long)d), exception, new Object[e]);
        }
    }

    private static void b(Plugin plugin, Player player, Player player2) {
        if (k) {
            player.showPlayer(plugin, player2);
        } else {
            player.showPlayer(player2);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x4AL;
        l ^= 0x2166DC4A6FAD0D14L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(17 + 51), (byte)(32 + 37), (byte)(14 + 69), (byte)(28 + 19), (byte)(25 + 42), 66, (byte)(32 + 35), (byte)(6 + 41), (byte)(48 + 32), (byte)(70 + 5), (byte)(46 + 21), (byte)(70 + 13), (byte)(24 + 29), 80, (byte)(7 + 90), (byte)(54 + 46), (byte)(55 + 45), (byte)(49 + 56), (byte)(47 + 63), (byte)(50 + 53)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(20 + 49), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u04f0\u04fd\u04fc\u04bf\u04ff\u04fb\u04f6\u04ff\u050a\u04f9\u04c6\u0504\u0508\u0501\u0504\u050a\u04cc\u0858\u0832\u0869\u085c\u085d\u0867\u0858\u086c\u0862\u085e", (byte)72, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.B("\u00c7\u00e9\u00eb\u00cb\u00ef\u010e\u0106\u011c\u0108\u00d7\u0115\u010b\u0119\u0113\u00dc\u0101\u0123\u0122\u011a\u0120\u011a\u00ef", (byte)16, 66), \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.A("\u0102\u010f\u010e\u00d1\u0111\u010d\u0108\u0111\u011c\u010b\u00d8\u0116\u011a\u0113\u0116\u011c\u00de\u046a\u0444\u047b\u046e\u046f\u0479\u046a\u047e\u0474\u0470\u00f4", (byte)16, 65) + string + \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.C("\u041f", (byte)16, 67) + methodType.toString(), exception);
        }
    }

    private static void a(Plugin plugin, Player player, Player player2) {
        if (k) {
            player.hidePlayer(plugin, player2);
        } else {
            player.hidePlayer(player2);
        }
    }

    private static void b() {
        int n;
        c = 5590440133169843952L;
        long l = c ^ 0x2166DC4A6FAD0D14L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(41 + 27), (byte)(59 + 10), (byte)(25 + 58), (byte)(41 + 6), 67, (byte)(42 + 24), (byte)(54 + 13), (byte)(23 + 24), (byte)(20 + 60), (byte)(66 + 9), (byte)(5 + 62), (byte)(71 + 12), (byte)(42 + 11), (byte)(67 + 13), 97, (byte)(23 + 77), (byte)(44 + 56), (byte)(11 + 94), (byte)(32 + 78), (byte)(96 + 7)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(16 + 53), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u0543\u0546\u0546\u053b\u0521\u0523\u0528\u0539\u051b\u054d\u0546\u053e\u0536\u0545\u0536\u054e\u0554\u0543\u0530\u0529\u051b\u053e\u0556\u053f\u052e\u0534\u0561\u054c\u052f\u0522\u0560\u0559\u0531\u0554\u0527\u056b\u0540\u055c\u0546\u0528\u053b\u0567\u054b\u0538", (byte)20, 70);
                    \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b[1] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u0509\u0548\u051c\u0548\u050b\u050a\u050b\u0550\u050c\u0530\u050d\u052b\u0556\u0541\u0514\u0559\u0544\u0522\u055c\u053c\u051d\u0526\u0523\u0524", (byte)20, 69);
                    \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b[2] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u0543\u0546\u0546\u053b\u0521\u0523\u0528\u0539\u051b\u054d\u0546\u053e\u0536\u0545\u0536\u054e\u0554\u0543\u0530\u0529\u051b\u053d\u053d\u0520\u0556\u052e\u0520\u051d\u0541\u0525\u053d\u0520\u0533\u0567\u053a\u0548\u055f\u0525\u056b\u053d\u055f\u056d\u0571\u0538", (byte)20, 70);
                    \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b[3] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u0509\u0548\u051c\u0548\u050b\u050a\u050b\u0550\u050c\u0530\u050d\u052b\u0556\u0541\u0514\u0559\u0544\u0522\u055c\u053c\u051d\u0526\u0523\u0524", (byte)20, 70);
                    \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b[4] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0516\u053b\u0535\u0507\u0528\u0548\u053d\u0549\u0542\u0509\u0513\u0527\u0523\u053f\u052d\u0511\u052a\u0549\u0549\u0525\u0519\u054c\u0523\u0524", (byte)20, 70);
                    continue block7;
                }
                case 1: {
                    \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u0464\u0467\u0467\u045c\u0442\u0444\u0449\u045a\u043c\u046e\u0467\u045f\u0457\u0466\u0457\u046f\u0475\u0464\u0451\u044a\u043c\u045f\u0477\u0460\u044f\u0455\u0482\u046d\u0450\u0443\u0481\u047a\u0461\u0475\u0483\u0466\u0479\u0463\u046b\u044a\u0482\u0452\u045c\u0459", (byte)20, 67);
                    \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b[1] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u0509\u0548\u051c\u0548\u050b\u050a\u050b\u0550\u050c\u0530\u050d\u0526\u0541\u0547\u0548\u0542\u0535\u0518\u0537\u0559\u0550\u054c\u0523\u0524", (byte)20, 70);
                    \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b[2] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u0543\u0546\u0546\u053b\u0521\u0523\u0528\u0539\u051b\u054d\u0546\u053e\u0536\u0545\u0536\u054e\u0554\u0543\u0530\u0529\u051b\u053d\u053d\u0520\u0556\u052e\u0520\u051d\u0541\u0525\u053d\u0520\u0555\u0523\u0554\u0562\u055c\u055b\u0541\u0545\u0572\u0542\u054b\u0538", (byte)20, 69);
                    \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b[3] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u042a\u0469\u043d\u0469\u042c\u042b\u042c\u0471\u042d\u0451\u042b\u0470\u0450\u0457\u0454\u0447\u0474\u045c\u0477\u046c\u047b\u0468\u043a\u0438\u044e\u0471\u0479\u0450\u0473\u0454\u0457\u0464", (byte)20, 68);
                    \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b[4] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u0516\u053b\u0535\u0507\u0528\u0548\u053d\u0549\u0542\u0509\u0509\u050e\u0530\u050d\u0543\u0544\u054c\u054d\u053a\u0532\u054c\u055c\u0523\u0524", (byte)20, 69);
                    continue block7;
                }
                case 2: {
                    \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u043b\u0466\u0440\u041f\u044c\u0450\u0444\u0464\u0467\u046e\u0449\u0443\u0474\u0435\u0472\u0444\u0432\u046e\u0445\u0458\u044b\u044c\u043f\u045f\u047c\u046d\u043c\u0470\u043c\u0482\u0478\u0448", (byte)20, 68);
                    continue block7;
                }
                case 4: {
                    \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u0527\u0524\u0514\u052b\u053a\u0527\u050e\u053c\u051e\u0508\u051b\u0518", (byte)20, 70);
                }
            }
        }
    }

    public static void b(nLoginBukkit nLoginBukkit2, Player player) {
        try {
            \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u0394 \u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942 = nLoginBukkit2.a().a();
            BukkitLoader bukkitLoader = nLoginBukkit2.a();
            for (\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 : nLoginBukkit2.b().c()) {
                if (\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.S() || !\u03b5\u03c3\u03bb\u03c1\u0394\u03bc\u0394\u03c8\u03c7\u03b5\u03b8\u03c5\u03bd\u03942.b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)) continue;
                Player player2 = (Player)\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.c();
                \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b((Plugin)bukkitLoader, player2, player);
                \u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.b((Plugin)bukkitLoader, player, player2);
            }
        }
        catch (Exception exception) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.c("\u3e80", (int)f, (long)(g ^ h)) + player.getName() + (String)\u03ba\u0393\u03c9\u03bb\u03bb\u03c4\u03b4\u03c7\u03bc\u03b7.c("\u3e83", (int)i, (long)(j ^ k)), exception, new Object[l]);
        }
    }
}

