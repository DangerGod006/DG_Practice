/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.bcrypt.BCrypt
 *  com.nickuc.login.lib.bcrypt.BCrypt$Hasher
 *  com.nickuc.login.lib.bcrypt.BCrypt$Result
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.lib.bcrypt.BCrypt;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03be\u03b5\u03c4\u03c6\u0394\u03bf\u03a9\u03c8\u03bd\u03b5;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8
implements \u03be\u03b5\u03c4\u03c6\u0394\u03bf\u03a9\u03c8\u03bd\u03b5 {
    private static long n;
    private static int r;
    private static long m;
    private static int h;
    private static int j;
    private final BCrypt.Hasher a;
    private static long d;
    private static int p;
    private static int o;
    private static int b;
    private static int i;
    private static int a;
    private static int f;
    private static long e;
    private static long c;
    private static int q;
    private static int s;
    private static int l;
    private static long k;
    private static int g;
    private static String[] a;
    private static String[] b;

    @Override
    public boolean v(String string) {
        return (!\u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.w(string) ? p : q) != 0;
    }

    private static String a(int n, long l) {
        l ^= 0x42L;
        l ^= 0x8E61B4F3E67583B4L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(29 + 39), (byte)(28 + 41), (byte)(24 + 59), (byte)(15 + 32), (byte)(45 + 22), (byte)(41 + 25), (byte)(60 + 7), (byte)(4 + 43), (byte)(20 + 60), (byte)(33 + 42), (byte)(30 + 37), (byte)(64 + 19), (byte)(49 + 4), (byte)(35 + 45), 97, (byte)(29 + 71), (byte)(10 + 90), (byte)(66 + 39), 110, (byte)(94 + 9)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(29 + 54)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.A("\u00e4\u00f1\u00f0\u00b3\u00f3\u00ef\u00ea\u00f3\u00fe\u00ed\u00ba\u00f8\u00fc\u00f5\u00f8\u00fe\u00c0\u0453\u0459\u0458\u044c\u0450\u0455\u044d\u0450\u0463\u0450\u0450\u045b\u0466\u0460\u0468", (byte)1, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Override
    public String w(String string) {
        return this.a.hashToString(\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.ac.r(), string.toCharArray());
    }

    private static void b() {
        int n;
        c = -5958888590188795124L;
        long l = c ^ 0x8E61B4F3E67583B4L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(23 + 46), (byte)(20 + 63), (byte)(41 + 6), (byte)(48 + 19), (byte)(11 + 55), (byte)(23 + 44), (byte)(33 + 14), (byte)(16 + 64), (byte)(8 + 67), (byte)(9 + 58), (byte)(60 + 23), (byte)(38 + 15), (byte)(42 + 38), (byte)(22 + 75), (byte)(42 + 58), 100, (byte)(82 + 23), (byte)(41 + 69), (byte)(81 + 22)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(69 + 14)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u0178\u0191\u01b4\u01c1\u0178\u019e\u0186\u019f\u01b6\u01ca\u0194\u0191", (byte)101, 66);
                    \u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.b[1] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.C("\u054e\u051b\u055e\u0539\u0542\u0556\u051e\u0523\u0552\u0538\u0522\u052c", (byte)101, 67);
                    \u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.b[2] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u054e\u051b\u055e\u0539\u0542\u0556\u051e\u0523\u0552\u0538\u0522\u052c", (byte)101, 67);
                    continue block7;
                }
                case 1: {
                    \u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.A("\u019c\u01c0\u01a4\u01b6\u0192\u01b5\u017e\u01a2\u01b9\u01a4\u0198\u0191", (byte)101, 65);
                    \u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.b[1] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0568\u0551\u0588\u0579\u0595\u056d\u059c\u0561\u0554\u0559\u057c\u0569", (byte)101, 70);
                    \u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.b[2] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.F("\u0563\u0552\u057b\u0570\u0570\u057b\u056f\u058e\u0578\u0570\u056c\u0569", (byte)101, 70);
                    continue block7;
                }
                case 2: {
                    \u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u058a\u0555\u0588\u0565\u058d\u0568\u056d\u0591\u0574\u058e\u0577\u056e\u0564\u0597\u0580\u0563\u0593\u0579\u0597\u05a6\u058e\u0587\u0574\u0575", (byte)101, 70);
                    continue block7;
                }
                case 4: {
                    \u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.B("\u01ba\u01b0\u01c4\u01b6\u019e\u01a4\u01c5\u019c\u01b5\u01b5\u01b5\u0184\u01cf\u01b8\u01c3\u01ab\u01bd\u01a1\u0193\u01cc\u018e\u01ac\u01ab\u0198\u01b0\u01c3\u0192\u01aa\u01ad\u01b9\u01da\u01d6", (byte)101, 66);
                }
            }
        }
    }

    static {
        a = Integer.reverse(0x3C000000);
        b = 0 >>> 173 | 0 << -173;
        d = Long.reverse(3518672128132231861L);
        e = Long.reverse(0x4200000000000000L);
        f = (512 >>> 9 | 512 << ~9 + 1) & 0xFFFFFFFF;
        g = Integer.reverse(0);
        h = 0 >>> 57 | 0 << -57;
        i = 65536 >>> 16 | 65536 << -16;
        j = (-1 >>> 202 | -1 << -202) & 0xFFFFFFFF;
        k = Long.reverse(8274473334635475637L);
        l = Integer.reverse(0x40000000);
        m = Long.reverse(3518672128132231861L);
        n = Long.reverse(0x4200000000000000L);
        o = Integer.reverse(0);
        p = 32 >>> 69 | 32 << -69;
        q = Integer.reverse(0);
        r = Integer.reverse(-1073741824);
        s = Integer.reverse(-1073741824);
        a = new String[r];
        b = new String[s];
        \u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.b();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u04b5\u04d7\u04d9\u04b9\u04dd\u04fc\u04f4\u050a\u04f6\u04c5\u0503\u04f9\u0507\u0501\u04ca\u04ef\u0511\u0510\u0508\u050e\u0508\u04dd", (byte)72, 67), \u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u04f0\u04fd\u04fc\u04bf\u04ff\u04fb\u04f6\u04ff\u050a\u04f9\u04c6\u0504\u0508\u0501\u0504\u050a\u04cc\u085f\u0865\u0864\u0858\u085c\u0861\u0859\u085c\u086f\u085c\u085c\u0867\u0872\u086c\u0874\u04e7", (byte)72, 67) + string + \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u04c7", (byte)72, 68) + methodType.toString(), exception);
        }
    }

    private static boolean w(String string) {
        return (string.length() == a && string.startsWith((String)\u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.c("\u3e80", (int)b, (long)(d ^ e))) ? f : g) != 0;
    }

    @Generated
    protected \u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8(BCrypt.Hasher hasher) {
        this.a = hasher;
    }

    @Override
    public boolean i(String string, String string2) {
        if (!\u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.w(string2)) {
            return h != 0;
        }
        String string3 = string2.contains((CharSequence)\u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.c("\u3e80", (int)(i & j), (long)k)) ? string2.split((String)\u03c1\u03c6\u03c4\u03b7\u03ba\u03be\u03b5\u03b7\u03c9\u03b5\u03b4\u03be\u03c8\u03c1\u03c8.c("\u3e83", (int)l, (long)(m ^ n)))[o] : string2;
        BCrypt.Result result = BCrypt.verifyer().verify(string.getBytes(StandardCharsets.UTF_8), string3.getBytes(StandardCharsets.UTF_8));
        return result.verified;
    }
}

