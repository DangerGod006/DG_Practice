/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03a3\u03c0\u03a9\u03b5\u03a8\u03c1\u03c9\u03c9\u0394\u03c3\u03c8\u03b2;
import com.nickuc.login.\u03a6\u03a3\u03b1\u03c9\u03b1\u03a8\u03c3\u03a0\u03b8\u03b1;
import com.nickuc.login.\u03a8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class \u0394\u03c4\u03b9\u03b7\u03b7\u03c4\u03b7\u03b6\u0394
extends \u03a3\u03c0\u03a9\u03b5\u03a8\u03c1\u03c9\u03c9\u0394\u03c3\u03c8\u03b2<ResultSet> {
    private final PreparedStatement a;

    private \u0394\u03c4\u03b9\u03b7\u03b7\u03c4\u03b7\u03b6\u0394(\u03a8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2 \u03c8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2, Connection connection, PreparedStatement preparedStatement, ResultSet resultSet) {
        super(\u03c8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2, connection, resultSet, null);
        this.a = preparedStatement;
    }

    @Override
    public void close() {
        ((ResultSet)this.d()).close();
        this.a.close();
        this.e.a(this.b);
    }

    /* synthetic */ \u0394\u03c4\u03b9\u03b7\u03b7\u03c4\u03b7\u03b6\u0394(\u03a8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2 \u03c8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2, Connection connection, PreparedStatement preparedStatement, ResultSet resultSet, \u03a6\u03a3\u03b1\u03c9\u03b1\u03a8\u03c3\u03a0\u03b8\u03b1 \u03c6\u03a3\u03b1\u03c9\u03b1\u03a8\u03c3\u03a0\u03b8\u03b1) {
        this(\u03c8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2, connection, preparedStatement, resultSet);
    }
}

