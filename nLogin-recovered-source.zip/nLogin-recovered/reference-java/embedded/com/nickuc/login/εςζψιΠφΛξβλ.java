/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.jedis.JedisCluster
 *  com.nickuc.login.lib.jedis.JedisPooled
 *  com.nickuc.login.lib.jedis.JedisPubSub
 *  com.nickuc.login.lib.jedis.UnifiedJedis
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.lib.jedis.JedisCluster;
import com.nickuc.login.lib.jedis.JedisPooled;
import com.nickuc.login.lib.jedis.JedisPubSub;
import com.nickuc.login.lib.jedis.UnifiedJedis;
import com.nickuc.login.\u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u039b\u03a3\u03c7\u03b1\u03c5\u03b8\u03b4\u03c4\u03b7\u03be\u03b5\u03bb\u03b1\u03b3;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.io.Closeable;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
class \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb
extends JedisPubSub
implements Closeable,
Runnable {
    private static int x;
    private static int w;
    private static int n;
    private static int ad;
    private static int e;
    private static long ab;
    private static int ah;
    private static long m;
    private static long g;
    private static long af;
    private static int l;
    private static String[] a;
    private static int b;
    private static int z;
    private final Consumer<String> b;
    private static long r;
    private static int a;
    private static int s;
    private static int j;
    private final String bm;
    private static long ac;
    private static String[] b;
    private static int h;
    private static int v;
    private static long y;
    private static int ai;
    private static int ae;
    private static int u;
    private static long o;
    private static int aa;
    private static int ag;
    private static int c;
    private static int t;
    private static int q;
    private static long d;
    private static int k;
    private boolean ae;
    private static long p;
    private static int i;
    private static long c;
    private final \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3 b;
    private static long f;

    private boolean ak() {
        UnifiedJedis unifiedJedis = \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.a(this.b);
        if (unifiedJedis instanceof JedisPooled) {
            return (!((JedisPooled)unifiedJedis).getPool().isClosed() ? s : t) != 0;
        }
        if (unifiedJedis instanceof JedisCluster) {
            return (!((JedisCluster)unifiedJedis).getClusterNodes().isEmpty() ? u : v) != 0;
        }
        throw new RuntimeException((String)\u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.c("\u3e80", (int)(w & x), (long)y) + unifiedJedis.getClass().getName());
    }

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = Integer.reverse(0);
        c = Integer.reverse(0);
        d = Long.reverse(-6572979787661432242L);
        e = 0x200000 >>> 181 | 0x200000 << -181;
        f = Long.reverse(-8158246856495846834L);
        g = Long.reverse(0x2A00000000000000L);
        h = (0 >>> 94 | 0 << -94) & 0xFFFFFFFF;
        i = Integer.reverse(Integer.MIN_VALUE);
        j = Integer.reverse(0);
        k = (1024 >>> 201 | 1024 << -201) & 0xFFFFFFFF;
        l = Integer.reverse(-1);
        m = Long.reverse(-6572979787661432242L);
        n = -1073741824 >>> 254 | -1073741824 << -254;
        o = Long.reverse(-8158246856495846834L);
        p = Long.reverse(0x2A00000000000000L);
        q = (0 >>> 5 | 0 << -5) & 0xFFFFFFFF;
        r = Long.reverse(1281274093986906112L);
        s = Integer.reverse(Integer.MIN_VALUE);
        t = Integer.reverse(0);
        u = (16 >>> 164 | 16 << ~164 + 1) & 0xFFFFFFFF;
        v = Integer.reverse(0);
        w = (0x8000000 >>> 89 | 0x8000000 << ~89 + 1) & 0xFFFFFFFF;
        x = Integer.reverse(-1);
        y = Long.reverse(-6572979787661432242L);
        z = 131072 >>> 177 | 131072 << -177;
        aa = 160 >>> 5 | 160 << ~5 + 1;
        ab = Long.reverse(-8158246856495846834L);
        ac = Long.reverse(0x2A00000000000000L);
        ad = Integer.reverse(0x60000000);
        ae = (-1 >>> 136 | -1 << -136) & 0xFFFFFFFF;
        af = Long.reverse(-6572979787661432242L);
        ag = Integer.reverse(0);
        ah = Integer.reverse(-536870912);
        ai = Integer.reverse(-536870912);
        a = new String[ah];
        b = new String[ai];
        \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u053b\u055d\u055f\u053f\u0563\u0582\u057a\u0590\u057c\u054b\u0589\u057f\u058d\u0587\u0550\u0575\u0597\u0596\u058e\u0594\u058e\u0563", (byte)87, 70), \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.F("\u0576\u0583\u0582\u0545\u0585\u0581\u057c\u0585\u0590\u057f\u054c\u058a\u058e\u0587\u058a\u0590\u0552\u08d9\u08e7\u08dc\u08ef\u08e1\u08c9\u08f0\u08c6\u08ea\u08df\u08e9\u0569", (byte)87, 70) + string + \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.E("\u054d", (byte)87, 69) + methodType.toString(), exception);
        }
    }

    @Override
    public void run() {
        int n = a;
        while (!this.ae && !Thread.interrupted() && this.ak()) {
            try {
                if (n != 0) {
                    n = b;
                } else {
                    \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.e((String)\u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.c("\u3e80", (int)c, (long)d) + this.bm + (String)\u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.c("\u3e83", (int)e, (long)(f ^ g)), new Object[h]);
                }
                String[] stringArray = new String[i];
                stringArray[\u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.j] = this.bm;
                \u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3.a(this.b).subscribe((JedisPubSub)this, stringArray);
            }
            catch (Exception exception) {
                if (this.ae) {
                    return;
                }
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.b((String)\u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.c("\u3e86", (int)(k & l), (long)m) + this.bm + (String)\u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.c("\u3e89", (int)\u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.n, (long)(o ^ p)), exception, new Object[q]);
                try {
                    this.unsubscribe();
                }
                catch (Exception exception2) {
                    // empty catch block
                }
                try {
                    Thread.sleep(r);
                }
                catch (InterruptedException interruptedException) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    public /* synthetic */ void b(Object object, Object object2) {
        this.m((String)object, (String)object2);
    }

    private static void b() {
        int n;
        c = 8238342705137587057L;
        long l = c ^ 0xD30F094C11EA8D36L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(21 + 47), 69, (byte)(12 + 71), (byte)(30 + 17), (byte)(41 + 26), (byte)(28 + 38), (byte)(49 + 18), (byte)(29 + 18), (byte)(8 + 72), (byte)(36 + 39), (byte)(45 + 22), (byte)(41 + 42), (byte)(23 + 30), (byte)(4 + 76), (byte)(63 + 34), (byte)(55 + 45), (byte)(99 + 1), (byte)(80 + 25), 110, (byte)(95 + 8)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(64 + 4), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u0563\u059c\u05a3\u057e\u0579\u058c\u0574\u0583\u0584\u056d\u0584\u0575", (byte)113, 70);
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[1] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.D("\u0557\u056e\u0582\u0540\u0556\u0573\u0545\u0563\u0544\u0560\u0576\u0589\u0585\u054a\u056d\u056c\u054c\u0586\u0591\u0592\u058a\u056c\u0555\u0566\u058a\u056c\u0551\u056c\u0571\u056b\u0572\u0598\u0589\u0572\u057b\u0562\u0582\u0596\u0582\u0590\u05a3\u059b\u0563\u0585\u0597\u057f\u0585\u0598\u0580\u057d\u05b1\u0583\u05a7\u056f\u0580\u058d\u0574\u0591\u05b0\u05ad\u0576\u05a9\u05ad\u05a8", (byte)113, 68);
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[2] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u0197\u01d0\u01d7\u01b2\u01ad\u01c0\u01a8\u01b7\u01b8\u01a1\u01b8\u01a9", (byte)113, 65);
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[3] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u01b0\u01c7\u01db\u0199\u01af\u01cc\u019e\u01bc\u019d\u01b9\u01cf\u01e2\u01de\u01a3\u01c6\u01c5\u01a5\u01df\u01ea\u01eb\u01e3\u01c5\u01ae\u01bf\u01e3\u01c5\u01aa\u01c5\u01ca\u01c4\u01cb\u01f1\u01f6\u01b2\u01dd\u01bc\u01d6\u01cc\u01dd\u01ed\u01bf\u01fd\u0200\u01bd\u01c2\u01e4\u0204\u01f5\u0209\u01d7\u01c8\u01e1\u01ec\u020a\u01de\u020c\u0201\u01e6\u01cc\u01cc\u01f0\u01f1\u01d7\u01d0\u01d1\u0219\u01e7\u01dc\u0215\u021c\u01f6\u0215\u0210\u0221\u021a\u01e2\u0207\u021f\u0226\u0219\u0222\u01fc\u022a\u022b\u0209\u01ec\u0223\u0202\u01fc\u020e\u0228\u0222\u0207\u01f6\u0203\u01f9", (byte)113, 65);
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[4] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u0598\u0577\u0565\u0571\u0569\u0595\u0588\u058d\u058d\u059e\u0579\u0589\u058a\u056d\u0583\u05aa\u058c\u0572\u0578\u0577\u05b1\u0572\u059c\u05b0\u05b0\u0578\u05aa\u05b9\u059c\u0596\u05b8\u05af", (byte)113, 69);
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[5] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u0563\u059c\u05a3\u057e\u0579\u058c\u0574\u0583\u0584\u056d\u0584\u0575", (byte)113, 69);
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[6] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u057c\u0593\u05a7\u0565\u057b\u0598\u056a\u0588\u0569\u0585\u059c\u05ac\u0593\u056d\u05a6\u056b\u05b3\u05a4\u05a4\u0575\u0579\u05b2\u0588\u05a7\u057d\u05a0\u05b9\u05bd\u05c1\u057d\u05b3\u05b2\u057e\u05b7\u05a6\u05a9\u05cb\u0588\u0583\u0597\u05c1\u05aa\u058d\u0591\u0584\u05a6\u05c9\u05b0\u05d4\u05ad\u05d9\u05b0\u05db\u05b3\u05a0\u05a1", (byte)113, 69);
                    continue block7;
                }
                case 1: {
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u054f\u0563\u057d\u0564\u054e\u0543\u0544\u0548\u0542\u0580\u055b\u0550", (byte)113, 67);
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.A("\u01b0\u01c7\u01db\u0199\u01af\u01cc\u019e\u01bc\u019d\u01b9\u01cf\u01e2\u01de\u01a3\u01c6\u01c5\u01a5\u01df\u01ea\u01eb\u01e3\u01c5\u01ae\u01bf\u01e3\u01c5\u01aa\u01c5\u01ca\u01c4\u01cb\u01f1\u01e2\u01cb\u01d4\u01bb\u01db\u01ef\u01db\u01e9\u01fc\u01f4\u01bc\u01de\u01f0\u01d8\u01de\u01f1\u01d9\u01d6\u020a\u01dc\u0200\u01cb\u0204\u01dc\u01e1\u01c9\u01f2\u01ce\u01d4\u01e3\u01f7\u01d4", (byte)113, 65);
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u01cb\u0193\u01b1\u01c7\u01d2\u01a8\u019e\u019a\u01df\u01d7\u01c0\u01a9", (byte)113, 66);
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[3] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u01b0\u01c7\u01db\u0199\u01af\u01cc\u019e\u01bc\u019d\u01b9\u01cf\u01e2\u01de\u01a3\u01c6\u01c5\u01a5\u01df\u01ea\u01eb\u01e3\u01c5\u01ae\u01bf\u01e3\u01c5\u01aa\u01c5\u01ca\u01c4\u01cb\u01f1\u01f6\u01b2\u01dd\u01bc\u01d6\u01cc\u01dd\u01ed\u01bf\u01fd\u0200\u01bd\u01c2\u01e4\u0204\u01f5\u0209\u01d7\u01c8\u01e1\u01ec\u020a\u01de\u020c\u0201\u01e6\u01cc\u01cc\u01f0\u01f1\u01d7\u01d0\u01d1\u0219\u01e7\u01dc\u0215\u021c\u01f6\u0215\u0210\u0221\u021a\u01e2\u0207\u021f\u0226\u0219\u0222\u01fc\u022a\u022b\u0209\u0230\u0207\u022f\u020b\u021f\u020b\u020a\u0228\u021f\u0202\u01ef", (byte)113, 66);
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[4] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u0573\u0552\u0540\u054c\u0544\u0570\u0563\u0568\u0568\u0579\u0554\u0564\u0565\u0548\u055e\u0585\u0567\u054d\u0553\u0552\u058c\u054e\u0578\u0560\u0567\u0569\u0593\u058e\u0588\u056f\u055a\u059c", (byte)113, 68);
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[5] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u01aa\u01b9\u01cb\u01af\u01a8\u01b7\u01e1\u019a\u01e1\u01c2\u01de\u01a9", (byte)113, 66);
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[6] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u057c\u0593\u05a7\u0565\u057b\u0598\u056a\u0588\u0569\u0585\u059c\u05ac\u0593\u056d\u05a6\u056b\u05b3\u05a4\u05a4\u0575\u0579\u05b2\u0588\u05a7\u057d\u05a0\u05b9\u05bd\u05c1\u057d\u05b3\u05b2\u057e\u05b7\u05a6\u05a9\u05cb\u0588\u0583\u0597\u05c1\u05aa\u058e\u0591\u05bd\u05c2\u05a9\u05a6\u05c9\u05d8\u058a\u05ce\u05af\u05c9\u05a0\u05a1", (byte)113, 70);
                    continue block7;
                }
                case 2: {
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[0] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.D("\u057a\u054a\u0573\u0570\u055a\u055d\u0585\u0584\u0580\u0542\u0574\u0559\u0575\u0578\u055a\u0560\u0586\u0549\u056f\u055c\u056b\u056e\u055b\u055c", (byte)113, 68);
                    continue block7;
                }
                case 4: {
                    \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u0541\u0540\u055e\u0562\u057e\u055d\u057c\u0560\u0573\u0565\u0546\u0550", (byte)113, 67);
                }
            }
        }
    }

    @Override
    public void close() {
        this.ae = z;
        try {
            this.unsubscribe();
        }
        catch (Exception exception) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.b((String)\u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.c("\u3e80", (int)aa, (long)(ab ^ ac)) + this.bm + (String)\u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.c("\u3e83", (int)(ad & ae), (long)af), exception, new Object[ag]);
        }
    }

    @Generated
    private \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb(\u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3 \u03b3\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3, String string, Consumer<String> consumer) {
        this.b = \u03b3\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3;
        this.bm = string;
        this.b = (int)consumer;
    }

    private static String a(int n, long l) {
        l ^= 0x54L;
        l ^= 0xD30F094C11EA8D36L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(65 + 3), (byte)(56 + 13), (byte)(33 + 50), 47, (byte)(20 + 47), (byte)(38 + 28), (byte)(56 + 11), (byte)(18 + 29), (byte)(47 + 33), (byte)(5 + 70), 67, (byte)(74 + 9), (byte)(9 + 44), (byte)(14 + 66), (byte)(11 + 86), (byte)(89 + 11), (byte)(60 + 40), (byte)(7 + 98), (byte)(67 + 43), (byte)(74 + 29)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(35 + 48)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u054e\u055b\u055a\u051d\u055d\u0559\u0554\u055d\u0568\u0557\u0524\u0562\u0566\u055f\u0562\u0568\u052a\u08b1\u08bf\u08b4\u08c7\u08b9\u08a1\u08c8\u089e\u08c2\u08b7\u08c1", (byte)47, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    /* synthetic */ \u03b5\u03c2\u03b6\u03c8\u03b9\u03a0\u03c6\u039b\u03be\u03b2\u03bb(\u0393\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3 \u03b3\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3, String string, Consumer consumer, \u03b8\u039b\u03a3\u03c7\u03b1\u03c5\u03b8\u03b4\u03c4\u03b7\u03be\u03b5\u03bb\u03b1\u03b3 \u03b8\u039b\u03a3\u03c7\u03b1\u03c5\u03b8\u03b4\u03c4\u03b7\u03be\u03b5\u03bb\u03b1\u03b32) {
        this(\u03b3\u03c5\u03b5\u03c4\u03bd\u039b\u03b6\u03a0\u03b9\u0393\u03b6\u03a3, string, consumer);
    }

    public void m(String string, String string2) {
        if (!string.equals(this.bm)) {
            return;
        }
        this.b.accept(string2);
    }
}

