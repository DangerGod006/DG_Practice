/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.md_5.bungee.api.chat.TextComponent
 *  net.md_5.bungee.api.connection.PendingConnection
 *  net.md_5.bungee.api.event.LoginEvent
 *  net.md_5.bungee.connection.InitialHandler
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c8\u03a8\u03c0\u03b7\u03b7\u03c5\u03c5\u03b4\u0394\u03b7;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.PendingConnection;
import net.md_5.bungee.api.event.LoginEvent;
import net.md_5.bungee.connection.InitialHandler;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2 {
    private static int bb;
    private static long aw;
    private static final Field p;
    private static int bg;
    private static int ao;
    private static int bd;
    private static long t;
    private static int k;
    private static int s;
    private static long ac;
    private static long u;
    private static long g;
    private static long bc;
    private static long q;
    private static int ad;
    private static int n;
    private static final Field s;
    private static int v;
    private static long as;
    private static int b;
    private static long d;
    private static int ab;
    private static long h;
    private static String[] a;
    private static long p;
    private static long be;
    private static final Field r;
    private static int ak;
    private static int ae;
    private static int at;
    private static int af;
    private static String[] b;
    private static int i;
    private static int au;
    private static long w;
    private static int ap;
    private static long m;
    private static long c;
    private static int aq;
    private static int x;
    private static int a;
    private static long l;
    private static long e;
    private static long ar;
    private static long y;
    private static int ay;
    private static final Field q;
    private static int aj;
    private static int aa;
    private static int ah;
    private static int j;
    private static int bf;
    private static int az;
    private static final Field o;
    private static int r;
    private static long z;
    private static long ax;
    private static long ai;
    private static long ba;
    private static int al;
    private static long an;
    private static int am;
    private static int ag;
    private static int f;
    private static int o;
    private static int av;
    private static final Class<?> o;

    static void a(PendingConnection pendingConnection, String string) {
        if (string == null) {
            throw new IllegalArgumentException((String)\u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.c("\u3e80", (int)o, (long)(p ^ q)));
        }
        if (string.length() > r) {
            throw new IllegalArgumentException((String)\u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.c("\u3e83", (int)s, (long)(t ^ u)) + string);
        }
        if (!pendingConnection.getName().equals(string)) {
            o.set(pendingConnection, string);
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u04d6\u04f8\u04fa\u04da\u04fe\u051d\u0515\u052b\u0517\u04e6\u0524\u051a\u0528\u0522\u04eb\u0510\u0532\u0531\u0529\u052f\u0529\u04fe", (byte)83, 67), \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0572\u057f\u057e\u0541\u0581\u057d\u0578\u0581\u058c\u057b\u0548\u0586\u058a\u0583\u0586\u058c\u054e\u08c3\u08d2\u08d3\u08d8\u08e2\u08e3\u08d9\u08e9\u0562", (byte)83, 70) + string + \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u0549", (byte)83, 69) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x62L;
        l ^= 0x32B36DAAA19FF5AAL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(13 + 55), (byte)(37 + 32), (byte)(30 + 53), (byte)(7 + 40), (byte)(19 + 48), (byte)(36 + 30), (byte)(3 + 64), 47, (byte)(7 + 73), (byte)(34 + 41), (byte)(22 + 45), 83, (byte)(10 + 43), (byte)(27 + 53), (byte)(7 + 90), (byte)(81 + 19), (byte)(47 + 53), (byte)(41 + 64), (byte)(44 + 66), (byte)(7 + 96)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(11 + 58), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u04b1\u04be\u04bd\u0480\u04c0\u04bc\u04b7\u04c0\u04cb\u04ba\u0487\u04c5\u04c9\u04c2\u04c5\u04cb\u048d\u0802\u0811\u0812\u0817\u0821\u0822\u0818\u0828", (byte)51, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static boolean a(LoginEvent loginEvent, UUID uUID) {
        PendingConnection pendingConnection = loginEvent.getConnection();
        try {
            \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.a(pendingConnection, uUID);
            return a != 0;
        }
        catch (IllegalAccessException illegalAccessException) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.c("\u3e80", (int)b, (long)(d ^ e)) + pendingConnection.getName() + (String)\u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.c("\u3e83", (int)f, (long)(g ^ h)), illegalAccessException, new Object[i]);
            loginEvent.setCancelled(j != 0);
            loginEvent.setCancelReason(TextComponent.fromLegacyText((String)\u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.c("\u3e86", (int)k, (long)(l ^ m))));
            return n != 0;
        }
    }

    static void a(PendingConnection pendingConnection, UUID uUID) {
        if (uUID == null) {
            throw new IllegalArgumentException((String)\u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.c("\u3e80", (int)v, (long)w));
        }
        p.set(pendingConnection, uUID);
        if (q != null) {
            q.set(pendingConnection, uUID);
        }
    }

    @Nullable
    static UUID a(PendingConnection pendingConnection) {
        if (r == null || s == null) {
            throw new UnsupportedOperationException((String)\u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.c("\u3e80", (int)x, (long)(y ^ z)));
        }
        Object object = r.get(pendingConnection);
        if (object == null) {
            throw new IllegalArgumentException((String)\u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.c("\u3e83", (int)(aa & ab), (long)ac));
        }
        return (UUID)s.get(object);
    }

    private static void b() {
        int n;
        c = -6823675783606093584L;
        long l = c ^ 0x32B36DAAA19FF5AAL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(53 + 15), (byte)(31 + 38), (byte)(55 + 28), (byte)(18 + 29), (byte)(16 + 51), (byte)(8 + 58), 67, (byte)(14 + 33), 80, (byte)(30 + 45), (byte)(9 + 58), (byte)(31 + 52), (byte)(34 + 19), (byte)(75 + 5), (byte)(79 + 18), (byte)(79 + 21), (byte)(7 + 93), (byte)(49 + 56), (byte)(95 + 15), (byte)(12 + 91)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(32 + 36), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u054e\u0549\u0543\u054c\u054a\u0563\u0548\u0562\u0552\u052b\u0564\u0570\u0559\u056b\u0567\u055a\u057d\u0537\u053b\u0552\u0560\u055b\u055a\u055d\u057c\u055f\u057e\u0554\u0589\u058b\u058c\u054c\u057c\u056f\u054b\u058a\u058f\u0594\u0552\u0557\u054e\u0574\u0571\u0590\u058c\u0591\u0566\u056d\u057c\u0557\u0583\u0593\u055f\u0593\u056a\u056b", (byte)59, 70);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[1] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u0497\u04b6\u04e1\u04ab\u04bc\u04df\u04c1\u049f\u04e1\u04b4\u04c5\u04ae", (byte)59, 68);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[2] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u013c\u0165\u0169\u0147\u0169\u013d\u014b\u0176\u014a\u0142\u0131\u0156\u0142\u0169\u0172\u0137\u0157\u0177\u0152\u0172\u013f\u013b\u017c\u0159\u0180\u015b\u0154\u015b\u0158\u0165\u0186\u0177\u0185\u015e\u0150\u016f\u014a\u018c\u0150\u014d\u018f\u0182\u0160\u0159\u0198\u0174\u0187\u0174\u017c\u0168\u0179\u016d\u016c\u0191\u0160\u016d\u019b\u0166\u01a9\u0169\u0192\u0196\u018d\u01a6\u0198\u017b\u0170\u0183\u017f\u01a1\u0190\u01b4\u018c\u0187\u01b6\u017d", (byte)59, 65);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[3] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.C("\u04e0\u04d5\u04db\u04a1\u04b1\u04b2\u04a1\u04d9\u04d3\u04e0\u04c4\u04d2\u04b3\u04e9\u04de\u04ec\u04c3\u04aa\u04bb\u04b0\u04ea\u04f4\u04e9\u04bf\u04af\u04cb\u04d3\u04c2\u04ed\u04ec\u04dd\u04ba", (byte)59, 67);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[4] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u04d9\u0492\u04d6\u04dc\u04df\u04bc\u04b1\u04d6\u04c5\u04a6\u04a4\u04be\u04eb\u04a6\u04d7\u04ac\u04e8\u04b0\u04e2\u04ad\u04eb\u04e1\u04cf\u04e0\u04ae\u04d5\u04d8\u04d0\u04c6\u04ae\u04fe\u04e9\u04cf\u04b7\u04e1\u04f1\u04dc\u04f7\u04d7\u04c6\u04fb\u04e6\u04e4\u0507\u04e1\u04f6\u04d8\u0508\u04cd\u04ef\u04d1\u0512\u04de\u0502\u04d9\u04da", (byte)59, 68);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[5] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.D("\u04be\u04d6\u0498\u04be\u04b5\u04a1\u04d6\u04d5\u04bd\u04c8\u04a7\u04a3\u04bb\u049e\u04aa\u04a6\u04bf\u04ab\u04ee\u04e4\u04ee\u04ef\u04c7\u04c4\u04ea\u04ef\u04b1\u04eb\u04ed\u04d4\u04c8\u04e7\u04b7\u04f9\u04d3\u04b4\u04d8\u04dd\u04f6\u04c0\u04d1\u04f1\u04dd\u04ce", (byte)59, 68);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[6] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u056f\u054a\u0532\u056a\u0547\u0569\u052e\u0537\u0548\u0556\u0531\u0537\u054b\u056c\u057e\u053c\u057d\u0541\u053e\u0583\u0573\u0578\u0550\u056f\u0568\u0569\u058b\u056c\u0564\u057d\u0584\u056b\u0558\u057a\u058c\u054d\u056c\u058c\u058e\u0587\u0558\u0588\u0583\u058a\u0557\u0570\u0569\u0596\u059b\u055e\u059b\u0599\u0564\u05a1\u057b\u0582\u0596\u059f\u0572\u0577\u0567\u059d\u0568\u0568\u0578\u05ac\u0583\u0587\u05b3\u0592\u0589\u0575\u056f\u0597\u05b4\u05b8\u059c\u05a5\u05ac\u057a\u05b1\u058b\u059f\u05ad\u05ba\u058d\u058a\u058b", (byte)59, 69);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[7] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.A("\u016d\u0148\u0130\u0168\u0145\u0167\u012c\u0135\u0146\u0154\u012f\u0145\u0169\u0136\u0168\u014c\u0147\u0148\u015e\u0170\u015a\u015d\u0157\u0186\u015e\u0155\u0156\u0164\u015a\u0147\u0158\u0175\u018b\u015e\u015a\u018f\u017b\u017f\u014c\u0187\u0174\u0152\u0160\u0184\u0174\u0183\u019a\u0155\u018b\u0199\u018b\u0196\u019c\u016b\u0168\u0169", (byte)59, 65);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[8] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.D("\u0498\u04b5\u04ac\u04cf\u04d4\u04a4\u049e\u04a5\u04db\u04c8\u04bc\u04dc\u04ba\u04e6\u04d6\u04de\u04bf\u04c9\u04c2\u04aa\u04e7\u04de\u04d5\u04be\u04b7\u04ea\u04b4\u04d7\u04fb\u04db\u04f0\u04e8\u04fa\u04cf\u04fa\u04e2\u04c1\u04b6\u04ce\u04c6\u04f6\u04e6\u04ea\u04f4\u04e7\u0505\u04fd\u0503\u04ce\u04df\u04ca\u0504\u04ed\u04f3\u0513\u050b\u050f\u04e8\u0513\u050e\u0511\u04e7\u04f2\u04f6", (byte)59, 68);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[9] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u052f\u054c\u053a\u0525\u0575\u054a\u0557\u0552\u054e\u0553\u0539\u053f", (byte)59, 70);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[10] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u013e\u013a\u014d\u013e\u012d\u012a\u0144\u0134\u016c\u015f\u0161\u016c\u014e\u0158\u0133\u0149\u017b\u0172\u0138\u0156\u0173\u015b\u0148\u0149", (byte)59, 66);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[11] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u0159\u014b\u016b\u0139\u0144\u0144\u0134\u0132\u0177\u014d\u0145\u0144\u0175\u0139\u014b\u0171\u0157\u0150\u0140\u014b\u0151\u0171\u0148\u0149", (byte)59, 66);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[12] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u054e\u0549\u0543\u054c\u054a\u0563\u0548\u0562\u0552\u052b\u0565\u056c\u0544\u0568\u055c\u0570\u0568\u0551\u054a\u0543\u0536\u0586\u0540\u0582\u0540\u0576\u0556\u0581\u0556\u056a\u0576\u0564\u0587\u0551\u0549\u054c\u0561\u0566\u058c\u0594\u0588\u0582\u056a\u055f", (byte)59, 69);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[13] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u04bd\u04b8\u04b2\u04bb\u04b9\u04d2\u04b7\u04d1\u04c1\u049a\u04d4\u04db\u04b3\u04d7\u04cb\u04df\u04d7\u04c0\u04b9\u04b2\u04a5\u04f5\u04af\u04f1\u04af\u04e5\u04c5\u04f0\u04c5\u04d9\u04e5\u04d3\u04b5\u04d6\u04bd\u04de\u04c0\u04bb\u04f8\u04bf\u04de\u04c3\u04c5\u04fa\u04fe\u04f8\u04e5\u04e1\u04d7\u04c8\u04ce\u04f2\u04df\u04fc\u04fe\u0508\u04ed\u0507\u04e2\u0506\u0504\u04e4\u04d8\u04e7", (byte)59, 67);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[14] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.F("\u054e\u0549\u0543\u054c\u054a\u0563\u0548\u0562\u0552\u052b\u0565\u056c\u0544\u0568\u055c\u0570\u0568\u0551\u054a\u0543\u0536\u0586\u0540\u0582\u0540\u0576\u0556\u0581\u0556\u056a\u0576\u0564\u0550\u0559\u0569\u0584\u0550\u0554\u0589\u058a\u0553\u0571\u0584\u0588\u055b\u058b\u055a\u0559\u057d\u0573\u057d\u0593\u0576\u05a6\u0584\u057c\u05a1\u0597\u05a1\u0594\u059f\u0577\u0583\u0561\u056c\u05b2\u0571\u0571\u05a0\u058c\u05a6\u0573\u0592\u05ae\u0579\u057f", (byte)59, 70);
                    continue block7;
                }
                case 1: {
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u04bd\u04b8\u04b2\u04bb\u04b9\u04d2\u04b7\u04d1\u04c1\u049a\u04d3\u04df\u04c8\u04da\u04d6\u04c9\u04ec\u04a6\u04aa\u04c1\u04cf\u04ca\u04c9\u04cc\u04eb\u04ce\u04ed\u04c3\u04f8\u04fa\u04fb\u04bb\u04eb\u04de\u04ba\u04f9\u04fe\u0503\u04c1\u04c6\u04bd\u04e3\u04e0\u0504\u04cb\u04f9\u04c3\u04c6\u04e8\u0511\u04fa\u050e\u050c\u04ec\u04d9\u04da", (byte)59, 67);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[1] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u0149\u0164\u012b\u015f\u0165\u016a\u014f\u0145\u014a\u0133\u016e\u013d", (byte)59, 66);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[2] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u04ad\u04d6\u04da\u04b8\u04da\u04ae\u04bc\u04e7\u04bb\u04b3\u04a2\u04c7\u04b3\u04da\u04e3\u04a8\u04c8\u04e8\u04c3\u04e3\u04b0\u04ac\u04ed\u04ca\u04f1\u04cc\u04c5\u04cc\u04c9\u04d6\u04f7\u04e8\u04f6\u04cf\u04c1\u04e0\u04bb\u04fd\u04c1\u04be\u0500\u04f3\u04d1\u04ca\u0509\u04e5\u04f8\u04e5\u04ed\u04d9\u04ea\u04de\u04dd\u0502\u04d1\u04de\u050c\u04d7\u051a\u04da\u0503\u0507\u04fe\u0517\u051c\u04d9\u04f9\u0503\u0516\u0518\u051e\u04fd\u0516\u04f9\u051f\u04ee", (byte)59, 68);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[3] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.C("\u04e0\u04d5\u04db\u04a1\u04b1\u04b2\u04a1\u04d9\u04d3\u04e0\u04c4\u04d2\u04b3\u04e9\u04de\u04ec\u04c3\u04aa\u04bb\u04b0\u04ea\u04b0\u04b3\u04b5\u04b5\u04e1\u04f8\u04f1\u04d7\u04b7\u04f6\u04ea", (byte)59, 67);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[4] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.D("\u04d9\u0492\u04d6\u04dc\u04df\u04bc\u04b1\u04d6\u04c5\u04a6\u04a4\u04be\u04eb\u04a6\u04d7\u04ac\u04e8\u04b0\u04e2\u04ad\u04eb\u04e1\u04cf\u04e0\u04ae\u04d5\u04d8\u04d0\u04c6\u04ae\u04fe\u04e9\u04cf\u04b7\u04e1\u04f1\u04dc\u04f7\u04d7\u04c6\u04fb\u04e6\u04e3\u0506\u04e3\u04da\u04fe\u0507\u04e5\u04ce\u0508\u0505\u04ce\u0512\u04d9\u04da", (byte)59, 68);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[5] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.C("\u04be\u04d6\u0498\u04be\u04b5\u04a1\u04d6\u04d5\u04bd\u04c8\u04a7\u04a3\u04bb\u049e\u04aa\u04a6\u04bf\u04ab\u04ee\u04e4\u04ee\u04ef\u04c7\u04c4\u04ea\u04ef\u04b1\u04eb\u04ed\u04d4\u04c8\u04e7\u04df\u04ee\u04f7\u04dd\u04d9\u04f4\u04de\u04c4\u04fe\u04fe\u0507\u04ce", (byte)59, 67);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[6] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u04de\u04b9\u04a1\u04d9\u04b6\u04d8\u049d\u04a6\u04b7\u04c5\u04a0\u04a6\u04ba\u04db\u04ed\u04ab\u04ec\u04b0\u04ad\u04f2\u04e2\u04e7\u04bf\u04de\u04d7\u04d8\u04fa\u04db\u04d3\u04ec\u04f3\u04da\u04c7\u04e9\u04fb\u04bc\u04db\u04fb\u04fd\u04f6\u04c7\u04f7\u04f2\u04f9\u04c6\u04df\u04d8\u0505\u050a\u04cd\u050a\u0508\u04d3\u0510\u04ea\u04f1\u0505\u050e\u04e1\u04e6\u04d6\u050c\u04d7\u04d7\u04e7\u051b\u04f2\u04f6\u0522\u0501\u04f8\u04e4\u04de\u0506\u0525\u0514\u04e5\u0518\u0506\u0522\u050b\u04ea\u052b\u04fc\u052f\u0532\u04f9\u04fa", (byte)59, 67);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[7] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u056f\u054a\u0532\u056a\u0547\u0569\u052e\u0537\u0548\u0556\u0531\u0547\u056b\u0538\u056a\u054e\u0549\u054a\u0560\u0572\u055c\u055f\u0559\u0588\u0560\u0557\u0558\u0566\u055c\u0549\u055a\u0577\u058d\u0560\u055c\u0591\u057d\u0581\u054e\u0589\u0576\u0554\u0562\u055b\u0592\u0576\u0558\u0596\u0579\u058e\u055a\u0573\u056e\u05a3\u056a\u056b", (byte)59, 70);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[8] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u0127\u0144\u013b\u015e\u0163\u0133\u012d\u0134\u016a\u0157\u014b\u016b\u0149\u0175\u0165\u016d\u014e\u0158\u0151\u0139\u0176\u016d\u0164\u014d\u0146\u0179\u0143\u0166\u018a\u016a\u017f\u0177\u0189\u015e\u0189\u0171\u0150\u0145\u015d\u0155\u0185\u0175\u0179\u0183\u0176\u0194\u018c\u0192\u015d\u016e\u0159\u0193\u017c\u0184\u0175\u019b\u01a0\u0183\u0196\u017c\u0188\u0169\u018a\u019b", (byte)59, 65);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[9] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u0167\u0159\u0150\u0139\u016f\u014f\u0168\u0146\u0145\u0176\u016a\u013d", (byte)59, 65);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[10] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0540\u053c\u054f\u0540\u052f\u052c\u0546\u0536\u056e\u0561\u0563\u053b\u0549\u0574\u0551\u0535\u055f\u055b\u0570\u056b\u0556\u055d\u054a\u054b", (byte)59, 69);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[11] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u055b\u054d\u056d\u053b\u0546\u0546\u0536\u0534\u0579\u054f\u0547\u056a\u0539\u0535\u0553\u0578\u056d\u056a\u056d\u0550\u0576\u0583\u054a\u054b", (byte)59, 69);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[12] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u054e\u0549\u0543\u054c\u054a\u0563\u0548\u0562\u0552\u052b\u0565\u056c\u0544\u0568\u055c\u0570\u0568\u0551\u054a\u0543\u0536\u0586\u0540\u0582\u0540\u0576\u0556\u0581\u0556\u056a\u0576\u0564\u0584\u0550\u0590\u0581\u056e\u0567\u0583\u0576\u0592\u0556\u0598\u055f", (byte)59, 70);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[13] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u054e\u0549\u0543\u054c\u054a\u0563\u0548\u0562\u0552\u052b\u0565\u056c\u0544\u0568\u055c\u0570\u0568\u0551\u054a\u0543\u0536\u0586\u0540\u0582\u0540\u0576\u0556\u0581\u0556\u056a\u0576\u0564\u0546\u0567\u054e\u056f\u0551\u054c\u0589\u0550\u056f\u0554\u0556\u058b\u058f\u0589\u0576\u0572\u0568\u0559\u055f\u0583\u0570\u057d\u05a6\u0588\u0572\u059a\u05aa\u055d\u0569\u057f\u0565\u058d\u057b\u058f\u059f\u0592\u058e\u05a2\u057f\u056d\u0597\u0576\u0575\u057f", (byte)59, 70);
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[14] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u04bd\u04b8\u04b2\u04bb\u04b9\u04d2\u04b7\u04d1\u04c1\u049a\u04d4\u04db\u04b3\u04d7\u04cb\u04df\u04d7\u04c0\u04b9\u04b2\u04a5\u04f5\u04af\u04f1\u04af\u04e5\u04c5\u04f0\u04c5\u04d9\u04e5\u04d3\u04bf\u04c8\u04d8\u04f3\u04bf\u04c3\u04f8\u04f9\u04c2\u04e0\u04f3\u04f7\u04ca\u04fa\u04c9\u04c8\u04ec\u04e2\u04ec\u0502\u04e5\u0515\u04f3\u04eb\u0510\u0506\u0510\u0503\u050e\u04e6\u04f2\u04d0\u04f6\u0510\u050b\u050a\u04fc\u04db\u04dc\u0522\u04d9\u0521\u0509\u04ee", (byte)59, 68);
                    continue block7;
                }
                case 2: {
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u052c\u0551\u0548\u055b\u0548\u055f\u052f\u0552\u0571\u057a\u0570\u053f", (byte)59, 70);
                    continue block7;
                }
                case 4: {
                    \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.B("\u014b\u0157\u013f\u0127\u0129\u0164\u014c\u016a\u0167\u016c\u0155\u0147\u014f\u0171\u017c\u0135\u015d\u0176\u0149\u014f\u017f\u0176\u017a\u015c\u0145\u017f\u0145\u0185\u0172\u015f\u018a\u0178", (byte)59, 66);
                }
            }
        }
    }

    static boolean aC() {
        return (o != null ? ad : ae) != 0;
    }

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = Integer.reverse(0);
        d = Long.reverse(1088918850628924037L);
        e = Long.reverse(0x4600000000000000L);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Long.reverse(1088918850628924037L);
        h = Long.reverse(0x4600000000000000L);
        i = Integer.reverse(0);
        j = Integer.reverse(Integer.MIN_VALUE);
        k = Integer.reverse(0x40000000);
        l = Long.reverse(1088918850628924037L);
        m = Long.reverse(0x4600000000000000L);
        n = 0 >>> 128 | 0 << -128;
        o = (192 >>> 134 | 192 << ~134 + 1) & 0xFFFFFFFF;
        p = Long.reverse(1088918850628924037L);
        q = Long.reverse(0x4600000000000000L);
        r = Integer.reverse(0x8000000);
        s = Integer.reverse(0x20000000);
        t = Long.reverse(1088918850628924037L);
        u = Long.reverse(0x4600000000000000L);
        v = (655360 >>> 241 | 655360 << -241) & 0xFFFFFFFF;
        w = Long.reverse(5268259304828744325L);
        x = (393216 >>> 176 | 393216 << -176) & 0xFFFFFFFF;
        y = Long.reverse(1088918850628924037L);
        z = Long.reverse(0x4600000000000000L);
        aa = Integer.reverse(-536870912);
        ab = Integer.reverse(-1);
        ac = Long.reverse(5268259304828744325L);
        ad = 32768 >>> 175 | 32768 << ~175 + 1;
        ae = Integer.reverse(0);
        af = Integer.reverse(-268435456);
        ag = (3840 >>> 232 | 3840 << ~232 + 1) & 0xFFFFFFFF;
        ah = Integer.reverse(0x10000000);
        ai = Long.reverse(5268259304828744325L);
        aj = 0 >>> 245 | 0 << -245;
        ak = (0x800000 >>> 215 | 0x800000 << ~215 + 1) & 0xFFFFFFFF;
        al = Integer.reverse(0);
        am = Integer.reverse(-1879048192);
        an = Long.reverse(5268259304828744325L);
        ao = Integer.reverse(Integer.MIN_VALUE);
        ap = Integer.reverse(0);
        aq = (0x1400000 >>> 21 | 0x1400000 << ~21 + 1) & 0xFFFFFFFF;
        ar = Long.reverse(1088918850628924037L);
        as = Long.reverse(0x4600000000000000L);
        at = (4096 >>> 172 | 4096 << -172) & 0xFFFFFFFF;
        au = Integer.reverse(0);
        av = Integer.reverse(-805306368);
        aw = Long.reverse(1088918850628924037L);
        ax = Long.reverse(0x4600000000000000L);
        ay = Integer.reverse(0x30000000);
        az = (-1 >>> 48 | -1 << -48) & 0xFFFFFFFF;
        ba = Long.reverse(5268259304828744325L);
        bb = 13312 >>> 74 | 13312 << -74;
        bc = Long.reverse(5268259304828744325L);
        bd = 114688 >>> 109 | 114688 << ~109 + 1;
        be = Long.reverse(5268259304828744325L);
        bf = 0 >>> 188 | 0 << ~188 + 1;
        bg = (0 >>> 192 | 0 << ~192 + 1) & 0xFFFFFFFF;
        a = new String[af];
        b = new String[ag];
        \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.b();
        o = \u03c8\u03a8\u03c0\u03b7\u03b7\u03c5\u03c5\u03b4\u0394\u03b7.a((String)\u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.c("\u3e80", (int)ah, (long)ai), new String[aj]);
        String[] stringArray = new String[ak];
        stringArray[\u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.al] = \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.c("\u3e83", (int)am, (long)an);
        o = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(InitialHandler.class, stringArray);
        String[] stringArray2 = new String[ao];
        stringArray2[\u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.ap] = \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.c("\u3e86", (int)aq, (long)(ar ^ as));
        p = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(InitialHandler.class, stringArray2);
        String[] stringArray3 = new String[at];
        stringArray3[\u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.au] = \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.c("\u3e89", (int)av, (long)(aw ^ ax));
        q = \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(InitialHandler.class, stringArray3);
        Object object = \u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.c("\u3e8c", (int)(ay & az), (long)ba);
        if (o == null) {
            throw new IllegalArgumentException((String)\u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.c("\u3e8f", (int)bb, (long)bc));
        }
        if (p == null) {
            throw new IllegalArgumentException((String)\u03a3\u03b1\u03b1\u03b5\u03be\u03be\u03b3\u03c2.c("\u3e92", (int)bd, (long)be));
        }
        r = o != null ? \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(InitialHandler.class, o, bf) : null;
        s = r != null ? \u0393\u039b\u03b8\u03c3\u03c6\u03b6\u03c2\u03b7\u03ba.a(o, UUID.class, bg) : null;
    }
}

