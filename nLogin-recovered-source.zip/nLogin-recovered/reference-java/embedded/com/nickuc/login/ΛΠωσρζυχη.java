/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.PacketEvents
 *  com.nickuc.login.lib.packetevents.api.event.PacketSendEvent
 *  com.nickuc.login.lib.packetevents.api.protocol.item.ItemStack
 *  com.nickuc.login.lib.packetevents.api.wrapper.PacketWrapper
 *  com.nickuc.login.lib.packetevents.api.wrapper.play.server.WrapperPlayServerWindowItems
 *  io.netty.channel.Channel
 *  lombok.Generated
 *  org.bukkit.entity.Player
 */
package com.nickuc.login;

import com.nickuc.login.lib.packetevents.api.PacketEvents;
import com.nickuc.login.lib.packetevents.api.event.PacketSendEvent;
import com.nickuc.login.lib.packetevents.api.protocol.item.ItemStack;
import com.nickuc.login.lib.packetevents.api.wrapper.PacketWrapper;
import com.nickuc.login.lib.packetevents.api.wrapper.play.server.WrapperPlayServerWindowItems;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c3\u03b4\u0394\u03be\u03b9\u03bf\u03bd\u03a6\u03c3\u0394\u03a8\u03c0;
import com.nickuc.login.\u03c5\u03c1\u03c8\u03a3\u03a9\u03bb\u03bc\u03c7\u03c1\u03a3\u03bc;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import io.netty.channel.Channel;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.bukkit.entity.Player;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u039b\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7 {
    public final \u03c3\u03b4\u0394\u03be\u03b9\u03bf\u03bd\u03a6\u03c3\u0394\u03a8\u03c0 a;
    private static int p;
    private static int i;
    private static int j;
    private static final int aj;
    private static long c;
    private static long e;
    private static final int ai;
    private final \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 w;
    private static final int ah;
    private static int c;
    private static int b;
    private static int k;
    private static long f;
    private static int a;
    private static final int al;
    private static int d;
    private static String[] a;
    private static int m;
    private static String[] b;
    private static final int ak;
    private static int g;
    private static int n;
    private static int h;
    private static final WrapperPlayServerWindowItems a;
    private static int q;
    public final \u03c5\u03c1\u03c8\u03a3\u03a9\u03bb\u03bc\u03c7\u03c1\u03a3\u03bc a = new \u03c5\u03c1\u03c8\u03a3\u03a9\u03bb\u03bc\u03c7\u03c1\u03a3\u03bc(this);
    private static int o;
    private static int l;

    private boolean az() {
        return (!\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.x.ar() ? a : b) != 0;
    }

    private static void b() {
        int n;
        c = -7289069383568088532L;
        long l = c ^ 0x14E273205976342FL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(33 + 35), (byte)(20 + 49), (byte)(67 + 16), (byte)(7 + 40), (byte)(63 + 4), (byte)(41 + 25), (byte)(17 + 50), (byte)(18 + 29), 80, 75, (byte)(35 + 32), (byte)(29 + 54), (byte)(14 + 39), (byte)(59 + 21), (byte)(76 + 21), (byte)(54 + 46), (byte)(18 + 82), (byte)(98 + 7), (byte)(58 + 52), (byte)(23 + 80)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(66 + 3), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u039b\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.D("\u054b\u0549\u054c\u0517\u053d\u0514\u052e\u0550\u055a\u053a\u0527\u0566\u0532\u0526\u052b\u0543\u053f\u0525\u054b\u054c\u0565\u055a\u054e\u0574\u0541\u0530\u0550\u0579\u054d\u052c\u053a\u053b\u0555\u0566\u054d\u0570\u055f\u0578\u053a\u057f\u055a\u0577\u056f\u0555\u0569\u0568\u0562\u058d\u054d\u054d\u0558\u054a\u0550\u056c\u0570\u0552\u0581\u0591\u058b\u0587\u056e\u056c\u0595\u057c", (byte)101, 68);
                    continue block7;
                }
                case 1: {
                    \u039b\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7.b[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u0588\u0586\u0589\u0554\u057a\u0551\u056b\u058d\u0597\u0577\u0564\u05a3\u056f\u0563\u0568\u0580\u057c\u0562\u0588\u0589\u05a2\u0597\u058b\u05b1\u057e\u056d\u058d\u05b6\u058a\u0569\u0577\u0578\u0592\u05a3\u058a\u05ad\u059c\u05b5\u0577\u05bc\u0597\u05b4\u05ac\u0592\u05a6\u05a5\u059f\u05ca\u058a\u058a\u0595\u0587\u058d\u05ac\u0587\u05b0\u05a4\u05c5\u05c7\u059d\u05cf\u05a9\u0590\u05b6\u05cc\u05c9\u05a7\u05d6\u05a7\u05d9\u05cc\u05ac\u05ce\u0595\u05e2\u05a9", (byte)101, 69);
                    continue block7;
                }
                case 2: {
                    \u039b\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7.b[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u055a\u055a\u0536\u0531\u054b\u055a\u0522\u0560\u0560\u0546\u0526\u052c", (byte)101, 67);
                    continue block7;
                }
                case 4: {
                    \u039b\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u01b2\u019a\u018f\u01c5\u0198\u01c2\u0193\u0186\u01b8\u0181\u01bb\u01a8\u019e\u019e\u01cb\u01c9\u01c5\u01bf\u01bd\u01c0\u01d3\u01c5\u019c\u019d", (byte)101, 65);
                }
            }
        }
    }

    public void a(Channel channel) {
        try {
            PacketEvents.getAPI().getProtocolManager().sendPacketSilently((Object)channel, (PacketWrapper)a);
        }
        catch (Exception exception) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u039b\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7.c("\u3e80", (int)d, (long)(e ^ f)), exception, new Object[g]);
        }
    }

    private void a(PacketSendEvent packetSendEvent, int n) {
        if (n != 0) {
            return;
        }
        Player player = (Player)packetSendEvent.getPlayer();
        if (player == null || !this.w.a().b(this.w.b().a(player))) {
            packetSendEvent.setCancelled(c != 0);
        }
    }

    static /* synthetic */ boolean a(\u039b\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7 \u03bb\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7) {
        return \u03bb\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7.az();
    }

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = Integer.reverse(0);
        c = Integer.reverse(Integer.MIN_VALUE);
        d = Integer.reverse(0);
        e = Long.reverse(3766694374883203929L);
        f = Long.reverse(-6773413839565225984L);
        g = (0 >>> 141 | 0 << ~141 + 1) & 0xFFFFFFFF;
        h = (4 >>> 226 | 4 << ~226 + 1) & 0xFFFFFFFF;
        i = Integer.reverse(Integer.MIN_VALUE);
        j = 0x1000000 >>> 246 | 0x1000000 << -246;
        k = (0 >>> 207 | 0 << -207) & 0xFFFFFFFF;
        l = Integer.reverse(-1610612736);
        m = Integer.reverse(-1879048192);
        n = 216 >>> 131 | 216 << ~131 + 1;
        o = Integer.reverse(-1275068416);
        p = Integer.reverse(0);
        q = Integer.reverse(0);
        a = new String[h];
        b = new String[i];
        \u039b\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7.b();
        aj = j;
        ah = k;
        ai = l;
        al = m;
        ak = n;
        Object[] objectArray = new ItemStack[o];
        Arrays.fill(objectArray, ItemStack.EMPTY);
        a = new WrapperPlayServerWindowItems(p, q, Arrays.asList(objectArray), null);
    }

    private static String a(int n, long l) {
        l ^= 0x45L;
        l ^= 0x14E273205976342FL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(54 + 14), (byte)(16 + 53), (byte)(25 + 58), (byte)(27 + 20), 67, (byte)(22 + 44), (byte)(63 + 4), 47, (byte)(55 + 25), (byte)(4 + 71), (byte)(15 + 52), (byte)(12 + 71), (byte)(6 + 47), (byte)(7 + 73), (byte)(32 + 65), (byte)(9 + 91), (byte)(55 + 45), (byte)(89 + 16), (byte)(43 + 67), (byte)(86 + 17)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(81 + 2)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u01ac\u01b9\u01b8\u017b\u01bb\u01b7\u01b2\u01bb\u01c6\u01b5\u0182\u01c0\u01c4\u01bd\u01c0\u01c6\u0188\u04f5\u04fb\u0525\u0520\u051f\u0515\u0525\u0528\u0519", (byte)101, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u039b\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Generated
    public \u039b\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        this.w = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u039b\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.F("\u0503\u0525\u0527\u0507\u052b\u054a\u0542\u0558\u0544\u0513\u0551\u0547\u0555\u054f\u0518\u053d\u055f\u055e\u0556\u055c\u0556\u052b", (byte)31, 70), \u039b\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u0475\u0482\u0481\u0444\u0484\u0480\u047b\u0484\u048f\u047e\u044b\u0489\u048d\u0486\u0489\u048f\u0451\u07be\u07c4\u07ee\u07e9\u07e8\u07de\u07ee\u07f1\u07e2\u0466", (byte)31, 68) + string + \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u044c", (byte)31, 67) + methodType.toString(), exception);
        }
    }

    static /* synthetic */ void a(\u039b\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7 \u03bb\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7, PacketSendEvent packetSendEvent, int n) {
        \u03bb\u03a0\u03c9\u03c3\u03c1\u03b6\u03c5\u03c7\u03b7.a(packetSendEvent, n);
    }
}

