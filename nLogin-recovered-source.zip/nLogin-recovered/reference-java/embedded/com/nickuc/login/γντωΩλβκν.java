/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd {
    private static String[] b;
    private static long aj;
    private static int z;
    private static long d;
    private static int af;
    private static long b;
    private static int p;
    private static int ak;
    private static int t;
    private static int ab;
    private static int i;
    private static int q;
    private static int ag;
    private static int m;
    private static long c;
    private final int ae;
    private static int r;
    private static String[] a;
    private static int an;
    private static long ai;
    private static int h;
    private static int y;
    private static int k;
    public static final \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd b;
    private static int w;
    private static long am;
    private static int v;
    private static long s;
    private static long al;
    private static long ao;
    private static int aa;
    private static int u;
    private static int l;
    private final int ad;
    private static int o;
    private static int x;
    public static final \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd a;
    private static int f;
    private static int j;
    private static int ac;
    private static int e;
    private static int g;
    private static int a;
    private final boolean ap;
    private static int ah;
    private static int n;
    private final InetAddress a;
    public static final \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd c;

    private static String a(int n, long l) {
        l ^= 0x2EL;
        l ^= 0x596A2383A968C9AL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(35 + 34), (byte)(25 + 58), (byte)(10 + 37), (byte)(43 + 24), (byte)(48 + 18), (byte)(10 + 57), (byte)(21 + 26), (byte)(51 + 29), (byte)(39 + 36), (byte)(13 + 54), (byte)(15 + 68), (byte)(26 + 27), (byte)(44 + 36), (byte)(46 + 51), (byte)(91 + 9), 100, (byte)(69 + 36), (byte)(31 + 79), (byte)(62 + 41)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(26 + 42), (byte)(48 + 21), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.C("\u0520\u052d\u052c\u04ef\u052f\u052b\u0526\u052f\u053a\u0529\u04f6\u0534\u0538\u0531\u0534\u053a\u04fc\u0881\u088c\u0894\u089a\u087b\u088e\u0886\u088f\u0893", (byte)88, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = (0 >>> 182 | 0 << ~182 + 1) & 0xFFFFFFFF;
        b = Long.reverse(-5802532275097059482L);
        d = Long.reverse(0x7400000000000000L);
        e = Integer.reverse(0x40000000);
        f = 0 >>> 81 | 0 << ~81 + 1;
        g = Integer.reverse(Integer.MIN_VALUE);
        h = (-1 >>> 172 | -1 << ~172 + 1) & 0xFFFFFFFF;
        i = (32768 >>> 206 | 32768 << -206) & 0xFFFFFFFF;
        j = (2 >>> 92 | 2 << -92) & 0xFFFFFFFF;
        k = (16384 >>> 142 | 16384 << -142) & 0xFFFFFFFF;
        l = 0 >>> 128 | 0 << -128;
        m = (0x400000 >>> 117 | 0x400000 << -117) & 0xFFFFFFFF;
        n = 64 >>> 63 | 64 << ~63 + 1;
        o = (0x8000000 >>> 27 | 0x8000000 << ~27 + 1) & 0xFFFFFFFF;
        p = 0 >>> 133 | 0 << ~133 + 1;
        q = 0x40000000 >>> 158 | 0x40000000 << ~158 + 1;
        r = Integer.reverse(-1);
        s = Long.reverse(-2631998137428230298L);
        t = Integer.reverse(-1);
        u = Integer.reverse(0x10000000);
        v = Integer.reverse(0);
        w = -536870881 >>> 21 | -536870881 << -21;
        x = 0xE000000 >>> 217 | 0xE000000 << -217;
        y = 0 >>> 200 | 0 << -200;
        z = Integer.reverse(0);
        aa = Integer.reverse(Integer.MIN_VALUE);
        ab = (0 >>> 172 | 0 << -172) & 0xFFFFFFFF;
        ac = Integer.reverse(Integer.MIN_VALUE);
        af = Integer.reverse(-1610612736);
        ag = 0xA00000 >>> 117 | 0xA00000 << -117;
        ah = Integer.reverse(0x40000000);
        ai = Long.reverse(-5802532275097059482L);
        aj = Long.reverse(0x7400000000000000L);
        ak = (0x18000000 >>> 91 | 0x18000000 << ~91 + 1) & 0xFFFFFFFF;
        al = Long.reverse(-5802532275097059482L);
        am = Long.reverse(0x7400000000000000L);
        an = Integer.reverse(0x20000000);
        ao = Long.reverse(-2631998137428230298L);
        a = new String[af];
        b = new String[ag];
        \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.b();
        try {
            a = new \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd((String)\u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.c("\u3e80", (int)ah, (long)(ai ^ aj)));
            b = new \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd((String)\u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.c("\u3e83", (int)ak, (long)(al ^ am)));
            c = new \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd((String)\u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.c("\u3e86", (int)an, (long)ao));
        }
        catch (UnknownHostException unknownHostException) {
            throw new RuntimeException(unknownHostException);
        }
    }

    private static void b() {
        int n;
        c = 7421255478472253173L;
        long l = c ^ 0x596A2383A968C9AL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(47 + 21), (byte)(21 + 48), (byte)(23 + 60), (byte)(7 + 40), (byte)(18 + 49), (byte)(53 + 13), (byte)(24 + 43), (byte)(11 + 36), 80, (byte)(13 + 62), (byte)(18 + 49), (byte)(62 + 21), 53, (byte)(35 + 45), (byte)(7 + 90), (byte)(13 + 87), (byte)(40 + 60), (byte)(19 + 86), (byte)(83 + 27), (byte)(46 + 57)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(21 + 48), (byte)(20 + 63)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.b[0] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.D("\u0585\u0562\u0547\u056a\u0564\u0562\u0561\u055a\u0544\u056c\u054b\u0559", (byte)116, 68);
                    \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.b[1] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.F("\u0572\u0575\u059a\u0576\u05ad\u05af\u059d\u0568\u0587\u0584\u05b1\u0588\u0587\u057f\u05a5\u0597\u0586\u05a4\u05b7\u05a8\u0588\u05a7\u0588\u0572\u0577\u058c\u05a3\u05b9\u0583\u05a4\u05a7\u0590\u0591\u05a3\u05bd\u05c3\u0598\u05c9\u05cc\u05bc\u05a6\u05bf\u05cd\u0598", (byte)116, 70);
                    \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.b[2] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u0571\u0578\u0567\u056a\u0569\u05ac\u057f\u05ad\u05a5\u0586\u0581\u0589\u058c\u059f\u05ad\u0580\u0590\u05ae\u05af\u058f\u0589\u0586\u0583\u0584", (byte)116, 69);
                    \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.b[3] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u0564\u0558\u055a\u057b\u0544\u058d\u055b\u0567\u0552\u0587\u0583\u0595\u056f\u0577\u0561\u0564\u0563\u0590\u0571\u058f\u0598\u0577\u0564\u0565", (byte)116, 68);
                    \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.b[4] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u0595\u0593\u05a6\u057d\u0564\u057d\u056d\u058c\u0580\u05aa\u05ae\u057f\u057d\u058e\u05b5\u0584\u0598\u05a2\u0598\u0585\u057b\u05bc\u0583\u0584", (byte)116, 70);
                    continue block7;
                }
                case 1: {
                    \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.b[0] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u01b7\u01b7\u01af\u01d7\u01dd\u01cf\u01a2\u01e7\u01db\u01b5\u01d4\u01af", (byte)116, 66);
                    \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.b[1] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u01a9\u01ac\u01d1\u01ad\u01e4\u01e6\u01d4\u019f\u01be\u01bb\u01e8\u01bf\u01be\u01b6\u01dc\u01ce\u01bd\u01db\u01ee\u01df\u01bf\u01de\u01bf\u01a9\u01ae\u01c3\u01da\u01f0\u01ba\u01db\u01de\u01c7\u01c8\u01d1\u01d1\u01d6\u01fe\u01e0\u01f2\u0207\u01f6\u01ff\u0200\u01cf", (byte)116, 66);
                    \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.b[2] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u01a8\u01af\u019e\u01a1\u01a0\u01e3\u01b6\u01e4\u01dc\u01bd\u01b6\u01a7\u01c0\u01b6\u01aa\u01a9\u01c8\u01b1\u01bc\u01e7\u01d0\u01bd\u01ba\u01bb", (byte)116, 66);
                    \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.b[3] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.E("\u0583\u0577\u0579\u059a\u0563\u05ac\u057a\u0586\u0571\u05a6\u05a4\u05b1\u0574\u05a1\u059f\u0570\u05b7\u058e\u0593\u05a5\u05a8\u0596\u0583\u0584", (byte)116, 69);
                    \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.b[4] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u0595\u0593\u05a6\u057d\u0564\u057d\u056d\u058c\u0580\u05aa\u05af\u058e\u05a9\u058f\u05a0\u0590\u058b\u05ae\u058d\u05a8\u057a\u0588\u0590\u05ac\u0577\u059c\u0592\u05bc\u05bd\u05b5\u05b2\u05c6", (byte)116, 69);
                    continue block7;
                }
                case 2: {
                    \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u0599\u0578\u0596\u0589\u059a\u05a3\u056f\u05b0\u0590\u0568\u056e\u057f\u0591\u0591\u05b0\u05a4\u0590\u0583\u05a4\u05ae\u0593\u05ac\u05b3\u059a\u058f\u059a\u059d\u05b8\u0591\u0593\u05a2\u0582", (byte)116, 70);
                    continue block7;
                }
                case 4: {
                    \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u05a1\u0595\u0586\u0574\u0582\u059c\u05aa\u05a8\u0590\u058d\u057e\u0585\u05b4\u05a7\u0580\u05a2\u05b0\u05a7\u05bc\u059d\u0594\u05bc\u0583\u0584", (byte)116, 69);
                }
            }
        }
    }

    public \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd(String string) {
        String string2;
        String[] stringArray = string.split((String)\u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.c("\u3e80", (int)a, (long)(b ^ d)));
        if (stringArray.length == e) {
            string2 = stringArray[f];
            this.ad = Integer.parseInt(stringArray[g]);
        } else {
            string2 = string;
            this.ad = h;
        }
        this.a = InetAddress.getByName(string2);
        if (this.a instanceof Inet4Address) {
            this.ap = stringArray.length != i || this.ad == j ? k : l;
        } else if (this.a instanceof Inet6Address) {
            this.ap = stringArray.length != m || this.ad == n ? o : p;
        } else {
            throw new IllegalArgumentException((String)\u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.c("\u3e83", (int)(q & r), (long)s) + this.a.getClass().getCanonicalName());
        }
        this.ae = this.ap ? t : this.ad / u;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0515\u0537\u0539\u0519\u053d\u055c\u0554\u056a\u0556\u0525\u0563\u0559\u0567\u0561\u052a\u054f\u0571\u0570\u0568\u056e\u0568\u053d", (byte)49, 70), \u03b3\u03bd\u03c4\u03c9\u03a9\u03bb\u03b2\u03ba\u03bd.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.B("\u0144\u0151\u0150\u0113\u0153\u014f\u014a\u0153\u015e\u014d\u011a\u0158\u015c\u0155\u0158\u015e\u0120\u04a5\u04b0\u04b8\u04be\u049f\u04b2\u04aa\u04b3\u04b7\u0135", (byte)49, 66) + string + \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u0527", (byte)49, 70) + methodType.toString(), exception);
        }
    }

    public boolean b(InetAddress inetAddress) {
        if (!this.a.getClass().equals(inetAddress.getClass())) {
            return v != 0;
        }
        if (this.ap) {
            return inetAddress.equals(this.a);
        }
        byte[] byArray = inetAddress.getAddress();
        byte[] byArray2 = this.a.getAddress();
        byte by = (byte)(w >> (this.ad & x));
        for (int i = y; i < this.ae; ++i) {
            if (byArray.length >= i && byArray2.length >= i && byArray[i] == byArray2[i]) continue;
            return z != 0;
        }
        if (by != 0) {
            return ((byArray[this.ae] & by) == (byArray2[this.ae] & by) ? aa : ab) != 0;
        }
        return ac != 0;
    }
}

