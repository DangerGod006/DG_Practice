/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.Location
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.spigotmc.event.player.PlayerSpawnLocationEvent
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.bukkit.\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u0393;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Optional;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.bukkit.Location;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.spigotmc.event.player.PlayerSpawnLocationEvent;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6
implements \u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8 {
    private static String[] b;
    private static int g;
    private static long o;
    private static long n;
    private static int v;
    private static long s;
    private static int u;
    private static long i;
    private static long f;
    private static int b;
    private static int p;
    private static int z;
    private static int a;
    private static int m;
    private static int ab;
    private final nLoginBukkit l;
    private static int ac;
    private static long r;
    private static int af;
    private static int e;
    private static int j;
    private static long c;
    private static long w;
    private static int x;
    private static int l;
    private static int k;
    private static int ad;
    private static int ag;
    private static int y;
    private static String[] a;
    private static long d;
    private static int t;
    private static long h;
    private static long aa;
    private static int q;
    private static int ah;
    private static long ae;
    private final \u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u0393 b;

    static {
        a = 0 >>> 204 | 0 << ~204 + 1;
        b = Integer.reverse(-1);
        d = Long.reverse(3669789765008591674L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Long.reverse(3669789765008591674L);
        g = (2 >>> 224 | 2 << -224) & 0xFFFFFFFF;
        h = Long.reverse(6407978338449853242L);
        i = Long.reverse(0x6A00000000000000L);
        j = 0 >>> 12 | 0 << ~12 + 1;
        k = -1610612736 >>> 93 | -1610612736 << -93;
        l = Integer.reverse(0);
        m = Integer.reverse(-1073741824);
        n = Long.reverse(6407978338449853242L);
        o = Long.reverse(0x6A00000000000000L);
        p = Integer.reverse(Integer.MIN_VALUE);
        q = Integer.reverse(0x20000000);
        r = Long.reverse(6407978338449853242L);
        s = Long.reverse(0x6A00000000000000L);
        t = Integer.reverse(0x40000000);
        u = 0x280000 >>> 179 | 0x280000 << -179;
        v = Integer.reverse(-1);
        w = Long.reverse(3669789765008591674L);
        x = Integer.reverse(-1073741824);
        y = Integer.reverse(0x60000000);
        z = -1 >>> 211 | -1 << ~211 + 1;
        aa = Long.reverse(3669789765008591674L);
        ab = Integer.reverse(0x20000000);
        ac = 0x3800000 >>> 23 | 0x3800000 << -23;
        ad = -1 >>> 199 | -1 << -199;
        ae = Long.reverse(3669789765008591674L);
        af = Integer.reverse(0);
        ag = 16 >>> 65 | 16 << ~65 + 1;
        ah = Integer.reverse(0x10000000);
        a = new String[ag];
        b = new String[ah];
        \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b();
    }

    private static void b() {
        int n;
        c = 6688353354888623898L;
        long l = c ^ 0xC02C6A6433BD1D1EL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(55 + 13), (byte)(2 + 67), (byte)(23 + 60), (byte)(45 + 2), (byte)(40 + 27), (byte)(54 + 12), (byte)(54 + 13), (byte)(28 + 19), (byte)(5 + 75), (byte)(21 + 54), 67, 83, (byte)(46 + 7), (byte)(78 + 2), (byte)(42 + 55), (byte)(36 + 64), (byte)(2 + 98), (byte)(43 + 62), (byte)(90 + 20), (byte)(18 + 85)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(82 + 1)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u04fd\u04cf\u04bb\u04c2\u04dd\u0504\u04c4\u04fc\u04fd\u04e4\u0501\u04ee\u04f8\u04e0\u04dd\u04c8\u04db\u04df\u0509\u0511\u04f5\u0513\u04d1\u04f8\u04cd\u04f1\u04e9\u04f7\u04fd\u051c\u0515\u04ec\u04db\u04f4\u0505\u051e\u0528\u0525\u04f1\u04e5\u051c\u0517\u04ff\u050c\u04fe\u051c\u0531\u04fa\u0533\u0504\u050b\u0530\u0533\u050c\u0519\u050e\u0524\u04f7\u04fb\u052f\u051d\u0532\u053b\u053b", (byte)71, 67);
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[1] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.B("\u0180\u015d\u017d\u0185\u015c\u0142\u0178\u0155\u0145\u0170\u014f\u0155", (byte)71, 66);
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[2] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.D("\u04cc\u04da\u04c4\u04e2\u04d1\u04f3\u04dc\u04e4\u04ca\u04c3\u050c\u04df\u04c9\u0509\u04cb\u04dd\u050b\u04d3\u04d4\u04f4\u0509\u050a\u04d8\u04f6\u04e4\u04e5\u04f9\u050c\u04ff\u04f1\u04ea\u0514\u0523\u04e0\u050d\u0516\u050f\u051e\u0503\u04e4\u0502\u04e9\u052c\u0509\u04e6\u052e\u051e\u0512\u052f\u052d\u04f5\u04f1\u050d\u0536\u04fd\u04fe", (byte)71, 68);
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[3] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u013c\u0185\u0146\u0147\u0165\u0167\u015f\u0145\u0144\u015d\u0178\u0164\u0182\u0182\u0152\u015f\u0155\u0177\u0186\u014b\u0154\u0163\u0160\u0161", (byte)71, 65);
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[4] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.B("\u0164\u0159\u0140\u0148\u0146\u016b\u015f\u0144\u016b\u014b\u0186\u0155", (byte)71, 66);
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[5] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.F("\u0539\u057a\u054b\u054a\u0560\u057f\u0560\u0555\u0540\u0554\u0584\u054b", (byte)71, 70);
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[6] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u055a\u054f\u0536\u053e\u053c\u0561\u0555\u053a\u0561\u0541\u057c\u054b", (byte)71, 70);
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[7] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u0183\u013e\u0187\u0175\u0142\u0154\u0174\u0148\u017d\u016c\u0147\u018e\u0168\u0192\u0195\u014d\u0188\u0152\u0177\u0186\u018f\u0187\u019d\u0194\u0186\u0175\u0197\u0182\u019e\u016e\u017f\u017b\u0192\u0182\u0174\u0198\u0164\u01a3\u0197\u018b\u016a\u01a7\u01a9\u0191\u018b\u0192\u01a3\u018b\u01a7\u0193\u01aa\u0177\u0175\u0183\u0180\u0181", (byte)71, 66);
                    continue block7;
                }
                case 1: {
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u0180\u0152\u013e\u0145\u0160\u0187\u0147\u017f\u0180\u0167\u0184\u0171\u017b\u0163\u0160\u014b\u015e\u0162\u018c\u0194\u0178\u0196\u0154\u017b\u0150\u0174\u016c\u017a\u0180\u019f\u0198\u016f\u015e\u0177\u0188\u01a1\u01ab\u01a8\u0174\u0168\u019f\u019a\u0182\u018f\u0181\u019f\u01b4\u017d\u01b6\u0187\u018e\u01b3\u01b6\u0189\u0198\u0191\u01b8\u018d\u01a1\u0196\u01ab\u01a1\u01b2\u0185", (byte)71, 65);
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[1] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u04bd\u04e3\u04cd\u04fe\u0503\u04c4\u04bf\u04dc\u0507\u04e4\u04f7\u04d2", (byte)71, 68);
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u014f\u015d\u0147\u0165\u0154\u0176\u015f\u0167\u014d\u0146\u018f\u0162\u014c\u018c\u014e\u0160\u018e\u0156\u0157\u0177\u018c\u018d\u015b\u0179\u0167\u0168\u017c\u018f\u0182\u0174\u016d\u0197\u01a6\u0163\u0190\u0199\u0192\u01a1\u0186\u0167\u0185\u016c\u01b1\u01a6\u0189\u0184\u019d\u0173\u01b0\u01b2\u018b\u019a\u01a4\u0173\u01b9\u01aa\u01b1\u0194\u01b5\u01be\u019f\u01c0\u01c0\u0180", (byte)71, 65);
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[3] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.F("\u0532\u057b\u053c\u053d\u055b\u055d\u0555\u053b\u053a\u0553\u0566\u0578\u0565\u0548\u054a\u057d\u058d\u0581\u056b\u057c\u0558\u0559\u0556\u0557", (byte)71, 70);
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[4] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u0500\u0501\u04d1\u04fb\u04dd\u04f0\u04c1\u04f4\u04c4\u050c\u04cc\u04d2", (byte)71, 68);
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[5] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u054e\u0557\u0556\u055b\u0573\u0554\u0580\u056f\u055f\u0557\u0552\u054b", (byte)71, 69);
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[6] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.F("\u0544\u056c\u055f\u0571\u056b\u054b\u0583\u0560\u0575\u0572\u0556\u054b", (byte)71, 70);
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[7] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u0183\u013e\u0187\u0175\u0142\u0154\u0174\u0148\u017d\u016c\u0147\u018e\u0168\u0192\u0195\u014d\u0188\u0152\u0177\u0186\u018f\u0187\u019d\u0194\u0186\u0175\u0197\u0182\u019e\u016e\u017f\u017b\u0192\u0182\u0174\u0198\u0164\u01a3\u0197\u018b\u016a\u01a7\u01a6\u01ac\u0188\u018c\u01af\u0173\u0171\u018b\u0185\u01aa\u018f\u0193\u0180\u0181", (byte)71, 65);
                    continue block7;
                }
                case 2: {
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u04ef\u04ce\u04bb\u04e7\u04d5\u04f8\u0503\u04dc\u04cb\u04fc\u04d9\u04d2", (byte)71, 67);
                    continue block7;
                }
                case 4: {
                    \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u04f5\u04be\u0504\u04f7\u04d7\u04e9\u04c5\u04c9\u04e3\u0507\u04eb\u04db\u04e2\u04dd\u04ca\u04d2\u04ed\u04ef\u0514\u04f5\u04d3\u0506\u04dd\u04de", (byte)71, 67);
                }
            }
        }
    }

    @EventHandler(priority=EventPriority.HIGH)
    public void a(PlayerSpawnLocationEvent playerSpawnLocationEvent) {
        InetAddress inetAddress;
        \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = this.l.b().a(playerSpawnLocationEvent.getPlayer());
        String string = \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.getName();
        \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 = \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a(string, inetAddress = (InetAddress)Optional.ofNullable(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a()).map(InetSocketAddress::getAddress).orElse(null), null);
        if (\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 == null) {
            String string2 = (String)\u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.c("\u3e80", (int)(a & b), (long)d) + string + (String)\u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.c("\u3e83", (int)e, (long)f) + playerSpawnLocationEvent.getClass().getSimpleName() + (String)\u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.c("\u3e86", (int)g, (long)(h ^ i));
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c(string2, new Object[j]);
            String[] stringArray = new String[k];
            stringArray[\u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.l] = \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.c("\u3e89", (int)m, (long)(n ^ o));
            stringArray[\u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.p] = \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.c("\u3e8c", (int)q, (long)(r ^ s));
            stringArray[\u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.t] = (String)\u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.c("\u3e8f", (int)(u & v), (long)w) + string2;
            stringArray[\u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.x] = \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.c("\u3e92", (int)(y & z), (long)aa);
            stringArray[\u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.ab] = \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.c("\u3e95", (int)(ac & ad), (long)ae);
            \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.a(\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(stringArray));
            return;
        }
        Location location = playerSpawnLocationEvent.getSpawnLocation();
        Location location2 = this.b.a().a(location, af != 0);
        if (location2 != null) {
            if (\u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.p) {
                \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a = location;
            } else {
                this.l.a().a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6).a().b(location);
            }
            playerSpawnLocationEvent.setSpawnLocation(location2);
        }
    }

    @Generated
    public \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6(nLoginBukkit nLoginBukkit2, \u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u0393 \u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u03932) {
        this.l = nLoginBukkit2;
        this.b = \u03bb\u0393\u03bb\u03c7\u03a9\u03b1\u03bf\u03a8\u03c9\u03b8\u03c4\u03bf\u03c2\u03932;
    }

    private static String a(int n, long l) {
        l ^= 0x56L;
        l ^= 0xC02C6A6433BD1D1EL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(5 + 63), (byte)(51 + 18), (byte)(57 + 26), (byte)(6 + 41), (byte)(13 + 54), (byte)(5 + 61), (byte)(15 + 52), (byte)(17 + 30), (byte)(16 + 64), (byte)(46 + 29), (byte)(28 + 39), (byte)(17 + 66), (byte)(13 + 40), 80, 97, (byte)(5 + 95), (byte)(95 + 5), (byte)(19 + 86), (byte)(104 + 6), (byte)(31 + 72)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(45 + 38)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.F("\u054f\u055c\u055b\u051e\u055e\u055a\u0555\u055e\u0569\u0558\u0525\u0563\u0567\u0560\u0563\u0569\u052b\u08b8\u08b4\u08c3\u08b1\u089c\u0895\u08cc\u08b7\u08a5\u08a9\u08be\u08bf\u08d1\u08b0", (byte)48, 70));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u04a6\u04c8\u04ca\u04aa\u04ce\u04ed\u04e5\u04fb\u04e7\u04b6\u04f4\u04ea\u04f8\u04f2\u04bb\u04e0\u0502\u0501\u04f9\u04ff\u04f9\u04ce", (byte)67, 68), \u03bb\u03b6\u03c4\u03b1\u039b\u0393\u03c9\u03b3\u03a0\u03a3\u03b7\u03b7\u03c8\u03a6.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u0168\u0175\u0174\u0137\u0177\u0173\u016e\u0177\u0182\u0171\u013e\u017c\u0180\u0179\u017c\u0182\u0144\u04d1\u04cd\u04dc\u04ca\u04b5\u04ae\u04e5\u04d0\u04be\u04c2\u04d7\u04d8\u04ea\u04c9\u015e", (byte)67, 65) + string + \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u0539", (byte)67, 70) + methodType.toString(), exception);
        }
    }
}

