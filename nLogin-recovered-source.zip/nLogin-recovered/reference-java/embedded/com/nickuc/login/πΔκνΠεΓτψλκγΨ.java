/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.Server
 *  org.bukkit.plugin.PluginDescriptionFile
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd;
import com.nickuc.login.\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03c0\u03c9\u03ba\u03c5\u0394\u03a3\u03a3;
import com.nickuc.login.\u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7;
import com.nickuc.login.\u03a0\u03c1\u03b2\u03c5\u03bf\u03c5\u03be\u03a3\u03c6\u03b5\u03c4\u03c7\u03b5;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u03a9\u0394\u03be\u03b4\u03ba\u039b\u03c8\u03c8\u03ba\u03c6\u03b4;
import com.nickuc.login.\u03a9\u03be\u03b2\u03a6\u03c5\u03bd\u039b\u03b1\u0394;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b5\u03be\u03bd\u03c3\u0394\u03c7\u03a3\u03b5\u03b8\u03b8\u03b6\u0394\u03b1\u03a0\u03b6;
import com.nickuc.login.\u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7;
import com.nickuc.login.\u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3;
import com.nickuc.login.\u03b8\u03b1\u03a9\u03a6\u03bd\u03c5\u03c8\u03b3;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03b9\u03b8\u03a3\u03c4\u0394\u03b7\u0393\u03c9\u03b6\u03be\u03c1\u03b2;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393;
import com.nickuc.login.\u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393;
import com.nickuc.login.\u03be\u03c0\u03be\u03be\u03c2\u03ba\u03b3\u03c7;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03b6\u03b9\u03b8\u039b\u0394\u03c1\u03c7\u03a8\u03c5\u0394;
import com.nickuc.login.\u03c0\u03c6\u03c5\u03a8\u03b5\u03be\u03b2\u03bd\u039b\u03a0\u03c8;
import com.nickuc.login.\u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c2\u03bc\u03ba\u0394\u03a3\u03b9\u03b6\u03c1\u039b\u03be\u03a8\u03b9\u03b8\u03c6\u03a0;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c6\u03bf\u03c5\u03c1\u03c7\u03c0\u03c6\u03bb\u03a0;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c8\u03a8\u03c0\u03b7\u03b7\u03c5\u03c5\u03b4\u0394\u03b7;
import com.nickuc.login.\u03c9\u0394\u03c4\u03b6\u03c7\u03b9\u03b1\u03c5\u0394\u03c4;
import com.nickuc.login.\u03c9\u03c5\u03b2\u03b2\u03b1\u03ba\u03c3\u03b4\u03c4\u03b9\u03a0\u03a3\u03bd;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.bukkit.Server;
import org.bukkit.plugin.PluginDescriptionFile;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
final class \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8
implements \u03a8\u03a9\u0394\u03be\u03b4\u03ba\u039b\u03c8\u03c8\u03ba\u03c6\u03b4 {
    private static int ah;
    private static int v;
    private final \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393 a;
    private static int j;
    private static int n;
    private static int m;
    private static String[] b;
    private static long as;
    private static long t;
    private static int s;
    private static long c;
    private static int f;
    private static int x;
    private static long ab;
    private static int l;
    private static int h;
    private static long y;
    private static long an;
    private static int aw;
    private static long ag;
    private static long aq;
    private static long aj;
    private static long o;
    private static int g;
    private static int b;
    private static int ak;
    private static int i;
    private static int k;
    private static long r;
    private static long u;
    private static int ax;
    private static long d;
    private static long at;
    private static int am;
    private static int aa;
    private static int e;
    private static int ai;
    private static int q;
    private static int ac;
    private static int au;
    private static int w;
    private static int p;
    private static int z;
    private static int ao;
    private static long af;
    private static int al;
    private static int av;
    private static int ap;
    private static int ad;
    private static int ae;
    private static String[] a;
    private static int ar;
    private static int a;

    @Override
    public void T() {
        this.a.T();
    }

    static {
        a = Integer.reverse(0);
        b = -1 >>> 135 | -1 << -135;
        d = Long.reverse(-3655845225621949696L);
        e = Integer.reverse(0);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = (416 >>> 5 | 416 << ~5 + 1) & 0xFFFFFFFF;
        h = (0x2000000 >>> 89 | 0x2000000 << -89) & 0xFFFFFFFF;
        i = Integer.reverse(0);
        j = Integer.reverse(Integer.MIN_VALUE);
        k = Integer.reverse(-2013265920);
        l = 1 >>> 32 | 1 << ~32 + 1;
        m = 0 >>> 207 | 0 << ~207 + 1;
        n = (512 >>> 137 | 512 << -137) & 0xFFFFFFFF;
        o = Long.reverse(-3655845225621949696L);
        p = (0x200000 >>> 84 | 0x200000 << -84) & 0xFFFFFFFF;
        q = -1 >>> 47 | -1 << ~47 + 1;
        r = Long.reverse(-3655845225621949696L);
        s = Integer.reverse(-1073741824);
        t = Long.reverse(379380040502014720L);
        u = Long.reverse(-4035225266123964416L);
        v = Integer.reverse(0);
        w = Integer.reverse(0x20000000);
        x = Integer.reverse(-1);
        y = Long.reverse(-3655845225621949696L);
        z = Integer.reverse(-1610612736);
        aa = Integer.reverse(-1);
        ab = Long.reverse(-3655845225621949696L);
        ac = 0 >>> 106 | 0 << ~106 + 1;
        ad = (8 >>> 227 | 8 << ~227 + 1) & 0xFFFFFFFF;
        ae = (-1073741824 >>> 61 | -1073741824 << ~61 + 1) & 0xFFFFFFFF;
        af = Long.reverse(379380040502014720L);
        ag = Long.reverse(-4035225266123964416L);
        ah = Integer.reverse(-536870912);
        ai = (-1 >>> 174 | -1 << ~174 + 1) & 0xFFFFFFFF;
        aj = Long.reverse(-3655845225621949696L);
        ak = 0 >>> 225 | 0 << -225;
        al = 0x8000000 >>> 155 | 0x8000000 << ~155 + 1;
        am = (4096 >>> 73 | 4096 << ~73 + 1) & 0xFFFFFFFF;
        an = Long.reverse(-3655845225621949696L);
        ao = Integer.reverse(-1879048192);
        ap = Integer.reverse(-1);
        aq = Long.reverse(-3655845225621949696L);
        ar = Integer.reverse(0x50000000);
        as = Long.reverse(379380040502014720L);
        at = Long.reverse(-4035225266123964416L);
        au = (0 >>> 115 | 0 << ~115 + 1) & 0xFFFFFFFF;
        av = Integer.reverse(Integer.MIN_VALUE);
        aw = (0xB000000 >>> 248 | 0xB000000 << ~248 + 1) & 0xFFFFFFFF;
        ax = Integer.reverse(-805306368);
        a = new String[aw];
        b = new String[ax];
        \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b();
    }

    @Override
    public \u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393 a() {
        return new \u03c6\u03bf\u03c5\u03c1\u03c7\u03c0\u03c6\u03bb\u03a0(this.a);
    }

    @Override
    public void V() {
        try {
            if (\u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.a().a(\u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.s)) {
                \u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.a();
                \u03c9\u03c5\u03b2\u03b2\u03b1\u03ba\u03c3\u03b4\u03c4\u03b9\u03a0\u03a3\u03bd.a();
                \u03c2\u03bc\u03ba\u0394\u03a3\u03b9\u03b6\u03c1\u039b\u03be\u03a8\u03b9\u03b8\u03c6\u03a0.a();
                \u03c0\u03b6\u03b9\u03b8\u039b\u0394\u03c1\u03c7\u03a8\u03c5\u0394.a();
                \u03b5\u03be\u03bd\u03c3\u0394\u03c7\u03a3\u03b5\u03b8\u03b8\u03b6\u0394\u03b1\u03a0\u03b6.values();
                \u03b6\u03b4\u03a9\u03c2\u03a3\u0393\u03b6\u03c4\u03c7.ae();
            }
            \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.a(this.a);
        }
        catch (Throwable throwable) {
            throw new RuntimeException((String)\u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.c("\u3e80", (int)s, (long)(t ^ u)), throwable);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x13L;
        l ^= 0x22E8B857BEA7E8F3L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(67 + 1), (byte)(32 + 37), (byte)(29 + 54), (byte)(34 + 13), (byte)(27 + 40), (byte)(50 + 16), (byte)(47 + 20), (byte)(25 + 22), (byte)(63 + 17), (byte)(7 + 68), (byte)(19 + 48), (byte)(28 + 55), (byte)(36 + 17), (byte)(42 + 38), (byte)(94 + 3), (byte)(94 + 6), 100, (byte)(45 + 60), (byte)(41 + 69), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(22 + 47), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u048d\u049a\u0499\u045c\u049c\u0498\u0493\u049c\u04a7\u0496\u0463\u04a1\u04a5\u049e\u04a1\u04a7\u0469\u07fb\u07d0\u07f7\u07fb\u07df\u07f5\u07d4\u0806\u080b\u07ff\u07ff\u07f9\u07ef", (byte)39, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u0133\u0155\u0157\u0137\u015b\u017a\u0172\u0188\u0174\u0143\u0181\u0177\u0185\u017f\u0148\u016d\u018f\u018e\u0186\u018c\u0186\u015b", (byte)70, 66), \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.E("\u0565\u0572\u0571\u0534\u0574\u0570\u056b\u0574\u057f\u056e\u053b\u0579\u057d\u0576\u0579\u057f\u0541\u08d3\u08a8\u08cf\u08d3\u08b7\u08cd\u08ac\u08de\u08e3\u08d7\u08d7\u08d1\u08c7\u055a", (byte)70, 69) + string + \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.D("\u04c1", (byte)70, 68) + methodType.toString(), exception);
        }
    }

    @Override
    public \u03c9\u0394\u03c4\u03b6\u03c7\u03b9\u03b1\u03c5\u0394\u03c4 a() {
        Server server = this.a.a();
        return new \u03a0\u03c1\u03b2\u03c5\u03bf\u03c5\u03be\u03a3\u03c6\u03b5\u03c4\u03c7\u03b5(this.a, server, \u039b\u03c0\u03c9\u03ba\u03c5\u0394\u03a3\u03a3.a(server, server.getConsoleSender()));
    }

    @Override
    public void U() {
        \u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd \u03b3\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd = \u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.a();
        int n = \u03b3\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.e() == f && \u03b3\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.f() <= g ? h : i;
        int n2 = \u03b3\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.e() == j && \u03b3\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.f() <= k ? l : m;
        \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.a(this.a, n != 0, n2 != 0);
    }

    @Override
    public void i() {
        this.a.i();
    }

    private static void b() {
        int n;
        c = 58405098885989024L;
        long l = c ^ 0x22E8B857BEA7E8F3L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(48 + 20), (byte)(51 + 18), (byte)(64 + 19), (byte)(21 + 26), 67, (byte)(27 + 39), (byte)(41 + 26), (byte)(33 + 14), (byte)(65 + 15), (byte)(69 + 6), (byte)(25 + 42), (byte)(13 + 70), (byte)(47 + 6), 80, (byte)(23 + 74), (byte)(57 + 43), (byte)(30 + 70), (byte)(8 + 97), (byte)(92 + 18), (byte)(37 + 66)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(51 + 18), (byte)(55 + 28)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.B("\u012a\u00eb\u00f4\u0117\u0134\u011b\u012b\u00f5\u0120\u010f\u012b\u0122\u0116\u0122\u0106\u011a\u013b\u0116\u0144\u011a\u0140\u012e\u0128\u012e\u013b\u012d\u0133\u014c\u0149\u013e\u0114\u0146\u0129\u0116\u0115\u0136\u0113\u013b\u013e\u011c\u015c\u014a\u014f\u013b\u011b\u0146\u0163\u013e\u0131\u013b\u0149\u014c\u016d\u013a\u014c\u0121\u0149\u012f\u0124\u0154\u012c\u012e\u0165\u0149\u014e\u0168\u016c\u012d\u0153\u015a\u016c\u0179\u015c\u0171\u0181\u0160\u0161\u016e\u017d\u0145\u0161\u0142\u018a\u0178\u0168\u017b\u0152\u0153", (byte)32, 66);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[1] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0488\u045b\u045b\u046c\u044f\u0461\u0494\u0462\u0455\u0492\u048b\u0462\u0459\u045a\u0452\u0465\u048e\u047b\u048f\u048e\u046f\u046b\u0468\u0469", (byte)32, 67);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[2] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.E("\u052e\u0544\u0544\u0535\u0514\u0542\u0531\u055b\u052c\u0527\u052a\u053c\u0520\u0550\u051b\u0544\u0535\u0546\u055f\u0559\u0536\u0558\u052f\u0530", (byte)32, 69);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[3] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.D("\u0464\u044d\u0468\u047e\u048a\u048d\u048b\u0484\u046e\u0473\u0486\u0476\u048d\u0494\u0453\u0498\u0493\u0473\u0470\u046e\u047e\u0482\u0492\u04a6\u0481\u04a3\u0472\u049f\u0466\u0487\u0489\u04a5\u046d\u04aa\u049a\u04a6\u04a0\u047d\u0493\u04af\u04af\u0490\u0471\u04aa\u048f\u04b3\u04b0\u0491\u04bd\u04bc\u0496\u0480\u04c2\u049b\u0488\u0489", (byte)32, 68);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[4] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u010e\u00f7\u0112\u0128\u0134\u0137\u0135\u012e\u0118\u011d\u0132\u013b\u0111\u00fd\u0114\u0143\u0102\u0116\u0109\u013d\u0135\u0120\u0146\u0148\u0138\u011c\u010e\u013c\u0122\u014c\u0122\u0115\u0112\u0147\u0139\u013a\u014e\u0128\u0128\u014f\u0139\u0135\u012c\u015d\u0122\u014e\u013d\u0138\u0127\u0143\u0138\u0162\u016a\u0147\u015a\u0145\u015d\u0150\u012f\u0132\u014b\u0166\u0145\u0166\u0164\u0163\u0166\u0158\u0139\u0178\u014b\u0178\u013b\u013d\u015b\u0157\u0158\u017b\u015f\u0176\u0155\u0171\u0155\u015e\u014b\u0165\u0152\u0153", (byte)32, 66);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[5] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u0132\u00f0\u00f0\u0126\u012a\u0129\u00f6\u00fc\u0108\u00fe\u0134\u0107", (byte)32, 65);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[6] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u044a\u044a\u0447\u045d\u046b\u0486\u048a\u0491\u0455\u0450\u044f\u045d", (byte)32, 67);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[7] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.D("\u0464\u044d\u0468\u047e\u048a\u048d\u048b\u0484\u046e\u0473\u0488\u0491\u0467\u0453\u046a\u0499\u0458\u046c\u045f\u0493\u048b\u0476\u049c\u049e\u048e\u0472\u0464\u0492\u0478\u04a2\u0478\u046b\u0468\u049d\u048f\u0490\u04a4\u047e\u047e\u04a5\u048f\u048b\u0482\u0492\u048e\u0492\u0472\u04b8\u0475\u048f\u04be\u04a0\u049a\u04ac\u04a0\u04be\u04c0\u04af\u04a7\u04bf\u0495\u049c\u04b6\u04a5\u04cd\u0485\u04c0\u049f\u04c7\u04af\u048e\u0487\u04d6\u04aa\u04b0\u04c4\u04a9\u0497\u04c6\u0497\u04cb\u04a9\u04ae\u04c1\u04e3\u04e0\u04a4\u04dc\u04c1\u049e\u04b2\u049f\u04c7\u04c3\u04ba\u04e6", (byte)32, 68);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[8] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.A("\u0118\u0138\u0109\u0117\u012b\u0107\u0109\u012c\u00fb\u00fd\u00fc\u011c\u010e\u0105\u0114\u0118\u011f\u0139\u0143\u010b\u010c\u011c\u0142\u014e\u0110\u0127\u0152\u010d\u012f\u014b\u0149\u0127", (byte)32, 65);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[9] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u010e\u00f7\u0112\u0128\u0134\u0137\u0135\u012e\u0118\u011d\u0132\u013b\u0111\u00fd\u0114\u0143\u0102\u0116\u0109\u013d\u0135\u0120\u0146\u0148\u0138\u011c\u010e\u013c\u0122\u014c\u0122\u0115\u0112\u0147\u0139\u013a\u014e\u0128\u0128\u014f\u0139\u0135\u012c\u013c\u015c\u0154\u0118\u013a\u0160\u0166\u0169\u0166\u013b\u0137\u014c\u0162\u015b\u0130\u0167\u0129\u016f\u0140\u0157\u0144\u0150\u0147\u0138\u014c\u015c\u016a\u0169\u0160\u0132\u015e\u015d\u013d\u017a\u016d\u0166\u0165\u0183\u016a\u0182\u0154\u0156\u0176\u018d\u016c\u0178\u017a\u0192\u0187\u0169\u017f\u0168\u0156\u0155\u0195\u0157\u0152\u0153\u0155\u0150\u017d\u0173\u019d\u0162\u0193\u0196\u0172\u017f\u0162\u019a\u0179\u0163\u0180\u0183\u0185\u0172\u0173", (byte)32, 65);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[10] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.A("\u0132\u00f0\u00f0\u0126\u012a\u0129\u00f6\u00fc\u0108\u00fe\u0134\u0107", (byte)32, 65);
                    continue block7;
                }
                case 1: {
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u0480\u0441\u044a\u046d\u048a\u0471\u0481\u044b\u0476\u0465\u0481\u0478\u046c\u0478\u045c\u0470\u0491\u046c\u049a\u0470\u0496\u0484\u047e\u0484\u0491\u0483\u0489\u04a2\u049f\u0494\u046a\u049c\u047f\u046c\u046b\u048c\u0469\u0491\u0494\u0472\u04b2\u04a0\u04a5\u0491\u0471\u049c\u04b9\u0494\u0487\u0491\u049f\u04a2\u04c3\u0490\u04a2\u0477\u049f\u0485\u047a\u04aa\u0482\u0484\u04bb\u049f\u04a4\u04be\u04c2\u0483\u04a9\u04b0\u04c2\u04cf\u04b2\u04c7\u04d8\u04ac\u04b5\u04b4\u04af\u04a8\u04dc\u04b8\u04d7\u04be\u04db\u04d1\u04a8\u04a9", (byte)32, 67);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[1] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.C("\u0488\u045b\u045b\u046c\u044f\u0461\u0494\u0462\u0455\u0492\u048a\u048d\u0468\u048a\u0489\u0469\u0455\u0478\u048d\u0476\u0492\u047b\u0468\u0469", (byte)32, 67);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[2] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u0467\u047d\u047d\u046e\u044d\u047b\u046a\u0494\u0465\u0460\u0462\u048c\u046a\u048b\u0494\u0485\u049c\u045a\u0489\u047e\u0496\u046b\u0468\u0469", (byte)32, 68);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[3] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u010e\u00f7\u0112\u0128\u0134\u0137\u0135\u012e\u0118\u011d\u0130\u0120\u0137\u013e\u00fd\u0142\u013d\u011d\u011a\u0118\u0128\u012c\u013c\u0150\u012b\u014d\u011c\u0149\u0110\u0131\u0133\u014f\u0117\u0154\u0144\u0150\u014a\u0127\u013d\u0159\u0159\u013a\u011a\u013e\u012d\u0133\u0133\u015e\u015b\u0138\u0167\u0159\u0163\u0135\u0132\u0133", (byte)32, 65);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[4] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u052b\u0514\u052f\u0545\u0551\u0554\u0552\u054b\u0535\u053a\u054f\u0558\u052e\u051a\u0531\u0560\u051f\u0533\u0526\u055a\u0552\u053d\u0563\u0565\u0555\u0539\u052b\u0559\u053f\u0569\u053f\u0532\u052f\u0564\u0556\u0557\u056b\u0545\u0545\u056c\u0556\u0552\u0549\u057a\u053f\u056b\u055a\u0555\u0544\u0560\u0555\u057f\u0587\u0564\u0577\u0562\u057a\u056d\u054c\u054f\u0568\u0583\u0562\u0583\u0581\u0580\u0583\u0575\u0556\u0595\u0568\u0595\u0558\u055a\u057a\u056f\u055f\u0596\u05a1\u057f\u055c\u055c\u0585\u0575\u0589\u0582\u056f\u0570", (byte)32, 69);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[5] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.D("\u0447\u0459\u0442\u0451\u048d\u044b\u0467\u048f\u0472\u0452\u0466\u0492\u0470\u0488\u0494\u049d\u0496\u0499\u048d\u045a\u049b\u046b\u0468\u0469", (byte)32, 68);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[6] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.F("\u0527\u050c\u0528\u050e\u0548\u0513\u0533\u0547\u051a\u053d\u054e\u054f\u055f\u0559\u051f\u051f\u0517\u0521\u0520\u0556\u0525\u0558\u052f\u0530", (byte)32, 70);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[7] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u052b\u0514\u052f\u0545\u0551\u0554\u0552\u054b\u0535\u053a\u054f\u0558\u052e\u051a\u0531\u0560\u051f\u0533\u0526\u055a\u0552\u053d\u0563\u0565\u0555\u0539\u052b\u0559\u053f\u0569\u053f\u0532\u052f\u0564\u0556\u0557\u056b\u0545\u0545\u056c\u0556\u0552\u0549\u0559\u0555\u0559\u0539\u057f\u053c\u0556\u0585\u0567\u0561\u0573\u0567\u0585\u0587\u0576\u056e\u0586\u055c\u0563\u057d\u056c\u0594\u054c\u0587\u0566\u058e\u0576\u0555\u054e\u059d\u0571\u0577\u058b\u0570\u055e\u058d\u055e\u0592\u0570\u0575\u0588\u05aa\u0599\u057a\u05a6\u057e\u058b\u059f\u0569\u0571\u0570\u05a9\u0571", (byte)32, 69);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[8] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u0535\u0555\u0526\u0534\u0548\u0524\u0526\u0549\u0518\u051a\u0519\u0539\u052b\u0522\u0531\u0535\u053c\u0556\u0560\u0528\u0529\u0535\u051d\u053e\u0529\u0541\u053b\u054a\u0569\u0532\u054d\u056a\u052c\u0544\u0551\u0565\u052b\u0553\u056d\u057d\u0578\u054c\u054b\u0544", (byte)32, 69);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[9] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u0464\u044d\u0468\u047e\u048a\u048d\u048b\u0484\u046e\u0473\u0488\u0491\u0467\u0453\u046a\u0499\u0458\u046c\u045f\u0493\u048b\u0476\u049c\u049e\u048e\u0472\u0464\u0492\u0478\u04a2\u0478\u046b\u0468\u049d\u048f\u0490\u04a4\u047e\u047e\u04a5\u048f\u048b\u0482\u0492\u04b2\u04aa\u046e\u0490\u04b6\u04bc\u04bf\u04bc\u0491\u048d\u04a2\u04b8\u04b1\u0486\u04bd\u047f\u04c5\u0496\u04ad\u049a\u04a6\u049d\u048e\u04a2\u04b2\u04c0\u04bf\u04b6\u0488\u04b4\u04b3\u0493\u04d0\u04c3\u04bc\u04bb\u04d9\u04c0\u04d8\u04aa\u04ac\u04cc\u04e3\u04c2\u04ce\u04d0\u04e8\u04dd\u04bf\u04d5\u04be\u04ac\u04ab\u04eb\u04ad\u04a8\u04a9\u04ab\u04a6\u04d3\u04c9\u04f3\u04aa\u04b4\u04fb\u04f1\u04dc\u04b3\u04bc\u04cc\u04da\u04ec\u04ef\u04cb\u04c8\u04c9", (byte)32, 68);
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[10] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.C("\u047c\u0446\u0486\u047c\u0483\u0453\u046f\u045f\u048a\u0457\u0453\u045d", (byte)32, 67);
                    continue block7;
                }
                case 2: {
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u051e\u0545\u0524\u0518\u052b\u0510\u0552\u0555\u051a\u053f\u054b\u0558\u0560\u055f\u0537\u0535\u0557\u0550\u0552\u0520\u0559\u0557\u055b\u0561\u056d\u0527\u0525\u052e\u055a\u052a\u053d\u0574", (byte)32, 70);
                    continue block7;
                }
                case 4: {
                    \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.D("\u0464\u046f\u047a\u045c\u045c\u046f\u047e\u0492\u047f\u0493\u0453\u0481\u0478\u0499\u045a\u044f\u048d\u0468\u0471\u0493\u0473\u0491\u0468\u0469", (byte)32, 68);
                }
            }
        }
    }

    @Override
    public void j() {
        this.a.j();
    }

    @Override
    public void O() {
        this.a.O();
    }

    @Generated
    public \u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8(\u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393 \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u03932) {
        this.a = \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u03932;
    }

    @Override
    public \u03b8\u03b1\u03a9\u03a6\u03bd\u03c5\u03c8\u03b3 a() {
        return new \u03a0\u03bb\u039b\u03bf\u03c5\u03be\u03c0\u03a6\u03a8\u03c7(this.a);
    }

    @Override
    public \u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9 a(boolean bl) {
        return \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.V() ? new \u03b9\u03b8\u03a3\u03c4\u0394\u03b7\u0393\u03c9\u03b6\u03be\u03c1\u03b2(this.a.a(), bl) : new \u03be\u03c0\u03be\u03be\u03c2\u03ba\u03b3\u03c7(this.a.a(), bl);
    }

    @Override
    public \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3 a() {
        Server server = this.a.a();
        return new \u03b8\u03a8\u039b\u03be\u03c4\u03a0\u03bd\u0393\u03c5\u03b9\u03b8\u03c2\u03c3(server.getName(), server.getVersion(), (String)\u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.c("\u3e80", (int)n, (long)o) + server.getBukkitVersion() + (String)\u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.c("\u3e83", (int)(p & q), (long)r) + server.getVersion(), \u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.b, \u03c0\u03b6\u03b9\u03b8\u039b\u0394\u03c1\u03c7\u03a8\u03c5\u0394.a().O());
    }

    @Override
    public \u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6[] a() {
        return this.a.a();
    }

    @Override
    public \u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393 b() {
        return \u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.a().a(\u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.b) && \u03c8\u03a8\u03c0\u03b7\u03b7\u03c5\u03c5\u03b4\u0394\u03b7.a((String)\u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.c("\u3e80", (int)(a & b), (long)d), new String[e]) ? new \u03c0\u03c6\u03c5\u03a8\u03b5\u03be\u03b2\u03bd\u039b\u03a0\u03c8(this.a, this.a.a()) : new \u03a9\u03be\u03b2\u03a6\u03c5\u03bd\u039b\u03b1\u0394(this.a, this.a.a());
    }

    @Override
    public boolean e(String string) {
        int n = v;
        PluginDescriptionFile pluginDescriptionFile = this.a.a().getDescription();
        if (!pluginDescriptionFile.getName().equals(string)) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.d((String)\u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.c("\u3e80", (int)(w & x), (long)y) + this.a.a().getName() + (String)\u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.c("\u3e83", (int)(z & aa), (long)ab), new Object[ac]);
            n = ad;
        }
        if (!pluginDescriptionFile.getAuthors().contains(\u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.c("\u3e86", (int)ae, (long)(af ^ ag)))) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.d((String)\u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.c("\u3e89", (int)(ah & ai), (long)aj), new Object[ak]);
            n = al;
        }
        if (pluginDescriptionFile.getWebsite() != null && !pluginDescriptionFile.getWebsite().equals(\u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.c("\u3e8c", (int)am, (long)an))) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.d((String)\u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.c("\u3e8f", (int)(ao & ap), (long)aq) + pluginDescriptionFile.getWebsite() + (String)\u03c0\u0394\u03ba\u03bd\u03a0\u03b5\u0393\u03c4\u03c8\u03bb\u03ba\u03b3\u03a8.c("\u3e92", (int)ar, (long)(as ^ at)), new Object[au]);
            n = av;
        }
        return n != 0;
    }
}

