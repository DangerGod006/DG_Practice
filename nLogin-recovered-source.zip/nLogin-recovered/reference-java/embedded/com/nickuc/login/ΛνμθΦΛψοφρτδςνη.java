/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

class \u039b\u03bd\u03bc\u03b8\u03a6\u039b\u03c8\u03bf\u03c6\u03c1\u03c4\u03b4\u03c2\u03bd\u03b7 {
}

