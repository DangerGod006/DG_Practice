/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.enums.ServerConnectType
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.api.enums.ServerConnectType;
import com.nickuc.login.\u03a6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a8\u03bc\u0394\u03b2\u03a3\u0393\u03c8\u03c5\u03c9\u03b6\u03b4\u03be\u03bd\u03c5;
import com.nickuc.login.\u03a8\u03c3\u03c4\u03bc\u03b1\u03c5\u03c2\u03c4\u03b8\u0393\u0394;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8;
import com.nickuc.login.\u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9;
import com.nickuc.login.\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb;
import com.nickuc.login.\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u0393\u03c0\u03ba\u03a9\u03b2\u03c2\u03c2\u03b4\u03be\u0394\u03bd;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.annotation.Nullable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public interface \u03bc\u03a6\u03be\u03b2\u03b5\u03c4\u03b4\u03bc\u03b3 {
    private /* synthetic */ void a(List list, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, String string, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, ServerConnectType serverConnectType, int n, Boolean bl) {
        if (!bl.booleanValue()) {
            this.b().a(() -> {
                if (list.size() > 1 && !\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.K)) {
                    HashSet<String> hashSet = new HashSet<String>();
                    hashSet.add(string);
                    \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.K, hashSet);
                }
                this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, serverConnectType);
            }, (long)n);
        } else {
            this.a().b().a().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, false);
        }
    }

    default public boolean b(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42) {
        return this.a(\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6));
    }

    @Nullable
    default public ServerConnectType a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42) {
        for (ServerConnectType serverConnectType : ServerConnectType.values()) {
            \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be2 = this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, serverConnectType);
            if (!\u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.a(\u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be2)) continue;
            return serverConnectType;
        }
        return null;
    }

    @Nullable
    public String a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 var1);

    public \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 a();

    public boolean t(String var1);

    default public boolean a(\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, String string) {
        if (string == null) {
            return false;
        }
        if (string.equals(\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.d(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.F))) {
            return true;
        }
        return \u03a8\u03c3\u03c4\u03bc\u03b1\u03c5\u03c2\u03c4\u03b8\u0393\u0394.a.a(new Object[0]).stream().anyMatch(string2 -> string2.equalsIgnoreCase(string));
    }

    public \u03c9\u0393\u03c0\u03ba\u03a9\u03b2\u03c2\u03c2\u03b4\u03be\u0394\u03bd a();

    public boolean a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 var1);

    public \u03bf\u03b5\u03a6\u03c1\u0393\u03c8\u03c9\u0393\u03be\u03b3\u0394\u03b9 b();

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    default public \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, ServerConnectType serverConnectType) {
        switch (\u03a8\u03bc\u0394\u03b2\u03a3\u0393\u03c8\u03c5\u03c9\u03b6\u03b4\u03be\u03bd\u03c5.T[serverConnectType.ordinal()]) {
            case 1: {
                \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92;
                String string;
                if (!\u03a8\u03c3\u03c4\u03bc\u03b1\u03c5\u03c2\u03c4\u03b8\u0393\u0394.g.ar() || (string = (String)(\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92 = \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a()).a().a(\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u04bd\u04b3\u04c6\u04c8\u0482\u04c9\u04bc\u04ca\u04cf\u04bf\u04cd", (byte)52, 68))) == null || this.a(\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, string) || !this.t(string) || \u03a8\u03c3\u03c4\u03bc\u03b1\u03c5\u03c2\u03c4\u03b8\u0393\u0394.h.a(new Object[0]).contains(string)) break;
                int n = \u03a8\u03c3\u03c4\u03bc\u03b1\u03c5\u03c2\u03c4\u03b8\u0393\u0394.f.r();
                \u03a6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9<Boolean> \u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9 = n <= 0 ? null : bl -> {
                    if (!bl.booleanValue()) {
                        this.b().a(() -> this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, serverConnectType), (long)n);
                    } else {
                        this.a().b().a().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, false);
                    }
                };
                return this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, string, ServerConnectType.WITH_LAST_SERVER, \u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9);
            }
            case 2: {
                String string;
                if (!\u03a8\u03c3\u03c4\u03bc\u03b1\u03c5\u03c2\u03c4\u03b8\u0393\u0394.d.ar() || (string = (String)\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.d(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.L)) == null || this.a(\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, string) || !this.t(string)) break;
                int n = \u03a8\u03c3\u03c4\u03bc\u03b1\u03c5\u03c2\u03c4\u03b8\u0393\u0394.f.r();
                \u03a6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9<Boolean> \u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9 = n <= 0 ? null : bl -> {
                    if (!bl.booleanValue()) {
                        this.b().a(() -> this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, serverConnectType), (long)n);
                    } else {
                        this.a().b().a().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, false);
                    }
                };
                return this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, string, ServerConnectType.WITH_PLATFORM_SERVER, \u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9);
            }
            case 3: {
                int n;
                Object object;
                Set set;
                Object object2;
                Set set2;
                List<String> list;
                if (!\u03a8\u03c3\u03c4\u03bc\u03b1\u03c5\u03c2\u03c4\u03b8\u0393\u0394.i.ar() || (list = \u03a8\u03c3\u03c4\u03bc\u03b1\u03c5\u03c2\u03c4\u03b8\u0393\u0394.j.a(new Object[0])).isEmpty()) break;
                String string = this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
                if (string != null) {
                    if (list.stream().anyMatch(string::equalsIgnoreCase)) break;
                }
                if ((set2 = (Set)\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.d(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.K)) != null) {
                    object2 = new ArrayList<String>(list);
                    set = set2;
                    synchronized (set) {
                        object2.removeIf(set2::contains);
                    }
                    if (object2.isEmpty()) {
                        object = list;
                        \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.K);
                        set2 = null;
                    } else {
                        object = object2;
                    }
                } else {
                    object = list;
                }
                object2 = object.get(\u03b9\u03c7\u03c9\u03c5\u03b6\u03c0\u03c8\u03b7\u03bc\u03c9\u0394\u03c4\u03a6\u03b8.a().nextInt(object.size()));
                if (set2 != null) {
                    set = set2;
                    synchronized (set) {
                        set2.add(object2);
                    }
                }
                \u03a6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9<Boolean> \u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9 = (n = \u03a8\u03c3\u03c4\u03bc\u03b1\u03c5\u03c2\u03c4\u03b8\u0393\u0394.f.r()) <= 0 ? null : arg_0 -> this.a(list, \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42, (String)object2, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, serverConnectType, n, arg_0);
                return this.a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, (String)object2, ServerConnectType.WITH_CONFIGURED_SERVER, \u03c6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9);
            }
            default: {
                throw new IllegalArgumentException(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u013c\u0156\u015c\u015f\u015b\u015c\u015c\u0160\u0163\u0155\u0155\u0112\u0166\u0159\u0167\u016c\u015c\u016a\u0119\u015d\u016a\u016a\u016b\u0163\u0162\u0174\u0121\u0176\u017c\u0174\u016a\u0127\u0127", (byte)52, 65) + serverConnectType);
            }
        }
        return \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be.d;
    }

    public \u03b7\u03b2\u03a8\u03c2\u03bb\u03b4\u03b8\u03c3\u0393\u03be a(\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 var1, String var2, ServerConnectType var3, @Nullable \u03a6\u03c4\u03c7\u03c0\u03b4\u03c3\u03c1\u03c7\u0393\u03a8\u03c9<Boolean> var4);
}

