/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import java.util.UUID;

public interface \u03b1\u03b5\u03b8\u03b6\u03b4\u03b2\u03a8\u03be\u03c2\u03c1\u03c0\u03a9\u03b6\u03b8\u03b4 {
    public boolean J();

    public boolean a(UUID var1);
}

