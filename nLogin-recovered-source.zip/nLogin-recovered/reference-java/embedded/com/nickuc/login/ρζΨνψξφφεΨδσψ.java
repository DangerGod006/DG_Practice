/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.player.PlayerLoginEvent
 *  org.bukkit.event.player.PlayerLoginEvent$Result
 */
package com.nickuc.login;

import com.nickuc.login.bukkit.nLoginBukkit;
import com.nickuc.login.bukkit.\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0;
import com.nickuc.login.\u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5;
import com.nickuc.login.\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0;
import com.nickuc.login.\u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c8\u03a8\u03c0\u03b7\u03b7\u03c5\u03c5\u03b4\u0394\u03b7;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.player.PlayerLoginEvent;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8
implements \u03a6\u03bf\u03b9\u03c5\u03be\u03c7\u03c2\u03a9\u03a6\u03c8\u03be\u0393\u03a3\u03a8 {
    private static long u;
    private static long ab;
    private static int p;
    private static int ag;
    private static int l;
    private static long ak;
    private static int n;
    private static int aa;
    private static int z;
    private static long c;
    private static int an;
    private static int ah;
    private static int am;
    private static long g;
    private static int a;
    private static long x;
    private static int ai;
    private static int t;
    public static final boolean p;
    private static int s;
    private static long d;
    private static int ad;
    private final nLoginBukkit i;
    private static String[] b;
    private static long h;
    private static int b;
    private static int o;
    private final \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5 g;
    private static int al;
    private static int m;
    private static int v;
    private static int r;
    private static int f;
    private static int y;
    private static long af;
    private static long e;
    private static int i;
    private static String[] a;
    private static long ae;
    private static long k;
    private final boolean q;
    private static int w;
    private static long aj;
    private static long j;
    private static long q;
    private static int ac;

    @EventHandler(priority=EventPriority.LOW)
    public void a(PlayerLoginEvent playerLoginEvent) {
        if (this.q) {
            return;
        }
        if (playerLoginEvent.getResult() != PlayerLoginEvent.Result.ALLOWED) {
            return;
        }
        Player player = playerLoginEvent.getPlayer();
        if (this.g.c(player)) {
            return;
        }
        Player player2 = Bukkit.getServer().getPlayerExact(player.getName());
        if (player2 == null) {
            player2 = Bukkit.getServer().getPlayer(player.getUniqueId());
        }
        if (player2 != null && player2.isOnline()) {
            String string = \u03b5\u03b4\u03b4\u03a0\u03b7\u03b4\u03be\u039b\u03a3\u03c7.a(\u03c0\u03c9\u03b9\u03c8\u03b3\u03b7\u03be\u0393\u03c1\u03c6\u03c5.Y, new Object[a]);
            playerLoginEvent.disallow(PlayerLoginEvent.Result.KICK_OTHER, string);
        }
    }

    static {
        a = Integer.reverse(0);
        b = 0 >>> 52 | 0 << ~52 + 1;
        d = Long.reverse(-3360534487613047538L);
        e = Long.reverse(0x3C00000000000000L);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Long.reverse(-3360534487613047538L);
        h = Long.reverse(0x3C00000000000000L);
        i = (0x2000000 >>> 88 | 0x2000000 << ~88 + 1) & 0xFFFFFFFF;
        j = Long.reverse(-3360534487613047538L);
        k = Long.reverse(0x3C00000000000000L);
        l = Integer.reverse(0);
        m = Integer.reverse(-1610612736);
        n = 0 >>> 139 | 0 << ~139 + 1;
        o = Integer.reverse(-1073741824);
        p = (-1 >>> 29 | -1 << ~29 + 1) & 0xFFFFFFFF;
        q = Long.reverse(-1342921854551065330L);
        r = (1 >>> 128 | 1 << ~128 + 1) & 0xFFFFFFFF;
        s = Integer.reverse(0x20000000);
        t = -1 >>> 209 | -1 << ~209 + 1;
        u = Long.reverse(-1342921854551065330L);
        v = Integer.reverse(0x40000000);
        w = 163840 >>> 79 | 163840 << -79;
        x = Long.reverse(-1342921854551065330L);
        y = Integer.reverse(-1073741824);
        z = (-2147483647 >>> 126 | -2147483647 << -126) & 0xFFFFFFFF;
        aa = (-1 >>> 195 | -1 << ~195 + 1) & 0xFFFFFFFF;
        ab = Long.reverse(-1342921854551065330L);
        ac = (4 >>> 64 | 4 << -64) & 0xFFFFFFFF;
        ad = (917504 >>> 17 | 917504 << ~17 + 1) & 0xFFFFFFFF;
        ae = Long.reverse(-3360534487613047538L);
        af = Long.reverse(0x3C00000000000000L);
        ag = Integer.reverse(-1879048192);
        ah = 0x1200000 >>> 149 | 0x1200000 << -149;
        ai = (131072 >>> 14 | 131072 << ~14 + 1) & 0xFFFFFFFF;
        aj = Long.reverse(-3360534487613047538L);
        ak = Long.reverse(0x3C00000000000000L);
        al = 0 >>> 32 | 0 << -32;
        am = Integer.reverse(Integer.MIN_VALUE);
        an = (0 >>> 32 | 0 << -32) & 0xFFFFFFFF;
        a = new String[ag];
        b = new String[ah];
        \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b();
        p = \u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.a().a(\u0393\u0394\u03c0\u03bb\u03b4\u03b3\u03b9\u03a6\u03b6\u0393\u039b\u03b4\u03bd.b) && \u03c8\u03a8\u03c0\u03b7\u03b7\u03c5\u03c5\u03b4\u0394\u03b7.a((String)\u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.c("\u3e80", (int)ai, (long)(aj ^ ak)), new String[al]) ? am : an;
    }

    private static String a(int n, long l) {
        l ^= 0x3CL;
        l ^= 0x7F0A168702589486L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(11 + 57), (byte)(42 + 27), (byte)(31 + 52), (byte)(40 + 7), 67, (byte)(14 + 52), (byte)(9 + 58), (byte)(29 + 18), (byte)(33 + 47), (byte)(65 + 10), (byte)(36 + 31), (byte)(59 + 24), (byte)(17 + 36), (byte)(79 + 1), (byte)(71 + 26), (byte)(12 + 88), (byte)(72 + 28), 105, (byte)(65 + 45), (byte)(64 + 39)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(5 + 63), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u057b\u0588\u0587\u054a\u058a\u0586\u0581\u058a\u0595\u0584\u0551\u058f\u0593\u058c\u058f\u0595\u0557\u08ea\u08e0\u08d3\u08e9\u08f5\u08ec\u08f5\u08f6\u08e6\u08da\u08e7\u08f7\u08fd", (byte)92, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @EventHandler(priority=EventPriority.HIGHEST)
    public void b(PlayerLoginEvent playerLoginEvent) {
        InetAddress inetAddress;
        if (playerLoginEvent.getResult() != PlayerLoginEvent.Result.ALLOWED) {
            return;
        }
        Player player = playerLoginEvent.getPlayer();
        if (this.g.c(player)) {
            return;
        }
        try {
            inetAddress = playerLoginEvent.getRealAddress();
        }
        catch (NoSuchMethodError noSuchMethodError) {
            inetAddress = null;
        }
        \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 = \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a(player.getName(), playerLoginEvent.getAddress(), inetAddress);
        if (\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 == null) {
            String string = (String)\u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.c("\u3e80", (int)b, (long)(d ^ e)) + player.getName() + (String)\u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.c("\u3e83", (int)f, (long)(g ^ h)) + playerLoginEvent.getClass().getSimpleName() + (String)\u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.c("\u3e86", (int)i, (long)(j ^ k));
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c(string, new Object[l]);
            String[] stringArray = new String[m];
            stringArray[\u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.n] = \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.c("\u3e89", (int)(o & p), (long)q);
            stringArray[\u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.r] = \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.c("\u3e8c", (int)(s & t), (long)u);
            stringArray[\u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.v] = (String)\u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.c("\u3e8f", (int)w, (long)x) + string;
            stringArray[\u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.y] = \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.c("\u3e92", (int)(z & aa), (long)ab);
            stringArray[\u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.ac] = \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.c("\u3e95", (int)ad, (long)(ae ^ af));
            playerLoginEvent.disallow(PlayerLoginEvent.Result.KICK_OTHER, \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(stringArray));
            return;
        }
        String string = this.g.a(this.i.a().b().a(player), \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0);
        if (string != null) {
            playerLoginEvent.disallow(PlayerLoginEvent.Result.KICK_OTHER, string);
        }
    }

    private static void b() {
        int n;
        c = 8124487526076332683L;
        long l = c ^ 0x7F0A168702589486L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(6 + 63), 83, (byte)(14 + 33), (byte)(65 + 2), (byte)(43 + 23), (byte)(14 + 53), (byte)(37 + 10), (byte)(54 + 26), (byte)(52 + 23), (byte)(28 + 39), (byte)(16 + 67), (byte)(27 + 26), (byte)(50 + 30), (byte)(25 + 72), (byte)(77 + 23), (byte)(99 + 1), (byte)(9 + 96), (byte)(61 + 49), (byte)(97 + 6)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(18 + 50), 69, (byte)(41 + 42)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.B("\u01dc\u01c3\u01ad\u01d3\u01e8\u01d2\u01c2\u01c9\u01d3\u01f7\u01fc\u01d8\u01ec\u01b7\u01f8\u01dd\u01bd\u01cf\u0200\u01f0\u01d5\u01c0\u01dd\u01d4\u01d6\u0204\u0200\u01c1\u0202\u020f\u01fb\u0206\u01e6\u01f0\u01f1\u01e5\u01f5\u0216\u0213\u01d2\u01fd\u01eb\u021a\u01d9\u01ec\u0219\u0200\u0213\u020d\u01e3\u01df\u01df\u01e0\u0216\u01fd\u0213\u01fe\u01f7\u0203\u0230\u0230\u01f0\u01fc\u0209", (byte)126, 66);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[1] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u0580\u0589\u05a7\u0597\u0587\u05b0\u0588\u0593\u05ad\u0592\u059d\u0582", (byte)126, 69);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[2] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u01eb\u01c2\u01b1\u01e3\u01c9\u01d7\u01b5\u01c6\u01f3\u01d0\u01c9\u01eb\u01e9\u01f3\u01cc\u01fd\u01bb\u01ef\u01d7\u01fc\u0201\u01fb\u01fa\u01f3\u01ca\u01f9\u01fb\u01c5\u01dd\u01e6\u01ee\u01fe\u01e3\u01e7\u020a\u01ed\u0216\u0210\u0210\u01ea\u0205\u01ef\u01ec\u0200\u01dc\u0217\u0219\u01fc\u021b\u0225\u01f2\u0223\u0228\u01f1\u01ee\u01ef", (byte)126, 66);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[3] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.E("\u056d\u058a\u0596\u0584\u0571\u0590\u0584\u0590\u0588\u0572\u05b3\u05a6\u05ad\u0576\u05ba\u05b6\u05bf\u0584\u05b3\u05a6\u05a6\u05a0\u058d\u058e", (byte)126, 69);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[4] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u01c3\u01af\u01ae\u01e5\u01c8\u01ef\u01db\u01cf\u01ae\u01c8\u01fc\u01c3", (byte)126, 66);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[5] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.F("\u0589\u0566\u0593\u0582\u0591\u05a3\u0571\u0573\u058c\u0589\u05a7\u0582", (byte)126, 70);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[6] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u0577\u0563\u0562\u0599\u057c\u05a3\u058f\u0583\u0562\u057c\u05b0\u0577", (byte)126, 67);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[7] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.E("\u057b\u0586\u05a6\u0584\u0569\u05a7\u0579\u0592\u058b\u0588\u0579\u0579\u057e\u0597\u058b\u05c3\u0593\u05b5\u05b2\u05a3\u05bb\u05a7\u059a\u0592\u0595\u058c\u0597\u05a3\u058b\u05b8\u0587\u058d\u059f\u05bc\u05ab\u0588\u05c0\u05c7\u05da\u05b7\u05db\u05a4\u05b2\u05bf\u059e\u05c1\u059d\u05b8\u059a\u059b\u05c2\u05d2\u05b4\u05b0\u05ad\u05ae", (byte)126, 69);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[8] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u0589\u0585\u056c\u058e\u0595\u05a5\u056b\u05a6\u05b0\u05b5\u05a8\u058d\u05a7\u05a1\u0589\u0594\u05b4\u0582\u05a3\u0582\u05a3\u05c1\u05bb\u05c3\u05cc\u05cc\u058c\u05ae\u0588\u05a7\u059d\u05bf\u05b0\u058b\u05cb\u05c6\u05a0\u05a1\u05a9\u05a4\u05b9\u05b7\u05da\u05d0\u05d9\u05b3\u05c0\u05c1\u05cd\u05cf\u05bc\u05bd\u05d6\u05d7\u05e1\u05c0\u05a8\u05d4\u05db\u05d9\u05da\u05bb\u05e9\u05dc\u05ea\u05dc\u05cb\u05ef\u05b5\u05c5\u05b5\u05b0\u05bb\u05f7\u05d9\u05b9\u05fb\u05bf\u05ee\u05ff\u05bc\u05f5\u05c4\u05e6\u05fa\u0606\u05cd\u05ce", (byte)126, 69);
                    continue block7;
                }
                case 1: {
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u0590\u0577\u0561\u0587\u059c\u0586\u0576\u057d\u0587\u05ab\u05b0\u058c\u05a0\u056b\u05ac\u0591\u0571\u0583\u05b4\u05a4\u0589\u0574\u0591\u0588\u058a\u05b8\u05b4\u0575\u05b6\u05c3\u05af\u05ba\u059a\u05a4\u05a5\u0599\u05a9\u05ca\u05c7\u0586\u05b1\u059f\u05ce\u058d\u05a0\u05cd\u05b4\u05c7\u05c1\u0597\u0593\u0593\u0594\u05bb\u05de\u059f\u05ab\u05ae\u05b8\u05ab\u05bd\u05ce\u05b9\u05af", (byte)126, 68);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[1] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u05a0\u0596\u058b\u05a1\u0562\u057d\u05a6\u058b\u0588\u05ad\u05a8\u0577", (byte)126, 68);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[2] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u059f\u0576\u0565\u0597\u057d\u058b\u0569\u057a\u05a7\u0584\u057d\u059f\u059d\u05a7\u0580\u05b1\u056f\u05a3\u058b\u05b0\u05b5\u05af\u05ae\u05a7\u057e\u05ad\u05af\u0579\u0591\u059a\u05a2\u05b2\u0597\u059b\u05be\u05a1\u05ca\u05c4\u05c4\u059e\u05b9\u05a3\u059e\u0590\u05a2\u059e\u058c\u05a4\u0593\u05d5\u05a5\u05b3\u05bc\u05d9\u05b7\u0596\u05b3\u05cc\u059e\u05bf\u05b1\u05e3\u05be\u05e8", (byte)126, 67);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[3] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u056d\u058a\u0596\u0584\u0571\u0590\u0584\u0590\u0588\u0572\u05b4\u058d\u059f\u0594\u0589\u059c\u05a3\u05a3\u0596\u059b\u05b1\u0590\u058d\u058e", (byte)126, 70);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[4] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.A("\u01e9\u01bd\u01b1\u01c1\u01e3\u01ab\u01c3\u01c6\u01e9\u01da\u01de\u01c3", (byte)126, 65);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[5] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u01f4\u01ee\u01eb\u01b7\u01d5\u01b7\u01ed\u01d4\u01d4\u01c7\u01da\u01c3", (byte)126, 66);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[6] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.E("\u0569\u059e\u0588\u05a1\u058b\u0593\u0593\u0592\u0598\u05a6\u0591\u0582", (byte)126, 69);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[7] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u01bc\u01c7\u01e7\u01c5\u01aa\u01e8\u01ba\u01d3\u01cc\u01c9\u01ba\u01ba\u01bf\u01d8\u01cc\u0204\u01d4\u01f6\u01f3\u01e4\u01fc\u01e8\u01db\u01d3\u01d6\u01cd\u01d8\u01e4\u01cc\u01f9\u01c8\u01ce\u01e0\u01fd\u01ec\u01c9\u0201\u0208\u021b\u01f8\u021c\u01e5\u01f3\u021e\u01f2\u0201\u01db\u021c\u01ec\u0224\u0227\u01e0\u0226\u0227\u01ee\u01ef", (byte)126, 65);
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[8] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.B("\u01ca\u01c6\u01ad\u01cf\u01d6\u01e6\u01ac\u01e7\u01f1\u01f6\u01e9\u01ce\u01e8\u01e2\u01ca\u01d5\u01f5\u01c3\u01e4\u01c3\u01e4\u0202\u01fc\u0204\u020d\u020d\u01cd\u01ef\u01c9\u01e8\u01de\u0200\u01f1\u01cc\u020c\u0207\u01e1\u01e2\u01ea\u01e5\u01fa\u01f8\u021b\u0211\u021a\u01f4\u0201\u0202\u020e\u0210\u01fd\u01fe\u0217\u0218\u0222\u0201\u01e9\u0215\u021c\u021a\u021b\u01fc\u022a\u021d\u022b\u021d\u020c\u0230\u01f6\u0206\u01f6\u01f1\u01fc\u0238\u021a\u0218\u0214\u021f\u0217\u0214\u0240\u0240\u023b\u0241\u021e\u0247\u020e\u020f", (byte)126, 66);
                    continue block7;
                }
                case 2: {
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.C("\u057d\u05a9\u057b\u0587\u056a\u0599\u0585\u059a\u056a\u0599\u05a2\u0581\u058d\u0584\u05af\u05b7\u0572\u05b0\u058d\u05a5\u0595\u05aa\u057c\u059a\u0572\u0591\u0594\u0582\u0594\u05a6\u0590\u05c0", (byte)126, 67);
                    continue block7;
                }
                case 4: {
                    \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.E("\u05ac\u057f\u0588\u0576\u058f\u05ad\u05ac\u0592\u05ae\u0599\u058a\u0587\u0589\u05b9\u0579\u059b\u05b2\u0595\u0591\u057c\u0596\u05c6\u058d\u058e", (byte)126, 69);
                }
            }
        }
    }

    @Generated
    public \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8(nLoginBukkit nLoginBukkit2, \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b5 \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b52, boolean bl) {
        this.i = nLoginBukkit2;
        this.g = \u03b1\u03bf\u039b\u03c3\u03c6\u03c8\u03a6\u03b52;
        this.q = bl;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u051a\u053c\u053e\u051e\u0542\u0561\u0559\u056f\u055b\u052a\u0568\u055e\u056c\u0566\u052f\u0554\u0576\u0575\u056d\u0573\u056d\u0542", (byte)54, 70), \u03c1\u03b6\u03a8\u03bd\u03c8\u03be\u03c6\u03c6\u03b5\u03a8\u03b4\u03c3\u03c8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u014e\u015b\u015a\u011d\u015d\u0159\u0154\u015d\u0168\u0157\u0124\u0162\u0166\u015f\u0162\u0168\u012a\u04bd\u04b3\u04a6\u04bc\u04c8\u04bf\u04c8\u04c9\u04b9\u04ad\u04ba\u04ca\u04d0\u0143", (byte)54, 65) + string + \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u0125", (byte)54, 66) + methodType.toString(), exception);
        }
    }
}

