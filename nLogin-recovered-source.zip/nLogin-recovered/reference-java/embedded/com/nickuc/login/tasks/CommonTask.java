/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login.tasks;

import lombok.Generated;

public abstract class CommonTask
implements Runnable {
    private final Runnable e;

    @Override
    public void run() {
        this.e.run();
    }

    @Generated
    public CommonTask(Runnable runnable) {
        this.e = runnable;
    }
}

