/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login.tasks.limbo;

import com.nickuc.login.tasks.CommonTask;

public class DelayedPlayerLimboClearTask
extends CommonTask {
    public DelayedPlayerLimboClearTask(Runnable runnable) {
        super(runnable);
    }
}

