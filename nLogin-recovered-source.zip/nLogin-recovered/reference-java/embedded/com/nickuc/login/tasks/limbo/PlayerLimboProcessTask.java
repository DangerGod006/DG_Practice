/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login.tasks.limbo;

import com.nickuc.login.tasks.CommonTask;

public class PlayerLimboProcessTask
extends CommonTask {
    public PlayerLimboProcessTask(Runnable runnable) {
        super(runnable);
    }
}

