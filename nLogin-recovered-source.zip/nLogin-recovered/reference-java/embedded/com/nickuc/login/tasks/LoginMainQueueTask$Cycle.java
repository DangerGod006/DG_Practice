/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login.tasks;

public class LoginMainQueueTask$Cycle {
    private static int a = Integer.reverse(-1073741824);
    private static int e;
    private static int c;
    private static int f;
    private int aR = a;
    private static int d;
    private static int b;

    static {
        b = Integer.reverse(Integer.MIN_VALUE);
        c = Integer.reverse(0x20000000);
        d = Integer.reverse(0);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = Integer.reverse(0);
    }

    public boolean aR() {
        this.aR += b;
        if (this.aR == c) {
            this.aR = d;
            return e != 0;
        }
        return f != 0;
    }
}

