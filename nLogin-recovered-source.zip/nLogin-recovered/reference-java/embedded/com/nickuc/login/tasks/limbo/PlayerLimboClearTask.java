/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login.tasks.limbo;

import com.nickuc.login.tasks.CommonTask;

public class PlayerLimboClearTask
extends CommonTask {
    public PlayerLimboClearTask(Runnable runnable) {
        super(runnable);
    }
}

