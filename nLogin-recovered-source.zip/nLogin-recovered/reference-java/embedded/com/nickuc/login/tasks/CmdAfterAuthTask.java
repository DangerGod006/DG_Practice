/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login.tasks;

import com.nickuc.login.tasks.CommonTask;

public class CmdAfterAuthTask
extends CommonTask {
    public CmdAfterAuthTask(Runnable runnable) {
        super(runnable);
    }
}

