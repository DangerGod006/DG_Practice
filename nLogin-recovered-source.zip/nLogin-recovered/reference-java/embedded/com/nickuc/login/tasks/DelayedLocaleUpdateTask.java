/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login.tasks;

import com.nickuc.login.tasks.CommonTask;

public class DelayedLocaleUpdateTask
extends CommonTask {
    public DelayedLocaleUpdateTask(Runnable runnable) {
        super(runnable);
    }
}

