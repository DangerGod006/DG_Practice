/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login.tasks;

import com.nickuc.login.tasks.CommonTask;

public class AsyncAuthApiTask
extends CommonTask {
    public AsyncAuthApiTask(Runnable runnable) {
        super(runnable);
    }
}

