/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login.tasks.limbo;

import com.nickuc.login.tasks.CommonTask;

public class PlayerLimboRestoreTask
extends CommonTask {
    public PlayerLimboRestoreTask(Runnable runnable) {
        super(runnable);
    }
}

