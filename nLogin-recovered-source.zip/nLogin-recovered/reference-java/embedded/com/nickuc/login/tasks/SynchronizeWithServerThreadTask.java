/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login.tasks;

import com.nickuc.login.tasks.CommonTask;

public class SynchronizeWithServerThreadTask
extends CommonTask {
    public SynchronizeWithServerThreadTask(Runnable runnable) {
        super(runnable);
    }
}

