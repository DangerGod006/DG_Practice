/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login.tasks;

import com.nickuc.login.tasks.CommonTask;

public class StartAsyncLoginTask
extends CommonTask {
    public StartAsyncLoginTask(Runnable runnable) {
        super(runnable);
    }
}

