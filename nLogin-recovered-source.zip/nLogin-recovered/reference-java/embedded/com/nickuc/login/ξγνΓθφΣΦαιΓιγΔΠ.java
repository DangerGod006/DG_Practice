/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03c9\u03c8\u0393\u03b7\u03b5\u03a9\u03b2\u03b8\u03b4\u03c0;
import java.security.KeyPair;
import lombok.Generated;

public class \u03be\u03b3\u03bd\u0393\u03b8\u03c6\u03a3\u03a6\u03b1\u03b9\u0393\u03b9\u03b3\u0394\u03a0 {
    private final KeyPair a;

    @Generated
    private \u03be\u03b3\u03bd\u0393\u03b8\u03c6\u03a3\u03a6\u03b1\u03b9\u0393\u03b9\u03b3\u0394\u03a0(KeyPair keyPair) {
        this.a = keyPair;
    }

    /* synthetic */ \u03be\u03b3\u03bd\u0393\u03b8\u03c6\u03a3\u03a6\u03b1\u03b9\u0393\u03b9\u03b3\u0394\u03a0(KeyPair keyPair, \u03c9\u03c8\u0393\u03b7\u03b5\u03a9\u03b2\u03b8\u03b4\u03c0 \u03c9\u03c8\u0393\u03b7\u03b5\u03a9\u03b2\u03b8\u03b4\u03c02) {
        this(keyPair);
    }

    @Generated
    public KeyPair a() {
        return this.a;
    }
}

