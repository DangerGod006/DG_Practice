/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.protocol.ConnectionState
 */
package com.nickuc.login;

import com.nickuc.login.lib.packetevents.api.protocol.ConnectionState;

class \u03be\u03c7\u03c2\u03ba\u03a8\u03c1\u03b3\u03c0\u039b\u0393\u03bc\u03b3\u03b6 {
    static final /* synthetic */ int[] R;
    private static int b;
    private static int c;
    private static int a;

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = Integer.reverse(0x40000000);
        c = (6144 >>> 107 | 6144 << -107) & 0xFFFFFFFF;
        R = new int[ConnectionState.values().length];
        try {
            \u03be\u03c7\u03c2\u03ba\u03a8\u03c1\u03b3\u03c0\u039b\u0393\u03bc\u03b3\u03b6.R[ConnectionState.LOGIN.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03be\u03c7\u03c2\u03ba\u03a8\u03c1\u03b3\u03c0\u039b\u0393\u03bc\u03b3\u03b6.R[ConnectionState.CONFIGURATION.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03be\u03c7\u03c2\u03ba\u03a8\u03c1\u03b3\u03c0\u039b\u0393\u03bc\u03b3\u03b6.R[ConnectionState.PLAY.ordinal()] = c;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

