/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.enums.SpawnType
 */
package com.nickuc.login;

import com.nickuc.login.api.enums.SpawnType;

class \u03b7\u03c4\u03bc\u03b4\u03b1\u03c2\u03a6\u03c4 {
    private static int a = Integer.reverse(Integer.MIN_VALUE);
    private static int c;
    static final /* synthetic */ int[] ah;
    private static int b;
    private static int d;
    private static int e;

    static {
        b = Integer.reverse(0x40000000);
        c = 6 >>> 193 | 6 << ~193 + 1;
        d = Integer.reverse(0x20000000);
        e = 0x140000 >>> 50 | 0x140000 << -50;
        ah = new int[SpawnType.values().length];
        try {
            \u03b7\u03c4\u03bc\u03b4\u03b1\u03c2\u03a6\u03c4.ah[SpawnType.JOIN.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b7\u03c4\u03bc\u03b4\u03b1\u03c2\u03a6\u03c4.ah[SpawnType.FIRST_JOIN.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b7\u03c4\u03bc\u03b4\u03b1\u03c2\u03a6\u03c4.ah[SpawnType.LOGIN.ordinal()] = c;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b7\u03c4\u03bc\u03b4\u03b1\u03c2\u03a6\u03c4.ah[SpawnType.REGISTER.ordinal()] = d;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03b7\u03c4\u03bc\u03b4\u03b1\u03c2\u03a6\u03c4.ah[SpawnType.RESPAWN.ordinal()] = e;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

