/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.types.Identity
 */
package com.nickuc.login;

import com.nickuc.login.api.types.Identity;

public abstract class \u03b4\u0393\u03b2\u03c2\u03b6\u03a3\u03c8\u03a0
implements Identity {
}

