/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;

class \u03bc\u03a3\u03a0\u03be\u03c2\u03b2\u03c9\u03b9\u03a3\u03b1\u03c4\u03c6\u03be {
    static final /* synthetic */ int[] B;
    private static int b;
    private static int a;

    static {
        a = Integer.reverse(Integer.MIN_VALUE);
        b = Integer.reverse(0x40000000);
        B = new int[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.values().length];
        try {
            \u03bc\u03a3\u03a0\u03be\u03c2\u03b2\u03c9\u03b9\u03a3\u03b1\u03c4\u03c6\u03be.B[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.b.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03bc\u03a3\u03a0\u03be\u03c2\u03b2\u03c9\u03b9\u03a3\u03b1\u03c4\u03c6\u03be.B[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.c.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

