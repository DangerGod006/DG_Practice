/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nonnull
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.util.List;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public interface \u03b1\u03b4\u03be\u03a0\u03c8\u03b2\u03a3\u03bb\u03c9\u039b\u03ba<K> {
    default public boolean a(K k, boolean bl) {
        Object object = this.b(k, bl);
        if (object instanceof Boolean) {
            return (Boolean)object;
        }
        return Boolean.parseBoolean(object.toString());
    }

    default public double a(K k, double d) {
        Object object = this.b(k, d);
        if (object instanceof Double) {
            return (Double)object;
        }
        return Double.parseDouble(object.toString());
    }

    @Nonnull
    default public <T> T c(K k) {
        Object object = this.e(k);
        if (object == null) {
            throw new IllegalStateException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.D("\u047b\u0496\u04ab\u0453", (byte)41, 68) + k + \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.E("\u0505\u0554\u0556\u055c\u0509\u0550\u055a\u0561\u055b\u0552\u0510", (byte)41, 69));
        }
        try {
            return (T)object;
        }
        catch (Throwable throwable) {
            throw new RuntimeException(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.C("\u0473\u049d\u0493\u04a6\u04a7\u0455\u0499\u0498\u04ab\u04ad\u045a\u04a0\u04b4\u04a0\u04a3\u04af\u04b4\u04aa\u04b1\u04b1\u0470\u0465\u04b1\u04ac\u04c1\u0469", (byte)41, 67) + k + (object != null ? \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u00fd\u00f2\u0149\u0135\u0141\u014b\u013c\u00f8\u013c\u0146\u013c\u014f\u0150\u00fe", (byte)41, 65) + object.getClass().getCanonicalName() : ""), throwable);
        }
    }

    @Nonnull
    default public List<Integer> c(K k, List<Integer> list) {
        return this.a(k, (Object)list);
    }

    default public short a(K k, short s) {
        Object object = this.b(k, s);
        if (object instanceof Short) {
            return (Short)object;
        }
        return Short.parseShort(object.toString());
    }

    @Nonnull
    default public List<?> b(K k, List<?> list) {
        return this.a(k, (Object)list);
    }

    @Nullable
    default public List<?> b(K k) {
        return (List)this.d(k);
    }

    @Nullable
    default public List<String> a(K k) {
        return (List)this.d(k);
    }

    default public short a(K k) {
        Object object = this.e(k);
        if (object instanceof Short) {
            return (Short)object;
        }
        if (object != null) {
            return Short.parseShort(object.toString());
        }
        return 0;
    }

    default public boolean d(K k) {
        Object object = this.e(k);
        if (object instanceof Boolean) {
            return (Boolean)object;
        }
        return object != null && Boolean.parseBoolean(object.toString());
    }

    public boolean c(K var1);

    default public int a(K k) {
        Object object = this.e(k);
        if (object instanceof Integer) {
            return (Integer)object;
        }
        if (object != null) {
            return Integer.parseInt(object.toString());
        }
        return 0;
    }

    @Nonnull
    default public Object b(K k, Object object) {
        if (object == null) {
            throw new IllegalArgumentException(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.D("\u0438\u045a\u045c\u0458\u046d\u0465\u046e\u041b\u0472\u045e\u046a\u0474\u0465\u0421\u0465\u0464\u0472\u0473\u0475\u047b\u0428\u046b\u046f\u042b\u047a\u0482\u047a\u047b\u0431", (byte)21, 68));
        }
        Object object2 = this.e(k);
        return object2 != null ? object2 : object;
    }

    default public long b(K k) {
        Object object = this.e(k);
        if (object instanceof Long) {
            return (Long)object;
        }
        if (object != null) {
            return Long.parseLong(object.toString());
        }
        return 0L;
    }

    default public long a(K k, long l) {
        Object object = this.b(k, l);
        if (object instanceof Long) {
            return (Long)object;
        }
        return Long.parseLong(object.toString());
    }

    @Nullable
    default public <T> T d(K k) {
        Object object = this.e(k);
        try {
            return (T)object;
        }
        catch (Throwable throwable) {
            throw new RuntimeException(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.B("\u00de\u0108\u00fe\u0111\u0112\u00c0\u0104\u0103\u0116\u0118\u00c5\u010b\u011f\u010b\u010e\u011a\u011f\u0115\u011c\u011c\u00db\u00d0\u011c\u0117\u012c\u00d4", (byte)14, 66) + k + (object != null ? \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.B("\u00c7\u00bc\u0113\u00ff\u010b\u0115\u0106\u00c2\u0106\u0110\u0106\u0119\u011a\u00c8", (byte)14, 66) + object.getClass().getCanonicalName() : ""), throwable);
        }
    }

    @Nullable
    public Object a(K var1);

    @Nonnull
    default public <T> T a(K k, T t) {
        Object object = this.b(k, t);
        try {
            return (T)object;
        }
        catch (Throwable throwable) {
            throw new RuntimeException(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u055e\u0588\u057e\u0591\u0592\u0540\u0584\u0583\u0596\u0598\u0545\u058b\u059f\u058b\u058e\u059a\u059f\u0595\u059c\u059c\u055b\u0550\u059c\u0597\u05ac\u0554", (byte)95, 70) + k + (object != null ? \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.C("\u04fe\u04f3\u054a\u0536\u0542\u054c\u053d\u04f9\u053d\u0547\u053d\u0550\u0551\u04ff", (byte)95, 67) + object.getClass().getCanonicalName() : ""), throwable);
        }
    }

    default public double a(K k) {
        Object object = this.e(k);
        if (object instanceof Double) {
            return (Double)object;
        }
        if (object != null) {
            return Double.parseDouble(object.toString());
        }
        return 0.0;
    }

    default public int a(K k, int n) {
        Object object = this.b(k, n);
        if (object instanceof Integer) {
            return (Integer)object;
        }
        return Integer.parseInt(object.toString());
    }

    @Nonnull
    default public String a(K k, String string) {
        Object object = this.b(k, string);
        return object.toString();
    }

    @Nonnull
    default public List<String> a(K k, List<String> list) {
        return this.a(k, (Object)list);
    }

    @Nullable
    default public Object e(K k) {
        if (k == null) {
            throw new IllegalArgumentException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.E("\u056e\u0589\u059e\u0546\u058a\u0589\u0597\u0598\u059a\u05a0\u054d\u0590\u0594\u0550\u059f\u05a7\u059f\u05a0\u0556", (byte)103, 69));
        }
        return this.c(k) ? this.a(k) : null;
    }

    @Nullable
    default public List<Integer> c(K k) {
        return (List)this.d(k);
    }

    default public String b(K k) {
        Object object = this.e(k);
        return object != null ? object.toString() : null;
    }
}

