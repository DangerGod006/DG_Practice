/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.caffeine.cache.Cache
 *  com.nickuc.login.lib.caffeine.cache.Caffeine
 *  com.nickuc.login.lib.packetevents.api.protocol.player.User
 *  io.netty.channel.Channel
 *  io.netty.channel.ChannelPipeline
 *  io.netty.util.AttributeKey
 *  javax.annotation.Nullable
 *  lombok.Generated
 *  org.bukkit.Location
 */
package com.nickuc.login.bukkit;

import com.nickuc.login.lib.caffeine.cache.Cache;
import com.nickuc.login.lib.caffeine.cache.Caffeine;
import com.nickuc.login.lib.packetevents.api.protocol.player.User;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03be\u03c8\u03bc\u03b1\u03c2\u03c8\u03c7;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03c7\u03b9\u03bb\u03a3\u03a9\u03bc\u03c8\u03b9\u03c4\u03b2\u0394\u03a3\u03b4\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c3\u03b9\u03b2\u03b5\u03b8\u03ba\u03b9\u03c0\u0393\u03bd\u03a3\u0394\u03bf\u03c5\u03c1;
import com.nickuc.login.\u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03bf\u03bc\u03a6\u03b4\u0394\u03c0\u03bd\u03a8\u03b5\u03b2\u03c5\u0393;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import io.netty.channel.Channel;
import io.netty.channel.ChannelPipeline;
import io.netty.util.AttributeKey;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.bukkit.Location;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0
implements \u03bd\u03c7\u03b9\u03bb\u03a3\u03a9\u03bc\u03c8\u03b9\u03c4\u03b2\u0394\u03a3\u03b4\u03bc {
    @Nullable
    private \u03b3\u03be\u03c8\u03bc\u03b1\u03c2\u03c8\u03c7 a;
    private static String[] b;
    private static long d;
    private static int e;
    @Nullable
    public final Runnable a;
    private static int m;
    private static int f;
    public final boolean a;
    @Nullable
    public final \u03c9\u03bf\u03bc\u03a6\u03b4\u0394\u03c0\u03bd\u03a8\u03b5\u03b2\u03c5\u0393 a;
    private static int a;
    private static int h;
    private boolean b;
    private static long g;
    private static String[] a;
    public final User a;
    private static int j;
    @Nullable
    public Location a;
    private static long c;
    private static long o;
    public final String k;
    @Nullable
    public final UUID c;
    private static long n;
    private static long b;
    private static int i;
    private static int l;
    public static final AttributeKey<\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0> a;
    private static final Cache<String, \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0> b;
    public final Channel a;
    private static int k;
    public final \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 a;

    public boolean d() {
        ChannelPipeline channelPipeline = this.a.pipeline();
        return (channelPipeline.get((String)\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.c("\u3e80", (int)a, (long)(b ^ d))) != null && channelPipeline.get((String)\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.c("\u3e83", (int)(e & f), (long)g)) != null ? h : i) != 0;
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(-5908577008732872104L);
        d = Long.reverse(-7926335344172072960L);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = (-1 >>> 87 | -1 << ~87 + 1) & 0xFFFFFFFF;
        g = Long.reverse(4323601344652894808L);
        h = 0x8000000 >>> 27 | 0x8000000 << -27;
        i = (0 >>> 224 | 0 << ~224 + 1) & 0xFFFFFFFF;
        j = 2 >>> 129 | 2 << ~129 + 1;
        k = (786432 >>> 210 | 786432 << ~210 + 1) & 0xFFFFFFFF;
        l = Integer.reverse(-1073741824);
        m = (128 >>> 102 | 128 << ~102 + 1) & 0xFFFFFFFF;
        n = Long.reverse(-5908577008732872104L);
        o = Long.reverse(-7926335344172072960L);
        a = new String[k];
        b = new String[l];
        \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.b();
        a = \u03c3\u03b9\u03b2\u03b5\u03b8\u03ba\u03b9\u03c0\u0393\u03bd\u03a3\u0394\u03bf\u03c5\u03c1.a((String)\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.c("\u3e80", (int)m, (long)(n ^ o)));
        b = Caffeine.newBuilder().expireAfterWrite(1L, TimeUnit.MINUTES).build();
    }

    private static String a(int n, long l) {
        l ^= 0x49L;
        l ^= 0x3B5FF3960DA3DE5AL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(33 + 35), (byte)(47 + 22), 83, (byte)(30 + 17), 67, (byte)(23 + 43), (byte)(22 + 45), (byte)(6 + 41), (byte)(79 + 1), (byte)(25 + 50), (byte)(36 + 31), (byte)(36 + 47), (byte)(12 + 41), (byte)(38 + 42), (byte)(47 + 50), (byte)(29 + 71), (byte)(53 + 47), (byte)(40 + 65), (byte)(13 + 97), (byte)(64 + 39)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(24 + 44), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.D("\u0526\u0533\u0532\u04f5\u0535\u0531\u052c\u0535\u0540\u052f\u04fc\u053a\u053e\u0537\u053a\u0540\u0502\u0536\u054a\u0541\u0542\u0541\u054d\u0509\u087b\u0895\u0893\u0894\u089e\u0888\u089b\u08aa\u0883\u0878\u08a5", (byte)90, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static void a(String string, @Nullable String string2, InetAddress inetAddress, \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0) {
        b.put((Object)string, (Object)\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0);
        b.put((Object)(string + inetAddress.getHostAddress()), (Object)\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0);
        if (string2 != null) {
            b.put((Object)(string2 + inetAddress.getHostAddress()), (Object)\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0);
        }
    }

    @Override
    @Generated
    public boolean f() {
        return this.b;
    }

    @Override
    public boolean e() {
        return this.a;
    }

    @Override
    @Nullable
    public \u03b3\u03be\u03c8\u03bc\u03b1\u03c2\u03c8\u03c7 a() {
        return this.a;
    }

    @Override
    public \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 a() {
        return this.a;
    }

    public static \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 a(String string, InetAddress inetAddress, @Nullable InetAddress inetAddress2) {
        \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 = null;
        if (inetAddress != null) {
            \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 = (\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0)b.getIfPresent((Object)(string + inetAddress.getHostAddress()));
        }
        if (\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 == null && inetAddress2 != null) {
            \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 = (\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0)b.getIfPresent((Object)(string + inetAddress2.getHostAddress()));
        }
        if (\u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 == null) {
            \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0 = (\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0)b.getIfPresent((Object)string);
        }
        return \u03c0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0;
    }

    @Generated
    public \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0(User user, \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b9 \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92, String string, @Nullable UUID uUID, boolean bl, @Nullable Runnable runnable, Channel channel, @Nullable \u03c9\u03bf\u03bc\u03a6\u03b4\u0394\u03c0\u03bd\u03a8\u03b5\u03b2\u03c5\u0393 \u03c9\u03bf\u03bc\u03a6\u03b4\u0394\u03c0\u03bd\u03a8\u03b5\u03b2\u03c5\u03932) {
        this.a = user;
        this.a = \u03c3\u03c4\u03a9\u03be\u03be\u03c7\u03ba\u03b92;
        this.k = string;
        this.c = uUID;
        this.a = bl;
        this.a = runnable;
        this.a = channel;
        this.a = \u03c9\u03bf\u03bc\u03a6\u03b4\u0394\u03c0\u03bd\u03a8\u03b5\u03b2\u03c5\u03932;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u0133\u0155\u0157\u0137\u015b\u017a\u0172\u0188\u0174\u0143\u0181\u0177\u0185\u017f\u0148\u016d\u018f\u018e\u0186\u018c\u0186\u015b", (byte)70, 66), \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u04ea\u04f7\u04f6\u04b9\u04f9\u04f5\u04f0\u04f9\u0504\u04f3\u04c0\u04fe\u0502\u04fb\u04fe\u0504\u04c6\u04fa\u050e\u0505\u0506\u0505\u0511\u04cd\u083f\u0859\u0857\u0858\u0862\u084c\u085f\u086e\u0847\u083c\u0869\u04e4", (byte)70, 68) + string + \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.B("\u0145", (byte)70, 66) + methodType.toString(), exception);
        }
    }

    private static void b() {
        int n;
        c = 1893753059455074421L;
        long l = c ^ 0x3B5FF3960DA3DE5AL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(43 + 26), (byte)(18 + 65), (byte)(35 + 12), (byte)(41 + 26), (byte)(16 + 50), (byte)(58 + 9), (byte)(5 + 42), (byte)(14 + 66), (byte)(14 + 61), (byte)(9 + 58), (byte)(78 + 5), (byte)(36 + 17), (byte)(66 + 14), (byte)(74 + 23), (byte)(41 + 59), (byte)(52 + 48), 105, (byte)(107 + 3), (byte)(96 + 7)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(11 + 58), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.b[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0513\u0514\u0524\u0518\u0537\u0504\u04ff\u0542\u0522\u0539\u054f\u0516", (byte)18, 69);
                    \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.b[1] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u0543\u0528\u0501\u050a\u0522\u050c\u0540\u052d\u0548\u053b\u051d\u0516", (byte)18, 70);
                    \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.b[2] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u0513\u0548\u04ff\u052b\u0506\u050c\u051e\u0517\u0545\u0502\u050c\u0540\u0553\u052b\u0554\u0545\u0551\u0532\u0551\u051a\u0513\u0558\u0530\u053c\u0527\u055a\u053c\u055b\u0519\u051a\u0525\u0546", (byte)18, 70);
                    continue block7;
                }
                case 1: {
                    \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u00f7\u00ed\u010d\u010c\u00d2\u0122\u0118\u00ec\u010c\u0110\u00e2\u00ef\u0122\u00fe\u00fb\u0122\u0117\u00f8\u011c\u00f7\u010b\u011f\u00f6\u00f7", (byte)18, 66);
                    \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.b[1] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.E("\u0517\u0526\u051e\u0504\u0540\u0514\u0548\u050b\u053e\u051f\u050f\u0542\u0541\u0530\u0521\u052c\u0524\u054e\u0551\u0546\u0511\u055a\u0521\u0522", (byte)18, 69);
                    \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.b[2] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.C("\u0430\u0465\u041c\u0448\u0423\u0429\u043b\u0434\u0462\u041f\u0429\u045d\u0470\u0448\u0471\u0462\u046e\u044f\u046e\u0437\u0430\u0468\u0463\u045a\u0439\u0459\u0475\u0470\u046a\u043b\u046d\u0440\u045e\u0471\u0472\u0445\u0487\u043b\u0477\u0475\u0461\u043f\u045a\u0453", (byte)18, 67);
                    continue block7;
                }
                case 2: {
                    \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u051e\u0540\u0505\u0542\u0521\u051e\u0547\u0505\u051a\u051d\u050e\u0527\u050e\u0531\u053d\u0534\u0522\u0529\u0526\u0559\u0556\u054a\u0521\u0522", (byte)18, 70);
                    continue block7;
                }
                case 4: {
                    \u03a0\u03b9\u03b6\u03b6\u03bf\u03a8\u03ba\u03c8\u03a0\u0394\u03c0.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u010f\u00f7\u00fa\u010c\u011e\u010f\u00da\u011b\u0115\u00ef\u0107\u0104\u011c\u0113\u00f3\u0116\u011e\u011b\u00e8\u010d\u012f\u012f\u00f6\u00f7", (byte)18, 66);
                }
            }
        }
    }

    @Override
    public String d() {
        return this.k;
    }

    @Override
    public void b(String string, String string2) {
        this.a = new \u03b3\u03be\u03c8\u03bc\u03b1\u03c2\u03c8\u03c7(string, string2);
    }

    @Override
    public void g() {
        this.b = j;
    }
}

