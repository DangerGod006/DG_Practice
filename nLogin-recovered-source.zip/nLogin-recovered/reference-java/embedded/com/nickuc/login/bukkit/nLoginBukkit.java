/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.loader.MemClassLoader
 *  com.nickuc.login.loader.platform.BukkitLoader
 *  lombok.Generated
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Cancellable
 *  org.bukkit.event.Event
 */
package com.nickuc.login.bukkit;

import com.nickuc.login.loader.MemClassLoader;
import com.nickuc.login.loader.platform.BukkitLoader;
import com.nickuc.login.\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6;
import com.nickuc.login.\u0394\u03bf\u0393\u03ba\u03c9\u03a0\u03b1\u03bb\u03be\u03c6\u03b9\u03a9\u03b8;
import com.nickuc.login.\u0394\u03c7\u03bb\u03a9\u03c8\u03b4\u03bb\u039b\u03b9\u03c7;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a6\u03c9\u03bf\u03c6\u03c5\u03b4\u03b9\u03c6\u03a3\u03a6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03c8\u03a8\u03c1\u03b5\u03be\u03bf\u03c3\u03a0\u03c2\u039b\u03c5;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b4\u03c2\u03bc\u03b8\u03b3\u03ba\u0393\u03b3\u03a8\u03bb\u03b7\u03bd\u03c5\u03a0;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03ba\u03b1\u03a6\u03b6\u03b8\u03b8\u03c5\u03c5\u03b5\u03c6\u03a6\u03b3;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Collections;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class nLoginBukkit
extends \u03bc\u039b\u0394\u03b8\u039b\u03c4\u03bd\u03b1\u03b5\u03b1\u0393
implements \u0394\u03c7\u03bb\u03a9\u03c8\u03b4\u03bb\u039b\u03b9\u03c7 {
    private static int j;
    private static long t;
    private static int af;
    private static int q;
    private static String[] b;
    private static int ak;
    private static int aj;
    private static int y;
    private static long c;
    private static long ad;
    private static int ag;
    private static int b;
    private static int ai;
    private static int ab;
    private static int n;
    private static long h;
    private boolean s;
    private static long r;
    private static int v;
    private static int g;
    private \u03a6\u03c9\u03bf\u03c6\u03c5\u03b4\u03b9\u03c6\u03a3\u03a6 a;
    private static long x;
    private static int f;
    private static long k;
    private static int i;
    private static long w;
    private static int l;
    private static long d;
    private static int ae;
    private static long e;
    private static long aa;
    private static int s;
    private static int p;
    private static long m;
    private static String[] a;
    private static long ac;
    private static long z;
    private static long o;
    private static long u;
    private static int ah;

    private static void b() {
        int n;
        c = -6867804744360207304L;
        long l = c ^ 0x4D751C2A0564664AL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(48 + 20), (byte)(26 + 43), (byte)(11 + 72), (byte)(14 + 33), (byte)(35 + 32), (byte)(48 + 18), (byte)(6 + 61), 47, (byte)(35 + 45), (byte)(8 + 67), (byte)(7 + 60), (byte)(63 + 20), (byte)(12 + 41), (byte)(77 + 3), (byte)(7 + 90), 100, (byte)(16 + 84), (byte)(69 + 36), (byte)(13 + 97), (byte)(19 + 84)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(26 + 43), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    nLoginBukkit.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0578\u0560\u058b\u055e\u058a\u0564\u0586\u0591\u056f\u0569\u054e\u055c", (byte)117, 67);
                    nLoginBukkit.b[1] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.D("\u0583\u058c\u054f\u054b\u0579\u0588\u0593\u054c\u0585\u0570\u057f\u054a\u056c\u0557\u0566\u0558\u0590\u0591\u0593\u056b\u055e\u056d\u0560\u0598\u059c\u05a3\u05a5\u05a2\u0575\u0580\u059d\u0584", (byte)117, 68);
                    nLoginBukkit.b[2] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u057d\u0565\u056c\u055b\u0591\u054e\u056f\u054f\u0570\u0581\u0571\u058e\u0562\u0572\u0563\u056a\u057e\u0599\u056f\u057f\u0596\u0579\u057e\u0563\u057e\u059d\u05a5\u059d\u0560\u0598\u057a\u059c\u05a0\u056c\u0590\u058f\u0584\u057d\u0583\u0589\u05b4\u05aa\u0573\u0577\u0599\u05b6\u05b6\u057c\u05be\u058a\u05b4\u0592\u05ad\u057b\u05ae\u0597\u057d\u05b0\u059d\u05a0\u0591\u059d\u05bd\u05aa\u05ba\u05cd\u05ac\u0587\u059a\u059d\u05c2\u05c8\u05a2\u0595\u058d\u05c8\u05a2\u05a2\u05b7\u05c5\u05d7\u05bd\u0595\u05bf\u05b4\u05bc\u05d9\u05d7\u05be\u05c4\u05db\u05e6\u05c0\u05b4\u05de\u05c4", (byte)117, 68);
                    nLoginBukkit.b[3] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u0589\u0557\u054a\u0587\u0561\u0550\u0588\u0593\u0576\u058b\u0580\u0589\u056a\u056a\u058e\u058a\u0595\u059f\u0559\u0579\u059e\u0598\u0573\u0561\u05a2\u055f\u0561\u0576\u0580\u0561\u058b\u058d\u0581\u0577\u05a0\u05b0\u058a\u0593\u05ad\u05a6\u05ae\u05b6\u05ad\u05b5\u05a1\u0597\u05b9\u05ae\u0594\u05ad\u057d\u057c\u05ae\u05b8\u05b6\u0591\u05a6\u0598\u05b3\u05b3\u05bd\u0584\u05b3\u05ab\u05ae\u05c4\u0586\u05a2\u05bb\u059d\u05c0\u05d5\u05c8\u0594\u059f\u05d8\u05c9\u0599\u05ca\u05cb\u05d5\u05a8\u059a\u05b5\u05e0\u05cd\u05de\u05e4\u05b7\u05be\u05e2\u05e9\u05a8\u05c6\u05a4\u05a2", (byte)117, 68);
                    nLoginBukkit.b[4] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.D("\u0560\u057c\u057b\u0550\u054b\u0592\u058f\u057c\u0596\u0570\u058c\u056b\u0585\u058c\u058e\u0553\u0587\u057e\u059f\u056f\u058b\u055f\u056f\u05a0\u057d\u058e\u059c\u0578\u0589\u0577\u0594\u05ac\u059d\u058c\u059a\u05ae\u05a2\u058f\u059f\u058f\u0591\u058c\u05a5\u0595\u0595\u05a4\u05a8\u05b3\u05a8\u058b\u05a8\u05ab\u057b\u05b5\u05b1\u057c\u059c\u05bb\u05b0\u0598\u059a\u059a\u05b9\u05c1\u058d\u05c5\u059e\u058c\u05c4\u05cc\u05bc\u05a8\u05a4\u059e\u05a1\u05cb\u05d2\u0592\u05b1\u05db\u05a6\u05b2\u0591\u05ce\u05b7\u05cf\u05d5\u05ad\u059f\u05d3\u05e8\u05c9\u05bf\u05ea\u05b5\u05c8", (byte)117, 68);
                    nLoginBukkit.b[5] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.B("\u01d7\u0199\u01da\u01c3\u01d2\u01c1\u01e2\u01b9\u01d6\u01dd\u01a7\u01e0\u01c9\u01be\u01e2\u01bc\u01da\u01bd\u01e6\u01f2\u01d3\u01a9\u01cc\u01d6\u01f4\u01e9\u01d4\u01d9\u01bb\u01f7\u01e0\u01d1\u01ee\u01cc\u01c1\u01d2\u01d1\u01e1\u01c0\u01f4\u01bc\u01d3\u01fa\u020c\u01fb\u01ee\u01fc\u01cc\u01e6\u0204\u01f1\u01d5\u01ce\u01f7\u01d7\u01e9\u01f1\u0205\u01fa\u01d4\u0208\u01db\u01d9\u01d9\u0201\u01eb\u0223\u01f6\u01f2\u01f4\u01fd\u021d\u01e6\u021c\u020b\u01f8\u01ea\u0228\u0229\u021e\u01e4\u021e\u01e6\u0202\u0204\u0236\u0225\u0214\u0222\u020a\u020b\u020d\u01fd\u01fe\u0228\u01f8", (byte)117, 66);
                    nLoginBukkit.b[6] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u0585\u059c\u059d\u05a0\u05a7\u05ab\u05b0\u059b\u0564\u0587\u058f\u0584\u056f\u0572\u05b2\u0572\u05b6\u05a3\u0595\u0576\u059c\u0588\u058a\u059a\u059a\u05c1\u0595\u05a6\u05bb\u0594\u0593\u0595\u05c6\u05ba\u0583\u05cd\u05c0\u05cb\u05c0\u059a\u058e\u05a5\u05b3\u05ce\u05c0\u05a1\u05b2\u05ab\u05bb\u05cf\u05b4\u05c7\u05d2\u05ba\u05ba\u05d9\u05b1\u05ae\u059b\u059c\u05b1\u05c6\u05c1\u05d5\u05a2\u05b4\u05bc\u05e6\u05bf\u05d9\u05d1\u05bd\u05cc\u05bf\u05ed\u05c0\u05e6\u05ae\u05c7\u05d6\u05ce\u05f5\u05f2\u05cd\u05dc\u05d8\u05f6\u0602\u05fd\u05fb\u05ec\u05f1\u05e7\u05d6\u05d6\u05de", (byte)117, 70);
                    nLoginBukkit.b[7] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.B("\u01af\u01b9\u01b8\u01ad\u01b4\u01d9\u01b7\u01be\u01b5\u01b3\u01a8\u019f\u01db\u01ea\u01b8\u01aa\u01c0\u01d3\u01b3\u01af\u01e3\u01d6\u01d0\u01cd\u01f0\u01b9\u01db\u01f0\u01bb\u01dd\u01b9\u01de\u01f2\u01fc\u01d8\u01d6\u01e7\u01f5\u01f8\u020a\u01e4\u0208\u01c2\u01d5\u01dc\u020e\u0203\u0203\u01e3\u01ea\u01e3\u01f2\u01f5\u01d6\u01e9\u01eb\u01ee\u01d5\u01da\u01ee\u01f4\u0218\u01db\u01fc\u0222\u0218\u01fb\u0205\u0201\u01fd\u01f5\u0209\u0215\u0202\u0229\u020d\u021e\u020f\u021c\u021e\u01e9\u0213\u022b\u0229\u022d\u020a\u0224\u0211\u0226\u022b\u020a\u0230\u0213\u0237\u01f6\u022e", (byte)117, 66);
                    nLoginBukkit.b[8] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.A("\u01b7\u01b2\u0196\u01ba\u01ae\u01e1\u01c6\u01d7\u01c5\u01ab\u01a5\u01df\u01db\u01bb\u01df\u01bc\u01aa\u01aa\u01c2\u01ce\u01e2\u01cc\u01b2\u01ca\u01ee\u01d2\u01fa\u01dd\u01e9\u01ca\u01c0\u01d9\u01ec\u01d1\u01ee\u01c5\u01e7\u01ff\u01f4\u01f2\u0205\u01f5\u01cb\u01d1", (byte)117, 65);
                    nLoginBukkit.b[9] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u01b7\u01b2\u0196\u01ba\u01ae\u01e1\u01c6\u01d7\u01c5\u01ab\u01a6\u01e2\u01b7\u01a9\u01d1\u01c6\u01af\u01de\u01e0\u01ad\u01a8\u01cf\u01bc\u01bd", (byte)117, 66);
                    continue block7;
                }
                case 1: {
                    nLoginBukkit.b[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.A("\u01d3\u01b8\u01d8\u01a0\u01a4\u01a1\u01c0\u01ca\u01d4\u01e6\u01e8\u01bc\u01df\u01a6\u01cd\u01a3\u01d0\u01bb\u01c8\u01a7\u01e6\u01e5\u01bc\u01bd", (byte)117, 65);
                    nLoginBukkit.b[1] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.E("\u05a0\u05a9\u056c\u0568\u0596\u05a5\u05b0\u0569\u05a2\u058d\u059c\u0567\u0589\u0574\u0583\u0575\u05ad\u05ae\u05b0\u0588\u057b\u058b\u058d\u05ad\u05a2\u0590\u05a4\u05bb\u05c1\u05b6\u057e\u0587", (byte)117, 69);
                    nLoginBukkit.b[2] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.C("\u057d\u0565\u056c\u055b\u0591\u054e\u056f\u054f\u0570\u0581\u0571\u058e\u0562\u0572\u0563\u056a\u057e\u0599\u056f\u057f\u0596\u0579\u057e\u0563\u057e\u059d\u05a5\u059d\u0560\u0598\u057a\u059c\u05a0\u056c\u0590\u058f\u0584\u057d\u0583\u0589\u05b4\u05aa\u0573\u0577\u0599\u05b6\u05b6\u057c\u05be\u058a\u05b4\u0592\u05ad\u057b\u05ae\u0597\u057d\u05b0\u059d\u05a0\u0591\u059d\u05bd\u05aa\u05ba\u05cd\u05ac\u0587\u059a\u059d\u05c2\u05c8\u05a2\u0595\u058d\u05c8\u05a2\u05a2\u05b7\u05c5\u05d7\u05bd\u0595\u05bf\u05b4\u05ba\u05a1\u05e5\u05db\u05e1\u05b0\u05e3\u05b3\u05d8\u05c7\u05dd", (byte)117, 67);
                    nLoginBukkit.b[3] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u0589\u0557\u054a\u0587\u0561\u0550\u0588\u0593\u0576\u058b\u0580\u0589\u056a\u056a\u058e\u058a\u0595\u059f\u0559\u0579\u059e\u0598\u0573\u0561\u05a2\u055f\u0561\u0576\u0580\u0561\u058b\u058d\u0581\u0577\u05a0\u05b0\u058a\u0593\u05ad\u05a6\u05ae\u05b6\u05ad\u05b5\u05a1\u0597\u05b9\u05ae\u0594\u05ad\u057d\u057c\u05ae\u05b8\u05b6\u0591\u05a6\u0598\u05b3\u05b3\u05bd\u0584\u05b3\u05ab\u05ae\u05c4\u0586\u05a2\u05bb\u059d\u05c0\u05d5\u05c8\u0594\u059f\u05d8\u05c9\u0599\u05ca\u05cb\u05d5\u05a8\u059a\u05b5\u05e0\u05c2\u05d0\u05a1\u05c5\u05b3\u05c1\u05b6\u05b8\u05e8\u05d6\u05dd", (byte)117, 68);
                    nLoginBukkit.b[4] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u057d\u0599\u0598\u056d\u0568\u05af\u05ac\u0599\u05b3\u058d\u05a9\u0588\u05a2\u05a9\u05ab\u0570\u05a4\u059b\u05bc\u058c\u05a8\u057c\u058c\u05bd\u059a\u05ab\u05b9\u0595\u05a6\u0594\u05b1\u05c9\u05ba\u05a9\u05b7\u05cb\u05bf\u05ac\u05bc\u05ac\u05ae\u05a9\u05c2\u05b2\u05b2\u05c1\u05c5\u05d0\u05c5\u05a8\u05c5\u05c8\u0598\u05d2\u05ce\u0599\u05b9\u05d8\u05cd\u05b5\u05b7\u05b7\u05d6\u05de\u05aa\u05e2\u05bb\u05a9\u05e1\u05e9\u05d9\u05c5\u05c1\u05bb\u05be\u05e8\u05ef\u05af\u05ce\u05f8\u05c3\u05cf\u05ae\u05eb\u05d4\u05db\u05c9\u0601\u05bd\u05de\u05ff\u05d5\u05d7\u05f9\u05c5\u05e8", (byte)117, 70);
                    nLoginBukkit.b[5] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.B("\u01d7\u0199\u01da\u01c3\u01d2\u01c1\u01e2\u01b9\u01d6\u01dd\u01a7\u01e0\u01c9\u01be\u01e2\u01bc\u01da\u01bd\u01e6\u01f2\u01d3\u01a9\u01cc\u01d6\u01f4\u01e9\u01d4\u01d9\u01bb\u01f7\u01e0\u01d1\u01ee\u01cc\u01c1\u01d2\u01d1\u01e1\u01c0\u01f4\u01bc\u01d3\u01fa\u020c\u01fb\u01ee\u01fc\u01cc\u01e6\u0204\u01f1\u01d5\u01ce\u01f7\u01d7\u01e9\u01f1\u0205\u01fa\u01d4\u0208\u01db\u01d9\u01d9\u0201\u01eb\u0223\u01f6\u01f2\u01f4\u01fd\u021d\u01e6\u021c\u020b\u01f8\u01ea\u0228\u0229\u021e\u01e4\u021e\u01e6\u0202\u0204\u01e9\u0202\u0211\u01f9\u01f8\u022a\u022f\u0206\u022e\u023f\u01fb", (byte)117, 66);
                    nLoginBukkit.b[6] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.E("\u0585\u059c\u059d\u05a0\u05a7\u05ab\u05b0\u059b\u0564\u0587\u058f\u0584\u056f\u0572\u05b2\u0572\u05b6\u05a3\u0595\u0576\u059c\u0588\u058a\u059a\u059a\u05c1\u0595\u05a6\u05bb\u0594\u0593\u0595\u05c6\u05ba\u0583\u05cd\u05c0\u05cb\u05c0\u059a\u058e\u05a5\u05b3\u05ce\u05c0\u05a1\u05b2\u05ab\u05bb\u05cf\u05b4\u05c7\u05d2\u05ba\u05ba\u05d9\u05b1\u05ae\u059b\u059c\u05b1\u05c6\u05c1\u05d5\u05a2\u05b4\u05bc\u05e6\u05bf\u05d9\u05d1\u05bd\u05cc\u05bf\u05ed\u05c0\u05e6\u05ae\u05c7\u05d6\u05ce\u05f5\u05f2\u05cd\u05dc\u05df\u05e9\u05d5\u05cb\u05c3\u05f2\u05e6\u05fb\u05d5\u05d6\u05f4", (byte)117, 69);
                    nLoginBukkit.b[7] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u01af\u01b9\u01b8\u01ad\u01b4\u01d9\u01b7\u01be\u01b5\u01b3\u01a8\u019f\u01db\u01ea\u01b8\u01aa\u01c0\u01d3\u01b3\u01af\u01e3\u01d6\u01d0\u01cd\u01f0\u01b9\u01db\u01f0\u01bb\u01dd\u01b9\u01de\u01f2\u01fc\u01d8\u01d6\u01e7\u01f5\u01f8\u020a\u01e4\u0208\u01c2\u01d5\u01dc\u020e\u0203\u0203\u01e3\u01ea\u01e3\u01f2\u01f5\u01d6\u01e9\u01eb\u01ee\u01d5\u01da\u01ee\u01f4\u0218\u01db\u01fc\u0222\u0218\u01fb\u0205\u0201\u01fd\u01f5\u0209\u0215\u0202\u0229\u020d\u021e\u020f\u021c\u021e\u01e9\u0213\u022b\u0229\u022d\u020d\u020b\u022d\u022c\u0236\u0237\u020f\u0234\u01f5\u0229\u0218", (byte)117, 65);
                    nLoginBukkit.b[8] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u0562\u055d\u0541\u0565\u0559\u058c\u0571\u0582\u0570\u0556\u0550\u058a\u0586\u0566\u058a\u0567\u0555\u0555\u056d\u0579\u058d\u0577\u055d\u0575\u0599\u057d\u05a5\u0588\u0594\u0575\u056b\u0584\u058c\u0579\u057c\u05ab\u05b1\u057c\u05b1\u056d\u05a9\u0594\u0593\u05b2\u05ac\u05b5\u057a\u057b\u05ae\u05ad\u05be\u05ad\u05bd\u058a\u0587\u0588", (byte)117, 67);
                    nLoginBukkit.b[9] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.F("\u057f\u057a\u055e\u0582\u0576\u05a9\u058e\u059f\u058d\u0573\u056d\u05a2\u056e\u0569\u05a2\u05b7\u0578\u05aa\u05b9\u0590\u0599\u0597\u0584\u0585", (byte)117, 70);
                    continue block7;
                }
                case 2: {
                    nLoginBukkit.b[0] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u0198\u01ad\u01ba\u01ae\u01b2\u01be\u01b2\u01de\u01c4\u01e0\u01db\u01ea\u01de\u01bb\u01e0\u01d0\u01c1\u01dc\u01e6\u01e5\u01b1\u01e5\u01bc\u01bd", (byte)117, 65);
                    continue block7;
                }
                case 4: {
                    nLoginBukkit.b[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u057b\u05a2\u0588\u05a4\u056c\u056c\u056c\u0583\u0564\u059f\u0584\u056c\u0583\u057f\u0580\u059a\u0587\u05ba\u0593\u0575\u05bd\u0597\u0584\u0585", (byte)117, 70);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x22L;
        l ^= 0x4D751C2A0564664AL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{68, 69, (byte)(14 + 69), (byte)(29 + 18), (byte)(3 + 64), (byte)(34 + 32), (byte)(32 + 35), (byte)(27 + 20), (byte)(19 + 61), (byte)(2 + 73), (byte)(29 + 38), (byte)(13 + 70), (byte)(46 + 7), (byte)(45 + 35), (byte)(54 + 43), (byte)(50 + 50), (byte)(50 + 50), (byte)(71 + 34), (byte)(84 + 26), (byte)(45 + 58)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(2 + 66), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u011a\u0127\u0126\u00e9\u0129\u0125\u0120\u0129\u0134\u0123\u00f0\u012e\u0132\u012b\u012e\u0134\u00f6\u012a\u013e\u0135\u0136\u0135\u0141\u00fd\u013d\u011c\u0140\u0139\u013c\u0142\u0117\u014b\u0142\u0143\u0142\u014e", (byte)28, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            nLoginBukkit.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        b = (0 >>> 159 | 0 << -159) & 0xFFFFFFFF;
        d = Long.reverse(2034313695531961605L);
        e = Long.reverse(0x4400000000000000L);
        f = 16 >>> 100 | 16 << -100;
        g = Integer.reverse(-1);
        h = Long.reverse(6357769337807637765L);
        i = Integer.reverse(0x40000000);
        j = (-1 >>> 88 | -1 << -88) & 0xFFFFFFFF;
        k = Long.reverse(6357769337807637765L);
        l = Integer.reverse(-1073741824);
        m = Long.reverse(6357769337807637765L);
        n = Integer.reverse(0x20000000);
        o = Long.reverse(6357769337807637765L);
        p = Integer.reverse(-1610612736);
        q = Integer.reverse(-1);
        r = Long.reverse(6357769337807637765L);
        s = Integer.reverse(0x60000000);
        t = Long.reverse(2034313695531961605L);
        u = Long.reverse(0x4400000000000000L);
        v = Integer.reverse(-536870912);
        w = Long.reverse(2034313695531961605L);
        x = Long.reverse(0x4400000000000000L);
        y = (512 >>> 38 | 512 << ~38 + 1) & 0xFFFFFFFF;
        z = Long.reverse(2034313695531961605L);
        aa = Long.reverse(0x4400000000000000L);
        ab = Integer.reverse(-1879048192);
        ac = Long.reverse(2034313695531961605L);
        ad = Long.reverse(0x4400000000000000L);
        ae = Integer.reverse(Integer.MIN_VALUE);
        af = Integer.reverse(0);
        ag = (0 >>> 125 | 0 << ~125 + 1) & 0xFFFFFFFF;
        ah = 0x800000 >>> 55 | 0x800000 << -55;
        ai = Integer.reverse(0);
        aj = (640 >>> 38 | 640 << ~38 + 1) & 0xFFFFFFFF;
        ak = Integer.reverse(0x50000000);
        a = new String[aj];
        b = new String[ak];
        nLoginBukkit.b();
    }

    public nLoginBukkit(BukkitLoader bukkitLoader) {
        super(bukkitLoader, (String)nLoginBukkit.c("\u3e80", (int)b, (long)(d ^ e)), new \u03ba\u03b1\u03a6\u03b6\u03b8\u03b8\u03c5\u03c5\u03b5\u03c6\u03a6\u03b3((String)nLoginBukkit.c("\u3e83", (int)(f & g), (long)h), (String)nLoginBukkit.c("\u3e86", (int)(i & j), (long)k), (String)nLoginBukkit.c("\u3e89", (int)l, (long)m), (String)nLoginBukkit.c("\u3e8c", (int)n, (long)o), (String)nLoginBukkit.c("\u3e8f", (int)(p & q), (long)r), (String)nLoginBukkit.c("\u3e92", (int)s, (long)(t ^ u)), (String)nLoginBukkit.c("\u3e95", (int)v, (long)(w ^ x))));
    }

    @Override
    public boolean callEvent(Object object) {
        this.a().getPluginManager().callEvent((Event)object);
        return (!(object instanceof Cancellable) || !((Cancellable)object).isCancelled() ? ah : ai) != 0;
    }

    @Override
    protected void j() {
        if (this.s) {
            this.a = new \u03a6\u03c9\u03bf\u03c6\u03c5\u03b4\u03b9\u03c6\u03a3\u03a6(this);
        }
        \u0394\u03bf\u0393\u03ba\u03c9\u03a0\u03b1\u03bb\u03be\u03c6\u03b9\u03a9\u03b8 \u03b4\u03bf\u0393\u03ba\u03c9\u03a0\u03b1\u03bb\u03be\u03c6\u03b9\u03a9\u03b8 = this.s ? new \u03b4\u03c2\u03bc\u03b8\u03b3\u03ba\u0393\u03b3\u03a8\u03bb\u03b7\u03bd\u03c5\u03a0(this) : new \u03b2\u03b6\u03b5\u03c1\u03b7\u03a3\u03bf\u03bb\u03c3\u03b1\u03bc(this);
        this.a(new \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6(\u03b4\u03bf\u0393\u03ba\u03c9\u03a0\u03b1\u03bb\u03be\u03c6\u03b9\u03a9\u03b8, this, this.s));
        super.j();
    }

    @Generated
    public boolean i() {
        return this.s;
    }

    @Override
    protected void i() {
        try {
            MemClassLoader memClassLoader = this.a().a();
            ClassLoader classLoader = memClassLoader.getParentLoader();
            (classLoader.getParent() != null ? classLoader.getParent() : ClassLoader.getSystemClassLoader()).loadClass((String)nLoginBukkit.c("\u3e80", (int)y, (long)(z ^ aa)));
            memClassLoader.configureFilter(Collections.singleton(nLoginBukkit.c("\u3e83", (int)ab, (long)(ac ^ ad))));
        }
        catch (ClassNotFoundException classNotFoundException) {
            // empty catch block
        }
        int n = (this.s = !\u03bf\u03c1\u03a3\u03c8\u03c6\u03c1\u0394\u03b1\u03b5\u03b4\u03c8\u03c3\u03b8\u03c5.aG && (\u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.T() || \u0393\u03c7\u03c5\u03c8\u03c0\u03c9\u03a3\u03c2\u03a0\u03ba\u03b3\u03b6\u03a6.U()) ? ae : af) ? 1 : 0;
        if (this.s) {
            this.b(ag);
        }
        super.i();
    }

    @Generated
    public \u03a6\u03c9\u03bf\u03c6\u03c5\u03b4\u03b9\u03c6\u03a3\u03a6 a() {
        return this.a;
    }

    public \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 a() {
        return (\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6)super.b();
    }

    @Override
    public Class<?> getPlayerClass() {
        return Player.class;
    }

    @Override
    protected \u03c1\u03a3\u03bd\u03bc\u03c7\u03b3\u03a8\u03bf\u0394\u03a6[] a() {
        return \u03a9\u03c8\u03a8\u03c1\u03b5\u03be\u03bf\u03c3\u03a0\u03c2\u039b\u03c5.values();
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(nLoginBukkit.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u011b\u013d\u013f\u011f\u0143\u0162\u015a\u0170\u015c\u012b\u0169\u015f\u016d\u0167\u0130\u0155\u0177\u0176\u016e\u0174\u016e\u0143", (byte)58, 65), nLoginBukkit.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.B("\u0156\u0163\u0162\u0125\u0165\u0161\u015c\u0165\u0170\u015f\u012c\u016a\u016e\u0167\u016a\u0170\u0132\u0166\u017a\u0171\u0172\u0171\u017d\u0139\u0179\u0158\u017c\u0175\u0178\u017e\u0153\u0187\u017e\u017f\u017e\u018a\u0151", (byte)58, 66) + string + \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.F("\u0530", (byte)58, 70) + methodType.toString(), exception);
        }
    }
}

