/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.CheckReturnValue
 */
package com.nickuc.login;

import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.Key;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import javax.annotation.CheckReturnValue;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3 {
    private static int v;
    private static long d;
    private static long j;
    private static int a;
    private static String[] b;
    private static int av;
    private static int ak;
    private static int y;
    private static long f;
    private static int ab;
    private static int as;
    private static int af;
    private static int q;
    private static int p;
    private static int t;
    private static long k;
    private static long g;
    private static int e;
    private static int h;
    private static int ae;
    private static int s;
    private static int l;
    private static int x;
    private static int m;
    private static int o;
    private static long c;
    private static int aa;
    private static int z;
    private static int aq;
    private static int ac;
    private static int ar;
    private static int aj;
    private static int w;
    private static int aw;
    private static int am;
    private static int r;
    private static int ai;
    private static long ag;
    private static int au;
    private static int u;
    private static int i;
    private static String[] a;
    private static int b;
    private static int at;
    private static int ao;
    private static int ap;
    private static int n;
    private static int an;
    private static int al;
    private static int ah;
    private static int ad;

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static boolean a(String string, File file) {
        InputStream inputStream = \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.a(string);
        try {
            if (inputStream == null) {
                throw new IOException((String)\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.c("\u3e80", (int)af, (long)ag) + string);
            }
            if (!\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b(file)) {
                boolean bl = ah;
                return bl;
            }
            \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.a(inputStream, file);
            boolean bl = aj;
            return bl;
        }
        finally {
            if (Collections.singletonList(inputStream).get(ai) != null) {
                inputStream.close();
            }
        }
    }

    @CheckReturnValue
    public static BufferedInputStream a(File file, OpenOption ... openOptionArray) {
        return new BufferedInputStream(Files.newInputStream(file.toPath(), openOptionArray));
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u0529\u054b\u054d\u052d\u0551\u0570\u0568\u057e\u056a\u0539\u0577\u056d\u057b\u0575\u053e\u0563\u0585\u0584\u057c\u0582\u057c\u0551", (byte)69, 70), \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.B("\u016c\u0179\u0178\u013b\u017b\u0177\u0172\u017b\u0186\u0175\u0142\u0180\u0184\u017d\u0180\u0186\u0148\u04da\u04d2\u04df\u04dc\u04d7\u04c2\u04d6\u04ca\u04da\u04be\u04d8\u04e0\u04dc\u04ea\u0162", (byte)69, 66) + string + \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.A("\u0143", (byte)69, 65) + methodType.toString(), exception);
        }
    }

    @CheckReturnValue
    public static BufferedOutputStream a(File file, int n, OpenOption ... openOptionArray) {
        return new BufferedOutputStream(Files.newOutputStream(file.toPath(), openOptionArray), n);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static boolean c(File file, File file2) {
        if (\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b(file2)) {
            BufferedInputStream bufferedInputStream = \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.a(file, new OpenOption[x]);
            try {
                boolean bl;
                block9: {
                    BufferedOutputStream bufferedOutputStream = \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.a(file2, new OpenOption[y]);
                    try {
                        \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.a((InputStream)bufferedInputStream, bufferedOutputStream);
                        bl = z;
                        if (Collections.singletonList(bufferedOutputStream).get(aa) == null) break block9;
                    }
                    catch (Throwable throwable) {
                        if (Collections.singletonList(bufferedOutputStream).get(ac) != null) {
                            ((OutputStream)bufferedOutputStream).close();
                        }
                        throw throwable;
                    }
                    ((OutputStream)bufferedOutputStream).close();
                }
                return bl;
            }
            finally {
                if (Collections.singletonList(bufferedInputStream).get(ab) != null) {
                    ((InputStream)bufferedInputStream).close();
                }
            }
        }
        return ae != 0;
    }

    static {
        a = (0 >>> 251 | 0 << ~251 + 1) & 0xFFFFFFFF;
        b = (-1 >>> 50 | -1 << -50) & 0xFFFFFFFF;
        d = Long.reverse(6063051706624428529L);
        e = (0x40000000 >>> 62 | 0x40000000 << ~62 + 1) & 0xFFFFFFFF;
        f = Long.reverse(1163135312045328881L);
        g = Long.reverse(0x4400000000000000L);
        h = 262144 >>> 82 | 262144 << -82;
        i = (262144 >>> 113 | 262144 << ~113 + 1) & 0xFFFFFFFF;
        j = Long.reverse(1163135312045328881L);
        k = Long.reverse(0x4400000000000000L);
        l = (0 >>> 66 | 0 << -66) & 0xFFFFFFFF;
        m = (8192 >>> 45 | 8192 << ~45 + 1) & 0xFFFFFFFF;
        n = Integer.reverse(0);
        o = Integer.reverse(Integer.MIN_VALUE);
        p = (0 >>> 186 | 0 << -186) & 0xFFFFFFFF;
        q = (0 >>> 11 | 0 << -11) & 0xFFFFFFFF;
        r = Integer.reverse(0);
        s = Integer.reverse(0);
        t = Integer.reverse(0);
        u = Integer.reverse(0);
        v = 0 >>> 147 | 0 << ~147 + 1;
        w = 0 >>> 215 | 0 << ~215 + 1;
        x = Integer.reverse(0);
        y = (0 >>> 229 | 0 << -229) & 0xFFFFFFFF;
        z = 65536 >>> 208 | 65536 << ~208 + 1;
        aa = 0 >>> 84 | 0 << ~84 + 1;
        ab = (0 >>> 52 | 0 << ~52 + 1) & 0xFFFFFFFF;
        ac = (0 >>> 194 | 0 << -194) & 0xFFFFFFFF;
        ad = 0 >>> 14 | 0 << -14;
        ae = Integer.reverse(0);
        af = Integer.reverse(-1073741824);
        ag = Long.reverse(6063051706624428529L);
        ah = Integer.reverse(0);
        ai = (0 >>> 32 | 0 << ~32 + 1) & 0xFFFFFFFF;
        aj = Integer.reverse(Integer.MIN_VALUE);
        ak = 0 >>> 10 | 0 << ~10 + 1;
        al = Integer.reverse(0);
        am = Integer.reverse(0);
        an = (0 >>> 22 | 0 << -22) & 0xFFFFFFFF;
        ao = Integer.reverse(0);
        ap = (0 >>> 200 | 0 << -200) & 0xFFFFFFFF;
        aq = 0x40000000 >>> 62 | 0x40000000 << ~62 + 1;
        ar = 0 >>> 37 | 0 << -37;
        as = Integer.reverse(0);
        at = Integer.reverse(Integer.MIN_VALUE);
        au = Integer.reverse(0);
        av = (8192 >>> 43 | 8192 << ~43 + 1) & 0xFFFFFFFF;
        aw = (4 >>> 96 | 4 << ~96 + 1) & 0xFFFFFFFF;
        a = new String[av];
        b = new String[aw];
        \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static String d(File file) {
        BufferedInputStream bufferedInputStream = \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.a(file, new OpenOption[r]);
        try {
            byte[] byArray = \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.a(bufferedInputStream);
            String string = new String(Base64.getEncoder().encode(byArray));
            return string;
        }
        finally {
            if (Collections.singletonList(bufferedInputStream).get(s) != null) {
                ((InputStream)bufferedInputStream).close();
            }
        }
    }

    public static File a(File file, String string) {
        Object[] objectArray;
        File file2;
        int n = \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.n;
        File file3 = file.getParentFile();
        do {
            objectArray = new Object[o];
            objectArray[\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.p] = n++;
        } while ((file2 = new File(file3, String.format(string, objectArray))).exists());
        return file2;
    }

    private static String a(int n, long l) {
        l ^= 0x22L;
        l ^= 0xB12E3497FACAFD87L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(47 + 21), (byte)(13 + 56), (byte)(25 + 58), (byte)(39 + 8), (byte)(38 + 29), (byte)(64 + 2), (byte)(26 + 41), (byte)(33 + 14), (byte)(78 + 2), (byte)(20 + 55), (byte)(42 + 25), (byte)(59 + 24), 53, (byte)(48 + 32), (byte)(9 + 88), (byte)(17 + 83), (byte)(29 + 71), (byte)(17 + 88), (byte)(37 + 73), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(34 + 35), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.C("\u055c\u0569\u0568\u052b\u056b\u0567\u0562\u056b\u0576\u0565\u0532\u0570\u0574\u056d\u0570\u0576\u0538\u08ca\u08c2\u08cf\u08cc\u08c7\u08b2\u08c6\u08ba\u08ca\u08ae\u08c8\u08d0\u08cc\u08da", (byte)108, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static File a(Class<?> clazz) {
        try {
            String string = clazz.getProtectionDomain().getCodeSource().getLocation().getPath();
            String string2 = URLDecoder.decode(string, (String)\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.c("\u3e80", (int)(a & b), (long)d));
            return new File(string2);
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            throw new RuntimeException(unsupportedEncodingException);
        }
    }

    public static void a(InputStream inputStream, File file) {
        BufferedOutputStream bufferedOutputStream = \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.a(file, new OpenOption[am]);
        try {
            \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.a(inputStream, bufferedOutputStream);
        }
        finally {
            if (Collections.singletonList(bufferedOutputStream).get(an) != null) {
                bufferedOutputStream.close();
            }
        }
    }

    @CheckReturnValue
    public static BufferedInputStream a(File file, int n, OpenOption ... openOptionArray) {
        return new BufferedInputStream(Files.newInputStream(file.toPath(), openOptionArray), n);
    }

    public static boolean a(File file) {
        File[] fileArray;
        if (file.isDirectory() && (fileArray = file.listFiles()) != null) {
            File[] fileArray2 = fileArray;
            int n = fileArray2.length;
            for (int i = q; i < n; ++i) {
                File file2 = fileArray2[i];
                \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.a(file2);
            }
        }
        return file.delete();
    }

    @CheckReturnValue
    public static BufferedOutputStream a(File file, OpenOption ... openOptionArray) {
        return new BufferedOutputStream(Files.newOutputStream(file.toPath(), openOptionArray));
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static String a(File file, MessageDigest messageDigest) {
        BufferedInputStream bufferedInputStream = \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.a(file, new OpenOption[u]);
        try {
            String string = \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.a((InputStream)bufferedInputStream, messageDigest);
            return string;
        }
        finally {
            if (Collections.singletonList(bufferedInputStream).get(v) != null) {
                bufferedInputStream.close();
            }
        }
    }

    public static boolean a(File file, long l) {
        BasicFileAttributes basicFileAttributes = Files.readAttributes(file.toPath(), BasicFileAttributes.class, new LinkOption[as]);
        long l2 = basicFileAttributes.creationTime().toMillis();
        return (System.currentTimeMillis() - l2 >= l ? at : au) != 0;
    }

    public static boolean a(File file, boolean bl) {
        if (!bl && file.exists()) {
            return aq != 0;
        }
        File file2 = file.getParentFile();
        if (file2 != null && !file2.exists() && !file2.mkdirs()) {
            return ar != 0;
        }
        return file.createNewFile();
    }

    public static String c(File file) {
        String string = file.getName();
        String[] stringArray = string.split((String)\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.c("\u3e80", (int)e, (long)(f ^ g)));
        if (stringArray.length == h) {
            return string;
        }
        return String.join((CharSequence)\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.c("\u3e83", (int)i, (long)(j ^ k)), Arrays.copyOfRange(stringArray, l, stringArray.length - m));
    }

    private static void b() {
        int n;
        c = -8101073877128305656L;
        long l = c ^ 0xB12E3497FACAFD87L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(8 + 60), (byte)(61 + 8), (byte)(67 + 16), (byte)(16 + 31), (byte)(40 + 27), (byte)(48 + 18), (byte)(49 + 18), (byte)(37 + 10), (byte)(66 + 14), (byte)(19 + 56), (byte)(66 + 1), (byte)(64 + 19), (byte)(4 + 49), (byte)(77 + 3), (byte)(77 + 20), (byte)(97 + 3), 100, (byte)(92 + 13), (byte)(76 + 34), (byte)(43 + 60)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(2 + 66), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u0585\u05a6\u056a\u05a1\u058c\u05a3\u05a8\u05a5\u056f\u0587\u058f\u057c", (byte)120, 70);
                    \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b[1] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u01c8\u01de\u01df\u01bd\u019e\u01d6\u01c8\u01a7\u01c5\u01c7\u01ad\u01b7", (byte)120, 66);
                    \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b[2] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u01bd\u01df\u01e6\u01c3\u01cd\u01ad\u01d7\u01ac\u01ab\u01e1\u01ec\u01b7", (byte)120, 66);
                    \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b[3] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.A("\u01b2\u01b3\u01e0\u01d3\u01b5\u01d8\u01db\u01ab\u01c2\u01be\u01bc\u01be\u01d0\u01cc\u01ee\u01e8\u01e4\u01c5\u01d9\u01ce\u01b8\u01cd\u01bc\u01f1\u01fd\u0202\u01e2\u01f3\u01b6\u01fe\u01ce\u01d9\u01c3\u01fd\u020a\u01fd\u01da\u01fa\u01fb\u0202\u01cb\u0210\u01fb\u0200\u01f2\u01f2\u01fe\u01f3\u01d4\u0201\u01fa\u01e9\u01ec\u01e7\u0208\u01fc\u021a\u01fb\u01f8\u01fe\u01f9\u01fa\u0217\u0216", (byte)120, 65);
                    continue block7;
                }
                case 1: {
                    \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u056a\u0574\u0586\u057a\u0550\u0566\u056d\u056c\u057c\u0590\u0558\u059d\u0592\u0595\u059f\u0574\u0565\u059d\u0591\u0560\u0580\u0599\u0570\u0571", (byte)120, 67);
                    \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b[1] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u056f\u0563\u0591\u0572\u058b\u0552\u058a\u0587\u0599\u0557\u057c\u0565", (byte)120, 67);
                    \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b[2] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.A("\u01d7\u01d6\u01eb\u01d6\u01a4\u01c1\u01c2\u01eb\u01ae\u01cc\u01dc\u01b7", (byte)120, 65);
                    \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b[3] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.B("\u01b2\u01b3\u01e0\u01d3\u01b5\u01d8\u01db\u01ab\u01c2\u01be\u01bc\u01be\u01d0\u01cc\u01ee\u01e8\u01e4\u01c5\u01d9\u01ce\u01b8\u01cd\u01bc\u01f1\u01fd\u0202\u01e2\u01f3\u01b6\u01fe\u01ce\u01d9\u01c3\u01fd\u020a\u01fd\u01da\u01fa\u01fb\u0202\u01cb\u0210\u01fb\u0200\u01f2\u01f2\u01fe\u01f3\u01d4\u0201\u01fa\u01e9\u01ec\u01f1\u020a\u0211\u021e\u01f5\u01ff\u021f\u0224\u01f0\u01dc\u01e5\u01de\u0218\u01ff\u0214\u020c\u0227\u0204\u01e7\u020b\u0227\u020e\u01f7", (byte)120, 66);
                    continue block7;
                }
                case 2: {
                    \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b[0] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.A("\u01a6\u01c1\u01d5\u01ba\u01e2\u01eb\u01c6\u01df\u01ac\u01c4\u01cf\u01a9\u01c6\u01d2\u01b2\u01e7\u01e8\u01c9\u01f1\u01cc\u01fc\u01c5\u01c2\u01c3", (byte)120, 65);
                    continue block7;
                }
                case 4: {
                    \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.F("\u058c\u059e\u057f\u058f\u0585\u057f\u0590\u05ab\u05ac\u058c\u0574\u05b3\u0595\u05af\u05a4\u05b0\u057c\u0593\u05bb\u05b1\u05b9\u058a\u0587\u0588", (byte)120, 70);
                }
            }
        }
    }

    public static boolean b(File file) {
        return \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.a(file, ap != 0);
    }
}

