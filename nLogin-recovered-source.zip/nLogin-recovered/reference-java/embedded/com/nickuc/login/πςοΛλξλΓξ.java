/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7;

class \u03c0\u03c2\u03bf\u039b\u03bb\u03be\u03bb\u0393\u03be {
    private static int a = (0x200000 >>> 213 | 0x200000 << -213) & 0xFFFFFFFF;
    private static int b = (0x2000000 >>> 184 | 0x2000000 << ~184 + 1) & 0xFFFFFFFF;
    static final /* synthetic */ int[] F;

    static {
        F = new int[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.values().length];
        try {
            \u03c0\u03c2\u03bf\u039b\u03bb\u03be\u03bb\u0393\u03be.F[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.b.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03c0\u03c2\u03bf\u039b\u03bb\u03be\u03bb\u0393\u03be.F[\u03b3\u03bf\u03b7\u03bb\u03b9\u03bc\u03b5\u03c0\u03b7.c.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

