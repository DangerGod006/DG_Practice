/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u03a8\u03c0\u03be\u03a3\u03b5\u03c5\u03a3\u03a0\u03b3\u03c2\u03c4;
import com.nickuc.login.\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0;
import java.util.concurrent.TimeUnit;
import lombok.Generated;

public class \u03b8\u03c1\u03b4\u03a3\u03b2\u0394\u03c9\u03a3\u039b {
    private static double e;
    private static double f;
    private static double a;
    private static int g;
    private static double c;
    private final long x;
    private static double b;
    private static double d;

    static {
        a = Double.longBitsToDouble(Long.reverse(192770L));
        b = Double.longBitsToDouble(Long.reverse(18969730L));
        c = Double.longBitsToDouble(Long.reverse(2796794754L));
        d = Double.longBitsToDouble(Long.reverse(57731437634L));
        e = Double.longBitsToDouble(Long.reverse(702789996866L));
        f = Double.longBitsToDouble(Long.reverse(4166733122370L));
        g = Integer.reverse(0x40000000);
    }

    public \u03b8\u03c1\u03b4\u03a3\u03b2\u0394\u03c9\u03a3\u039b(long l) {
        this.x = l;
    }

    public String aq() {
        return this.a(TimeUnit.SECONDS, g);
    }

    public double a(TimeUnit timeUnit, long l) {
        long l2 = l - this.x;
        switch (\u03a8\u03c0\u03be\u03a3\u03b5\u03c5\u03a3\u03a0\u03b3\u03c2\u03c4.s[timeUnit.ordinal()]) {
            case 1: {
                return l2;
            }
            case 2: {
                return (double)l2 / a;
            }
            case 3: {
                return (double)l2 / b;
            }
            case 4: {
                return (double)l2 / c;
            }
            case 5: {
                return (double)l2 / d;
            }
            case 6: {
                return (double)l2 / e;
            }
            case 7: {
                return (double)l2 / f;
            }
        }
        return l2;
    }

    @Generated
    public long i() {
        return this.x;
    }

    public double a(TimeUnit timeUnit) {
        return this.a(timeUnit, System.nanoTime());
    }

    public static \u03b8\u03c1\u03b4\u03a3\u03b2\u0394\u03c9\u03a3\u039b a(long l) {
        return new \u03b8\u03c1\u03b4\u03a3\u03b2\u0394\u03c9\u03a3\u039b(l);
    }

    public String a(TimeUnit timeUnit, int n) {
        return \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(this.a(timeUnit), n);
    }

    public String a(TimeUnit timeUnit, long l, int n) {
        return \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(this.a(timeUnit, l), n);
    }

    public \u03b8\u03c1\u03b4\u03a3\u03b2\u0394\u03c9\u03a3\u039b() {
        this(System.nanoTime());
    }

    public long h() {
        return (long)this.a(TimeUnit.MILLISECONDS);
    }
}

