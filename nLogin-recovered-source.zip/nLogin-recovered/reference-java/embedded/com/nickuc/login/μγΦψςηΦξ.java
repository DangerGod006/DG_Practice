/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.velocitypowered.api.command.CommandSource
 *  com.velocitypowered.api.event.PostOrder
 *  com.velocitypowered.api.event.Subscribe
 *  com.velocitypowered.api.event.command.CommandExecuteEvent
 *  com.velocitypowered.api.event.command.CommandExecuteEvent$CommandResult
 *  com.velocitypowered.api.event.player.PlayerChatEvent
 *  com.velocitypowered.api.event.player.PlayerChatEvent$ChatResult
 *  com.velocitypowered.api.event.player.PlayerSettingsChangedEvent
 *  com.velocitypowered.api.event.player.TabCompleteEvent
 *  com.velocitypowered.api.proxy.Player
 *  com.velocitypowered.api.proxy.player.PlayerSettings
 *  lombok.Generated
 *  net.kyori.adventure.text.Component
 */
package com.nickuc.login;

import com.nickuc.login.proxy.velocity.nLoginVelocity;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a3;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u03a9\u03a9\u03b1\u03bf\u03bc\u03bf\u03a3\u03c8\u03a9;
import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.event.PostOrder;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.command.CommandExecuteEvent;
import com.velocitypowered.api.event.player.PlayerChatEvent;
import com.velocitypowered.api.event.player.PlayerSettingsChangedEvent;
import com.velocitypowered.api.event.player.TabCompleteEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.player.PlayerSettings;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import net.kyori.adventure.text.Component;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be
implements \u03c9\u03a9\u03a9\u03b1\u03bf\u03bc\u03bf\u03a3\u03c8\u03a9 {
    private static int bn;
    private static long ac;
    private static int ag;
    private static int aa;
    private static long t;
    private static String[] b;
    private static int bv;
    private static int am;
    private static int x;
    private static String[] a;
    private static int ap;
    private static long k;
    private static long w;
    private static int av;
    private static int bd;
    private static int e;
    private static int m;
    private static long aw;
    private static int ch;
    private static long bz;
    private static long ad;
    private static int bk;
    private static long y;
    private static int bt;
    private static long ay;
    private static int ca;
    private static int cb;
    private static long az;
    private static long bq;
    private static int ab;
    private static long g;
    private static long b;
    private static long be;
    private static long as;
    private static long n;
    private final \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 E;
    private static int u;
    private static long ah;
    private static long aj;
    private static int bg;
    private static long br;
    private static int ae;
    private static int r;
    private static long bi;
    private static int af;
    private static long bf;
    private static int cc;
    private static long ak;
    private static int a;
    private static long bl;
    private static int l;
    private static int ba;
    private static int bu;
    private static long cd;
    private static int ax;
    private static int bw;
    private static int bp;
    private static long at;
    private static long d;
    private static long ao;
    private static int p;
    private static int v;
    private static int by;
    private static int cg;
    private static int cf;
    private static long bb;
    private static int o;
    private static int ar;
    private static int j;
    private static int bo;
    private static int f;
    private static long bc;
    private static long c;
    private static int bs;
    private static long h;
    private static long q;
    private static int ai;
    private static int an;
    private static int bx;
    private final nLoginVelocity c;
    private static int al;
    private static long z;
    private static long bj;
    private static int bh;
    private static int ce;
    private static int au;
    private static long bm;
    private static long aq;
    private static int i;
    private static int s;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u04f5\u0517\u0519\u04f9\u051d\u053c\u0534\u054a\u0536\u0505\u0543\u0539\u0547\u0541\u050a\u052f\u0551\u0550\u0548\u054e\u0548\u051d", (byte)17, 70), \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u0104\u0111\u0110\u00d3\u0113\u010f\u010a\u0113\u011e\u010d\u00da\u0118\u011c\u0115\u0118\u011e\u00e0\u046e\u0466\u045a\u047d\u0478\u046e\u045e\u0477\u00f4", (byte)17, 65) + string + \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.F("\u0507", (byte)17, 70) + methodType.toString(), exception);
        }
    }

    @Subscribe(order=PostOrder.LAST)
    public void b(CommandExecuteEvent commandExecuteEvent) {
        if (!commandExecuteEvent.getResult().isAllowed() && this.a(commandExecuteEvent.getCommand())) {
            commandExecuteEvent.setResult(CommandExecuteEvent.CommandResult.allowed());
        }
    }

    @Subscribe
    public void a(TabCompleteEvent tabCompleteEvent) {
        List list = tabCompleteEvent.getSuggestions();
        if (list.isEmpty()) {
            return;
        }
        String string = tabCompleteEvent.getPartialMessage().trim();
        if (!string.isEmpty() && string.charAt(ae) != af) {
            return;
        }
        Player player = tabCompleteEvent.getPlayer();
        try {
            \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = this.c.b().a(player);
            if (\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.S()) {
                return;
            }
            int n = \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.i((String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e80", (int)ag, (long)ah)) || \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.i((String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e83", (int)ai, (long)(aj ^ ak))) ? al : am;
            list.removeIf(arg_0 -> this.a(n != 0, \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, arg_0));
        }
        catch (Throwable throwable) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e86", (int)an, (long)ao) + tabCompleteEvent.getClass().getSimpleName() + (String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e89", (int)ap, (long)aq) + player.getUsername() + (String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e8c", (int)ar, (long)(as ^ at)), throwable, new Object[au]);
            player.disconnect((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a((String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e8f", (int)av, (long)aw)));
        }
    }

    private boolean a(String string) {
        String[] stringArray;
        if (!string.trim().isEmpty() && (stringArray = string.split((String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e80", (int)bk, (long)(bl ^ bm)))).length > bn) {
            String string2 = stringArray[bo].toLowerCase(Locale.ENGLISH);
            return string2.equals(\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e83", (int)bp, (long)(bq ^ br)));
        }
        return bs != 0;
    }

    @Subscribe
    public void a(PlayerSettingsChangedEvent playerSettingsChangedEvent) {
        Player player = playerSettingsChangedEvent.getPlayer();
        try {
            \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = this.c.b().a(player);
            if (\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.S()) {
                return;
            }
            PlayerSettings playerSettings = playerSettingsChangedEvent.getPlayerSettings();
            \u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a3 \u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a32 = \u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a3.c(playerSettings.getLocale().toLanguageTag());
            if (\u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a32 != null) {
                \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = this.E.a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
                \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.i, (Object)\u03b5\u03b8\u03c3\u03be\u03be\u03c4\u039b\u03b1\u03ba\u03c0\u03a32);
            }
        }
        catch (Throwable throwable) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e80", (int)ax, (long)(ay ^ az)) + playerSettingsChangedEvent.getClass().getSimpleName() + (String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e83", (int)ba, (long)(bb ^ bc)) + player.getUsername() + (String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e86", (int)bd, (long)(be ^ bf)), throwable, new Object[bg]);
            player.disconnect((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a((String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e89", (int)bh, (long)(bi ^ bj))));
        }
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(5941419528884695104L);
        d = Long.reverse(0x1C00000000000000L);
        e = Integer.reverse(-281018368);
        f = 0x20000000 >>> 29 | 0x20000000 << ~29 + 1;
        g = Long.reverse(5941419528884695104L);
        h = Long.reverse(0x1C00000000000000L);
        i = Integer.reverse(0x40000000);
        j = -1 >>> 40 | -1 << -40;
        k = Long.reverse(5653189152732983360L);
        l = Integer.reverse(-1073741824);
        m = (-1 >>> 51 | -1 << -51) & 0xFFFFFFFF;
        n = Long.reverse(5653189152732983360L);
        o = Integer.reverse(0);
        p = Integer.reverse(0x20000000);
        q = Long.reverse(5653189152732983360L);
        r = Integer.reverse(-281018368);
        s = Integer.reverse(-1610612736);
        t = Long.reverse(5653189152732983360L);
        u = 96 >>> 164 | 96 << ~164 + 1;
        v = Integer.reverse(-1);
        w = Long.reverse(5653189152732983360L);
        x = Integer.reverse(-536870912);
        y = Long.reverse(5941419528884695104L);
        z = Long.reverse(0x1C00000000000000L);
        aa = Integer.reverse(0);
        ab = (512 >>> 38 | 512 << ~38 + 1) & 0xFFFFFFFF;
        ac = Long.reverse(5941419528884695104L);
        ad = Long.reverse(0x1C00000000000000L);
        ae = 0 >>> 20 | 0 << -20;
        af = 24641536 >>> 19 | 24641536 << ~19 + 1;
        ag = 0x900000 >>> 52 | 0x900000 << -52;
        ah = Long.reverse(5653189152732983360L);
        ai = Integer.reverse(0x50000000);
        aj = Long.reverse(5941419528884695104L);
        ak = Long.reverse(0x1C00000000000000L);
        al = 64 >>> 70 | 64 << ~70 + 1;
        am = Integer.reverse(0);
        an = Integer.reverse(-805306368);
        ao = Long.reverse(5653189152732983360L);
        ap = Integer.reverse(0x30000000);
        aq = Long.reverse(5653189152732983360L);
        ar = (106496 >>> 13 | 106496 << ~13 + 1) & 0xFFFFFFFF;
        as = Long.reverse(5941419528884695104L);
        at = Long.reverse(0x1C00000000000000L);
        au = Integer.reverse(0);
        av = Integer.reverse(0x70000000);
        aw = Long.reverse(5653189152732983360L);
        ax = (122880 >>> 205 | 122880 << -205) & 0xFFFFFFFF;
        ay = Long.reverse(5941419528884695104L);
        az = Long.reverse(0x1C00000000000000L);
        ba = Integer.reverse(0x8000000);
        bb = Long.reverse(5941419528884695104L);
        bc = Long.reverse(0x1C00000000000000L);
        bd = Integer.reverse(-2013265920);
        be = Long.reverse(5941419528884695104L);
        bf = Long.reverse(0x1C00000000000000L);
        bg = Integer.reverse(0);
        bh = Integer.reverse(0x48000000);
        bi = Long.reverse(5941419528884695104L);
        bj = Long.reverse(0x1C00000000000000L);
        bk = (0x130000 >>> 48 | 0x130000 << -48) & 0xFFFFFFFF;
        bl = Long.reverse(5941419528884695104L);
        bm = Long.reverse(0x1C00000000000000L);
        bn = Integer.reverse(Integer.MIN_VALUE);
        bo = Integer.reverse(0);
        bp = Integer.reverse(0x28000000);
        bq = Long.reverse(5941419528884695104L);
        br = Long.reverse(0x1C00000000000000L);
        bs = Integer.reverse(0);
        bt = Integer.reverse(0);
        bu = Integer.reverse(0);
        bv = Integer.reverse(-201326592);
        bw = 0 >>> 89 | 0 << ~89 + 1;
        bx = (0xA800000 >>> 151 | 0xA800000 << -151) & 0xFFFFFFFF;
        by = Integer.reverse(-1);
        bz = Long.reverse(5653189152732983360L);
        ca = (0 >>> 39 | 0 << ~39 + 1) & 0xFFFFFFFF;
        cb = Integer.reverse(0x68000000);
        cc = Integer.reverse(-1);
        cd = Long.reverse(5653189152732983360L);
        ce = (128 >>> 71 | 128 << -71) & 0xFFFFFFFF;
        cf = Integer.reverse(0);
        cg = Integer.reverse(-402653184);
        ch = (736 >>> 197 | 736 << -197) & 0xFFFFFFFF;
        a = new String[cg];
        b = new String[ch];
        \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b();
    }

    @Subscribe(order=PostOrder.FIRST)
    public void a(PlayerChatEvent playerChatEvent) {
        String string = playerChatEvent.getMessage().trim();
        if (string.isEmpty()) {
            return;
        }
        Player player = playerChatEvent.getPlayer();
        try {
            \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = this.c.b().a(player);
            if (\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.S()) {
                return;
            }
            if (this.E.b().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, string)) {
                \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = this.E.a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
                if (player.getProtocolVersion().getProtocol() >= r && (\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.I) || \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.d(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.c) != false)) {
                    return;
                }
                playerChatEvent.setResult(PlayerChatEvent.ChatResult.denied());
            }
        }
        catch (Throwable throwable) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e80", (int)s, (long)t) + playerChatEvent.getClass().getSimpleName() + (String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e83", (int)(u & v), (long)w) + player.getUsername() + (String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e86", (int)x, (long)(y ^ z)), throwable, new Object[aa]);
            player.disconnect((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a((String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e89", (int)ab, (long)(ac ^ ad))));
        }
    }

    private /* synthetic */ boolean a(boolean bl, \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, String string) {
        if (string.trim().isEmpty()) {
            return bt != 0;
        }
        if (string.charAt(bu) != bv) {
            return bw != 0;
        }
        String[] stringArray = string.split((String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e80", (int)(bx & by), (long)bz));
        String string2 = stringArray[ca].toLowerCase(Locale.ENGLISH);
        if (!bl && ((String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e83", (int)(cb & cc), (long)cd)).equals(string2)) {
            return ce != 0;
        }
        if (this.E.a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)) {
            return cf != 0;
        }
        return this.E.a().b(string);
    }

    private static String a(int n, long l) {
        l ^= 0x38L;
        l ^= 0xA1986BD552092B2EL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(3 + 65), (byte)(12 + 57), (byte)(25 + 58), 47, (byte)(9 + 58), (byte)(6 + 60), 67, (byte)(15 + 32), (byte)(64 + 16), (byte)(29 + 46), (byte)(30 + 37), (byte)(82 + 1), (byte)(34 + 19), (byte)(36 + 44), (byte)(8 + 89), (byte)(9 + 91), (byte)(12 + 88), (byte)(13 + 92), (byte)(27 + 83), (byte)(9 + 94)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(40 + 43)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u00fe\u010b\u010a\u00cd\u010d\u0109\u0104\u010d\u0118\u0107\u00d4\u0112\u0116\u010f\u0112\u0118\u00da\u0468\u0460\u0454\u0477\u0472\u0468\u0458\u0471", (byte)14, 66));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static void b() {
        int n;
        c = 147982190495673930L;
        long l = c ^ 0xA1986BD552092B2EL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(3 + 65), (byte)(60 + 9), (byte)(5 + 78), (byte)(25 + 22), (byte)(15 + 52), (byte)(10 + 56), (byte)(64 + 3), (byte)(38 + 9), 80, (byte)(55 + 20), 67, (byte)(23 + 60), (byte)(42 + 11), (byte)(65 + 15), (byte)(72 + 25), (byte)(92 + 8), (byte)(8 + 92), (byte)(19 + 86), (byte)(4 + 106), (byte)(66 + 37)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(38 + 31), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.D("\u0557\u054c\u0571\u0596\u056c\u056d\u0577\u059f\u055f\u056b\u0573\u0568", (byte)121, 68);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[1] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.B("\u01d5\u01d8\u01d5\u01cb\u01bb\u01dd\u01ae\u01e2\u01af\u01d1\u01e1\u01cc\u01f2\u01e1\u01f2\u01c7\u01d5\u01c7\u01d4\u01fe\u01f5\u01fe\u01df\u01ef\u0201\u01d2\u01ef\u01d2\u01c0\u0203\u01e3\u01ea", (byte)121, 66);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[2] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.B("\u01c1\u01c0\u01cb\u01e3\u01ae\u01c0\u01dc\u01ae\u01c1\u01a9\u01aa\u01eb\u01bf\u01cf\u01ce\u01f1\u01c5\u01cd\u01c8\u01ea\u01f1\u01d7\u01c4\u01c5", (byte)121, 66);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[3] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.B("\u01a4\u01cb\u01b5\u01e9\u01c5\u01ab\u01ac\u01cd\u01ba\u01ad\u01bc\u01b9", (byte)121, 66);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[4] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.D("\u0568\u0590\u0568\u0570\u0594\u056d\u058a\u0577\u0558\u0561\u059b\u059b\u0583\u0577\u0562\u0567\u05a9\u05a9\u05a0\u0582\u057d\u05ac\u057a\u059a\u05ac\u0587\u058f\u0582\u0591\u0585\u05ad\u05ad\u0587\u05b8\u058a\u0590\u058f\u05b1\u0576\u05b5\u0573\u0597\u059d\u05bf\u05c1\u059a\u05b5\u05b1\u05b7\u0588\u05a8\u058a\u0597\u059c\u058d\u05bc\u05bb\u05c0\u05d2\u05d3\u05b4\u05d5\u05a6\u05c4\u0591\u05d9\u059b\u05b0\u05ca\u05d6\u05dd\u05b4\u059e\u05d0\u05e3\u05ce\u05c5\u05b7\u05da\u05b5\u05dc\u05b2\u05ec\u05c7\u05b5\u05ee\u05e5\u05cd\u05cf\u05cb\u05c4\u05ec\u05df\u05b4\u05df\u05ae", (byte)121, 68);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[5] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u01d5\u01d8\u01d5\u01cb\u01bb\u01dd\u01ae\u01e2\u01af\u01d1\u01e1\u01cc\u01f2\u01e1\u01f2\u01c7\u01d5\u01c7\u01d4\u01fe\u01f5\u01fe\u01df\u01ef\u0201\u01d2\u01ef\u01d2\u01c0\u0203\u01e3\u01ea", (byte)121, 66);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[6] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u0585\u0584\u058f\u05a7\u0572\u0584\u05a0\u0572\u0585\u056d\u056e\u05af\u0583\u0593\u0592\u05b5\u0589\u0591\u058c\u05ae\u05b5\u059b\u0588\u0589", (byte)121, 70);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[7] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.D("\u0553\u057a\u0564\u0598\u0574\u055a\u055b\u057c\u0569\u055c\u056b\u0568", (byte)121, 68);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[8] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.D("\u0568\u0590\u0568\u0570\u0594\u056d\u058a\u0577\u0558\u0561\u059b\u059b\u0583\u0577\u0562\u0567\u05a9\u05a9\u05a0\u0582\u057d\u05ac\u057a\u059a\u05ac\u0587\u058f\u0582\u0591\u0585\u05ad\u05ad\u0587\u05b8\u058a\u0590\u058f\u05b1\u0576\u05b5\u0573\u0597\u059d\u05bf\u05c1\u059a\u05b5\u05b1\u05b7\u0588\u05a8\u058a\u0597\u059c\u058d\u05bc\u05bb\u05c0\u05d2\u05d3\u05b4\u05d5\u05a6\u05c4\u0591\u05d9\u059b\u05b0\u05ca\u05d6\u05dd\u05b4\u059e\u05d0\u05e3\u05ce\u05c5\u05b7\u05da\u05b5\u05dc\u05b2\u05ec\u05c7\u05b5\u05ee\u05e5\u05cd\u05cf\u05cb\u05c4\u05ec\u05df\u05b4\u05df\u05ae", (byte)121, 68);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[9] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.B("\u01d5\u01a3\u01b7\u01ed\u01bd\u01b7\u01d9\u01e3\u01eb\u01de\u01f4\u01c5\u01b1\u01d6\u01f0\u01b0\u01c6\u01b7\u01cf\u01fe\u01ea\u01b5\u01f3\u0200\u01bf\u01f3\u01d9\u01e4\u01db\u01d5\u01d3\u01c2", (byte)121, 66);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[10] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.A("\u01e3\u01d4\u01c0\u01c2\u01ef\u01a8\u01d9\u01eb\u01ab\u01c8\u01c9\u01c3\u01cc\u01f7\u01b1\u01b1\u01cc\u01e5\u01eb\u01d0\u01bb\u01c7\u01c4\u01c5", (byte)121, 65);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[11] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u01d5\u01d8\u01d5\u01cb\u01bb\u01dd\u01ae\u01e2\u01af\u01d1\u01e1\u01cc\u01f2\u01e1\u01f2\u01c7\u01d5\u01c7\u01d4\u01fe\u01f5\u01fe\u01df\u01ef\u0201\u01d2\u01ef\u01d2\u01c0\u0203\u01e3\u01ea", (byte)121, 65);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[12] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.B("\u01c1\u01c0\u01cb\u01e3\u01ae\u01c0\u01dc\u01ae\u01c1\u01a9\u01aa\u01eb\u01bf\u01cf\u01ce\u01f1\u01c5\u01cd\u01c8\u01ea\u01f1\u01d7\u01c4\u01c5", (byte)121, 66);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[13] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u01a4\u01cb\u01b5\u01e9\u01c5\u01ab\u01ac\u01cd\u01ba\u01ad\u01bc\u01b9", (byte)121, 65);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[14] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u0568\u0590\u0568\u0570\u0594\u056d\u058a\u0577\u0558\u0561\u059b\u059b\u0583\u0577\u0562\u0567\u05a9\u05a9\u05a0\u0582\u057d\u05ac\u057a\u059a\u05ac\u0587\u058f\u0582\u0591\u0585\u05ad\u05ad\u0587\u05b8\u058a\u0590\u058f\u05b1\u0576\u05b5\u0573\u0597\u059d\u05bf\u05c1\u059a\u05b5\u05b1\u05b7\u0588\u05a8\u058a\u0597\u059c\u058d\u05bc\u05bb\u05c0\u05d2\u05d3\u05b4\u05d5\u05a6\u05c4\u0591\u05d9\u059b\u05b0\u05ca\u05d6\u05dd\u05b4\u059e\u05d0\u05e3\u05ce\u05c5\u05b7\u05da\u05b5\u05dc\u05b2\u05ec\u05c7\u05b5\u05ee\u05e5\u05cd\u05cf\u05cb\u05c4\u05ec\u05df\u05b4\u05df\u05ae", (byte)121, 67);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[15] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u0584\u0587\u0584\u057a\u056a\u058c\u055d\u0591\u055e\u0580\u0590\u057b\u05a1\u0590\u05a1\u0576\u0584\u0576\u0583\u05ad\u05a4\u05ad\u058e\u059e\u05b0\u0581\u059e\u0581\u056f\u05b2\u0592\u0599", (byte)121, 68);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[16] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u0570\u056f\u057a\u0592\u055d\u056f\u058b\u055d\u0570\u0558\u0559\u059a\u056e\u057e\u057d\u05a0\u0574\u057c\u0577\u0599\u05a0\u0586\u0573\u0574", (byte)121, 68);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[17] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.A("\u01a4\u01cb\u01b5\u01e9\u01c5\u01ab\u01ac\u01cd\u01ba\u01ad\u01bc\u01b9", (byte)121, 65);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[18] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u057d\u05a5\u057d\u0585\u05a9\u0582\u059f\u058c\u056d\u0576\u05b0\u05b0\u0598\u058c\u0577\u057c\u05be\u05be\u05b5\u0597\u0592\u05c1\u058f\u05af\u05c1\u059c\u05a4\u0597\u05a6\u059a\u05c2\u05c2\u059c\u05cd\u059f\u05a5\u05a4\u05c6\u058b\u05ca\u0588\u05ac\u05b2\u05d4\u05d6\u05af\u05ca\u05c6\u05cc\u059d\u05bd\u059f\u05ac\u05b1\u05a2\u05d1\u05d0\u05d5\u05e7\u05e8\u05c9\u05ea\u05bb\u05d9\u05a6\u05ee\u05b0\u05c5\u05df\u05eb\u05f2\u05c9\u05b3\u05e5\u05f8\u05e3\u05da\u05cc\u05ef\u05ca\u05f1\u05c7\u0601\u05dc\u05ca\u0603\u05fa\u05e2\u05e4\u05e0\u05d9\u0601\u05f4\u05c9\u05f4\u05c3", (byte)121, 69);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[19] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u0586\u0587\u057c\u058f\u058c\u05aa\u057f\u058c\u05b0\u058b\u0590\u057d", (byte)121, 70);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[20] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.D("\u056b\u0586\u0553\u0569\u057b\u0558\u058b\u0574\u0590\u057f\u0577\u0568", (byte)121, 68);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[21] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u0571\u0572\u0567\u057a\u0577\u0595\u056a\u0577\u059b\u0576\u057b\u0568", (byte)121, 67);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[22] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u01b7\u01dc\u01ca\u01e2\u01e8\u01c5\u01c4\u01c4\u01bf\u01c3\u01ab\u01b9", (byte)121, 66);
                    continue block7;
                }
                case 1: {
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u058e\u058e\u0576\u0593\u0577\u056a\u0557\u0593\u057f\u056b\u056f\u0568", (byte)121, 68);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[1] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u01d5\u01d8\u01d5\u01cb\u01bb\u01dd\u01ae\u01e2\u01af\u01d1\u01e1\u01cc\u01f2\u01e1\u01f2\u01c7\u01d5\u01c7\u01d4\u01fe\u01f5\u01bf\u01ef\u01cc\u01bf\u01d0\u01de\u01d2\u01f8\u01bf\u01d1\u01e3", (byte)121, 65);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[2] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u0585\u0584\u058f\u05a7\u0572\u0584\u05a0\u0572\u0585\u056d\u0578\u05b9\u0578\u056d\u0587\u058f\u05bb\u0576\u0596\u057f\u05a1\u058b\u0588\u0589", (byte)121, 69);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[3] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0562\u0572\u056b\u0569\u0585\u057e\u0579\u0591\u0561\u058c\u057f\u0568", (byte)121, 67);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[4] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u0568\u0590\u0568\u0570\u0594\u056d\u058a\u0577\u0558\u0561\u059b\u059b\u0583\u0577\u0562\u0567\u05a9\u05a9\u05a0\u0582\u057d\u05ac\u057a\u059a\u05ac\u0587\u058f\u0582\u0591\u0585\u05ad\u05ad\u0587\u05b8\u058a\u0590\u058f\u05b1\u0576\u05b5\u0573\u0597\u059d\u05bf\u05c1\u059a\u05b5\u05b1\u05b7\u0588\u05a8\u058a\u0597\u059c\u058d\u05bc\u05bb\u05c0\u05d2\u05d3\u05b4\u05d5\u05a6\u05c4\u0591\u05d9\u059b\u05b0\u05ca\u05d6\u05dd\u05b4\u059e\u05d0\u05e3\u05ce\u05c5\u05b7\u05da\u05b5\u05dc\u05b2\u05ec\u05c7\u05b5\u05a0\u05d8\u05a9\u05c4\u05c7\u05f3\u05e4\u05e3\u05c0\u05f7\u05aa\u05e1\u05c9\u05b9\u05e9\u05e8\u05fa\u05ba\u05fe\u05d0\u05bd\u05f5\u05c8", (byte)121, 68);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[5] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u01d5\u01d8\u01d5\u01cb\u01bb\u01dd\u01ae\u01e2\u01af\u01d1\u01e1\u01cc\u01f2\u01e1\u01f2\u01c7\u01d5\u01c7\u01d4\u01fe\u01f5\u01fe\u01be\u01b8\u01fb\u01d6\u01f0\u01c2\u01be\u01d7\u01e8\u01f3", (byte)121, 66);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[6] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u01c1\u01c0\u01cb\u01e3\u01ae\u01c0\u01dc\u01ae\u01c1\u01a9\u01aa\u01ed\u01d7\u01ec\u01d1\u01da\u01d2\u01fb\u01fb\u01d9\u01e6\u01c7\u01c4\u01c5", (byte)121, 66);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[7] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.C("\u0556\u0567\u058e\u0567\u057d\u0554\u0573\u0597\u0561\u0595\u0595\u0568", (byte)121, 67);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[8] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u057d\u05a5\u057d\u0585\u05a9\u0582\u059f\u058c\u056d\u0576\u05b0\u05b0\u0598\u058c\u0577\u057c\u05be\u05be\u05b5\u0597\u0592\u05c1\u058f\u05af\u05c1\u059c\u05a4\u0597\u05a6\u059a\u05c2\u05c2\u059c\u05cd\u059f\u05a5\u05a4\u05c6\u058b\u05ca\u0588\u05ac\u05b2\u05d4\u05d6\u05af\u05ca\u05c6\u05cc\u059d\u05bd\u059f\u05ac\u05b1\u05a2\u05d1\u05d0\u05d5\u05e7\u05e8\u05c9\u05ea\u05bb\u05d9\u05a6\u05ee\u05b0\u05c5\u05df\u05eb\u05f2\u05c9\u05b3\u05e5\u05f8\u05e3\u05da\u05cc\u05ef\u05ca\u05f1\u05c7\u0601\u05dc\u05ca\u05ba\u05c1\u05c5\u05f4\u05f1\u0607\u05d4\u0601\u05f4\u0609\u05c3\u05fc\u05fc\u05e8\u05e1\u060a\u05d0\u05d3\u05e9\u05cc\u05ed\u060a\u05dd", (byte)121, 70);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[9] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u0599\u0567\u057b\u05b1\u0581\u057b\u059d\u05a7\u05af\u05a2\u05b8\u0589\u0575\u059a\u05b4\u0574\u058a\u057b\u0593\u05c2\u05ae\u0581\u05c1\u05a1\u05a2\u0590\u05a5\u05b7\u05b3\u059a\u05bf\u05c7", (byte)121, 69);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[10] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u05a7\u0598\u0584\u0586\u05b3\u056c\u059d\u05af\u056f\u058c\u058d\u0577\u0574\u056d\u05b3\u058b\u059e\u05ba\u05a9\u0589\u058c\u05ae\u0599\u059a\u05c4\u05b6\u059a\u0583\u05bc\u05b6\u05b8\u05ad", (byte)121, 70);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[11] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.C("\u0584\u0587\u0584\u057a\u056a\u058c\u055d\u0591\u055e\u0580\u0590\u057b\u05a1\u0590\u05a1\u0576\u0584\u0576\u0583\u05ad\u05a4\u056c\u059d\u056b\u056c\u0590\u056a\u057d\u05a5\u05b4\u05ab\u056e", (byte)121, 67);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[12] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.F("\u0585\u0584\u058f\u05a7\u0572\u0584\u05a0\u0572\u0585\u056d\u0577\u05a9\u0584\u058e\u059d\u0599\u0586\u05b6\u05bf\u05b9\u05a3\u058b\u0588\u0589", (byte)121, 70);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[13] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.D("\u0596\u0598\u0590\u059c\u0559\u0568\u055e\u0581\u0571\u058e\u0583\u0568", (byte)121, 68);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[14] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u057d\u05a5\u057d\u0585\u05a9\u0582\u059f\u058c\u056d\u0576\u05b0\u05b0\u0598\u058c\u0577\u057c\u05be\u05be\u05b5\u0597\u0592\u05c1\u058f\u05af\u05c1\u059c\u05a4\u0597\u05a6\u059a\u05c2\u05c2\u059c\u05cd\u059f\u05a5\u05a4\u05c6\u058b\u05ca\u0588\u05ac\u05b2\u05d4\u05d6\u05af\u05ca\u05c6\u05cc\u059d\u05bd\u059f\u05ac\u05b1\u05a2\u05d1\u05d0\u05d5\u05e7\u05e8\u05c9\u05ea\u05bb\u05d9\u05a6\u05ee\u05b0\u05c5\u05df\u05eb\u05f2\u05c9\u05b3\u05e5\u05f8\u05e3\u05da\u05cc\u05ef\u05ca\u05f1\u05c7\u0601\u05dc\u05ca\u05bc\u05bc\u05f8\u05df\u05fc\u05c3\u05f8\u060b\u05f3\u05e0\u05df\u05c4\u0604\u0610\u05c8\u060c\u0603\u0610\u060a\u05f0\u05cf\u05f4\u05dd", (byte)121, 70);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[15] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.E("\u0599\u059c\u0599\u058f\u057f\u05a1\u0572\u05a6\u0573\u0595\u05a5\u0590\u05b6\u05a5\u05b6\u058b\u0599\u058b\u0598\u05c2\u05b9\u05c3\u05bb\u05b2\u058e\u0591\u05bc\u05c0\u059e\u05ba\u05c7\u05b7", (byte)121, 69);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[16] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u0585\u0584\u058f\u05a7\u0572\u0584\u05a0\u0572\u0585\u056d\u0578\u0571\u0576\u0585\u058d\u058a\u057b\u0578\u05a9\u0581\u05c3\u058b\u0588\u0589", (byte)121, 70);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[17] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.E("\u05a3\u0566\u058a\u05ae\u05a6\u057b\u056a\u05b3\u05a4\u05a0\u05a6\u057d", (byte)121, 69);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[18] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u057d\u05a5\u057d\u0585\u05a9\u0582\u059f\u058c\u056d\u0576\u05b0\u05b0\u0598\u058c\u0577\u057c\u05be\u05be\u05b5\u0597\u0592\u05c1\u058f\u05af\u05c1\u059c\u05a4\u0597\u05a6\u059a\u05c2\u05c2\u059c\u05cd\u059f\u05a5\u05a4\u05c6\u058b\u05ca\u0588\u05ac\u05b2\u05d4\u05d6\u05af\u05ca\u05c6\u05cc\u059d\u05bd\u059f\u05ac\u05b1\u05a2\u05d1\u05d0\u05d5\u05e7\u05e8\u05c9\u05ea\u05bb\u05d9\u05a6\u05ee\u05b0\u05c5\u05df\u05eb\u05f2\u05c9\u05b3\u05e5\u05f8\u05e3\u05da\u05cc\u05ef\u05ca\u05f1\u05c7\u0601\u05dc\u05ca\u05bc\u05c3\u05fe\u05f1\u05bf\u05e6\u0605\u05d9\u05d8\u05cc\u060a\u05dd\u060d\u05fa\u05cc\u0605\u05ff\u05cc\u0602\u05eb\u05d1\u05f4\u05dd", (byte)121, 69);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[19] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u05a9\u057f\u057c\u057f\u0564\u0587\u058a\u05b6\u0592\u0571\u05a2\u057d", (byte)121, 70);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[20] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0597\u05a1\u058e\u05a6\u0582\u05ae\u05a9\u0580\u0574\u05b4\u0576\u0571\u05b1\u058c\u0572\u059d\u05af\u0599\u0596\u05bc\u05b7\u058b\u0588\u0589", (byte)121, 69);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[21] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.E("\u0580\u0577\u056e\u0589\u05a1\u05b4\u05b2\u058d\u05b5\u0582\u05aa\u057d", (byte)121, 69);
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[22] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u05ac\u058d\u057e\u05a5\u0581\u05a8\u0571\u058e\u056e\u0575\u05af\u05a1\u0597\u05b7\u0593\u057a\u058c\u05b7\u05aa\u0577\u0596\u059b\u0588\u0589", (byte)121, 70);
                    continue block7;
                }
                case 2: {
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.D("\u0557\u056a\u0557\u0589\u0579\u059c\u056a\u0578\u055d\u0571\u0560\u0577\u057e\u057d\u0583\u0567\u0564\u05a0\u056b\u0569\u05a5\u057f\u05a8\u056c\u0585\u058c\u05b4\u05a3\u0589\u0582\u0581\u058a", (byte)121, 68);
                    continue block7;
                }
                case 4: {
                    \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.B("\u01c5\u01eb\u01a4\u01e0\u01ec\u01d7\u01ce\u01ad\u01e9\u01ea\u01af\u01cb\u01e6\u01e9\u01ea\u01b7\u01ba\u01f8\u01c5\u01c9\u01f4\u01da\u01ce\u01e9\u01f1\u01d1\u0204\u0201\u01db\u01d0\u01f5\u0202", (byte)121, 66);
                }
            }
        }
    }

    @Generated
    public \u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be(nLoginVelocity nLoginVelocity2, \u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6) {
        this.c = nLoginVelocity2;
        this.E = \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
    }

    @Subscribe
    public void a(CommandExecuteEvent commandExecuteEvent) {
        if (!commandExecuteEvent.getResult().isAllowed()) {
            return;
        }
        CommandSource commandSource = commandExecuteEvent.getCommandSource();
        if (!(commandSource instanceof Player)) {
            return;
        }
        String string = commandExecuteEvent.getCommand().trim();
        if (string.isEmpty()) {
            return;
        }
        Player player = (Player)commandSource;
        try {
            \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 \u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 = this.c.b().a(player);
            if (\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6.S()) {
                return;
            }
            String string2 = this.E.b().a(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6, (String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e80", (int)a, (long)(b ^ d)) + string);
            if (string2 == null) {
                \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b4 \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42 = this.E.a().b(\u03c8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6);
                if (player.getProtocolVersion().getProtocol() >= e && (\u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.a(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.I) || \u03b9\u03b7\u03bf\u03c8\u03c3\u03b3\u03be\u03c2\u03a9\u03b3\u03b42.d(\u03c0\u03b2\u03ba\u03bd\u03bb\u03bf\u039b\u03ba\u03a0\u03b4\u03a6\u03c4\u03c6\u03bb.c) != false)) {
                    commandExecuteEvent.setResult(CommandExecuteEvent.CommandResult.forwardToServer());
                    return;
                }
                commandExecuteEvent.setResult(CommandExecuteEvent.CommandResult.denied());
            }
        }
        catch (Throwable throwable) {
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e83", (int)f, (long)(g ^ h)) + commandExecuteEvent.getClass().getSimpleName() + (String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e86", (int)(i & j), (long)k) + player.getUsername() + (String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e89", (int)(l & m), (long)n), throwable, new Object[o]);
            player.disconnect((Component)\u03a9\u03c4\u03c9\u03bd\u03bf\u03c6\u03c7\u03b5\u03a0.a((String)\u03bc\u03b3\u03a6\u03c8\u03c2\u03b7\u03a6\u03be.c("\u3e8c", (int)p, (long)q)));
        }
    }
}

