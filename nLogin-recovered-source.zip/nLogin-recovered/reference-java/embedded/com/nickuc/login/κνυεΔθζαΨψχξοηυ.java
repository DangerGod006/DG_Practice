/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.api.types.Location
 *  com.nickuc.login.lib.json.JSONObject
 *  javax.annotation.Nonnull
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 */
package com.nickuc.login;

import com.nickuc.login.api.types.Location;
import com.nickuc.login.lib.json.JSONObject;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b;
import com.nickuc.login.\u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c2\u03bd\u039b\u03c9\u03a0\u03b8\u03c1\u03c0\u03c5\u03a3\u03bc\u03ba\u0393\u03a9\u03bf;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.annotation.Nonnull;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.bukkit.Bukkit;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03ba\u03bd\u03c5\u03b5\u0394\u03b8\u03b6\u03b1\u03a8\u03c8\u03c7\u03be\u03bf\u03b7\u03c5
implements \u03c2\u03bd\u039b\u03c9\u03a0\u03b8\u03c1\u03c0\u03c5\u03a3\u03bc\u03ba\u0393\u03a9\u03bf<Location> {
    private static int c;
    public static \u03ba\u03bd\u03c5\u03b5\u0394\u03b8\u03b6\u03b1\u03a8\u03c8\u03c7\u03be\u03bf\u03b7\u03c5 a;
    private static long b;
    private static int a;
    private static int f;
    private static String[] b;
    private static long c;
    private static long d;
    private static int g;
    private static String[] a;
    private static long e;

    @Override
    public Class<?> a() {
        return Location.class;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03ba\u03bd\u03c5\u03b5\u0394\u03b8\u03b6\u03b1\u03a8\u03c8\u03c7\u03be\u03bf\u03b7\u03c5.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.E("\u0537\u0559\u055b\u053b\u055f\u057e\u0576\u058c\u0578\u0547\u0585\u057b\u0589\u0583\u054c\u0571\u0593\u0592\u058a\u0590\u058a\u055f", (byte)83, 69), \u03ba\u03bd\u03c5\u03b5\u0394\u03b8\u03b6\u03b1\u03a8\u03c8\u03c7\u03be\u03bf\u03b7\u03c5.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.E("\u0572\u057f\u057e\u0541\u0581\u057d\u0578\u0581\u058c\u057b\u0548\u0586\u058a\u0583\u0586\u058c\u054e\u08da\u08de\u08e7\u08d8\u08b8\u08dd\u08dc\u08d8\u08d0\u08f1\u08f1\u08e9\u08eb\u08e4\u08f3\u0569", (byte)83, 69) + string + \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u04e8", (byte)83, 67) + methodType.toString(), exception);
        }
    }

    private static String a(int n, long l) {
        l ^= 0x1DL;
        l ^= 0x44F1C34E28515C2L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(4 + 64), (byte)(29 + 40), (byte)(9 + 74), (byte)(35 + 12), (byte)(25 + 42), 66, (byte)(54 + 13), (byte)(16 + 31), (byte)(70 + 10), (byte)(21 + 54), (byte)(13 + 54), (byte)(21 + 62), (byte)(36 + 17), (byte)(53 + 27), (byte)(55 + 42), (byte)(67 + 33), (byte)(91 + 9), (byte)(48 + 57), 110, (byte)(8 + 95)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(47 + 21), 69, (byte)(63 + 20)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u0457\u0464\u0463\u0426\u0466\u0462\u045d\u0466\u0471\u0460\u042d\u046b\u046f\u0468\u046b\u0471\u0433\u07bf\u07c3\u07cc\u07bd\u079d\u07c2\u07c1\u07bd\u07b5\u07d6\u07d6\u07ce\u07d0\u07c9\u07d8", (byte)21, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03ba\u03bd\u03c5\u03b5\u0394\u03b8\u03b6\u03b1\u03a8\u03c8\u03c7\u03be\u03bf\u03b7\u03c5.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(-917250826490552079L);
        c = 512 >>> 105 | 512 << ~105 + 1;
        d = Long.reverse(5423817448847106289L);
        e = Long.reverse(-5188146770730811392L);
        f = 1024 >>> 73 | 1024 << ~73 + 1;
        g = (0x2000000 >>> 56 | 0x2000000 << -56) & 0xFFFFFFFF;
        a = new String[f];
        b = new String[g];
        \u03ba\u03bd\u03c5\u03b5\u0394\u03b8\u03b6\u03b1\u03a8\u03c8\u03c7\u03be\u03bf\u03b7\u03c5.b();
        a = new \u03ba\u03bd\u03c5\u03b5\u0394\u03b8\u03b6\u03b1\u03a8\u03c8\u03c7\u03be\u03bf\u03b7\u03c5();
    }

    private static void b() {
        int n;
        c = -8140510632079088942L;
        long l = c ^ 0x44F1C34E28515C2L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, (byte)(48 + 21), (byte)(47 + 36), (byte)(23 + 24), (byte)(4 + 63), (byte)(35 + 31), (byte)(17 + 50), (byte)(39 + 8), (byte)(8 + 72), (byte)(29 + 46), (byte)(20 + 47), 83, (byte)(19 + 34), (byte)(59 + 21), (byte)(88 + 9), (byte)(23 + 77), (byte)(86 + 14), (byte)(42 + 63), (byte)(76 + 34), (byte)(17 + 86)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(48 + 35)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03ba\u03bd\u03c5\u03b5\u0394\u03b8\u03b6\u03b1\u03a8\u03c8\u03c7\u03be\u03bf\u03b7\u03c5.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u0478\u04af\u04b2\u049a\u04a4\u04c7\u0484\u04c4\u0487\u04a7\u04a3\u0490", (byte)49, 67);
                    \u03ba\u03bd\u03c5\u03b5\u0394\u03b8\u03b6\u03b1\u03a8\u03c8\u03c7\u03be\u03bf\u03b7\u03c5.b[1] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u0111\u0148\u014b\u0133\u013d\u0160\u011d\u015d\u0120\u0140\u013c\u0129", (byte)49, 66);
                    continue block7;
                }
                case 1: {
                    \u03ba\u03bd\u03c5\u03b5\u0394\u03b8\u03b6\u03b1\u03a8\u03c8\u03c7\u03be\u03bf\u03b7\u03c5.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.A("\u0124\u0134\u0129\u0130\u011c\u012f\u011e\u0113\u013c\u0140\u012f\u0144\u0140\u0126\u0139\u0136\u0144\u0146\u0138\u0143\u0128\u015d\u0134\u0135", (byte)49, 65);
                    \u03ba\u03bd\u03c5\u03b5\u0394\u03b8\u03b6\u03b1\u03a8\u03c8\u03c7\u03be\u03bf\u03b7\u03c5.b[1] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0558\u051d\u0568\u0537\u055d\u055a\u0529\u055a\u0529\u055d\u0550\u0528\u054b\u0570\u0568\u0546\u052d\u0531\u0559\u054d\u0550\u0553\u0540\u0541", (byte)49, 70);
                    continue block7;
                }
                case 2: {
                    \u03ba\u03bd\u03c5\u03b5\u0394\u03b8\u03b6\u03b1\u03a8\u03c8\u03c7\u03be\u03bf\u03b7\u03c5.b[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u047f\u04ae\u048f\u04b6\u04c5\u04ae\u0493\u04c2\u04a3\u0487\u049c\u04cb\u04aa\u04c5\u04cf\u04a7\u04cd\u04a3\u04d2\u04c9\u04b5\u04d4\u049b\u049c", (byte)49, 68);
                    continue block7;
                }
                case 4: {
                    \u03ba\u03bd\u03c5\u03b5\u0394\u03b8\u03b6\u03b1\u03a8\u03c8\u03c7\u03be\u03bf\u03b7\u03c5.b[0] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.C("\u0497\u0480\u04be\u049f\u04b1\u04af\u04a5\u04b3\u0495\u04cb\u04a1\u048a\u0486\u0499\u0498\u04ca\u04bd\u04b3\u04c1\u04d4\u04b3\u04d5\u04d3\u04b5\u04d8\u04aa\u0495\u049a\u04d9\u049d\u049c\u04af", (byte)49, 67);
                }
            }
        }
    }

    @Override
    public Location a(@Nonnull JSONObject jSONObject) {
        String string = jSONObject.getString((String)\u03ba\u03bd\u03c5\u03b5\u0394\u03b8\u03b6\u03b1\u03a8\u03c8\u03c7\u03be\u03bf\u03b7\u03c5.c("\u3e80", (int)c, (long)(d ^ e)));
        org.bukkit.Location location = \u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9.a(string);
        return new \u03b3\u03b4\u03b4\u039b\u03b6\u03a8\u03c6\u03b4\u03a0\u039b(location.getWorld().getName(), location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
    }

    @Override
    public JSONObject a(@Nonnull Location location) {
        JSONObject jSONObject = new JSONObject();
        org.bukkit.Location location2 = new org.bukkit.Location(Bukkit.getServer().getWorld(location.getWorldName()), location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
        jSONObject.put((String)\u03ba\u03bd\u03c5\u03b5\u0394\u03b8\u03b6\u03b1\u03a8\u03c8\u03c7\u03be\u03bf\u03b7\u03c5.c("\u3e80", (int)a, (long)b), (Object)\u03be\u03c0\u03c7\u03b9\u03b2\u03c1\u03bc\u03bf\u03b3\u03b9\u03c9.a(location2));
        return jSONObject;
    }
}

