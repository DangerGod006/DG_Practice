/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0;
import com.nickuc.login.\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b;

class \u03bb\u03b6\u03c6\u03a8\u03bc\u03c4\u03b4\u03a0\u03bf\u03c0\u0393\u0394\u03c4 {
    private static int f;
    static final /* synthetic */ int[] X;
    static final /* synthetic */ int[] W;
    private static int c;
    private static int h;
    private static int b;
    private static int d;
    private static int a;
    private static int g;
    private static int e;

    static {
        a = 2048 >>> 43 | 2048 << ~43 + 1;
        b = (512 >>> 8 | 512 << ~8 + 1) & 0xFFFFFFFF;
        c = (196608 >>> 144 | 196608 << ~144 + 1) & 0xFFFFFFFF;
        d = (1 >>> 222 | 1 << -222) & 0xFFFFFFFF;
        e = Integer.reverse(Integer.MIN_VALUE);
        f = (65536 >>> 239 | 65536 << ~239 + 1) & 0xFFFFFFFF;
        g = (0x300000 >>> 212 | 0x300000 << ~212 + 1) & 0xFFFFFFFF;
        h = Integer.reverse(0x20000000);
        X = new int[\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.values().length];
        try {
            \u03bb\u03b6\u03c6\u03a8\u03bc\u03c4\u03b4\u03a0\u03bf\u03c0\u0393\u0394\u03c4.X[\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.a.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03bb\u03b6\u03c6\u03a8\u03bc\u03c4\u03b4\u03a0\u03bf\u03c0\u0393\u0394\u03c4.X[\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.b.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03bb\u03b6\u03c6\u03a8\u03bc\u03c4\u03b4\u03a0\u03bf\u03c0\u0393\u0394\u03c4.X[\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.d.ordinal()] = c;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03bb\u03b6\u03c6\u03a8\u03bc\u03c4\u03b4\u03a0\u03bf\u03c0\u0393\u0394\u03c4.X[\u03b8\u03ba\u03c1\u03b4\u03b2\u03ba\u0393\u03b7\u03b6\u03b2\u03b4\u039b.c.ordinal()] = d;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        W = new int[\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.values().length];
        try {
            \u03bb\u03b6\u03c6\u03a8\u03bc\u03c4\u03b4\u03a0\u03bf\u03c0\u0393\u0394\u03c4.W[\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.b.ordinal()] = e;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03bb\u03b6\u03c6\u03a8\u03bc\u03c4\u03b4\u03a0\u03bf\u03c0\u0393\u0394\u03c4.W[\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.c.ordinal()] = f;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03bb\u03b6\u03c6\u03a8\u03bc\u03c4\u03b4\u03a0\u03bf\u03c0\u0393\u0394\u03c4.W[\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.d.ordinal()] = g;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03bb\u03b6\u03c6\u03a8\u03bc\u03c4\u03b4\u03a0\u03bf\u03c0\u0393\u0394\u03c4.W[\u03b7\u03b5\u0393\u03b2\u03a6\u03c7\u03a9\u03c8\u03c2\u03b7\u03b4\u03a0.e.ordinal()] = h;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

