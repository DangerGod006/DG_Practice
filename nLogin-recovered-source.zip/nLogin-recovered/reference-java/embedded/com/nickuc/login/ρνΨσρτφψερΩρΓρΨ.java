/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b6\u03b1\u03be\u03c1\u03c5\u03c9\u03b2\u03b6\u03c0;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03be\u03b5\u03c4\u03c6\u0394\u03bf\u03a9\u03c8\u03bd\u03b5;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8
extends \u03b6\u03b1\u03be\u03c1\u03c5\u03c9\u03b2\u03b6\u03c0
implements \u03be\u03b5\u03c4\u03c6\u0394\u03bf\u03a9\u03c8\u03bd\u03b5 {
    private static long h;
    private static long e;
    private static int l;
    private static String[] c;
    private static int w;
    private static long af;
    private static int ak;
    private static int o;
    private static int r;
    private static int t;
    private static int aj;
    private static String[] d;
    private static int ag;
    private static int f;
    private static int ae;
    private static long k;
    private static int q;
    private static long ah;
    private static int n;
    private static long ai;
    private static int x;

    @Override
    public boolean v(String string) {
        return w != 0;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.B("\u0105\u0127\u0129\u0109\u012d\u014c\u0144\u015a\u0146\u0115\u0153\u0149\u0157\u0151\u011a\u013f\u0161\u0160\u0158\u015e\u0158\u012d", (byte)47, 66), \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u04a5\u04b2\u04b1\u0474\u04b4\u04b0\u04ab\u04b4\u04bf\u04ae\u047b\u04b9\u04bd\u04b6\u04b9\u04bf\u0481\u0814\u0811\u07fd\u0819\u0818\u081c\u081f\u0822\u0810\u081d\u0806\u081f\u07f2\u0821\u0809\u049c", (byte)47, 68) + string + \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u0117", (byte)47, 65) + methodType.toString(), exception);
        }
    }

    static {
        f = Integer.reverse(0);
        h = Long.reverse(8064923723118277693L);
        k = Long.reverse(0x1600000000000000L);
        l = Integer.reverse(0x60000000);
        n = (0 >>> 71 | 0 << ~71 + 1) & 0xFFFFFFFF;
        o = Integer.reverse(0x40000000);
        q = Integer.reverse(-1073741824);
        r = 1 >>> 190 | 1 << ~190 + 1;
        t = Integer.reverse(-1610612736);
        w = Integer.reverse(0);
        x = (0 >>> 144 | 0 << ~144 + 1) & 0xFFFFFFFF;
        ae = 8 >>> 227 | 8 << ~227 + 1;
        af = Long.reverse(8785499663497557053L);
        ag = Integer.reverse(0x40000000);
        ah = Long.reverse(8064923723118277693L);
        ai = Long.reverse(0x1600000000000000L);
        aj = Integer.reverse(-1073741824);
        ak = (0x300000 >>> 244 | 0x300000 << -244) & 0xFFFFFFFF;
        c = new String[aj];
        d = new String[ak];
        \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.b();
    }

    private static String a(int n, long l) {
        l ^= 0x68L;
        l ^= 0x7BECF5B301D6F7L;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(13 + 55), (byte)(55 + 14), (byte)(49 + 34), (byte)(11 + 36), 67, (byte)(48 + 18), (byte)(63 + 4), (byte)(8 + 39), (byte)(42 + 38), (byte)(74 + 1), (byte)(42 + 25), (byte)(39 + 44), (byte)(47 + 6), (byte)(34 + 46), (byte)(66 + 31), (byte)(29 + 71), 100, (byte)(22 + 83), (byte)(43 + 67), (byte)(45 + 58)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(42 + 27), (byte)(66 + 17)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u0584\u0591\u0590\u0553\u0593\u058f\u058a\u0593\u059e\u058d\u055a\u0598\u059c\u0595\u0598\u059e\u0560\u08f3\u08f0\u08dc\u08f8\u08f7\u08fb\u08fe\u0901\u08ef\u08fc\u08e5\u08fe\u08d1\u0900\u08e8", (byte)101, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    private static void b() {
        int n;
        e = -4886501671318177802L;
        long l = e ^ 0x7BECF5B301D6F7L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(8 + 60), (byte)(45 + 24), (byte)(21 + 62), (byte)(25 + 22), (byte)(53 + 14), (byte)(44 + 22), (byte)(7 + 60), 47, (byte)(3 + 77), (byte)(52 + 23), (byte)(60 + 7), 83, (byte)(17 + 36), (byte)(64 + 16), (byte)(33 + 64), (byte)(36 + 64), (byte)(34 + 66), (byte)(43 + 62), (byte)(26 + 84), (byte)(22 + 81)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(79 + 4)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.d[0] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.F("\u052c\u0545\u056a\u052e\u054b\u0564\u056f\u052d\u0557\u0569\u056c\u0543", (byte)63, 70);
                    \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.d[1] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.A("\u015f\u0172\u0177\u0172\u015a\u0174\u013b\u0139\u016f\u015a\u017f\u0179\u0142\u0143\u016e\u017c\u013c\u0141\u0163\u017f\u016b\u0179\u0150\u0151", (byte)63, 65);
                    \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.d[2] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.B("\u0140\u0144\u0165\u0133\u0137\u0165\u0138\u012f\u015e\u013d\u0148\u0145", (byte)63, 66);
                    continue block7;
                }
                case 1: {
                    \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.d[0] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u04ec\u04e7\u04cd\u04b6\u04df\u04a7\u04f2\u04c2\u04f4\u04f1\u04f3\u04ba", (byte)63, 68);
                    \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.d[1] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.F("\u055d\u0570\u0575\u0570\u0558\u0572\u0539\u0537\u056d\u0558\u057f\u0559\u0554\u0580\u0577\u054d\u0576\u0537\u0587\u0568\u0580\u0577\u054e\u054f", (byte)63, 70);
                    \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.d[2] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u04bc\u04eb\u04ac\u04d8\u04c1\u04aa\u04be\u04e3\u04b3\u04c3\u04ac\u04ba", (byte)63, 67);
                    continue block7;
                }
                case 2: {
                    \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.d[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u0545\u052b\u0565\u0529\u056e\u0532\u0564\u0559\u054f\u054b\u054e\u0543", (byte)63, 70);
                    continue block7;
                }
                case 4: {
                    \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.d[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u04bb\u04c5\u04d7\u04c1\u04ca\u04bf\u04e8\u04aa\u04c5\u04cf\u04e2\u04d6\u04ad\u04d3\u04c6\u04f3\u04e8\u04bc\u04fe\u04b4\u04da\u04db\u04be\u04c0\u04fa\u04df\u04ff\u0501\u04e6\u04e3\u04fb\u04fa", (byte)63, 67);
                }
            }
        }
    }

    @Override
    public boolean i(String string, String string2) {
        String[] stringArray = string2.split((String)\u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.c("\u3e80", (int)f, (long)(h ^ k)));
        if (stringArray.length != l) {
            return n != 0;
        }
        String string3 = stringArray[o];
        int n = Integer.parseInt(stringArray[q]);
        int n2 = \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.b(string3);
        byte[] byArray = Base64.getUrlDecoder().decode(stringArray[r]);
        byte[] byArray2 = Base64.getUrlDecoder().decode(stringArray[t]);
        byte[] byArray3 = \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.a(string3, string.toCharArray(), byArray, n, n2);
        return \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.a(byArray2, byArray3);
    }

    @Override
    public String w(String string) {
        String string2 = \u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.ae.a(new Object[x]);
        int n = \u03a3\u03bb\u03bd\u03a8\u03bf\u03c5\u03a9\u0394\u03bf\u03b8\u03b5\u03b2.ad.r();
        return (String)\u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.c("\u3e80", (int)ae, (long)af) + string2 + (String)\u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.c("\u3e83", (int)ag, (long)(ah ^ ai)) + \u03c1\u03bd\u03a8\u03c3\u03c1\u03c4\u03c6\u03c8\u03b5\u03c1\u03a9\u03c1\u0393\u03c1\u03a8.c(string2, n, string);
    }
}

