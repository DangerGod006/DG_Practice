/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.packetevents.api.protocol.ConnectionState
 */
package com.nickuc.login;

import com.nickuc.login.lib.packetevents.api.protocol.ConnectionState;
import com.nickuc.login.\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4;

class \u03c2\u03b6\u03be\u03b3\u03b7\u03bb\u039b\u03c9\u03c8\u03a3 {
    private static int a = Integer.reverse(Integer.MIN_VALUE);
    private static int d;
    static final /* synthetic */ int[] L;
    static final /* synthetic */ int[] M;
    private static int c;
    private static int e;
    private static int b;

    static {
        b = Integer.reverse(0x40000000);
        c = Integer.reverse(Integer.MIN_VALUE);
        d = (0x800000 >>> 54 | 0x800000 << -54) & 0xFFFFFFFF;
        e = Integer.reverse(-1073741824);
        M = new int[ConnectionState.values().length];
        try {
            \u03c2\u03b6\u03be\u03b3\u03b7\u03bb\u039b\u03c9\u03c8\u03a3.M[ConnectionState.CONFIGURATION.ordinal()] = a;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03c2\u03b6\u03be\u03b3\u03b7\u03bb\u039b\u03c9\u03c8\u03a3.M[ConnectionState.PLAY.ordinal()] = b;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        L = new int[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.values().length];
        try {
            \u03c2\u03b6\u03be\u03b3\u03b7\u03bb\u039b\u03c9\u03c8\u03a3.L[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.b.ordinal()] = c;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03c2\u03b6\u03be\u03b3\u03b7\u03bb\u039b\u03c9\u03c8\u03a3.L[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.d.ordinal()] = d;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            \u03c2\u03b6\u03be\u03b3\u03b7\u03bb\u039b\u03c9\u03c8\u03a3.L[\u03ba\u03b9\u03b2\u03b2\u03c9\u03c3\u03b3\u03c7\u03c2\u03a3\u03b2\u03a0\u03a3\u03b4.c.ordinal()] = e;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

