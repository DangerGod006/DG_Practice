/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import java.net.URL;
import java.net.URLClassLoader;

public class \u0394\u03a6\u03be\u03a9\u03a3\u03b1\u03b3\u03bb\u03b8\u03b5\u0393\u03b2\u03c7
extends URLClassLoader {
    public \u0394\u03a6\u03be\u03a9\u03a3\u03b1\u03b3\u03bb\u03b8\u03b5\u0393\u03b2\u03c7(URL[] uRLArray) {
        super(uRLArray, ClassLoader.getSystemClassLoader().getParent());
    }

    static {
        ClassLoader.registerAsParallelCapable();
    }
}

