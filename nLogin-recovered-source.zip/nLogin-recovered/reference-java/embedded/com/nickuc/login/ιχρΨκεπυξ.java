/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.caffeine.cache.Cache
 *  com.nickuc.login.lib.caffeine.cache.Caffeine
 *  javax.annotation.Nullable
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.lib.caffeine.cache.Cache;
import com.nickuc.login.lib.caffeine.cache.Caffeine;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4;
import com.nickuc.login.\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c9\u0394\u03c4\u03b6\u03c7\u03b9\u03b1\u03c5\u0394\u03c4;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public abstract class \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<T extends \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?>> {
    private static double a = Double.longBitsToDouble(Long.reverse(2044L));
    private static int aj;
    protected T a;
    private static int aa;
    private static long r;
    private static final Set<String> o;
    private static int g;
    private static long ab;
    private static int x;
    private static int p;
    private static long ae;
    private static long t;
    private static int al;
    private static int e;
    private double e = a;
    private static int v;
    private boolean am;
    private static int d;
    private static int ai;
    private boolean al;
    private static int w;
    private static int f;
    private static String[] a;
    private static int k;
    private static int s;
    private static final Cache<String, Long> f;
    private static int m;
    private List<String> b;
    private List<String> k;
    private static long j;
    private double f = b;
    private static String[] b;
    private static int y;
    private static long ad;
    private static int i;
    private static int c;
    private static double b;
    private static int o;
    private \u03c9\u0394\u03c4\u03b6\u03c7\u03b9\u03b1\u03c5\u0394\u03c4 a;
    private static long ah;
    private static long ag;
    private static int af;
    private static int am;
    private static long u;
    private static long h;
    private static long ao;
    private static int l;
    private static long c;
    private static long q;
    private static int z;
    private static int an;
    private String bw;
    private static int ac;
    private static long ak;
    private String Z;
    private static long n;

    @Generated
    public \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<T> a(double d) {
        this.e = d;
        return this;
    }

    @Generated
    public boolean ap() {
        return this.al;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public final void a(Object object, String string, boolean bl, String string2, String[] stringArray) {
        Object object2;
        String string3 = (String)\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.c("\u3e80", (int)(f & g), (long)h) + string.toLowerCase(Locale.ENGLISH);
        if (bl) {
            object2 = (Long)f.getIfPresent((Object)string3);
            long l = System.currentTimeMillis();
            if (object2 != null && (double)(l - (Long)object2) <= this.e) {
                return;
            }
            f.put((Object)string3, (Object)l);
        }
        if (this.al && !o.add(string3)) {
            return;
        }
        try {
            object2 = bl ? this.a.a(object) : this.a.a();
            this.d((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)object2, string2, stringArray);
        }
        finally {
            o.remove(string3);
        }
    }

    public \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<T> b() {
        this.am = e;
        return this;
    }

    @Generated
    public \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<T> b(String string) {
        this.bw = string;
        return this;
    }

    @Generated
    public \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<T> a(String string) {
        this.Z = string;
        return this;
    }

    protected List<String> a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String string, String[] stringArray) {
        return null;
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.D("\u0401\u0423\u0425\u0405\u0429\u0448\u0440\u0456\u0442\u0411\u044f\u0445\u0453\u044d\u0416\u043b\u045d\u045c\u0454\u045a\u0454\u0429", (byte)12, 68), \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.C("\u043c\u0449\u0448\u040b\u044b\u0447\u0442\u044b\u0456\u0445\u0412\u0450\u0454\u044d\u0450\u0456\u0418\u07a3\u07b2\u07ad\u0795\u07a8\u07a4\u07b0\u07b6\u07b0\u042d", (byte)12, 67) + string + \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u0502", (byte)12, 70) + methodType.toString(), exception);
        }
    }

    protected abstract void b(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba var1, String var2, String[] var3);

    @Generated
    public String ab() {
        return this.bw;
    }

    static {
        b = Double.longBitsToDouble(Long.reverse(6456360425798341628L));
        c = Integer.reverse(Integer.MIN_VALUE);
        d = Integer.reverse(0);
        e = Integer.reverse(Integer.MIN_VALUE);
        f = 0 >>> 1 | 0 << ~1 + 1;
        g = Integer.reverse(-1);
        h = Long.reverse(-3280801439210216613L);
        i = Integer.reverse(Integer.MIN_VALUE);
        j = Long.reverse(-3280801439210216613L);
        k = Integer.reverse(0);
        l = Integer.reverse(Integer.MIN_VALUE);
        m = Integer.reverse(0x40000000);
        n = Long.reverse(-3280801439210216613L);
        o = Integer.reverse(Integer.MIN_VALUE);
        p = Integer.reverse(-1073741824);
        q = Long.reverse(4213188340734288731L);
        r = Long.reverse(-1729382256910270464L);
        s = Integer.reverse(0x20000000);
        t = Long.reverse(4213188340734288731L);
        u = Long.reverse(-1729382256910270464L);
        v = Integer.reverse(0);
        w = (4 >>> 2 | 4 << ~2 + 1) & 0xFFFFFFFF;
        x = (32768 >>> 47 | 32768 << ~47 + 1) & 0xFFFFFFFF;
        y = Integer.reverse(0);
        z = 40 >>> 3 | 40 << -3;
        aa = Integer.reverse(-1);
        ab = Long.reverse(-3280801439210216613L);
        ac = Integer.reverse(0x60000000);
        ad = Long.reverse(4213188340734288731L);
        ae = Long.reverse(-1729382256910270464L);
        af = Integer.reverse(-536870912);
        ag = Long.reverse(4213188340734288731L);
        ah = Long.reverse(-1729382256910270464L);
        ai = (0x40000000 >>> 91 | 0x40000000 << ~91 + 1) & 0xFFFFFFFF;
        aj = (-1 >>> 108 | -1 << -108) & 0xFFFFFFFF;
        ak = Long.reverse(-3280801439210216613L);
        al = Integer.reverse(0);
        am = (0x900000 >>> 52 | 0x900000 << -52) & 0xFFFFFFFF;
        an = 0x12000000 >>> 25 | 0x12000000 << ~25 + 1;
        ao = Long.reverse(-6917529027641081856L);
        a = new String[am];
        b = new String[an];
        \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b();
        o = ConcurrentHashMap.newKeySet();
        f = (int)Caffeine.newBuilder().expireAfterWrite(ao, TimeUnit.SECONDS).build();
    }

    @Generated
    public boolean aq() {
        return this.am;
    }

    private static void b() {
        int n;
        c = -2682154520481227172L;
        long l = c ^ 0xAF45D01A6D70B8FEL;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(7 + 61), (byte)(6 + 63), (byte)(10 + 73), (byte)(7 + 40), (byte)(24 + 43), (byte)(23 + 43), (byte)(5 + 62), (byte)(16 + 31), 80, (byte)(16 + 59), (byte)(8 + 59), (byte)(17 + 66), (byte)(48 + 5), (byte)(36 + 44), (byte)(95 + 2), (byte)(32 + 68), (byte)(53 + 47), (byte)(70 + 35), (byte)(3 + 107), 103}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(24 + 45), (byte)(6 + 77)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[0] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u0590\u057e\u0576\u058d\u056a\u058f\u059a\u057a\u058e\u057a\u0567\u056d", (byte)105, 69);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[1] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u01bc\u01aa\u01a2\u01b9\u0196\u01bb\u01c6\u01a6\u01ba\u01a6\u0193\u0199", (byte)105, 65);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[2] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u0592\u0579\u0577\u055a\u056d\u0560\u059b\u05a1\u0575\u057b\u0567\u056d", (byte)105, 70);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[3] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.E("\u0578\u0576\u0575\u0579\u058e\u0577\u05a4\u058f\u0583\u05a1\u0597\u059f\u0560\u055d\u05aa\u058d\u058e\u0582\u059c\u058e\u057d\u0587\u058b\u0596\u0568\u0588\u05a4\u05a6\u05bb\u05b1\u05ad\u05b5\u05b1\u0596\u0596\u0592\u05c0\u057e\u0583\u059d\u057f\u05a7\u05b6\u05ba\u05ab\u0595\u05a6\u0599\u05ad\u05c9\u05a2\u05cc\u058b\u05bf\u05c4\u05c4\u05c0\u058e\u05b1\u05b6\u05b2\u05c6\u05bc\u05a7\u05d3\u05cf\u05dc\u05b2\u05d3\u05de\u05dd\u05ce\u059f\u05c8\u05d0\u05dc\u05d7\u05e3\u05e3\u05dc\u05e7\u05ed\u05c5\u05bb\u05cc\u05bd\u05c0\u05de\u05e6\u05b0\u05cd\u05c7\u05f7\u05f5\u05fd\u05e9\u05e6\u05e8\u05ba\u05bf\u0603\u05f9\u05f5\u05f0\u05f3\u05df\u05d7\u05c3\u0600\u05ca\u05dd\u05d6\u05e0\u05ec\u05e0\u060e\u05de\u0600\u05e2\u0613\u05d2\u0600\u060a\u05f8\u05e9\u05f6\u05e4\u05da", (byte)105, 69);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[4] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.E("\u0572\u0551\u055a\u055b\u0597\u058f\u058e\u0578\u056e\u0599\u05a3\u0567\u0592\u057d\u056a\u0583\u0588\u057d\u0581\u057a\u059b\u0591\u058f\u058e\u05aa\u05b5\u058a\u0572\u0571\u0590\u057c\u0589\u05be\u05b8\u0588\u058f\u0596\u05a2\u05c0\u05c4\u0594\u0593\u05ba\u058d", (byte)105, 69);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[5] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u0543\u0541\u0540\u0544\u0559\u0542\u056f\u055a\u054e\u056c\u0562\u056a\u052b\u0528\u0575\u0558\u0559\u054d\u0567\u0559\u0548\u0552\u0556\u0561\u0533\u0553\u056f\u0571\u0586\u057c\u0578\u0580\u057c\u0561\u0561\u055d\u058b\u0549\u054e\u0568\u054a\u0572\u0583\u0582\u0561\u056f\u058e\u058e\u0568\u059a\u0574\u059a\u0591\u056f\u055a\u059d\u0576\u0561\u05a0\u05a2\u0577\u055e\u057e\u0560\u05aa\u0562\u0585\u0598\u05a0\u0579\u05a5\u0566\u05a3\u05a3\u058a\u0588\u05ac\u059e\u0584\u05b6\u0574\u0591\u05ac\u0587\u05a8\u0594\u05b9\u059d\u05b3\u05bc\u05ae\u059f\u0582\u05c7\u05c6\u059b\u05a6\u05a0\u0598\u05ab\u05b5\u05ca\u0599\u05c4\u0588\u05a5\u05ce\u05c5\u05b6\u05c3\u0590\u05d9\u0594\u05a8\u05dc\u05b2\u05ab\u059d\u0597\u059b\u05c1\u05dc\u0599\u05e3\u05d1\u05c3\u05e7\u05d1", (byte)105, 68);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[6] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u0572\u0551\u055a\u055b\u0597\u058f\u058e\u0578\u056e\u0599\u05a3\u05a1\u0578\u0598\u0575\u0595\u059d\u0590\u059f\u057d\u0589\u0588\u0593\u056f\u056f\u0594\u0590\u0579\u05b3\u0577\u05a4\u05a8", (byte)105, 69);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[7] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.B("\u01bd\u019b\u01a0\u01cb\u0188\u01a6\u01aa\u01b1\u01d0\u01d2\u01cd\u01d0\u01d4\u01c9\u01c0\u01d9\u01a6\u01a9\u0194\u01da\u0199\u01b7\u01a4\u01a5", (byte)105, 66);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[8] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.C("\u051b\u0563\u053f\u0538\u0548\u0566\u0559\u0549\u055f\u0543\u0552\u054c\u0542\u0549\u0574\u054f\u052b\u0548\u0576\u053b\u055c\u0546\u0543\u0544", (byte)105, 67);
                    continue block7;
                }
                case 1: {
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u056a\u053a\u0524\u056b\u0567\u0543\u056e\u056f\u055a\u056d\u0571\u0538", (byte)105, 67);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[1] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.F("\u057b\u0598\u059e\u055b\u055d\u057a\u058f\u0574\u0566\u0560\u0596\u056d", (byte)105, 70);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[2] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.C("\u0526\u0561\u0546\u0538\u055d\u0568\u054e\u052e\u0550\u054c\u0571\u0538", (byte)105, 67);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[3] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u0543\u0541\u0540\u0544\u0559\u0542\u056f\u055a\u054e\u056c\u0562\u056a\u052b\u0528\u0575\u0558\u0559\u054d\u0567\u0559\u0548\u0552\u0556\u0561\u0533\u0553\u056f\u0571\u0586\u057c\u0578\u0580\u057c\u0561\u0561\u055d\u058b\u0549\u054e\u0568\u054a\u0572\u0581\u0585\u0576\u0560\u0571\u0564\u0578\u0594\u056d\u0597\u0556\u058a\u058f\u058f\u058b\u0559\u057c\u0581\u057d\u0591\u0587\u0572\u059e\u059a\u05a7\u057d\u059e\u05a9\u05a8\u0599\u056a\u0593\u059b\u05a7\u05a2\u05ae\u05ae\u05a7\u05b2\u05b8\u0590\u0586\u0597\u0588\u058b\u05a9\u05b1\u057b\u0598\u0592\u05c2\u05c0\u05c8\u05b4\u05b1\u05b3\u0585\u058a\u05ce\u05c4\u05c0\u05bb\u05be\u05aa\u05a2\u058e\u05cb\u0595\u05a8\u05a1\u05ab\u05b7\u05ab\u05d9\u05a9\u05cb\u059c\u05b7\u0593\u05be\u05d6\u05b5\u05d3\u05ce\u05d6\u05a0", (byte)105, 67);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[4] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u053d\u051c\u0525\u0526\u0562\u055a\u0559\u0543\u0539\u0564\u056e\u0532\u055d\u0548\u0535\u054e\u0553\u0548\u054c\u0545\u0566\u055c\u055a\u0559\u0575\u0580\u0555\u053d\u053c\u055b\u0547\u0554\u0541\u057d\u0541\u0548\u0569\u0586\u0581\u054d\u056c\u0569\u0567\u057d\u0563\u0574\u0577\u0558\u0567\u056f\u0593\u0586\u0557\u0566\u0563\u0564", (byte)105, 67);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[5] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u0543\u0541\u0540\u0544\u0559\u0542\u056f\u055a\u054e\u056c\u0562\u056a\u052b\u0528\u0575\u0558\u0559\u054d\u0567\u0559\u0548\u0552\u0556\u0561\u0533\u0553\u056f\u0571\u0586\u057c\u0578\u0580\u057c\u0561\u0561\u055d\u058b\u0549\u054e\u0568\u054a\u0572\u0583\u0582\u0561\u056f\u058e\u058e\u0568\u059a\u0574\u059a\u0591\u056f\u055a\u059d\u0576\u0561\u05a0\u05a2\u0577\u055e\u057e\u0560\u05aa\u0562\u0585\u0598\u05a0\u0579\u05a5\u0566\u05a3\u05a3\u058a\u0588\u05ac\u059e\u0584\u05b6\u0574\u0591\u05ac\u0587\u05a8\u0594\u05b9\u059d\u05b3\u05bc\u05ae\u059f\u0582\u05c7\u05c6\u059b\u05a6\u05a0\u0598\u05ab\u05b5\u05ca\u0599\u05c4\u0588\u05a5\u05ce\u05c5\u05b6\u05c3\u0590\u05d9\u0594\u05a8\u05dc\u05b2\u05ab\u059a\u05cb\u05b0\u05e2\u05ca\u05cc\u05ac\u05d0\u05dc\u05c7\u05d2\u05e9\u05e5\u05c8\u05c4\u05d6\u05d6\u05e3\u05ce\u05dd\u05e6\u05e1\u05b8", (byte)105, 67);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[6] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u053d\u051c\u0525\u0526\u0562\u055a\u0559\u0543\u0539\u0564\u056e\u056c\u0543\u0563\u0540\u0560\u0568\u055b\u056a\u0548\u0554\u054e\u054d\u053b\u053f\u0561\u0573\u0579\u0582\u0574\u057c\u0562\u0567\u0579\u0573\u0586\u056a\u0583\u057a\u0558\u055e\u055b\u056f\u0558", (byte)105, 67);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[7] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.B("\u01bd\u019b\u01a0\u01cb\u0188\u01a6\u01aa\u01b1\u01d0\u01d2\u01ca\u01c1\u01c0\u01a5\u01c8\u0198\u01c4\u01c6\u01ac\u01a7\u01ca\u01cd\u01a4\u01a5", (byte)105, 66);
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[8] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u017c\u01c4\u01a0\u0199\u01a9\u01c7\u01ba\u01aa\u01c0\u01a4\u01b1\u01d4\u01be\u01d8\u01d4\u01b9\u0190\u01ce\u0193\u0197\u01cd\u01cd\u01a4\u01a5", (byte)105, 66);
                    continue block7;
                }
                case 2: {
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.A("\u01b9\u0185\u01c4\u01ae\u01cc\u019a\u018e\u01c7\u0189\u0185\u0191\u01a3\u0196\u01c2\u01c3\u01cf\u01c9\u01d3\u01aa\u01b8\u01d2\u01da\u01ab\u01da\u019a\u01d4\u01a4\u01bf\u01bf\u01b2\u01d0\u01a6", (byte)105, 65);
                    continue block7;
                }
                case 4: {
                    \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.F("\u0574\u0593\u055f\u058d\u055d\u056c\u0573\u0597\u0586\u0586\u0580\u057c\u0583\u0575\u058d\u0585\u05a1\u058a\u056c\u059c\u057b\u05ad\u05a1\u0596\u05a0\u05a8\u05b5\u05a9\u0578\u05b0\u057a\u05be", (byte)105, 70);
                }
            }
        }
    }

    public void u(String string) {
        this.k.add(string.toLowerCase(Locale.ENGLISH));
    }

    @Generated
    public \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<T> a(boolean bl) {
        this.al = bl;
        return this;
    }

    public void a(String ... stringArray) {
        String[] stringArray2 = stringArray;
        int n = stringArray2.length;
        for (int i = d; i < n; ++i) {
            String string = stringArray2[i];
            this.b.add(string.toLowerCase(Locale.ENGLISH));
        }
    }

    @Generated
    public String aa() {
        return this.Z;
    }

    @Generated
    public T a() {
        return this.a;
    }

    @Generated
    public \u03c9\u0394\u03c4\u03b6\u03c7\u03b9\u03b1\u03c5\u0394\u03c4 b() {
        return this.a;
    }

    protected boolean a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String string, String[] stringArray, boolean bl) {
        if (this.k.isEmpty()) {
            return w != 0;
        }
        for (String string2 : this.k) {
            if (!\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2.i(string2)) continue;
            return x != 0;
        }
        return y != 0;
    }

    public \u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1 a(\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b4<?> \u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42) {
        this.a = (double)\u03b5\u03b7\u03c7\u03b2\u03b3\u03c1\u03a6\u03b2\u03a6\u039b\u03ba\u03b3\u03a6\u03bf\u03b42;
        this.a = this.a.b();
        \u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1 \u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c12 = this.a.a(this);
        \u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c12.W();
        this.s();
        return \u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c12;
    }

    public void s() {
    }

    @Generated
    public double a() {
        return this.e;
    }

    private static String a(int n, long l) {
        l ^= 0x17L;
        l ^= 0xAF45D01A6D70B8FEL;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(21 + 47), (byte)(19 + 50), (byte)(12 + 71), (byte)(37 + 10), (byte)(20 + 47), (byte)(18 + 48), (byte)(30 + 37), (byte)(39 + 8), (byte)(43 + 37), 75, (byte)(55 + 12), 83, (byte)(52 + 1), (byte)(58 + 22), (byte)(31 + 66), (byte)(34 + 66), (byte)(69 + 31), (byte)(24 + 81), (byte)(38 + 72), (byte)(73 + 30)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(54 + 15), (byte)(31 + 52)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u056d\u057a\u0579\u053c\u057c\u0578\u0573\u057c\u0587\u0576\u0543\u0581\u0585\u057e\u0581\u0587\u0549\u08d4\u08e3\u08de\u08c6\u08d9\u08d5\u08e1\u08e7\u08e1", (byte)78, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private List<String> d(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String string, String[] stringArray) {
        if (!this.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, string, stringArray, o != 0)) {
            return null;
        }
        try {
            return this.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, string, stringArray);
        }
        catch (Exception exception) {
            \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2.k((String)\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.c("\u3e80", (int)p, (long)(q ^ r)));
            \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.c("\u3e83", (int)s, (long)(t ^ u)) + string.toLowerCase(Locale.ENGLISH), exception, new Object[v]);
            return null;
        }
    }

    @Generated
    public double b() {
        return this.f;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public final void c(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String string, String[] stringArray) {
        String string2 = (String)\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.c("\u3e80", (int)i, (long)j) + \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2.getName().toLowerCase(Locale.ENGLISH);
        if (\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2 instanceof \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6) {
            Long l = (Long)f.getIfPresent((Object)string2);
            long l2 = System.currentTimeMillis();
            if (l != null && (double)(l2 - l) <= this.e) {
                return;
            }
            f.put((Object)string2, (Object)l2);
        }
        if (this.al && !o.add(string2)) {
            return;
        }
        try {
            this.d(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, string, stringArray);
        }
        finally {
            o.remove(string2);
        }
    }

    @Generated
    public List<String> c() {
        return this.b;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Nullable
    public final List<String> a(Object object, String string, boolean bl, String string2, String[] stringArray) {
        Object object2;
        String string3 = (String)\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.c("\u3e80", (int)m, (long)n) + string.toLowerCase(Locale.ENGLISH);
        if (bl) {
            object2 = (Long)f.getIfPresent((Object)string3);
            long l = System.currentTimeMillis();
            if (object2 != null && (double)(l - (Long)object2) <= this.e) {
                return null;
            }
            f.put((Object)string3, (Object)l);
        }
        if (this.al && !o.add(string3)) {
            return null;
        }
        try {
            object2 = bl ? this.a.a(object) : this.a.a();
            List<String> list = this.d((\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba)object2, string2, stringArray);
            return list;
        }
        finally {
            o.remove(string3);
        }
    }

    public \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be(String string) {
        this.al = c;
        this.Z = string;
        this.b = new ArrayList<String>();
        this.k = (int)new ArrayList();
    }

    public final void d(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, String string, String[] stringArray) {
        if (!this.a(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, string, stringArray, k != 0)) {
            return;
        }
        Runnable runnable = () -> {
            if (\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2 instanceof \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 && !((\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6)\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2).R()) {
                return;
            }
            try {
                this.b(\u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2, string, stringArray);
            }
            catch (Exception exception) {
                \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2.k((String)\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.c("\u3e80", (int)(z & aa), (long)ab));
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.c((String)\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.c("\u3e83", (int)ac, (long)(ad ^ ae)) + string.toLowerCase(Locale.ENGLISH) + (String)\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.c("\u3e86", (int)af, (long)(ag ^ ah)) + \u03b8\u03a6\u03b3\u03bd\u03a9\u03b5\u03c1\u03c1\u03b9\u03b4\u03ba2.getName() + (String)\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be.c("\u3e89", (int)(ai & aj), (long)ak) + this.am, exception, new Object[al]);
            }
        };
        if (this.am) {
            this.a.b(l != 0).a(runnable);
        } else {
            runnable.run();
        }
    }

    @Generated
    public \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<T> b(double d) {
        this.f = d;
        return this;
    }

    @Generated
    public List<String> d() {
        return this.k;
    }

    @Generated
    public \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<T> a(List<String> list) {
        this.b = list;
        return this;
    }

    @Generated
    public \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<T> b(List<String> list) {
        this.k = (int)list;
        return this;
    }
}

