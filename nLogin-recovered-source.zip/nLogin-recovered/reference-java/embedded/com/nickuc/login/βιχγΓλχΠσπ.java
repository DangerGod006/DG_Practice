/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Base64;
import java.util.Locale;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0 {
    private static int e;
    private static int aq;
    private static int au;
    private static int bj;
    private static int p;
    private static long af;
    private static long bz;
    private static int bw;
    private static int u;
    private static int x;
    private static int as;
    private static int j;
    private static int w;
    private static int ah;
    private static int t;
    private static int an;
    private static String[] b;
    private static long ae;
    private static final DecimalFormat[] a;
    private static int ar;
    private static int br;
    private static long ab;
    private static int bp;
    private static long ax;
    private static int l;
    private static int i;
    private static final DecimalFormat b;
    private static int bg;
    private static long n;
    private static long f;
    private static int aa;
    private static long q;
    private static long z;
    private static int bc;
    private static long bq;
    private static int bl;
    private static int bh;
    private static long b;
    private static long ac;
    private static int bo;
    private static double bf;
    private static long at;
    private static int v;
    private static long bb;
    private static long by;
    private static int ak;
    private static int ao;
    private static int bk;
    private static int av;
    private static long be;
    private static int bi;
    private static String[] a;
    private static int ag;
    private static long al;
    private static int y;
    private static int aw;
    private static long ay;
    private static long ba;
    private static long d;
    private static int a;
    private static int m;
    private static int ad;
    private static int aj;
    private static int bn;
    private static int o;
    private static int am;
    private static long bs;
    private static int s;
    private static long r;
    private static long bd;
    private static int ap;
    private static long c;
    private static int bv;
    private static long bt;
    private static int bm;
    private static long ai;
    private static int az;
    private static int bu;
    private static int h;
    private static int bx;
    private static int k;
    private static long g;

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u04ec\u050e\u0510\u04f0\u0514\u0533\u052b\u0541\u052d\u04fc\u053a\u0530\u053e\u0538\u0501\u0526\u0548\u0547\u053f\u0545\u053f\u0514", (byte)8, 70), \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.C("\u0430\u043d\u043c\u03ff\u043f\u043b\u0436\u043f\u044a\u0439\u0406\u0444\u0448\u0441\u0444\u044a\u040c\u0790\u0798\u07a7\u0794\u0775\u079e\u07ab\u0785\u07a9\u07a7\u0422", (byte)8, 67) + string + \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u00c9", (byte)8, 65) + methodType.toString(), exception);
        }
    }

    private static DecimalFormat[] a(int n) {
        DecimalFormat[] decimalFormatArray = new DecimalFormat[n];
        for (int i = h; i < n; ++i) {
            DecimalFormat decimalFormat;
            decimalFormatArray[i] = decimalFormat = \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(i + \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.i);
        }
        return decimalFormatArray;
    }

    public static String b(double d, double d2, int n, String string) {
        int n2 = (int)(d * bf / d2);
        int n3 = n2 <= bg ? bh : (n2 <= bi ? bj : (n2 <= bk ? bl : (n2 <= bm ? bn : bo)));
        int n4 = (int)(d * (double)n / d2);
        return (String)\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e80", (int)bp, (long)bq) + (char)n3 + \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b(string, n4) + (String)\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e83", (int)br, (long)(bs ^ bt)) + \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b(string, n - n4);
    }

    public static String a(double d) {
        return b.format(d);
    }

    public static String b(String string, int n) {
        if (n <= 0) {
            return \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e80", (int)(aj & ak), (long)al);
        }
        int n2 = string.length();
        char[] cArray = new char[n2 * n];
        char[] cArray2 = string.toCharArray();
        for (int i = am; i < cArray.length; ++i) {
            cArray[i] = cArray2[i % n2];
        }
        return new String(cArray);
    }

    public static String a(double d, double d2) {
        return \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(d, d2, av, (String)\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e80", (int)aw, (long)(ax ^ ay)));
    }

    static {
        a = (0 >>> 238 | 0 << ~238 + 1) & 0xFFFFFFFF;
        b = Long.reverse(8150228016070543639L);
        d = Long.reverse(0x4C00000000000000L);
        e = (0x10000000 >>> 92 | 0x10000000 << -92) & 0xFFFFFFFF;
        f = Long.reverse(8150228016070543639L);
        g = Long.reverse(0x4C00000000000000L);
        h = Integer.reverse(0);
        i = 0x10000000 >>> 220 | 0x10000000 << -220;
        j = Integer.reverse(0);
        k = 0 >>> 17 | 0 << -17;
        l = (0x4000000 >>> 153 | 0x4000000 << ~153 + 1) & 0xFFFFFFFF;
        m = Integer.reverse(-1);
        n = Long.reverse(4403233126098290967L);
        o = Integer.reverse(0);
        p = 0x30000000 >>> 252 | 0x30000000 << -252;
        q = Long.reverse(8150228016070543639L);
        r = Long.reverse(0x4C00000000000000L);
        s = (0 >>> 253 | 0 << -253) & 0xFFFFFFFF;
        t = 123 >>> 160 | 123 << ~160 + 1;
        u = Integer.reverse(Integer.MIN_VALUE);
        v = Integer.reverse(-1107296256);
        w = 0x2000000 >>> 120 | 0x2000000 << ~120 + 1;
        x = 1024 >>> 138 | 1024 << -138;
        y = Integer.reverse(0x20000000);
        z = Long.reverse(4403233126098290967L);
        aa = (-2147483646 >>> 255 | -2147483646 << ~255 + 1) & 0xFFFFFFFF;
        ab = Long.reverse(8150228016070543639L);
        ac = Long.reverse(0x4C00000000000000L);
        ad = 192 >>> 197 | 192 << -197;
        ae = Long.reverse(8150228016070543639L);
        af = Long.reverse(0x4C00000000000000L);
        ag = (-2147483645 >>> 191 | -2147483645 << ~191 + 1) & 0xFFFFFFFF;
        ah = -1 >>> 161 | -1 << -161;
        ai = Long.reverse(4403233126098290967L);
        aj = (131072 >>> 238 | 131072 << ~238 + 1) & 0xFFFFFFFF;
        ak = Integer.reverse(-1);
        al = Long.reverse(4403233126098290967L);
        am = Integer.reverse(0);
        an = Integer.reverse(0);
        ao = -1 >>> 223 | -1 << -223;
        ap = Integer.reverse(0);
        aq = 16 >>> 36 | 16 << ~36 + 1;
        ar = (18 >>> 193 | 18 << -193) & 0xFFFFFFFF;
        as = Integer.reverse(-1);
        at = Long.reverse(4403233126098290967L);
        au = Integer.reverse(Integer.MIN_VALUE);
        av = Integer.reverse(0x28000000);
        aw = (640 >>> 38 | 640 << -38) & 0xFFFFFFFF;
        ax = Long.reverse(8150228016070543639L);
        ay = Long.reverse(0x4C00000000000000L);
        az = (0x2C000000 >>> 26 | 0x2C000000 << ~26 + 1) & 0xFFFFFFFF;
        ba = Long.reverse(8150228016070543639L);
        bb = Long.reverse(0x4C00000000000000L);
        bc = Integer.reverse(0x30000000);
        bd = Long.reverse(8150228016070543639L);
        be = Long.reverse(0x4C00000000000000L);
        bf = Double.longBitsToDouble(Long.reverse(39426L));
        bg = Integer.reverse(0x28000000);
        bh = 49664 >>> 137 | 49664 << -137;
        bi = (0x280000 >>> 48 | 0x280000 << -48) & 0xFFFFFFFF;
        bj = (100 >>> 129 | 100 << ~129 + 1) & 0xFFFFFFFF;
        bk = -2147483641 >>> 29 | -2147483641 << -29;
        bl = (0x1B00000 >>> 211 | 0x1B00000 << ~211 + 1) & 0xFFFFFFFF;
        bm = (640 >>> 35 | 640 << ~35 + 1) & 0xFFFFFFFF;
        bn = Integer.reverse(-973078528);
        bo = Integer.reverse(0x2C000000);
        bp = Integer.reverse(-1342177280);
        bq = Long.reverse(4403233126098290967L);
        br = (229376 >>> 46 | 229376 << ~46 + 1) & 0xFFFFFFFF;
        bs = Long.reverse(8150228016070543639L);
        bt = Long.reverse(0x4C00000000000000L);
        bu = Integer.reverse(0x8000000);
        bv = (0x40000000 >>> 90 | 0x40000000 << -90) & 0xFFFFFFFF;
        bw = Integer.reverse(-1610612736);
        bx = Integer.reverse(-268435456);
        by = Long.reverse(8150228016070543639L);
        bz = Long.reverse(0x4C00000000000000L);
        a = new String[bu];
        b = new String[bv];
        \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b();
        a = \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(bw);
        b = new DecimalFormat((String)\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e80", (int)bx, (long)(by ^ bz)));
    }

    public static String y(String string) {
        if (string.isEmpty()) {
            return string;
        }
        CharSequence[] charSequenceArray = string.split((String)\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e80", (int)(l & m), (long)n));
        if (charSequenceArray.length == 0) {
            return string;
        }
        for (int i = o; i < charSequenceArray.length; ++i) {
            charSequenceArray[i] = \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.t(charSequenceArray[i]);
        }
        return String.join((CharSequence)\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e83", (int)p, (long)(q ^ r)), charSequenceArray);
    }

    public static String a(String string, Object ... objectArray) {
        if (objectArray != null && objectArray.length > 0) {
            int n = string.length();
            StringBuilder stringBuilder = new StringBuilder(n);
            block0: for (int i = s; i < n; ++i) {
                char c;
                block10: {
                    c = string.charAt(i);
                    if (c == t) {
                        for (int j = i + u; j < n; ++j) {
                            char c2 = string.charAt(j);
                            if (c2 == v) {
                                if (j - i >= w) {
                                    String string2 = string.substring(i + x, j);
                                    Integer n2 = \u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.a(string2);
                                    if (n2 == null) {
                                        throw new IllegalArgumentException((String)\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e80", (int)y, (long)z) + string2 + (String)\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e83", (int)aa, (long)(ab ^ ac)) + string + (String)\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e86", (int)ad, (long)(ae ^ af)) + i);
                                    }
                                    if (n2 < objectArray.length) {
                                        stringBuilder.append(objectArray[n2]);
                                        i += j - i;
                                        continue block0;
                                    }
                                }
                            } else if (\u03b5\u03bb\u03bb\u03b7\u03bb\u03c6\u03b1\u0394\u03bb\u03b1.a(c2)) {
                                continue;
                            }
                            break block10;
                        }
                        stringBuilder.append(string.substring(i));
                        break;
                    }
                }
                stringBuilder.append(c);
            }
            return stringBuilder.toString();
        }
        return string;
    }

    public static String a(double d, double d2, int n, String string) {
        int n2 = (int)(d * (double)n / d2);
        return (String)\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e80", (int)az, (long)(ba ^ bb)) + \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b(string, n2) + (String)\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e83", (int)bc, (long)(bd ^ be)) + \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b(string, n - n2);
    }

    public static String a(double d, int n) {
        DecimalFormat decimalFormat = a.length <= n ? \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a(n) : a[n - au];
        return decimalFormat.format(d);
    }

    public static String t(String string) {
        if (string.isEmpty()) {
            return string;
        }
        char[] cArray = string.toCharArray();
        cArray[\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.j] = Character.toUpperCase(cArray[k]);
        return new String(cArray);
    }

    private static String a(int n, long l) {
        l ^= 0x32L;
        l ^= 0xFF26AC6911587D59L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(44 + 24), 69, (byte)(57 + 26), (byte)(23 + 24), (byte)(5 + 62), (byte)(45 + 21), (byte)(30 + 37), (byte)(36 + 11), (byte)(2 + 78), (byte)(70 + 5), (byte)(3 + 64), (byte)(16 + 67), 53, (byte)(16 + 64), (byte)(10 + 87), (byte)(97 + 3), (byte)(81 + 19), (byte)(58 + 47), (byte)(87 + 23), (byte)(63 + 40)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(56 + 12), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u052f\u053c\u053b\u04fe\u053e\u053a\u0535\u053e\u0549\u0538\u0505\u0543\u0547\u0540\u0543\u0549\u050b\u088f\u0897\u08a6\u0893\u0874\u089d\u08aa\u0884\u08a8\u08a6", (byte)93, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    public static String a(String string, String string2, String string3) {
        String string4 = string.toLowerCase();
        String string5 = string2.toLowerCase();
        int n = an;
        StringBuilder stringBuilder = new StringBuilder(string);
        while ((n = string4.indexOf(string5, n)) != ao) {
            stringBuilder.replace(n, n + string5.length(), string3);
            n += string3.length();
        }
        return stringBuilder.toString();
    }

    private static void b() {
        int n;
        c = -1688205446378760050L;
        long l = c ^ 0xFF26AC6911587D59L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(65 + 3), (byte)(60 + 9), (byte)(38 + 45), (byte)(4 + 43), (byte)(33 + 34), 66, (byte)(47 + 20), (byte)(11 + 36), (byte)(26 + 54), (byte)(51 + 24), (byte)(14 + 53), (byte)(15 + 68), (byte)(21 + 32), (byte)(15 + 65), (byte)(60 + 37), (byte)(67 + 33), (byte)(79 + 21), (byte)(65 + 40), 110, (byte)(22 + 81)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(30 + 38), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[0] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.E("\u053a\u0520\u0549\u053a\u056a\u0564\u056b\u052c\u0556\u0547\u0562\u0535", (byte)49, 69);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[1] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.F("\u052f\u0543\u0543\u0565\u0547\u056a\u0522\u0544\u052a\u053b\u0550\u0535", (byte)49, 70);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[2] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.F("\u0566\u0563\u055d\u051b\u0561\u0546\u0562\u052d\u0556\u0526\u052b\u0535", (byte)49, 70);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[3] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.A("\u015a\u0157\u0151\u010f\u0155\u013a\u0156\u0121\u014a\u011a\u011f\u0129", (byte)49, 65);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[4] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.B("\u014b\u0129\u0148\u014c\u013d\u0149\u012c\u012e\u015f\u0138\u0145\u0165\u011c\u0147\u0148\u013d\u0133\u0147\u014a\u0155\u013d\u015d\u013f\u0128\u0147\u012d\u0145\u012f\u0128\u0164\u0168\u0157\u0174\u0154\u0151\u017b\u0171\u013c\u0180\u0177\u0139\u0140\u013b\u0185\u0179\u015f\u0161\u0143\u0176\u015e\u014c\u0185\u0160\u016b\u0182\u0189\u0160\u0160\u0165\u016f\u0183\u015f\u016b\u0177", (byte)49, 66);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[5] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.C("\u04b4\u04b7\u04a3\u0476\u049d\u04b5\u04b1\u0480\u0494\u04c3\u0498\u04cc\u04ce\u04c0\u049c\u048c\u049b\u04ca\u04d0\u048d\u0491\u04d4\u049b\u049c", (byte)49, 67);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[6] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u0526\u051e\u0566\u0542\u0549\u053d\u0541\u0526\u0566\u053b\u0562\u0535", (byte)49, 69);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[7] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.F("\u051d\u0533\u0538\u0566\u053d\u056c\u0534\u0548\u0561\u0543\u053c\u0535", (byte)49, 70);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[8] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.D("\u04b0\u0481\u04a3\u04b5\u04ae\u04a7\u04c4\u049a\u04c7\u04b2\u04a3\u0490", (byte)49, 68);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[9] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u055b\u0541\u053f\u056a\u0534\u0526\u0560\u055c\u0536\u0546\u052b\u0535", (byte)49, 69);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[10] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u0133\u014d\u013b\u0138\u0154\u0140\u0116\u0121\u014d\u0164\u0138\u0129", (byte)49, 65);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[11] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.C("\u048c\u0496\u04bd\u04ac\u04ae\u04c2\u0485\u04a6\u0482\u0496\u04b5\u0490", (byte)49, 67);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[12] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u0481\u04bb\u047e\u0484\u049f\u04b5\u04b2\u049d\u04b3\u04bd\u049b\u0490", (byte)49, 67);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[13] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.F("\u0531\u0565\u0532\u055e\u0540\u0546\u0561\u054d\u054f\u0570\u052f\u0535", (byte)49, 70);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[14] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.E("\u0526\u0560\u0523\u0529\u0544\u055a\u0557\u0542\u0558\u0562\u0540\u0535", (byte)49, 69);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[15] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.A("\u012e\u0152\u0125\u0146\u015c\u013d\u015b\u0139\u0153\u013b\u0138\u0129", (byte)49, 65);
                    continue block7;
                }
                case 1: {
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[0] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.F("\u0523\u055a\u0538\u0548\u0547\u0535\u051e\u054a\u052e\u0568\u0540\u0535", (byte)49, 70);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[1] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.D("\u048b\u048c\u0499\u04b6\u04c6\u047f\u04c2\u04b0\u0486\u04c9\u04a7\u0490", (byte)49, 68);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u053f\u0537\u0564\u0534\u055c\u056b\u0563\u0557\u0547\u053e\u0527\u0535", (byte)49, 69);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[3] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.A("\u014e\u011b\u0118\u015a\u014c\u0135\u0135\u012d\u0136\u0153\u0123\u0129", (byte)49, 65);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[4] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u04b2\u0490\u04af\u04b3\u04a4\u04b0\u0493\u0495\u04c6\u049f\u04ac\u04cc\u0483\u04ae\u04af\u04a4\u049a\u04ae\u04b1\u04bc\u04a4\u04c4\u04a6\u048f\u04ae\u0494\u04ac\u0496\u048f\u04cb\u04cf\u04be\u04db\u04bb\u04b8\u04e2\u04d8\u04a3\u04e7\u04de\u04a0\u04a7\u04a2\u04ec\u04e0\u04c6\u04c8\u04aa\u04dd\u04c5\u04b3\u04ec\u04c7\u04df\u04cb\u04f8\u04d5\u04f5\u04c3\u04b9\u04f1\u04ea\u04b5\u04fb\u04f6\u04ec\u04d0\u04c0\u04ee\u04ee\u04df\u04d0\u04c1\u04dd\u04e3\u04d0", (byte)49, 68);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[5] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.E("\u0559\u055c\u0548\u051b\u0542\u055a\u0556\u0525\u0539\u0568\u053f\u052f\u0532\u052d\u0572\u054d\u0563\u054e\u0537\u0555\u056b\u0553\u0540\u0541", (byte)49, 69);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[6] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u0117\u0132\u0156\u013c\u0147\u0118\u0157\u012c\u012f\u0133\u0153\u011f\u0135\u0144\u0153\u013d\u012a\u0169\u015d\u0127\u0129\u0137\u0134\u0135", (byte)49, 65);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[7] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u0122\u0129\u012c\u0113\u0117\u0130\u0155\u0162\u0143\u015e\u0140\u0129", (byte)49, 65);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[8] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.D("\u0492\u04a1\u049c\u047a\u0491\u04c0\u0498\u049d\u04a8\u04aa\u04c1\u0490", (byte)49, 68);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[9] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.F("\u0541\u0539\u0535\u055e\u0532\u0526\u0538\u056d\u053d\u056b\u056f\u0531\u0547\u0552\u0530\u0572\u056c\u056c\u0556\u0535\u0543\u0569\u0540\u0541", (byte)49, 70);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[10] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.E("\u0542\u0531\u055a\u055d\u0540\u055a\u0529\u054a\u0537\u0546\u055e\u0535", (byte)49, 69);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[11] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.A("\u0135\u0159\u0129\u0155\u013a\u012e\u011e\u0137\u014a\u0162\u0123\u0129", (byte)49, 65);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[12] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.F("\u0537\u0534\u0565\u0569\u055d\u056c\u0527\u0547\u0548\u0537\u0566\u0535", (byte)49, 70);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[13] = \u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u0145\u0150\u013d\u0149\u011e\u0132\u0158\u0113\u015b\u0133\u014e\u0129", (byte)49, 65);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[14] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.B("\u012e\u012e\u0158\u015d\u013d\u0134\u013f\u0134\u0151\u0141\u0144\u0129", (byte)49, 66);
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[15] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.E("\u0552\u0564\u0539\u0566\u0529\u054b\u0548\u052b\u054d\u0565\u055e\u0535", (byte)49, 69);
                    continue block7;
                }
                case 2: {
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.B("\u012b\u0139\u015d\u0146\u013a\u011a\u014f\u012a\u011c\u0134\u0165\u0132\u0154\u0150\u0144\u0143\u0134\u0136\u0168\u013c\u0125\u016d\u0134\u0135", (byte)49, 66);
                    continue block7;
                }
                case 4: {
                    \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u048c\u048a\u04bf\u04c1\u0498\u048f\u04be\u04bb\u04c6\u0488\u047d\u0487\u049a\u0480\u0486\u04bb\u04d0\u049a\u049f\u04cb\u04a3\u04ae\u049b\u049c", (byte)49, 67);
                }
            }
        }
    }

    public static String a(String ... stringArray) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = ap; i < stringArray.length; ++i) {
            stringBuilder.append(stringArray[i]);
            if (i == stringArray.length - aq) continue;
            stringBuilder.append((String)\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e80", (int)(ar & as), (long)at));
        }
        return stringBuilder.toString();
    }

    public static String d(long l) {
        return b.format(l);
    }

    private static DecimalFormat a(int n) {
        return new DecimalFormat((String)\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e80", (int)a, (long)(b ^ d)) + \u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.b((String)\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e83", (int)e, (long)(f ^ g)), n), DecimalFormatSymbols.getInstance(Locale.ENGLISH));
    }

    public static String a(int n) {
        return (String)\u03b2\u03b9\u03c7\u03b3\u0393\u03bb\u03c7\u03a0\u03c3\u03c0.c("\u3e80", (int)(ag & ah), (long)ai) + Integer.toHexString(n).toUpperCase(Locale.ENGLISH);
    }
}

