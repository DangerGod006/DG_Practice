/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03a8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03ba\u03b4\u03be\u03c4\u03a6\u03a0\u03c9\u03c6 {
    private static final long[][] a;
    private static int f;
    private static int g;
    private static final int aT;
    private static final Object[] d;
    private static final int aS;
    private static int c;
    private static final long[] a;
    private static int a;
    private static int e;
    private static final int[] ai;
    private static int d;
    private static int b;
    private static final boolean[] a;

    static /* synthetic */ boolean[] a() {
        return a;
    }

    static {
        a = (0x400000 >>> 182 | 0x400000 << -182) & 0xFFFFFFFF;
        b = Integer.reverse(-813694976);
        c = Integer.reverse(Integer.MIN_VALUE);
        d = Integer.reverse(0);
        e = 0 >>> 255 | 0 << ~255 + 1;
        f = 16000 >>> 37 | 16000 << ~37 + 1;
        g = Integer.reverse(796917760);
        aS = f;
        aT = \u03a8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3.values().length;
        d = \u03ba\u03b4\u03be\u03c4\u03a6\u03a0\u03c9\u03c6.a(aT);
        a = new long[aT][g];
        a = new long[aT];
        ai = new int[aT];
        a = new boolean[aT];
    }

    static /* synthetic */ Object[] a() {
        return d;
    }

    private static Object[] a(int n) {
        Object[] objectArray = new Object[n];
        for (int i = e; i < objectArray.length; ++i) {
            objectArray[i] = new Object();
        }
        return objectArray;
    }

    static /* synthetic */ long[][] a() {
        return a;
    }

    static /* synthetic */ int[] a() {
        return ai;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void a(\u03a8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3 \u03c8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3, long l) {
        long l2 = System.nanoTime() - l;
        int n = \u03c8\u039b\u03c5\u03bd\u03b3\u03c6\u03c5\u03bd\u03b4\u03a8\u03b4\u03b3\u03a3.ordinal();
        Object object = d[n];
        synchronized (object) {
            int n2 = n;
            int n3 = ai[n2];
            ai[n2] = n3 + a;
            int n4 = n3;
            \u03ba\u03b4\u03be\u03c4\u03a6\u03a0\u03c9\u03c6.a[n][n4] = l2;
            \u03ba\u03b4\u03be\u03c4\u03a6\u03a0\u03c9\u03c6.a[n] = l2;
            if (n4 == b) {
                \u03ba\u03b4\u03be\u03c4\u03a6\u03a0\u03c9\u03c6.a[n] = c;
                \u03ba\u03b4\u03be\u03c4\u03a6\u03a0\u03c9\u03c6.ai[n] = d;
            }
        }
    }

    static /* synthetic */ long[] a() {
        return a;
    }
}

