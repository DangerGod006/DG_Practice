/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  lombok.Generated
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.messaging.PluginMessageListener
 *  org.jetbrains.annotations.NotNull
 */
package com.nickuc.login;

import com.nickuc.login.\u03a6\u03c9\u03bf\u03c6\u03c5\u03b4\u03b9\u03c6\u03a3\u03a6;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;
import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.jetbrains.annotations.NotNull;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bc\u03c6\u03bb\u03ba\u03b6\u03a6\u03b8\u03b6\u03c7\u0394\u03a9\u03bb\u03c4\u03c2\u03a3
implements PluginMessageListener {
    private static int a = Integer.reverse(0);
    private static String[] a;
    private static long c;
    private static String[] b;
    private static long b;
    private static int c;
    private static int d;
    final /* synthetic */ \u03a6\u03c9\u03bf\u03c6\u03c5\u03b4\u03b9\u03c6\u03a3\u03a6 c;

    private static void b() {
        int n;
        c = -3765327963148225197L;
        long l = c ^ 0x5E9BE637756FEFA5L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{68, 69, (byte)(20 + 63), (byte)(38 + 9), (byte)(11 + 56), (byte)(10 + 56), (byte)(37 + 30), (byte)(11 + 36), (byte)(10 + 70), (byte)(65 + 10), (byte)(46 + 21), (byte)(41 + 42), (byte)(30 + 23), (byte)(58 + 22), (byte)(81 + 16), (byte)(63 + 37), (byte)(43 + 57), (byte)(21 + 84), (byte)(96 + 14), (byte)(41 + 62)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(9 + 74)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bc\u03c6\u03bb\u03ba\u03b6\u03a6\u03b8\u03b6\u03c7\u0394\u03a9\u03bb\u03c4\u03c2\u03a3.b[0] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.B("\u0111\u00fe\u010d\u00f7\u012b\u00f1\u00f5\u0118\u0139\u0128\u0127\u010e\u012e\u0122\u0134\u00ff\u013f\u0130\u0143\u013c\u0120\u0137\u010e\u010f", (byte)30, 66);
                    continue block7;
                }
                case 1: {
                    \u03bc\u03c6\u03bb\u03ba\u03b6\u03a6\u03b8\u03b6\u03c7\u0394\u03a9\u03bb\u03c4\u03c2\u03a3.b[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.E("\u0530\u051d\u052c\u0516\u054a\u0510\u0514\u0537\u0558\u0547\u0546\u0554\u0540\u0560\u054f\u0521\u0535\u0516\u0517\u054e\u0565\u0556\u052d\u052e", (byte)30, 69);
                    continue block7;
                }
                case 2: {
                    \u03bc\u03c6\u03bb\u03ba\u03b6\u03a6\u03b8\u03b6\u03c7\u0394\u03a9\u03bb\u03c4\u03c2\u03a3.b[0] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.F("\u0534\u050b\u0512\u0541\u0558\u054f\u052d\u052a\u0528\u052d\u0537\u051b\u0527\u051b\u0561\u0519\u0550\u0521\u055f\u0563\u054f\u053a\u0539\u055e\u053d\u054b\u055e\u0568\u056a\u0540\u0550\u056f", (byte)30, 70);
                    continue block7;
                }
                case 4: {
                    \u03bc\u03c6\u03bb\u03ba\u03b6\u03a6\u03b8\u03b6\u03c7\u0394\u03a9\u03bb\u03c4\u03c2\u03a3.b[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.F("\u0521\u0554\u054f\u0516\u051f\u0554\u0542\u054b\u054c\u052d\u055a\u052b\u0548\u054c\u0536\u054f\u0536\u053f\u0565\u053f\u0526\u0552\u0556\u0525\u0569\u0559\u052d\u0557\u053c\u056d\u052a\u056f", (byte)30, 70);
                }
            }
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bc\u03c6\u03bb\u03ba\u03b6\u03a6\u03b8\u03b6\u03c7\u0394\u03a9\u03bb\u03c4\u03c2\u03a3.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.E("\u04f6\u0518\u051a\u04fa\u051e\u053d\u0535\u054b\u0537\u0506\u0544\u053a\u0548\u0542\u050b\u0530\u0552\u0551\u0549\u054f\u0549\u051e", (byte)18, 69), \u03bc\u03c6\u03bb\u03ba\u03b6\u03a6\u03b8\u03b6\u03c7\u0394\u03a9\u03bb\u03c4\u03c2\u03a3.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.F("\u0531\u053e\u053d\u0500\u0540\u053c\u0537\u0540\u054b\u053a\u0507\u0545\u0549\u0542\u0545\u054b\u050d\u089b\u08a6\u089c\u089c\u0899\u088a\u089d\u089c\u08ae\u087c\u0892\u08a5\u08af\u08ae\u0890\u0528", (byte)18, 70) + string + \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u0425", (byte)18, 67) + methodType.toString(), exception);
        }
    }

    @Generated
    public \u03bc\u03c6\u03bb\u03ba\u03b6\u03a6\u03b8\u03b6\u03c7\u0394\u03a9\u03bb\u03c4\u03c2\u03a3(\u03a6\u03c9\u03bf\u03c6\u03c5\u03b4\u03b9\u03c6\u03a3\u03a6 \u03c6\u03c9\u03bf\u03c6\u03c5\u03b4\u03b9\u03c6\u03a3\u03a6) {
        this.c = \u03c6\u03c9\u03bf\u03c6\u03c5\u03b4\u03b9\u03c6\u03a3\u03a6;
    }

    public void onPluginMessageReceived(@NotNull String string, Player player, byte[] byArray) {
        if (string.equals(\u03bc\u03c6\u03bb\u03ba\u03b6\u03a6\u03b8\u03b6\u03c7\u0394\u03a9\u03bb\u03c4\u03c2\u03a3.c("\u3e80", (int)a, (long)b))) {
            this.c.a(\u03a6\u03c9\u03bf\u03c6\u03c5\u03b4\u03b9\u03c6\u03a3\u03a6.a(this.c).b().a(player), byArray);
        }
    }

    static {
        b = Long.reverse(-2400931371821597229L);
        c = (2048 >>> 11 | 2048 << ~11 + 1) & 0xFFFFFFFF;
        d = (8192 >>> 237 | 8192 << -237) & 0xFFFFFFFF;
        a = new String[c];
        b = new String[d];
        \u03bc\u03c6\u03bb\u03ba\u03b6\u03a6\u03b8\u03b6\u03c7\u0394\u03a9\u03bb\u03c4\u03c2\u03a3.b();
    }

    private static String a(int n, long l) {
        l ^= 0x28L;
        l ^= 0x5E9BE637756FEFA5L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(66 + 2), (byte)(51 + 18), (byte)(10 + 73), (byte)(33 + 14), (byte)(58 + 9), (byte)(30 + 36), 67, (byte)(23 + 24), 80, (byte)(26 + 49), (byte)(43 + 24), (byte)(42 + 41), (byte)(14 + 39), (byte)(39 + 41), (byte)(89 + 8), (byte)(86 + 14), (byte)(33 + 67), (byte)(18 + 87), (byte)(10 + 100), (byte)(29 + 74)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(18 + 50), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u041b\u0428\u0427\u03ea\u042a\u0426\u0421\u042a\u0435\u0424\u03f1\u042f\u0433\u042c\u042f\u0435\u03f7\u0785\u0790\u0786\u0786\u0783\u0774\u0787\u0786\u0798\u0766\u077c\u078f\u0799\u0798\u077a", (byte)1, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bc\u03c6\u03bb\u03ba\u03b6\u03a6\u03b8\u03b6\u03c7\u0394\u03a9\u03bb\u03c4\u03c2\u03a3.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }
}

