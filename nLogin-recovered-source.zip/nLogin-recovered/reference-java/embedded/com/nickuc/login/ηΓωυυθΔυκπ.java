/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.nickuc.login.lib.hikari.HikariConfig
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.lib.hikari.HikariConfig;
import com.nickuc.login.\u0394\u03b3\u03a8\u03bd\u03c2\u03c7\u03b9\u03b4\u03ba\u03c4\u03c2\u03b5\u03c2;
import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a3\u03b4\u03c1\u0394\u03b6\u03b7\u03be\u03be;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6;
import com.nickuc.login.\u03a8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3;
import com.nickuc.login.\u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb;
import com.nickuc.login.\u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc;
import com.nickuc.login.\u03c0\u03a9\u03c6\u03a0\u03c5\u03b8\u03bb\u03bb\u03bb\u03b3\u03b1\u03c8;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03b2\u039b\u03c6\u03a8\u03a6\u03c6\u03b4\u03b1\u0394\u03b7\u03c0\u03c7\u03c2;
import com.nickuc.login.\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03b9\u03b3\u03c1\u03c4\u03a9\u03bb\u03b1\u03b3\u03c0\u03b2\u03c1;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Base64;
import java.util.Properties;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0 {
    private static int aj;
    private static long ab;
    private static int aa;
    private static String[] a;
    private static String[] b;
    private static long v;
    private static int u;
    private static int s;
    private static long f;
    private static long l;
    private static int w;
    private static int a;
    private static int ai;
    private static long x;
    private static int m;
    private static long g;
    private static long y;
    private static int af;
    private static int e;
    private static long b;
    private static int ad;
    private static int k;
    private static int z;
    private static int p;
    private static long q;
    private static int ah;
    private static long c;
    private static int j;
    private static long n;
    private static long t;
    private static int r;
    private static int ag;
    private static int h;
    private static int o;
    private static int ac;
    private static long i;
    private static long d;
    private static int ae;

    public static boolean a(\u03a8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2 \u03c8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2, String string) {
        Connection connection = \u03c8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2.a();
        try {
            boolean bl;
            block13: {
                boolean bl2;
                ResultSet resultSet = connection.getMetaData().getTables(connection.getCatalog(), null, (String)\u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.c("\u3e80", (int)(z & aa), (long)ab), null);
                try {
                    while (resultSet.next()) {
                        if (!resultSet.getString(ac).equalsIgnoreCase(string)) continue;
                        bl2 = ad;
                        if (resultSet == null) break block12;
                    }
                }
                catch (Throwable throwable) {
                    if (resultSet != null) {
                        try {
                            resultSet.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                {
                    block12: {
                        resultSet.close();
                    }
                    return bl2;
                }
                bl = ae;
                if (resultSet == null) break block13;
                resultSet.close();
            }
            return bl;
        }
        finally {
            \u03c8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2.a(connection);
        }
    }

    static {
        a = 0 >>> 215 | 0 << ~215 + 1;
        b = Long.reverse(-1023000667195002521L);
        d = Long.reverse(-5044031582654955520L);
        e = (0x4000000 >>> 186 | 0x4000000 << ~186 + 1) & 0xFFFFFFFF;
        f = Long.reverse(-1023000667195002521L);
        g = Long.reverse(-5044031582654955520L);
        h = Integer.reverse(0x40000000);
        i = Long.reverse(5462182796218511719L);
        j = Integer.reverse(-1073741824);
        k = -1 >>> 214 | -1 << -214;
        l = Long.reverse(5462182796218511719L);
        m = (4 >>> 128 | 4 << -128) & 0xFFFFFFFF;
        n = Long.reverse(5462182796218511719L);
        o = (0x50000000 >>> 188 | 0x50000000 << -188) & 0xFFFFFFFF;
        p = Integer.reverse(-1);
        q = Long.reverse(5462182796218511719L);
        r = Integer.reverse(0x60000000);
        s = -1 >>> 194 | -1 << ~194 + 1;
        t = Long.reverse(5462182796218511719L);
        u = (0xE00000 >>> 181 | 0xE00000 << -181) & 0xFFFFFFFF;
        v = Long.reverse(5462182796218511719L);
        w = 65536 >>> 237 | 65536 << ~237 + 1;
        x = Long.reverse(-1023000667195002521L);
        y = Long.reverse(-5044031582654955520L);
        z = Integer.reverse(-1879048192);
        aa = (-1 >>> 37 | -1 << ~37 + 1) & 0xFFFFFFFF;
        ab = Long.reverse(5462182796218511719L);
        ac = 0x180000 >>> 51 | 0x180000 << -51;
        ad = 4096 >>> 44 | 4096 << ~44 + 1;
        ae = Integer.reverse(0);
        af = 8192 >>> 77 | 8192 << ~77 + 1;
        ag = (0x400000 >>> 182 | 0x400000 << ~182 + 1) & 0xFFFFFFFF;
        ah = Integer.reverse(0);
        ai = Integer.reverse(0x50000000);
        aj = 0x50000000 >>> 187 | 0x50000000 << ~187 + 1;
        a = new String[ai];
        b = new String[aj];
        \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b();
    }

    public static \u0394\u03b3\u03a8\u03bd\u03c2\u03c7\u03b9\u03b4\u03ba\u03c4\u03c2\u03b5\u03c2 a(\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2 \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22, \u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3 \u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a32) {
        Properties properties = new Properties();
        String string = \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.b(\u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.c("\u3e80", (int)(j & k), (long)l));
        String string2 = \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.b(\u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.c("\u3e83", (int)m, (long)n));
        String string3 = \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.b(\u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.c("\u3e86", (int)(o & p), (long)q));
        String string4 = \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.b(\u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.c("\u3e89", (int)(r & s), (long)t));
        for (String string5 : \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.a((String)\u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.c("\u3e8c", (int)u, (long)v))) {
            String string6 = \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.b((String)\u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.c("\u3e8f", (int)w, (long)(x ^ y)) + string5);
            properties.setProperty(string5, string6);
        }
        return \u0394\u03b3\u03a8\u03bd\u03c2\u03c7\u03b9\u03b4\u03ba\u03c4\u03c2\u03b5\u03c2.a(string, string2, string3, string4, properties, \u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a32.i());
    }

    private static String a(int n, long l) {
        l ^= 0x5DL;
        l ^= 0xF8EE2FE93807FFF6L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(33 + 35), (byte)(24 + 45), (byte)(78 + 5), (byte)(43 + 4), (byte)(50 + 17), (byte)(34 + 32), (byte)(56 + 11), (byte)(44 + 3), (byte)(32 + 48), (byte)(46 + 29), (byte)(11 + 56), (byte)(73 + 10), (byte)(27 + 26), (byte)(65 + 15), 97, (byte)(69 + 31), 100, (byte)(2 + 103), (byte)(15 + 95), (byte)(49 + 54)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(21 + 47), 69, 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.E("\u059d\u05aa\u05a9\u056c\u05ac\u05a8\u05a3\u05ac\u05b7\u05a6\u0573\u05b1\u05b5\u05ae\u05b1\u05b7\u0579\u0902\u08df\u0916\u0913\u0914\u0908\u08e5\u0917\u090d\u0914", (byte)126, 69));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    private static void b() {
        int n;
        c = -1833709091121679473L;
        long l = c ^ 0xF8EE2FE93807FFF6L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(42 + 26), (byte)(47 + 22), 83, (byte)(43 + 4), (byte)(45 + 22), (byte)(16 + 50), (byte)(9 + 58), 47, (byte)(42 + 38), (byte)(37 + 38), (byte)(36 + 31), (byte)(27 + 56), (byte)(32 + 21), (byte)(44 + 36), (byte)(92 + 5), (byte)(12 + 88), (byte)(19 + 81), (byte)(61 + 44), (byte)(95 + 15), (byte)(93 + 10)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(10 + 58), 69, (byte)(63 + 20)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[0] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.A("\u00d9\u00da\u00ce\u00d2\u00e2\u00f8\u0102\u00f3\u0101\u00e2\u0104\u0107\u00fc\u00ea\u00ca\u00c3\u0113\u00e2\u00f4\u0110\u0113\u0115\u00dc\u00dd", (byte)5, 65);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[1] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0538\u04f9\u053a\u0508\u050f\u0534\u053f\u0534\u0533\u051a\u0538\u0545\u0513\u0540\u04fa\u0517\u0535\u0547\u0523\u0503\u0537\u053d\u0514\u0515", (byte)5, 70);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[2] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.E("\u0527\u051b\u0533\u0529\u04f6\u04fc\u0510\u04fe\u0514\u0540\u0542\u050d\u0502\u0522\u0546\u0548\u0528\u0504\u0502\u051e\u0505\u052a\u0506\u051c\u0525\u0512\u054f\u050d\u0545\u0526\u0549\u0535\u050c\u0555\u0533\u053a\u0550\u053a\u053d\u055a\u054c\u0553\u0562\u0529", (byte)5, 69);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[3] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.C("\u0428\u0434\u03f7\u0439\u040a\u043c\u03ff\u042f\u03f7\u0440\u03fe\u0415\u0406\u041d\u041b\u040c\u0418\u044a\u0406\u042e\u0448\u0421\u044b\u0431\u0430\u040c\u0449\u0428\u0426\u0416\u0449\u0452\u043e\u0451\u0416\u041c\u044e\u0438\u042f\u044d\u041f\u0442\u042f\u042c", (byte)5, 67);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[4] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.D("\u0428\u0434\u03f7\u0439\u040a\u043c\u03ff\u042f\u03f7\u0440\u03fe\u0415\u0406\u041d\u041b\u040c\u0418\u044a\u0406\u042e\u0448\u041a\u0446\u042a\u0421\u0457\u042e\u0424\u0423\u0437\u0429\u0437\u0419\u0437\u045b\u0417\u0457\u041d\u045c\u042f\u0444\u044e\u0433\u042c", (byte)5, 68);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[5] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.C("\u0428\u0434\u03f7\u0439\u040a\u043c\u03ff\u042f\u03f7\u0440\u03fe\u0415\u0406\u041d\u041b\u040c\u0418\u044a\u0406\u042e\u0448\u0428\u044d\u0455\u0440\u0429\u0451\u0453\u0410\u0413\u0446\u042d\u044e\u0416\u042b\u0428\u043c\u045f\u041e\u042e\u0420\u0457\u043f\u042c", (byte)5, 67);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[6] = \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.E("\u0525\u0531\u04f4\u0536\u0507\u0539\u04fc\u052c\u04f4\u053d\u04fb\u0512\u0503\u051a\u0518\u0509\u0515\u0547\u0503\u052b\u0545\u0518\u0529\u051b\u0551\u0525\u0545\u0511\u0516\u0520\u0551\u0531\u0559\u053b\u052b\u0530\u055d\u053a\u0551\u051f\u0539\u054b\u055a\u0529", (byte)5, 69);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[7] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.F("\u0525\u0531\u04f4\u0536\u0507\u0539\u04fc\u052c\u04f4\u053d\u04fb\u0512\u0503\u051a\u0518\u0509\u0515\u0547\u0503\u052b\u0545\u0518\u052c\u051b\u051f\u052b\u054d\u0507\u0541\u0553\u0534\u050f\u051a\u051b\u0551\u055d\u0515\u052c\u0531\u052d\u0543\u053b\u051f\u0529", (byte)5, 70);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[8] = \u03bf\u03b3\u03bf\u0394\u03b9\u03c2\u0394\u03b1\u03b6\u03b6\u03c2\u03bb.A("\u00ed\u00f9\u00bc\u00fe\u00cf\u0101\u00c4\u00f4\u00bc\u0105\u00c3\u00da\u00cb\u00e2\u00e0\u00d1\u00dd\u010f\u00cb\u00f3\u010d\u00e0\u00f4\u00e3\u00e7\u00f3\u0115\u00cf\u0109\u011b\u00fc\u00d7\u00f6\u00dd\u0110\u0113\u0124\u011e\u00f2\u00fa\u0105\u00f4\u0100\u00f1", (byte)5, 65);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[9] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.B("\u00dc\u00eb\u00dc\u00f0\u00bd\u00d7\u00e0\u00e5\u00da\u0101\u00c3\u00d1", (byte)5, 66);
                    continue block7;
                }
                case 1: {
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.C("\u0414\u0415\u0409\u040d\u041d\u0433\u043d\u042e\u043c\u041d\u0440\u0437\u041d\u041b\u03fd\u0407\u03ff\u0420\u041b\u0438\u040a\u0440\u0417\u0418", (byte)5, 67);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[1] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.D("\u043b\u03fc\u043d\u040b\u0412\u0437\u0442\u0437\u0436\u041d\u043c\u0410\u0445\u041e\u043c\u0438\u0428\u0420\u041a\u042c\u0449\u0427\u0411\u042b\u0423\u0443\u0456\u0433\u0426\u044d\u0431\u0451", (byte)5, 68);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[2] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.F("\u0527\u051b\u0533\u0529\u04f6\u04fc\u0510\u04fe\u0514\u0540\u0542\u050d\u0502\u0522\u0546\u0548\u0528\u0504\u0502\u051e\u0505\u052a\u0506\u051c\u0525\u0512\u054f\u050d\u0545\u0526\u0549\u0535\u055b\u0536\u0529\u053b\u0514\u0550\u055c\u055b\u0553\u0519\u055a\u0529", (byte)5, 70);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[3] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.C("\u0428\u0434\u03f7\u0439\u040a\u043c\u03ff\u042f\u03f7\u0440\u03fe\u0415\u0406\u041d\u041b\u040c\u0418\u044a\u0406\u042e\u0448\u0421\u044b\u0431\u0430\u040c\u0449\u0428\u0426\u0416\u0449\u0452\u045b\u044d\u043f\u0419\u0419\u0459\u0415\u0453\u0461\u0424\u042f\u042c", (byte)5, 67);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[4] = \u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.E("\u0525\u0531\u04f4\u0536\u0507\u0539\u04fc\u052c\u04f4\u053d\u04fb\u0512\u0503\u051a\u0518\u0509\u0515\u0547\u0503\u052b\u0545\u0517\u0543\u0527\u051e\u0554\u052b\u0521\u0520\u0534\u0526\u0534\u0554\u0544\u053c\u051d\u0550\u055c\u0558\u053f\u0559\u0544\u053c\u0529", (byte)5, 69);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[5] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.A("\u00ed\u00f9\u00bc\u00fe\u00cf\u0101\u00c4\u00f4\u00bc\u0105\u00c3\u00da\u00cb\u00e2\u00e0\u00d1\u00dd\u010f\u00cb\u00f3\u010d\u00ed\u0112\u011a\u0105\u00ee\u0116\u0118\u00d5\u00d8\u010b\u00f2\u00f7\u00e3\u0124\u00d7\u011f\u00e3\u0108\u0112\u00e3\u0120\u0104\u00f1", (byte)5, 65);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[6] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u0428\u0434\u03f7\u0439\u040a\u043c\u03ff\u042f\u03f7\u0440\u03fe\u0415\u0406\u041d\u041b\u040c\u0418\u044a\u0406\u042e\u0448\u041b\u042c\u041e\u0454\u0428\u0448\u0414\u0419\u0423\u0454\u0434\u044e\u0435\u0429\u0438\u0462\u0462\u043b\u0450\u0421\u0439\u0455\u042c", (byte)5, 68);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[7] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.C("\u0428\u0434\u03f7\u0439\u040a\u043c\u03ff\u042f\u03f7\u0440\u03fe\u0415\u0406\u041d\u041b\u040c\u0418\u044a\u0406\u042e\u0448\u041b\u042f\u041e\u0422\u042e\u0450\u040a\u0444\u0456\u0437\u0412\u042e\u043d\u0450\u0417\u041e\u0433\u045e\u0454\u044f\u044f\u0422\u042c", (byte)5, 67);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[8] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.B("\u00ed\u00f9\u00bc\u00fe\u00cf\u0101\u00c4\u00f4\u00bc\u0105\u00c3\u00da\u00cb\u00e2\u00e0\u00d1\u00dd\u010f\u00cb\u00f3\u010d\u00e0\u00f4\u00e3\u00e7\u00f3\u0115\u00cf\u0109\u011b\u00fc\u00d7\u00d4\u0123\u00d6\u011c\u0106\u00f3\u00fc\u00df\u0102\u0101\u00f4\u00f1", (byte)5, 66);
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[9] = \u03b9\u0394\u03c3\u039b\u03c9\u03c3\u03c0\u03c3\u03bc\u03b8\u03a8.E("\u04f9\u0508\u051c\u0533\u051c\u04fb\u04f6\u0517\u050b\u052b\u04ff\u0509", (byte)5, 69);
                    continue block7;
                }
                case 2: {
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[0] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.C("\u040b\u041b\u03fc\u041f\u03fb\u042b\u043a\u043b\u0436\u0437\u0416\u0426\u0435\u0425\u0409\u0440\u0437\u0426\u040b\u044e\u0411\u0429\u044b\u0413\u0414\u042f\u0449\u0458\u0415\u0423\u0427\u0459", (byte)5, 67);
                    continue block7;
                }
                case 4: {
                    \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.b[0] = \u03b4\u0394\u03bd\u03bb\u039b\u03b3\u03b2\u03b5\u03c0\u03b3\u03c3.F("\u0531\u0510\u0539\u052c\u0539\u053f\u0515\u051b\u04f4\u0530\u04ff\u0509", (byte)5, 70);
                }
            }
        }
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.B("\u0141\u0163\u0165\u0145\u0169\u0188\u0180\u0196\u0182\u0151\u018f\u0185\u0193\u018d\u0156\u017b\u019d\u019c\u0194\u019a\u0194\u0169", (byte)77, 66), \u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u04ff\u050c\u050b\u04ce\u050e\u050a\u0505\u050e\u0519\u0508\u04d5\u0513\u0517\u0510\u0513\u0519\u04db\u0864\u0841\u0878\u0875\u0876\u086a\u0847\u0879\u086f\u0876\u04f1", (byte)77, 67) + string + \u03bf\u03c7\u03b6\u03c5\u03b8\u03b9\u03b9\u03b3\u03bc.A("\u0153", (byte)77, 65) + methodType.toString(), exception);
        }
    }

    public static boolean a(\u03a8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2 \u03c8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2, String string, String string2) {
        Connection connection = \u03c8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2.a();
        try {
            boolean bl;
            block9: {
                ResultSet resultSet = connection.getMetaData().getColumns(connection.getCatalog(), null, string, string2);
                try {
                    bl = resultSet.next();
                    if (resultSet == null) break block9;
                }
                catch (Throwable throwable) {
                    if (resultSet != null) {
                        try {
                            resultSet.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                resultSet.close();
            }
            return bl;
        }
        finally {
            \u03c8\u03b4\u03a8\u03be\u03be\u03bf\u03b6\u03b5\u03a6\u03b5\u03c2\u03bd\u03b4\u03c2.a(connection);
        }
    }

    public static \u03c0\u03b2\u039b\u03c6\u03a8\u03a6\u03c6\u03b4\u03b1\u0394\u03b7\u03c0\u03c7\u03c2 a(\u03a8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6 \u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a3 \u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a32, \u0394\u03b3\u03a8\u03bd\u03c2\u03c7\u03b9\u03b4\u03ba\u03c4\u03c2\u03b5\u03c2 \u03b4\u03b3\u03a8\u03bd\u03c2\u03c7\u03b9\u03b4\u03ba\u03c4\u03c2\u03b5\u03c2, @Nullable Consumer<HikariConfig> consumer) {
        if (!\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a32.aa()) {
            throw new IllegalArgumentException((String)\u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.c("\u3e80", (int)a, (long)(b ^ d)) + (Object)((Object)\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a32) + (String)\u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.c("\u3e83", (int)e, (long)(f ^ g)));
        }
        switch (\u03c0\u03a9\u03c6\u03a0\u03c5\u03b8\u03bb\u03bb\u03bb\u03b3\u03b1\u03c8.h[\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a32.ordinal()]) {
            case 1: {
                return \u03a3\u03b4\u03c1\u0394\u03b6\u03b7\u03be\u03be.a(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03b4\u03b3\u03a8\u03bd\u03c2\u03c7\u03b9\u03b4\u03ba\u03c4\u03c2\u03b5\u03c2, consumer);
            }
            case 2: {
                return \u03c2\u03b9\u03b3\u03c1\u03c4\u03a9\u03bb\u03b1\u03b3\u03c0\u03b2\u03c1.a(\u03c8\u03b3\u03b7\u03bc\u03b9\u03b4\u03be\u0393\u03c4\u03bf\u03b8\u03b1\u03b6, \u03b4\u03b3\u03a8\u03bd\u03c2\u03c7\u03b9\u03b4\u03ba\u03c4\u03c2\u03b5\u03c2, consumer);
            }
        }
        throw new IllegalArgumentException((String)\u03b7\u0393\u03c9\u03c5\u03c5\u03b8\u0394\u03c5\u03ba\u03c0.c("\u3e86", (int)h, (long)i) + (Object)((Object)\u03c1\u03a3\u03c0\u03c0\u03bc\u03b6\u03b8\u03bc\u03c0\u03bd\u03bf\u03a32));
    }

    public static boolean a(ResultSet resultSet, String string) {
        ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
        int n = resultSetMetaData.getColumnCount();
        for (int i = af; i <= n; ++i) {
            if (!string.equals(resultSetMetaData.getColumnName(i))) continue;
            return ag != 0;
        }
        return ah != 0;
    }
}

