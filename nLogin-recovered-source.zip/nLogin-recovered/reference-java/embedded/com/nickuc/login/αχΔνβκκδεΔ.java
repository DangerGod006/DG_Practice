/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.velocitypowered.api.proxy.messages.ChannelIdentifier
 *  com.velocitypowered.api.proxy.messages.LegacyChannelIdentifier
 *  com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393;
import com.nickuc.login.\u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be;
import com.nickuc.login.\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9;
import com.nickuc.login.\u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.nickuc.login.\u03c9\u03a9\u03a9\u03b1\u03bf\u03bc\u03bf\u03a3\u03c8\u03a9;
import com.nickuc.login.\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3;
import com.velocitypowered.api.proxy.messages.ChannelIdentifier;
import com.velocitypowered.api.proxy.messages.LegacyChannelIdentifier;
import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394
extends \u03be\u03c5\u03bd\u03be\u03b2\u03bc\u03c7\u03b5<\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9> {
    private static long al;
    private static int m;
    private static String[] c;
    private static int ae;
    private static int an;
    private static int p;
    private static long h;
    private static long ah;
    private static long ac;
    private static int ao;
    private static long ai;
    private static int aa;
    private static int y;
    private static int aj;
    private static int s;
    private static long o;
    private static long n;
    private static int z;
    private static int ap;
    private static long e;
    private static int ad;
    private static int b;
    private static int q;
    private static int ag;
    private static int r;
    private static long f;
    private static String[] d;
    private static int am;
    private static int ab;
    private static long w;
    private static long v;
    private static int af;
    private static long t;
    private static long ak;
    private static int u;
    private static int x;

    @Override
    public void b(Object object) {
        this.a(object, null);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c9\u03c8\u03b3\u03b7\u03bd\u03be\u03bb\u03b4\u03a8\u03c7\u03a3.A("\u0173\u0195\u0197\u0177\u019b\u01ba\u01b2\u01c8\u01b4\u0183\u01c1\u01b7\u01c5\u01bf\u0188\u01ad\u01cf\u01ce\u01c6\u01cc\u01c6\u019b", (byte)102, 65), \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.A("\u01ae\u01bb\u01ba\u017d\u01bd\u01b9\u01b4\u01bd\u01c8\u01b7\u0184\u01c2\u01c6\u01bf\u01c2\u01c8\u018a\u050d\u0524\u04f2\u051c\u0512\u051b\u051c\u0517\u0519\u04f9\u01a0", (byte)102, 65) + string + \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.F("\u055c", (byte)102, 70) + methodType.toString(), exception);
        }
    }

    public \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394(\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9 \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a92) {
        super(\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a92);
    }

    @Override
    public void a(Object object, Object object2) {
        ChannelIdentifier channelIdentifier;
        if (object2 != null && !(object2 instanceof \u03c9\u03a9\u03a9\u03b1\u03bf\u03bc\u03bf\u03a3\u03c8\u03a9)) {
            throw new IllegalArgumentException((String)\u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.c("\u3e80", (int)b, (long)(f ^ h)) + object2.getClass().getCanonicalName());
        }
        if (object instanceof String) {
            String string = (String)object;
            String[] stringArray = string.split((String)\u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.c("\u3e83", (int)m, (long)(n ^ o)));
            channelIdentifier = stringArray.length == p ? MinecraftChannelIdentifier.create((String)stringArray[q], (String)stringArray[r]) : new LegacyChannelIdentifier(string);
        } else if (object instanceof ChannelIdentifier) {
            channelIdentifier = (ChannelIdentifier)object;
        } else {
            throw new IllegalArgumentException((String)\u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.c("\u3e86", (int)s, (long)t) + object + (String)\u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.c("\u3e89", (int)u, (long)(v ^ w)) + object.getClass().getCanonicalName());
        }
        ChannelIdentifier[] channelIdentifierArray = new ChannelIdentifier[x];
        channelIdentifierArray[\u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.y] = channelIdentifier;
        ((\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9)this.h).a().getChannelRegistrar().register(channelIdentifierArray);
        if (object2 != null) {
            ((\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9)this.h).a((\u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393)object2, new \u03bc\u0393\u03bc\u03c1\u03a8\u03c0\u03b6\u03bd\u03b9\u03c6\u03c6\u03b2\u03a9\u039b\u0393[z]);
        }
    }

    private static void b() {
        int n;
        e = -8045332613857315897L;
        long l = e ^ 0x6E8C8D7AD1947454L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(18 + 50), 69, (byte)(51 + 32), (byte)(22 + 25), (byte)(53 + 14), (byte)(34 + 32), (byte)(50 + 17), (byte)(38 + 9), (byte)(15 + 65), (byte)(45 + 30), (byte)(31 + 36), (byte)(78 + 5), (byte)(30 + 23), (byte)(60 + 20), 97, (byte)(45 + 55), (byte)(63 + 37), (byte)(45 + 60), (byte)(18 + 92), (byte)(5 + 98)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(12 + 71)}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[0] = \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.F("\u0501\u0511\u0533\u0528\u0520\u054c\u0518\u0518\u053a\u052a\u0507\u0543\u0541\u050d\u052b\u050e\u0542\u0545\u0554\u054b\u0530\u050d\u052e\u055d\u053a\u0540\u0549\u055a\u0558\u051d\u0535\u0557", (byte)17, 70);
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[1] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u00d3\u0119\u00ed\u00fc\u00e6\u00de\u00f7\u00fb\u00f1\u011d\u00f8\u00e9", (byte)17, 65);
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[2] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.E("\u0501\u0511\u0533\u0528\u0520\u054c\u0518\u0518\u053a\u052a\u0509\u053d\u0551\u0550\u0527\u054b\u0532\u054c\u0552\u0541\u0514\u0531\u053b\u052b\u0510\u051d\u0559\u0521\u054c\u052d\u0535\u054f\u0558\u0551\u055e\u0538\u0525\u0528\u052a\u0538\u052e\u0546\u052f\u0535", (byte)17, 69);
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[3] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u043b\u0431\u044d\u0437\u044e\u0425\u0455\u0434\u0423\u0422\u0433\u0430", (byte)17, 67);
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[4] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.B("\u00d3\u0119\u00ed\u00fc\u00e6\u00de\u00f7\u00fb\u00f1\u011d\u00f8\u00e9", (byte)17, 66);
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[5] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.D("\u041c\u042c\u044e\u0443\u043b\u0467\u0433\u0433\u0455\u0445\u0424\u0458\u046c\u046b\u0442\u0466\u044d\u0467\u046d\u045c\u042f\u044c\u0456\u0446\u042b\u0438\u0474\u043c\u0467\u0448\u0450\u046a\u0473\u046c\u0479\u0453\u0440\u0443\u0445\u0453\u0449\u0461\u044a\u0450", (byte)17, 68);
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[6] = \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.C("\u043b\u0431\u044d\u0437\u044e\u0425\u0455\u0434\u0423\u0422\u0433\u0430", (byte)17, 67);
                    continue block7;
                }
                case 1: {
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[0] = \u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.E("\u0501\u0511\u0533\u0528\u0520\u054c\u0518\u0518\u053a\u052a\u0507\u0543\u0541\u050d\u052b\u050e\u0542\u0545\u0554\u054b\u0530\u0516\u0528\u052f\u0536\u052e\u0551\u055c\u0518\u0550\u0523\u0545", (byte)17, 69);
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[1] = \u03bd\u03b1\u03bf\u03a9\u03c2\u03a3\u03b6\u03c7\u03c8\u03bc\u03be.F("\u0534\u0538\u04fe\u0536\u0541\u0526\u0543\u054e\u054d\u0509\u0524\u0515", (byte)17, 70);
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[2] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.E("\u0501\u0511\u0533\u0528\u0520\u054c\u0518\u0518\u053a\u052a\u0509\u053d\u0551\u0550\u0527\u054b\u0532\u054c\u0552\u0541\u0514\u0531\u053b\u052b\u0510\u051d\u0559\u0521\u054c\u052d\u0535\u054f\u0546\u0521\u0560\u055b\u0538\u0569\u0522\u053d\u056f\u052c\u056b\u056a\u053c\u055b\u0545\u052d\u0550\u0552\u0547\u0577\u0531\u0553\u0540\u0541", (byte)17, 69);
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[3] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u00ec\u00f4\u00f7\u0106\u00fa\u00dc\u0110\u00f7\u00fc\u00ed\u0116\u00e9", (byte)17, 65);
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[4] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.A("\u0118\u00ed\u00ee\u010d\u0106\u011f\u00f0\u00dd\u0123\u00eb\u011e\u00e9", (byte)17, 65);
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[5] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.A("\u00d5\u00e5\u0107\u00fc\u00f4\u0120\u00ec\u00ec\u010e\u00fe\u00dd\u0111\u0125\u0124\u00fb\u011f\u0106\u0120\u0126\u0115\u00e8\u0105\u010f\u00ff\u00e4\u00f1\u012d\u00f5\u0120\u0101\u0109\u0123\u012e\u011b\u0137\u0137\u013c\u0136\u0134\u0111\u0117\u0131\u00fc\u013e\u0105\u0121\u0115\u0136\u0102\u0107\u011b\u011b\u0126\u0117\u0114\u0115", (byte)17, 65);
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[6] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.B("\u011b\u0103\u00e6\u00f6\u0116\u00fc\u00db\u00f1\u010c\u010b\u011e\u00e9", (byte)17, 66);
                    continue block7;
                }
                case 2: {
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[0] = \u03c1\u03ba\u03b1\u03b7\u03a6\u03b6\u03bb\u03c1\u03c7.B("\u00e5\u00ea\u00ce\u0114\u0116\u0115\u00eb\u0113\u00fd\u00e3\u010e\u00e4\u011a\u0102\u00ff\u00ff\u00fa\u0125\u00e9\u00f9\u0109\u011d\u00f4\u00f5", (byte)17, 66);
                    continue block7;
                }
                case 4: {
                    \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.d[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u041f\u0439\u043d\u042d\u0445\u0465\u0444\u0448\u0462\u0459\u0426\u0430", (byte)17, 68);
                }
            }
        }
    }

    private static String a(int n, long l) {
        l ^= 0x4FL;
        l ^= 0x6E8C8D7AD1947454L;
        if (c[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(52 + 16), (byte)(12 + 57), (byte)(12 + 71), 47, (byte)(55 + 12), (byte)(16 + 50), (byte)(55 + 12), (byte)(5 + 42), (byte)(28 + 52), (byte)(13 + 62), (byte)(48 + 19), (byte)(70 + 13), (byte)(33 + 20), 80, (byte)(31 + 66), (byte)(43 + 57), (byte)(47 + 53), (byte)(101 + 4), (byte)(109 + 1), (byte)(41 + 62)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(18 + 51), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.D("\u050b\u0518\u0517\u04da\u051a\u0516\u0511\u051a\u0525\u0514\u04e1\u051f\u0523\u051c\u051f\u0525\u04e7\u086a\u0881\u084f\u0879\u086f\u0878\u0879\u0874\u0876\u0856", (byte)81, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.c[n] = new String(cipher.doFinal(Base64.getDecoder().decode(d[n])), StandardCharsets.UTF_8);
        }
        return c[n];
    }

    @Override
    public void c(Object object) {
        ChannelIdentifier channelIdentifier;
        if (object instanceof String) {
            String string = (String)object;
            String[] stringArray = string.split((String)\u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.c("\u3e80", (int)(aa & ab), (long)ac));
            channelIdentifier = stringArray.length == ad ? MinecraftChannelIdentifier.create((String)stringArray[ae], (String)stringArray[af]) : new LegacyChannelIdentifier(string);
        } else if (object instanceof ChannelIdentifier) {
            channelIdentifier = (ChannelIdentifier)object;
        } else {
            throw new IllegalArgumentException((String)\u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.c("\u3e83", (int)ag, (long)(ah ^ ai)) + object + (String)\u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.c("\u3e86", (int)aj, (long)(ak ^ al)) + object.getClass().getCanonicalName());
        }
        ChannelIdentifier[] channelIdentifierArray = new ChannelIdentifier[am];
        channelIdentifierArray[\u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.an] = channelIdentifier;
        ((\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9)this.h).a().getChannelRegistrar().unregister(channelIdentifierArray);
    }

    static {
        b = (0 >>> 167 | 0 << ~167 + 1) & 0xFFFFFFFF;
        f = Long.reverse(-2031452354611734007L);
        h = Long.reverse(-1008806316530991104L);
        m = Integer.reverse(Integer.MIN_VALUE);
        n = Long.reverse(-2031452354611734007L);
        o = Long.reverse(-1008806316530991104L);
        p = 0x2000000 >>> 248 | 0x2000000 << ~248 + 1;
        q = Integer.reverse(0);
        r = Integer.reverse(Integer.MIN_VALUE);
        s = Integer.reverse(0x40000000);
        t = Long.reverse(1283196971132951049L);
        u = (1536 >>> 9 | 1536 << ~9 + 1) & 0xFFFFFFFF;
        v = Long.reverse(-2031452354611734007L);
        w = Long.reverse(-1008806316530991104L);
        x = 16384 >>> 174 | 16384 << ~174 + 1;
        y = (0 >>> 46 | 0 << -46) & 0xFFFFFFFF;
        z = 0 >>> 35 | 0 << ~35 + 1;
        aa = (4096 >>> 74 | 4096 << -74) & 0xFFFFFFFF;
        ab = (-1 >>> 252 | -1 << ~252 + 1) & 0xFFFFFFFF;
        ac = Long.reverse(1283196971132951049L);
        ad = (0x200000 >>> 84 | 0x200000 << -84) & 0xFFFFFFFF;
        ae = (0 >>> 192 | 0 << ~192 + 1) & 0xFFFFFFFF;
        af = (0x20000000 >>> 93 | 0x20000000 << ~93 + 1) & 0xFFFFFFFF;
        ag = 0x500000 >>> 84 | 0x500000 << -84;
        ah = Long.reverse(-2031452354611734007L);
        ai = Long.reverse(-1008806316530991104L);
        aj = Integer.reverse(0x60000000);
        ak = Long.reverse(-2031452354611734007L);
        al = Long.reverse(-1008806316530991104L);
        am = Integer.reverse(Integer.MIN_VALUE);
        an = 0 >>> 180 | 0 << -180;
        ao = Integer.reverse(-536870912);
        ap = Integer.reverse(-536870912);
        c = new String[ao];
        d = new String[ap];
        \u03b1\u03c7\u0394\u03bd\u03b2\u03ba\u03ba\u03b4\u03b5\u0394.b();
    }
}

