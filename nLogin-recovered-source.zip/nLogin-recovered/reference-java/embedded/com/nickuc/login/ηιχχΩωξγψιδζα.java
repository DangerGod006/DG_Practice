/*
 * Decompiled with CFR 0.152.
 */
package com.nickuc.login;

import com.nickuc.login.\u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9;
import com.nickuc.login.\u03c2\u03bc\u03ba\u0394\u03a3\u03b9\u03b6\u03c1\u039b\u03be\u03a8\u03b9\u03b8\u03c6\u03a0;

public class \u03b7\u03b9\u03c7\u03c7\u03a9\u03c9\u03be\u03b3\u03c8\u03b9\u03b4\u03b6\u03b1 {
    private static \u03c2\u03bc\u03ba\u0394\u03a3\u03b9\u03b6\u03c1\u039b\u03be\u03a8\u03b9\u03b8\u03c6\u03a0 a;

    static \u03c2\u03bc\u03ba\u0394\u03a3\u03b9\u03b6\u03c1\u039b\u03be\u03a8\u03b9\u03b8\u03c6\u03a0 a() {
        return a;
    }

    static {
        try {
            a = new \u03b6\u03a0\u03a8\u03b8\u03bc\u03b4\u03bc\u03b8\u03b3\u03ba\u03a3\u03b7\u03c9();
        }
        catch (ReflectiveOperationException reflectiveOperationException) {
            // empty catch block
        }
        if (a == null) {
            a = (player, string) -> {};
        }
    }
}

