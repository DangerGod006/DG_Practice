/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.velocitypowered.api.plugin.PluginContainer
 *  com.velocitypowered.api.plugin.PluginDescription
 *  com.velocitypowered.api.proxy.ProxyServer
 *  javax.annotation.Nullable
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2;
import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u03a3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a8;
import com.nickuc.login.\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9;
import com.nickuc.login.\u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c9\u0394\u03c4\u03b6\u03c7\u03b9\u03b1\u03c5\u0394\u03c4;
import com.nickuc.login.\u03c9\u039b\u03c3\u03a6\u0394\u03c4\u03b2\u03c9\u03c5\u03c5\u03c4\u03b8\u03b8\u0393\u03c5;
import com.velocitypowered.api.plugin.PluginContainer;
import com.velocitypowered.api.plugin.PluginDescription;
import com.velocitypowered.api.proxy.ProxyServer;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Collection;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03a0\u03b5\u03b7\u03a0\u03b3\u03b1\u03c2\u03b3\u03c4\u03b6\u03bb\u03c7\u03c6\u03be
implements \u03c9\u0394\u03c4\u03b6\u03c7\u03b9\u03b1\u03c5\u0394\u03c4 {
    private static int g;
    private static int f;
    private static long e;
    private static int a;
    private static String[] b;
    private final \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9 d;
    private final \u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a8 c;
    private static long d;
    private static long c;
    private static int b;
    private static String[] a;
    private final ProxyServer e;

    @Override
    public \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 a(UUID uUID) {
        return this.e.getPlayer(uUID).map(this::a).orElse(null);
    }

    private static String a(int n, long l) {
        l ^= 0x6FL;
        l ^= 0xBAE6773591BB0229L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(57 + 11), (byte)(39 + 30), 83, (byte)(14 + 33), (byte)(34 + 33), (byte)(35 + 31), (byte)(42 + 25), (byte)(32 + 15), (byte)(38 + 42), (byte)(67 + 8), (byte)(7 + 60), (byte)(67 + 16), 53, (byte)(51 + 29), (byte)(83 + 14), (byte)(87 + 13), (byte)(11 + 89), (byte)(29 + 76), (byte)(86 + 24), (byte)(93 + 10)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(28 + 40), (byte)(25 + 44), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.D("\u0430\u043d\u043c\u03ff\u043f\u043b\u0436\u043f\u044a\u0439\u0406\u0444\u0448\u0441\u0444\u044a\u040c\u077e\u0794\u0797\u0781\u0795\u0794\u07a6\u0798\u07aa\u079d\u07a3\u07b0\u07b0\u07a9", (byte)8, 68));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03a0\u03b5\u03b7\u03a0\u03b3\u03b1\u03c2\u03b3\u03c4\u03b6\u03bb\u03c7\u03c6\u03be.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    static {
        a = Integer.reverse(0);
        b = 0 >>> 168 | 0 << ~168 + 1;
        d = Long.reverse(6503928490126306317L);
        e = Long.reverse(-720575940379279360L);
        f = Integer.reverse(Integer.MIN_VALUE);
        g = Integer.reverse(Integer.MIN_VALUE);
        a = new String[f];
        b = new String[g];
        \u03a0\u03b5\u03b7\u03a0\u03b3\u03b1\u03c2\u03b3\u03c4\u03b6\u03bb\u03c7\u03c6\u03be.b();
    }

    @Override
    public \u03a3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4[] a() {
        Collection collection = this.e.getPluginManager().getPlugins();
        \u03a3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4[] \u03c3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4Array = new \u03a3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4[collection.size()];
        int n = a;
        for (PluginContainer pluginContainer : collection) {
            PluginDescription pluginDescription = pluginContainer.getDescription();
            \u03c3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4Array[n++] = new \u03a3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4(pluginDescription.getId(), (String)pluginDescription.getVersion().orElse(\u03a0\u03b5\u03b7\u03a0\u03b3\u03b1\u03c2\u03b3\u03c4\u03b6\u03bb\u03c7\u03c6\u03be.c("\u3e80", (int)b, (long)(d ^ e))), pluginDescription.getAuthors(), pluginDescription.getSource().orElse(null));
        }
        return \u03c3\u03b8\u03a6\u0393\u03bc\u03bf\u039b\u03c3\u03b2\u03b2\u03b4Array;
    }

    @Generated
    public \u03a0\u03b5\u03b7\u03a0\u03b3\u03b1\u03c2\u03b3\u03c4\u03b6\u03bb\u03c7\u03c6\u03be(\u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a9 \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a92, ProxyServer proxyServer, \u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a8 \u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a82) {
        this.d = \u03bd\u03b5\u0393\u03c4\u03b5\u03ba\u0393\u03b7\u03b6\u03b5\u0394\u03bb\u03b9\u03a92;
        this.e = proxyServer;
        this.c = \u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a82;
    }

    @Override
    public \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 a(String string) {
        return \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.a(this.d, this.e, string);
    }

    @Override
    public \u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1 a(\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<?> \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be2) {
        return new \u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2(this.e, \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be2);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03a0\u03b5\u03b7\u03a0\u03b3\u03b1\u03c2\u03b3\u03c4\u03b6\u03bb\u03c7\u03c6\u03be.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.B("\u00c1\u00e3\u00e5\u00c5\u00e9\u0108\u0100\u0116\u0102\u00d1\u010f\u0105\u0113\u010d\u00d6\u00fb\u011d\u011c\u0114\u011a\u0114\u00e9", (byte)13, 66), \u03a0\u03b5\u03b7\u03a0\u03b3\u03b1\u03c2\u03b3\u03c4\u03b6\u03bb\u03c7\u03c6\u03be.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.C("\u043f\u044c\u044b\u040e\u044e\u044a\u0445\u044e\u0459\u0448\u0415\u0453\u0457\u0450\u0453\u0459\u041b\u078d\u07a3\u07a6\u0790\u07a4\u07a3\u07b5\u07a7\u07b9\u07ac\u07b2\u07bf\u07bf\u07b8\u0435", (byte)13, 67) + string + \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.D("\u0416", (byte)13, 68) + methodType.toString(), exception);
        }
    }

    @Override
    public Collection<\u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6> c() {
        return this.e.getAllPlayers().stream().map(this::a).collect(Collectors.toList());
    }

    @Override
    public <T> T c() {
        return (T)this.e;
    }

    @Override
    @Nullable
    public \u03c9\u039b\u03c3\u03a6\u0394\u03c4\u03b2\u03c9\u03c5\u03c5\u03c4\u03b8\u03b8\u0393\u03c5 a(String string) {
        return this.e.getPluginManager().getPlugin(string).map(pluginContainer -> {
            PluginDescription pluginDescription = pluginContainer.getDescription();
            Object object2 = pluginContainer.getInstance().map(object -> object).orElse(pluginContainer);
            return new \u03c9\u039b\u03c3\u03a6\u0394\u03c4\u03b2\u03c9\u03c5\u03c5\u03c4\u03b8\u03b8\u0393\u03c5(pluginDescription.getName().orElse(null), pluginDescription.getVersion().orElse(null), object2);
        }).orElse(null);
    }

    @Override
    public void c() {
        this.e.shutdown();
    }

    @Override
    @Generated
    public \u03b5\u03c2\u03bf\u03b5\u03c9\u03b6\u03c6\u03c0\u03c9\u03a8 a() {
        return this.c;
    }

    @Override
    public \u03a8\u03b1\u03c7\u03a8\u03c7\u03a3\u03bb\u03b5\u03a0\u03c8\u03a6 a(Object object) {
        return \u03be\u03bf\u03c6\u03c8\u03b2\u0394\u03b4\u03be\u03a6\u03c0\u03c5\u03b4.a(this.d, this.e, object);
    }

    private static void b() {
        int n;
        c = -5749230556548611494L;
        long l = c ^ 0xBAE6773591BB0229L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(7 + 61), (byte)(26 + 43), (byte)(51 + 32), (byte)(13 + 34), (byte)(62 + 5), (byte)(53 + 13), 67, (byte)(4 + 43), (byte)(77 + 3), 75, (byte)(19 + 48), (byte)(41 + 42), (byte)(8 + 45), (byte)(70 + 10), (byte)(57 + 40), (byte)(64 + 36), (byte)(36 + 64), (byte)(101 + 4), (byte)(4 + 106), (byte)(72 + 31)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(2 + 67), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03a0\u03b5\u03b7\u03a0\u03b3\u03b1\u03c2\u03b3\u03c4\u03b6\u03bb\u03c7\u03c6\u03be.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u0484\u0478\u0478\u0466\u0484\u0446\u047b\u047e\u0463\u045e\u0461\u045a", (byte)31, 67);
                    continue block7;
                }
                case 1: {
                    \u03a0\u03b5\u03b7\u03a0\u03b3\u03b1\u03c2\u03b3\u03c4\u03b6\u03bb\u03c7\u03c6\u03be.b[0] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.F("\u0523\u054b\u0552\u054e\u0542\u0537\u0539\u0531\u050e\u0539\u052a\u0533\u0529\u055f\u054e\u0535\u054e\u054d\u051f\u053a\u0541\u0541\u052e\u052f", (byte)31, 70);
                    continue block7;
                }
                case 2: {
                    \u03a0\u03b5\u03b7\u03a0\u03b3\u03b1\u03c2\u03b3\u03c4\u03b6\u03bb\u03c7\u03c6\u03be.b[0] = \u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.C("\u0441\u0482\u046d\u0478\u048b\u0448\u0484\u0469\u0483\u046f\u045e\u0489\u044d\u0465\u0454\u0491\u0498\u049c\u0498\u048f\u046e\u0468\u0465\u0466", (byte)31, 67);
                    continue block7;
                }
                case 4: {
                    \u03a0\u03b5\u03b7\u03a0\u03b3\u03b1\u03c2\u03b3\u03c4\u03b6\u03bb\u03c7\u03c6\u03be.b[0] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u0542\u0523\u0546\u052b\u0516\u053a\u054e\u0544\u0559\u054c\u053c\u0550\u0518\u0555\u0514\u0515\u0553\u0566\u051f\u0560\u0561\u0531\u052e\u052f", (byte)31, 70);
                }
            }
        }
    }

    @Override
    public boolean j(String string) {
        return this.e.getPluginManager().isLoaded(string);
    }
}

