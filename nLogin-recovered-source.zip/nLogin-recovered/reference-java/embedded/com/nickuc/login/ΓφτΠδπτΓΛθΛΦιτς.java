/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.velocitypowered.api.command.Command
 *  com.velocitypowered.api.command.CommandInvocation
 *  com.velocitypowered.api.command.CommandManager
 *  com.velocitypowered.api.command.CommandMeta
 *  com.velocitypowered.api.command.CommandSource
 *  com.velocitypowered.api.command.SimpleCommand
 *  com.velocitypowered.api.command.SimpleCommand$Invocation
 *  com.velocitypowered.api.proxy.Player
 *  com.velocitypowered.api.proxy.ProxyServer
 *  lombok.Generated
 */
package com.nickuc.login;

import com.nickuc.login.\u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5;
import com.nickuc.login.\u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6;
import com.nickuc.login.\u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6;
import com.nickuc.login.\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc;
import com.nickuc.login.\u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6;
import com.velocitypowered.api.command.Command;
import com.velocitypowered.api.command.CommandInvocation;
import com.velocitypowered.api.command.CommandManager;
import com.velocitypowered.api.command.CommandMeta;
import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import lombok.Generated;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2
implements \u03bf\u03b7\u0394\u03a6\u03b8\u03ba\u03bf\u03c1,
SimpleCommand {
    private static int e;
    private static long d;
    private static String[] b;
    private static int c;
    private static int a;
    private static String[] a;
    private final ProxyServer a;
    private static int g;
    private static long c;
    private static int f;
    private static long b;
    private final \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<?> d;

    @Override
    public void X() {
        this.a.getCommandManager().unregister(this.d.aa());
    }

    @Override
    public void W() {
        CommandManager commandManager = this.a.getCommandManager();
        CommandMeta commandMeta = commandManager.metaBuilder(this.d.aa()).aliases(this.d.c().toArray(new String[e])).build();
        commandManager.register(commandMeta, (Command)this);
    }

    @Generated
    public \u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2(ProxyServer proxyServer, \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be<?> \u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be2) {
        this.a = proxyServer;
        this.d = (long)\u03b9\u03c7\u03c1\u03a8\u03ba\u03b5\u03c0\u03c5\u03be2;
    }

    static {
        a = (0 >>> 241 | 0 << ~241 + 1) & 0xFFFFFFFF;
        b = Long.reverse(-140215777637429804L);
        c = Integer.reverse(Integer.MIN_VALUE);
        d = Long.reverse(-140215777637429804L);
        e = Integer.reverse(0);
        f = (4096 >>> 11 | 4096 << -11) & 0xFFFFFFFF;
        g = Integer.reverse(0x40000000);
        a = new String[f];
        b = new String[g];
        \u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2.b();
    }

    public /* synthetic */ List suggest(CommandInvocation commandInvocation) {
        return this.a((SimpleCommand.Invocation)commandInvocation);
    }

    public /* synthetic */ void execute(CommandInvocation commandInvocation) {
        this.a((SimpleCommand.Invocation)commandInvocation);
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.C("\u0506\u0528\u052a\u050a\u052e\u054d\u0545\u055b\u0547\u0516\u0554\u054a\u0558\u0552\u051b\u0540\u0562\u0561\u0559\u055f\u0559\u052e", (byte)99, 67), \u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03b8\u03c9\u03c1\u03c7\u03b6\u03bd\u03b7\u03bd\u03c3\u03a6\u03bd\u03b6.A("\u01a8\u01b5\u01b4\u0177\u01b7\u01b3\u01ae\u01b7\u01c2\u01b1\u017e\u01bc\u01c0\u01b9\u01bc\u01c2\u0184\u04e9\u051d\u051c\u04f9\u050e\u051b\u0520\u04f0\u04f9\u0517\u04fb\u0507\u051b\u0527\u0526\u019f", (byte)99, 65) + string + \u039b\u03bc\u03bd\u03a8\u0394\u03a3\u0394\u03a6.D("\u0518", (byte)99, 68) + methodType.toString(), exception);
        }
    }

    public List<String> a(SimpleCommand.Invocation invocation) {
        CommandSource commandSource = invocation.source();
        boolean bl = commandSource instanceof Player;
        Object object = bl ? ((Player)commandSource).getUsername() : \u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2.c("\u3e80", (int)c, (long)d);
        List<String> list = this.d.a(commandSource, (String)object, bl, invocation.alias(), (String[])invocation.arguments());
        return list != null ? list : Collections.emptyList();
    }

    private static void b() {
        int n;
        c = 3148051858599948408L;
        long l = c ^ 0xD8A9F6DC4D3BB4E4L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(54 + 14), (byte)(43 + 26), (byte)(79 + 4), 47, (byte)(7 + 60), 66, (byte)(46 + 21), (byte)(44 + 3), (byte)(41 + 39), (byte)(24 + 51), (byte)(32 + 35), (byte)(73 + 10), (byte)(40 + 13), (byte)(49 + 31), (byte)(20 + 77), (byte)(93 + 7), (byte)(55 + 45), (byte)(31 + 74), (byte)(94 + 16), (byte)(77 + 26)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{(byte)(8 + 60), 69, 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2.b[0] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.C("\u0423\u0426\u0446\u0418\u0445\u0457\u0433\u0429\u0434\u043b\u0450\u0427", (byte)14, 67);
                    \u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2.b[1] = \u039b\u039b\u03b6\u0394\u03c6\u03c6\u03bc\u03c5\u03b2\u03a0\u03c4\u039b\u03c1\u0394\u03b5.A("\u00df\u00e2\u0102\u00d4\u0101\u0113\u00ef\u00e5\u00f0\u00f7\u010c\u00e3", (byte)14, 65);
                    continue block7;
                }
                case 1: {
                    \u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2.b[0] = \u03c7\u03bd\u03c5\u03b2\u03b6\u03b5\u03c2\u03a8\u03a3\u03c6\u03b7\u03b2\u03c0\u03c6.A("\u00ea\u00e3\u00de\u00f7\u0114\u0109\u010e\u00ef\u0119\u00d9\u00d4\u00d1\u00f0\u011d\u00fd\u0110\u00dd\u00fa\u010e\u0128\u0124\u0101\u00ee\u00ef", (byte)14, 65);
                    \u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2.b[1] = \u03bf\u03b3\u03bd\u03c5\u0393\u03bc\u03b9\u03bc.D("\u0433\u0439\u044b\u0435\u0413\u042b\u0429\u043b\u0449\u044f\u042e\u0419\u042f\u043d\u0444\u041f\u0420\u043a\u0438\u0426\u0437\u046b\u0432\u0433", (byte)14, 68);
                    continue block7;
                }
                case 2: {
                    \u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2.b[0] = \u03a6\u03c3\u03b1\u03bd\u03c2\u03a8\u03bd\u03bc\u03a6\u03c6.C("\u0431\u042c\u0433\u0443\u0438\u0439\u042f\u045b\u0438\u044a\u043f\u045a\u0455\u045f\u0445\u0464\u0456\u045a\u043f\u0465\u043c\u046e\u046b\u045d\u046a\u043a\u0470\u042e\u0466\u0453\u0430\u046e", (byte)14, 67);
                    continue block7;
                }
                case 4: {
                    \u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2.b[0] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.E("\u051e\u053c\u051d\u051f\u0521\u0521\u0509\u0543\u0547\u053d\u050b\u053e\u050e\u0550\u052f\u053b\u053e\u050c\u050e\u052e\u054c\u0530\u051d\u051e", (byte)14, 69);
                }
            }
        }
    }

    public void a(SimpleCommand.Invocation invocation) {
        CommandSource commandSource = invocation.source();
        boolean bl = commandSource instanceof Player;
        Object object = bl ? ((Player)commandSource).getUsername() : \u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2.c("\u3e80", (int)a, (long)b);
        this.d.a(commandSource, (String)object, bl, invocation.alias(), (String[])invocation.arguments());
    }

    private static String a(int n, long l) {
        l ^= 7L;
        l ^= 0xD8A9F6DC4D3BB4E4L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(2 + 66), (byte)(18 + 51), (byte)(7 + 76), (byte)(5 + 42), (byte)(56 + 11), (byte)(21 + 45), (byte)(23 + 44), (byte)(5 + 42), (byte)(53 + 27), (byte)(19 + 56), (byte)(57 + 10), 83, (byte)(38 + 15), (byte)(29 + 51), (byte)(60 + 37), (byte)(36 + 64), (byte)(12 + 88), (byte)(58 + 47), (byte)(27 + 83), 103}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(52 + 17), 83}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.C("\u0547\u0554\u0553\u0516\u0556\u0552\u054d\u0556\u0561\u0550\u051d\u055b\u055f\u0558\u055b\u0561\u0523\u0888\u08bc\u08bb\u0898\u08ad\u08ba\u08bf\u088f\u0898\u08b6\u089a\u08a6\u08ba\u08c6\u08c5", (byte)101, 67));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u0393\u03c6\u03c4\u03a0\u03b4\u03c0\u03c4\u0393\u039b\u03b8\u039b\u03a6\u03b9\u03c4\u03c2.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }
}

