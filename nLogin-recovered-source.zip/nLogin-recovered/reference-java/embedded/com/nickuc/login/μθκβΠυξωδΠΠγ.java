/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package com.nickuc.login;

import com.nickuc.login.\u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8;
import com.nickuc.login.\u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8;
import com.nickuc.login.\u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9;
import com.nickuc.login.\u03a9\u0393\u03b9\u03a0\u03c9\u03b5\u03b1\u03b9\u03c5\u03c4\u03c9\u03be\u03a0;
import com.nickuc.login.\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8;
import com.nickuc.login.\u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5;
import com.nickuc.login.\u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5;
import com.nickuc.login.\u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8;
import com.nickuc.login.\u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9;
import com.nickuc.login.\u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be;
import com.nickuc.login.\u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9;
import com.nickuc.login.\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be;
import com.nickuc.login.\u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393;
import com.nickuc.login.\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be;
import com.nickuc.login.\u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6;
import com.nickuc.login.\u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3;
import com.nickuc.login.\u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393;
import com.nickuc.login.\u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6;
import com.nickuc.login.\u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7;
import com.nickuc.login.\u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2;
import com.nickuc.login.\u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9;
import com.nickuc.login.\u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8;
import com.nickuc.login.\u03c8\u03b5\u03b9\u03c4\u03a3\u03be\u03c8\u03b3\u03b4\u03c9\u03b2\u03a0\u03b5;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.nio.charset.StandardCharsets;
import java.nio.file.OpenOption;
import java.security.Key;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3 {
    private static int aj;
    private static int p;
    private static long r;
    private static int j;
    private static int m;
    private static int z;
    private static long w;
    private static int ax;
    private static long b;
    private static long ao;
    private static int ak;
    private static int ac;
    private static String[] b;
    private static long bb;
    private static int av;
    private static int l;
    private static int ae;
    private static final int F;
    private static int aa;
    private static int h;
    private static int af;
    private final Map<String, byte[]> e = new HashMap<String, byte[]>();
    private static int i;
    private static int e;
    private static long c;
    private static int bc;
    private static int q;
    private static String[] a;
    private static int ad;
    private final String au;
    private static int ar;
    private static int t;
    private static int g;
    private static int be;
    private static int k;
    private static int az;
    private static int n;
    private static int aq;
    private static int aw;
    private static int ap;
    private static int al;
    private static int at;
    private static long ay;
    private static int ah;
    private static long o;
    private static long d;
    private static long s;
    private static int v;
    private static int y;
    private static long ai;
    private static int as;
    private static long ag;
    private static int f;
    private static long u;
    private static int an;
    private static long x;
    private final File f;
    private static int bd;
    private static int au;
    private static int ab;
    private static long am;
    private static int a;
    private static int ba;

    @Nullable
    public synchronized Byte a(String string) {
        return this.a(string, (Byte)null);
    }

    public synchronized \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3 a(String string, Consumer<\u03c8\u03b5\u03b9\u03c4\u03a3\u03be\u03c8\u03b3\u03b4\u03c9\u03b2\u03a0\u03b5> consumer) {
        return this.a(string, \u03c0\u03b5\u03bb\u03c0\u03c6\u03b2\u03c5\u03c8\u03b5\u03c3\u03b1\u03c9\u03bf\u03a6.a(consumer));
    }

    public synchronized boolean c(String string) {
        return this.e.containsKey(string);
    }

    public synchronized \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3 a(String string, String string2) {
        if (string2 == null) {
            throw new IllegalArgumentException((String)\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.c("\u3e80", (int)a, (long)(b ^ d)));
        }
        return this.a(string, string2.getBytes(StandardCharsets.UTF_8));
    }

    static {
        a = Integer.reverse(0);
        b = Long.reverse(6166286554052340526L);
        d = Long.reverse(-1152921504606846976L);
        e = (0 >>> 251 | 0 << -251) & 0xFFFFFFFF;
        f = (512 >>> 169 | 512 << -169) & 0xFFFFFFFF;
        g = Integer.reverse(Integer.MIN_VALUE);
        h = Integer.reverse(0);
        i = (0x4000000 >>> 250 | 0x4000000 << -250) & 0xFFFFFFFF;
        j = 0 >>> 211 | 0 << -211;
        k = Integer.reverse(0);
        l = Integer.reverse(Integer.MIN_VALUE);
        m = Integer.reverse(0);
        n = (0x1000000 >>> 24 | 0x1000000 << ~24 + 1) & 0xFFFFFFFF;
        o = Long.reverse(-6515849996622976210L);
        p = Integer.reverse(0);
        q = 32768 >>> 46 | 32768 << ~46 + 1;
        r = Long.reverse(6166286554052340526L);
        s = Long.reverse(-1152921504606846976L);
        t = (-2147483647 >>> 95 | -2147483647 << -95) & 0xFFFFFFFF;
        u = Long.reverse(-6515849996622976210L);
        v = 262144 >>> 48 | 262144 << -48;
        w = Long.reverse(6166286554052340526L);
        x = Long.reverse(-1152921504606846976L);
        y = (0 >>> 0 | 0 << -0) & 0xFFFFFFFF;
        z = 0 >>> 239 | 0 << -239;
        aa = Integer.reverse(0);
        ab = Integer.reverse(0);
        ac = Integer.reverse(0);
        ad = (0 >>> 87 | 0 << -87) & 0xFFFFFFFF;
        ae = (-2147483646 >>> 191 | -2147483646 << -191) & 0xFFFFFFFF;
        af = Integer.reverse(-1);
        ag = Long.reverse(-6515849996622976210L);
        ah = Integer.reverse(0x60000000);
        ai = Long.reverse(-6515849996622976210L);
        aj = (0x1D000000 >>> 87 | 0x1D000000 << -87) & 0xFFFFFFFF;
        ak = Integer.reverse(0x74000000);
        al = (57344 >>> 173 | 57344 << -173) & 0xFFFFFFFF;
        am = Long.reverse(-6515849996622976210L);
        an = Integer.reverse(0x10000000);
        ao = Long.reverse(-6515849996622976210L);
        ap = (0 >>> 29 | 0 << -29) & 0xFFFFFFFF;
        aq = Integer.reverse(0);
        ar = Integer.reverse(0);
        as = (0 >>> 223 | 0 << -223) & 0xFFFFFFFF;
        at = Integer.reverse(0);
        au = (0 >>> 197 | 0 << -197) & 0xFFFFFFFF;
        av = (0 >>> 50 | 0 << ~50 + 1) & 0xFFFFFFFF;
        aw = 589824 >>> 176 | 589824 << ~176 + 1;
        ax = (-1 >>> 63 | -1 << -63) & 0xFFFFFFFF;
        ay = Long.reverse(-6515849996622976210L);
        az = (0x280000 >>> 178 | 0x280000 << -178) & 0xFFFFFFFF;
        ba = Integer.reverse(-1);
        bb = Long.reverse(-6515849996622976210L);
        bc = 180224 >>> 110 | 180224 << -110;
        bd = Integer.reverse(-805306368);
        be = Integer.reverse(0);
        a = new String[bc];
        b = new String[bd];
        \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b();
        F = be;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public synchronized void af() {
        block17: {
            try {
                this.e.clear();
                if (this.f.exists()) {
                    BufferedInputStream bufferedInputStream = \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.a(this.f, new OpenOption[p]);
                    try {
                        DataInputStream dataInputStream = new DataInputStream(bufferedInputStream);
                        try {
                            int n = dataInputStream.readInt();
                            if (n > 0) {
                                throw new UnsupportedOperationException((String)\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.c("\u3e80", (int)q, (long)(r ^ s)) + this.f + (String)\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.c("\u3e83", (int)t, (long)u) + n + (String)\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.c("\u3e86", (int)v, (long)(w ^ x)) + y);
                            }
                            int n2 = dataInputStream.readInt();
                            for (int i = z; i < n2; ++i) {
                                String string = dataInputStream.readUTF();
                                int n3 = dataInputStream.readInt();
                                byte[] byArray = new byte[n3];
                                dataInputStream.readFully(byArray);
                                this.e.put(string, byArray);
                            }
                            break block17;
                        }
                        finally {
                            if (Collections.singletonList(dataInputStream).get(aa) != null) {
                                dataInputStream.close();
                            }
                        }
                    }
                    finally {
                        if (Collections.singletonList(bufferedInputStream).get(ac) != null) {
                            bufferedInputStream.close();
                        }
                    }
                }
                File file = new File(this.f.getParentFile(), this.au.toLowerCase(Locale.ENGLISH) + (String)\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.c("\u3e89", (int)(ae & af), (long)ag));
                if (file.exists()) {
                    \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2 \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22 = new \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c2(file);
                    for (String string : \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.a((String)\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.c("\u3e8c", (int)ah, (long)ai))) {
                        String string2;
                        if (string == null || string.isEmpty() || (string2 = \u03c4\u03c6\u03b8\u03c7\u0394\u03b1\u03a3\u03b3\u03c4\u03c6\u03c22.b(string)) == null) continue;
                        if (!string2.isEmpty()) {
                            string2 = \u03a9\u0393\u03b9\u03a0\u03c9\u03b5\u03b1\u03b9\u03c5\u03c4\u03c9\u03be\u03a0.u(string2);
                        }
                        this.e.put(string.replace((char)aj, (char)ak), string2.getBytes(StandardCharsets.UTF_8));
                    }
                    this.ag();
                    if (!file.delete()) {
                        file.deleteOnExit();
                    }
                }
            }
            catch (IOException iOException) {
                \u03c8\u0393\u03c9\u03c4\u03b9\u03bc\u03c9\u03ba\u03c7\u03c8\u039b\u03a8.b((String)\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.c("\u3e8f", (int)al, (long)am) + this.f + (String)\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.c("\u3e92", (int)an, (long)ao), iOException, new Object[ap]);
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public synchronized void ag() {
        try {
            \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.b(this.f);
            BufferedOutputStream bufferedOutputStream = \u03c0\u03b7\u03c3\u03bf\u03b9\u03a3\u03b6\u03a9\u03b8\u039b\u03b4\u03bb\u03b6\u03c3.a(this.f, new OpenOption[aq]);
            try {
                DataOutputStream dataOutputStream = new DataOutputStream(bufferedOutputStream);
                try {
                    dataOutputStream.writeInt(ar);
                    dataOutputStream.writeInt(this.e.size());
                    for (Map.Entry<String, byte[]> entry : this.e.entrySet()) {
                        dataOutputStream.writeUTF(entry.getKey());
                        byte[] byArray = entry.getValue();
                        dataOutputStream.writeInt(byArray.length);
                        dataOutputStream.write(byArray);
                    }
                    dataOutputStream.flush();
                }
                finally {
                    if (Collections.singletonList(dataOutputStream).get(as) != null) {
                        dataOutputStream.close();
                    }
                }
            }
            finally {
                if (Collections.singletonList(bufferedOutputStream).get(au) != null) {
                    bufferedOutputStream.close();
                }
            }
        }
        catch (IOException iOException) {
            throw new RuntimeException((String)\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.c("\u3e80", (int)(aw & ax), (long)ay) + this.f + (String)\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.c("\u3e83", (int)(az & ba), (long)bb), iOException);
        }
    }

    public \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3(String string, File file) {
        this.au = string;
        this.f = file;
        this.af();
    }

    public synchronized boolean m(String string) {
        return this.a(string, e != 0);
    }

    public synchronized Byte a(String string, @Nullable Byte by) {
        byte[] byArray = this.a(string);
        return byArray != null && byArray.length > 0 ? Byte.valueOf(byArray[k]) : by;
    }

    public synchronized \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3 a(String string, byte by) {
        byte[] byArray = new byte[l];
        byArray[\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.m] = by;
        return this.a(string, byArray);
    }

    public synchronized boolean a(String string, boolean n) {
        Byte by = this.a(string);
        return (by != null ? (by == f ? g : h) : n) != 0;
    }

    private static void b() {
        int n;
        c = 8418760056873470378L;
        long l = c ^ 0x90C6519719052893L;
        Cipher cipher = Cipher.getInstance(new String(new byte[]{(byte)(25 + 43), (byte)(65 + 4), (byte)(8 + 75), (byte)(35 + 12), (byte)(15 + 52), (byte)(19 + 47), 67, (byte)(9 + 38), (byte)(57 + 23), (byte)(14 + 61), (byte)(9 + 58), 83, (byte)(18 + 35), (byte)(21 + 59), (byte)(6 + 91), (byte)(91 + 9), (byte)(70 + 30), (byte)(59 + 46), (byte)(46 + 64), (byte)(47 + 56)}, StandardCharsets.UTF_8));
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, (byte)(20 + 49), 83}, StandardCharsets.UTF_8));
        byte[] byArray = new byte[8];
        byArray[0] = (byte)(l >>> 56);
        for (n = 1; n < 8; ++n) {
            byArray[n] = (byte)(l << n * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
        n = 1;
        block7: for (int i = 0; i < n; ++i) {
            switch (i) {
                case 0: {
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[0] = \u03bf\u03c7\u03b9\u03c7\u03a9\u03b4\u03c1\u0393\u03b9\u03b1\u03a6\u03b2\u0393.F("\u0587\u0564\u057d\u0578\u059c\u056b\u05a8\u058f\u059e\u059a\u05aa\u0564\u0589\u058b\u058a\u059e\u05b3\u0581\u0572\u058e\u0598\u05b1\u05b0\u0595\u05b0\u059f\u05ab\u057b\u0593\u057d\u057c\u05ae", (byte)114, 70);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[1] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.A("\u01bc\u0199\u01b2\u01ad\u01d1\u01a0\u01dd\u01c4\u01d3\u01cf\u01df\u0199\u01be\u01c0\u01bf\u01d3\u01e8\u01b6\u01a7\u01c3\u01cd\u01e6\u01e5\u01ca\u01e5\u01d4\u01e0\u01b0\u01c8\u01b2\u01b1\u01e3", (byte)114, 65);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[2] = \u03b5\u03b2\u03b1\u03b2\u0393\u03c6\u03bd\u03b9\u0393\u03b8\u03a0\u03c5.C("\u0540\u0557\u057e\u0579\u0589\u057c\u0583\u0573\u0563\u0557\u055e\u0558\u055d\u057e\u0591\u054a\u0552\u0582\u0548\u0576\u058f\u0597\u055e\u055f", (byte)114, 67);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[3] = \u03c0\u03c0\u03b4\u03b2\u03c6\u03bf\u03be\u03c5\u03b4\u0393.F("\u056f\u0562\u0585\u0577\u0564\u0582\u058c\u0599\u059a\u0590\u058d\u059f\u05a1\u0594\u05a3\u05a1\u05b4\u058d\u0593\u0573\u058d\u057c\u0589\u059a\u057f\u0590\u058f\u058d\u059d\u059e\u05b0\u05b0\u0599\u0580\u059a\u05a5\u0589\u0584\u05ac\u0598\u05a5\u05a5\u058a\u058f\u05b1\u05ab\u05c2\u05a2\u05a5\u05b1\u05c2\u05b8\u05af\u05b6\u05cc\u05c7\u05d1\u05d4\u05dc\u05e2\u05dc\u05bf\u05ce\u05c3", (byte)114, 70);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[4] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.D("\u053a\u057d\u0556\u0550\u0559\u0554\u057f\u0569\u054b\u0558\u0549\u0553", (byte)114, 68);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[5] = \u03a8\u0394\u03c6\u03a0\u03a0\u03b7\u03c8\u03bb\u03b8\u03b7\u03b9.A("\u0195\u01a6\u0198\u019d\u01d8\u01ce\u01b2\u01da\u01c2\u01a3\u01b2\u01ab", (byte)114, 65);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[6] = \u03c5\u03a6\u03a6\u03be\u03c9\u0394\u03a8\u03c0\u03c1\u03c2\u03a0\u03a9.B("\u01d2\u01ca\u01ac\u01be\u01d0\u01d1\u01ad\u01cd\u01a1\u01e6\u01e0\u01ab", (byte)114, 66);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[7] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u0540\u0557\u057e\u0579\u0589\u057c\u0583\u0573\u0563\u0557\u0561\u057f\u055a\u0568\u0581\u058d\u0571\u0580\u0589\u0595\u058c\u0597\u055e\u055f", (byte)114, 68);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[8] = \u03bf\u0394\u03bd\u03b9\u03b2\u03b2\u039b\u03c1\u03a0\u03c3\u03b5\u03b2\u03a0\u0393\u03a9.F("\u055d\u0576\u0593\u0562\u05a3\u0585\u056b\u059f\u057c\u058c\u059b\u0576", (byte)114, 70);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[9] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.F("\u0563\u057a\u05a1\u059c\u05ac\u059f\u05a6\u0596\u0586\u057a\u0582\u05aa\u058e\u058e\u056d\u0568\u05a3\u05b8\u0573\u05ac\u05a4\u05ba\u0581\u0582", (byte)114, 70);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[10] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u0192\u01ab\u01c8\u0197\u01d8\u01ba\u01a0\u01d4\u01b1\u01c1\u01d0\u01ab", (byte)114, 65);
                    continue block7;
                }
                case 1: {
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.C("\u0564\u0541\u055a\u0555\u0579\u0548\u0585\u056c\u057b\u0577\u0587\u0541\u0566\u0568\u0567\u057b\u0590\u055e\u054f\u056b\u0575\u058e\u0574\u059c\u0556\u055c\u057b\u057a\u0573\u0573\u059c\u055f\u055e\u057d\u0599\u0573\u05a8\u0563\u05ab\u05a4\u057a\u057e\u0576\u0573", (byte)114, 67);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[1] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.C("\u0564\u0541\u055a\u0555\u0579\u0548\u0585\u056c\u057b\u0577\u0587\u0541\u0566\u0568\u0567\u057b\u0590\u055e\u054f\u056b\u0575\u058c\u0550\u056f\u056a\u0592\u057f\u055e\u0593\u058a\u0573\u0595\u059a\u058f\u057d\u0593\u0575\u0583\u0566\u059a\u057d\u0580\u0576\u0573", (byte)114, 67);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[2] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.C("\u0540\u0557\u057e\u0579\u0589\u057c\u0583\u0573\u0563\u0557\u055e\u0579\u057a\u0559\u0586\u0584\u057e\u0564\u0569\u0551\u058e\u0552\u0597\u0576\u0573\u055d\u0558\u0568\u0559\u057c\u057e\u056c", (byte)114, 67);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[3] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.F("\u056f\u0562\u0585\u0577\u0564\u0582\u058c\u0599\u059a\u0590\u058d\u059f\u05a1\u0594\u05a3\u05a1\u05b4\u058d\u0593\u0573\u058d\u057c\u0589\u059a\u057f\u0590\u058f\u058d\u059d\u059e\u05b0\u05b0\u0599\u0580\u059a\u05a5\u0589\u0584\u05ac\u0598\u05a5\u05a5\u058a\u058f\u05b1\u05ab\u05c2\u05a2\u05a5\u05b1\u05c2\u05b8\u05af\u05c9\u05c7\u0596\u05d6\u05b3\u05ae\u05e2\u05bc\u05b7\u05a4\u05c4\u05e1\u05db\u05df\u05dd\u05d9\u05e4\u05e3\u05e9\u05b8\u05ce\u05b0\u05b6", (byte)114, 70);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[4] = \u03ba\u03b4\u03ba\u03c1\u03a9\u03a3\u03c1\u03ba\u03a0\u0393\u03bc\u03c9\u03c5\u03bb\u03b8.D("\u053b\u0574\u055f\u057d\u0589\u055b\u0540\u0561\u0554\u0565\u0545\u0553", (byte)114, 68);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[5] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u0576\u0573\u05aa\u0583\u059b\u055e\u0586\u058f\u056e\u0599\u0581\u0576", (byte)114, 69);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[6] = \u03ba\u03c5\u039b\u03a8\u03c0\u03bc\u03a9\u03a9\u03c3\u03b9.D("\u055c\u0584\u0560\u0574\u0568\u053b\u0578\u0582\u0561\u055b\u0580\u0553", (byte)114, 68);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[7] = \u0393\u03c7\u03bb\u03c4\u03a3\u03a8\u0393\u03c9\u03b1\u0393\u03b4\u03b8.E("\u0563\u057a\u05a1\u059c\u05ac\u059f\u05a6\u0596\u0586\u057a\u0584\u05af\u05b0\u0574\u05b4\u0573\u05b8\u056e\u0593\u058b\u05b4\u05a9\u05a9\u059d\u059e\u05b7\u05aa\u05bc\u05ac\u05b8\u05c3\u0578", (byte)114, 69);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[8] = \u039b\u039b\u03c9\u03bc\u03b1\u03c6\u03ba\u03c5\u03a0\u03c8.F("\u059b\u0596\u0593\u057e\u0587\u058b\u0566\u059f\u057b\u057e\u05a3\u05a7\u05ab\u0589\u056d\u0585\u05b6\u058f\u0585\u0598\u057b\u05aa\u0581\u0582", (byte)114, 70);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[9] = \u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u0198\u01af\u01d6\u01d1\u01e1\u01d4\u01db\u01cb\u01bb\u01af\u01b7\u019d\u01d8\u01d6\u01e7\u01e7\u01ab\u01c8\u01e1\u01a1\u01e6\u01cb\u01ba\u01d3\u01cf\u01ad\u01c7\u01e7\u01d2\u01d5\u01f2\u01f3", (byte)114, 66);
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[10] = \u03bb\u03a3\u03a8\u03b9\u03b2\u03a9\u03b7\u03bd\u03c2\u03c6\u039b\u03b1\u0393\u03a0\u03be.A("\u019b\u01af\u01cb\u0195\u01cf\u01aa\u01d1\u01ce\u019e\u01dd\u01da\u01e7\u01a6\u01d9\u01aa\u01a9\u01ea\u01e0\u01c7\u01da\u01cf\u01ef\u01b6\u01b7", (byte)114, 65);
                    continue block7;
                }
                case 2: {
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[0] = \u03c2\u03bc\u03a9\u03ba\u03c1\u03b2\u03c3\u03c4\u03a8\u03c5\u03bf\u03c6\u03b7.D("\u0576\u0543\u0550\u0581\u0543\u055a\u0540\u0563\u055c\u054b\u054b\u0578\u0589\u057d\u0584\u0584\u056e\u0589\u0596\u056c\u0583\u0589\u0559\u0568\u0565\u0596\u0588\u0578\u055e\u0579\u057b\u0577", (byte)114, 68);
                    continue block7;
                }
                case 4: {
                    \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.b[0] = \u03c2\u03b4\u03bd\u03b8\u03c9\u03ba\u03b6\u03a6.D("\u0540\u057e\u053d\u057e\u0578\u0541\u0561\u057e\u056a\u0578\u0540\u0541\u0588\u0566\u0566\u0561\u058f\u0574\u0550\u054d\u0570\u054b\u0551\u057b\u0571\u0588\u058e\u057e\u058b\u055c\u059f\u05a1", (byte)114, 68);
                }
            }
        }
    }

    public synchronized \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3 a(String string) {
        this.e.remove(string);
        return this;
    }

    private static String a(int n, long l) {
        l ^= 0xFL;
        l ^= 0x90C6519719052893L;
        if (a[n] == null) {
            SecretKeyFactory secretKeyFactory;
            Cipher cipher;
            try {
                cipher = Cipher.getInstance(new String(new byte[]{(byte)(16 + 52), (byte)(5 + 64), (byte)(41 + 42), (byte)(22 + 25), (byte)(3 + 64), (byte)(39 + 27), 67, (byte)(15 + 32), (byte)(41 + 39), (byte)(74 + 1), (byte)(46 + 21), (byte)(40 + 43), (byte)(39 + 14), (byte)(54 + 26), (byte)(93 + 4), 100, (byte)(23 + 77), (byte)(17 + 88), (byte)(45 + 65), (byte)(64 + 39)}, StandardCharsets.UTF_8));
                secretKeyFactory = SecretKeyFactory.getInstance(new String(new byte[]{68, 69, (byte)(53 + 30)}, StandardCharsets.UTF_8));
            }
            catch (Exception exception) {
                throw new RuntimeException(\u03b1\u0394\u03bb\u03c0\u03c4\u0394\u03b3\u0393\u03c7\u03a0\u03a8.A("\u016e\u017b\u017a\u013d\u017d\u0179\u0174\u017d\u0188\u0177\u0144\u0182\u0186\u017f\u0182\u0188\u014a\u04d8\u04d5\u04d8\u04d1\u04c0\u04e6\u04e0\u04ec\u04d8\u04c5\u04c6\u04da", (byte)70, 65));
            }
            byte[] byArray = new byte[8];
            byArray[0] = (byte)(l >>> 56);
            for (int i = 1; i < 8; ++i) {
                byArray[i] = (byte)(l << i * 8 >>> 56);
            }
            cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray)), new IvParameterSpec(new byte[8]));
            \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.a[n] = new String(cipher.doFinal(Base64.getDecoder().decode(b[n])), StandardCharsets.UTF_8);
        }
        return a[n];
    }

    @Nullable
    public synchronized byte[] a(String string) {
        return this.e.get(string);
    }

    @Nullable
    public synchronized String k(String string) {
        return this.g(string, null);
    }

    public synchronized \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3 a(String string, byte[] byArray) {
        if (byArray == null) {
            throw new IllegalArgumentException((String)\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.c("\u3e80", (int)n, (long)o));
        }
        this.e.put(string, byArray);
        return this;
    }

    public synchronized \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3 a(String string, boolean bl) {
        return this.a(string, (byte)(bl ? i : j));
    }

    private static Object c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        try {
            return new MutableCallSite(lookup.findStatic(\u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.class, new String(new byte[]{97}, StandardCharsets.UTF_8), MethodType.fromMethodDescriptorString(\u03bf\u03a3\u03b3\u03c4\u03c1\u03b3\u03b2\u03c8\u03b9\u03c6\u03be.E("\u050d\u052f\u0531\u0511\u0535\u0554\u054c\u0562\u054e\u051d\u055b\u0551\u055f\u0559\u0522\u0547\u0569\u0568\u0560\u0566\u0560\u0535", (byte)41, 69), \u03bc\u03b8\u03ba\u03b2\u03a0\u03c5\u03be\u03c9\u03b4\u03a0\u03a0\u03b3.class.getClassLoader())).asType(methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException(\u03c0\u03b1\u03c9\u03b4\u03b9\u03c4\u03bc\u03be\u03b8\u03c1\u03a9\u03c2\u03b4\u03c2\u03be.B("\u0134\u0141\u0140\u0103\u0143\u013f\u013a\u0143\u014e\u013d\u010a\u0148\u014c\u0145\u0148\u014e\u0110\u049e\u049b\u049e\u0497\u0486\u04ac\u04a6\u04b2\u049e\u048b\u048c\u04a0\u0128", (byte)41, 66) + string + \u03b3\u03c6\u03c0\u039b\u03bf\u03a3\u03b5\u03b2\u03b4\u03a9\u03ba\u03c1\u03ba\u03b5.D("\u046a", (byte)41, 68) + methodType.toString(), exception);
        }
    }

    @Nullable
    public synchronized String g(String string, String string2) {
        byte[] byArray = this.a(string);
        return byArray != null ? new String(byArray, StandardCharsets.UTF_8) : string2;
    }
}

