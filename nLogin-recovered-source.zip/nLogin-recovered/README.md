# nLogin 2.0.19 — recovered and cleaned

This project was recovered from the supplied nLogin.jar. It preserves the original nLogin implementation. A confirmed injected RAT and plugin infector were removed before the plugin was executed for testing.

**Source format:** `src/main/jvm` is the complete, authoritative, rebuildable textual JVM assembly source for all 816 retained classes. `reference-java` contains decompiled Java for inspection. The original core is heavily obfuscated, and that Java is not a complete compilable Java/Maven project. Original variable names, comments, and unobfuscated Java could not be recovered reliably. The assembly build preserves the original class bytes instead of replacing functionality or guessing at broken decompiler output.

## Build

Install Python 3; the assembler is bundled and the build requires no downloads or original plugin JAR.

```powershell
python build.py
# Alternatively on Windows:
.\build.ps1
```

Use `py -3 build.py` if that is your Python launcher. `build.ps1` also accepts the `PYTHON` environment variable as an executable path. Python 3.12.14 was used for the delivered build. Java is not required to assemble the source; Java 21 is required for the tested Paper target.

The output is `dist/nLogin-2.0.19-cleaned.jar`. The default build checks every assembled class and resource against the audited hashes in `verification/expected-entries.json` and fails if anything differs. For deliberate later source edits, `python build.py --allow-source-changes` allows a changed build; such a build is outside this audit.

The delivered JAR was assembled entirely from `.j` text and resource files. No precompiled plugin classes, original plugin JAR, or vendor JAR are needed for rebuilding.

## Layout

| Path | Purpose |
| --- | --- |
| `src/main/jvm/outer` | 108 platform loader, API, and support classes |
| `src/main/jvm/embedded` | 708 original core classes |
| `src/main/resources` | Original descriptors, configurations, translations, and other resources |
| `reference-java` | CFR Java recovery; inspection only, with decompiler limitations |
| `tools/Krakatau` | Bundled assembler; its GPL license is alongside it |
| `audit` | Decoded strings, class and call inventories, evidence, analysis scripts |
| `verification` | Class hashes, final rescan, bytecode checks, and runtime evidence |
| `AUDIT-REPORT.md` | Findings, removals, preserved behavior, and test limitations |

The build creates the embedded `com/nickuc/login/loader/plugin.jar`, then the outer plugin archive. ZIP timestamps and ordering are normalized. Recompression changes archive bytes; each retained class and resource matches the same-version vendor reference exactly.

## Runtime check

The delivered JAR loaded on Paper 1.21.11 build 132 with Temurin Java 21.0.12.1. Registration, password mismatch rejection, login, wrong-password rejection, password changes, non-admin permission denial, and persistence after a server restart were exercised with a synthetic account. See the report for remaining warnings and features not tested live.

Install the cleaned JAR as the single nLogin plugin JAR in your server's plugins directory, with the server stopped. Preserve your existing nLogin configuration and database backups. This recovery retains upstream runtime dependency downloads and licensing behavior.

The source ZIP omits `dist` to keep source and compiled deliverables separate. Building recreates it. Original copyright and licensing remain applicable; source recovery does not grant a new license to nLogin. The bundled assembler has its own license.
