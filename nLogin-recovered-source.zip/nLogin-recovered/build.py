#!/usr/bin/env python3
"""Reassemble EVERY class from textual JVM source; no original plugin JAR needed."""
import argparse,hashlib,io,json,pathlib,sys,time,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from Krakatau.assembler import parse

def archive(entries):
    data=io.BytesIO()
    with zipfile.ZipFile(data,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,content in sorted(entries.items()):
            zi=zipfile.ZipInfo(name,(1980,1,1,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(zi,content)
    return data.getvalue()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--allow-source-changes',action='store_true',help='Permit deliberate source edits to differ from audited class hashes.')
    args=parser.parse_args()
    expected=json.loads((ROOT/'verification/expected-entries.json').read_text())
    parts={};result={};started=time.time()
    for part in ['embedded','outer']:
        entries={};sources=sorted((ROOT/'src/main/jvm'/part).rglob('*.j'))
        for num,p in enumerate(sources,1):
            pairs=list(parse.assemble(p.read_text(encoding='utf8').replace('\t','  ')+'\n',str(p),fatal=True))
            if len(pairs)!=1:raise RuntimeError(f'Expected one class in {p}')
            for name,data in pairs:
                name=name.decode('utf8') if isinstance(name,bytes) else name
                if name.startswith('l/M/x/'):raise RuntimeError('Payload namespace is forbidden')
                entry=name+'.class'
                if entry in entries:raise RuntimeError('Duplicate class '+entry)
                entries[entry]=data
            if num%100==0:print(f'{part}: assembled {num}/{len(sources)} classes',flush=True)
        for p in (ROOT/'src/main/resources'/part).rglob('*'):
            if p.is_file():
                n=p.relative_to(ROOT/'src/main/resources'/part).as_posix()
                if n.endswith(('.class','.jar')) or n=='.gitkeep_':raise RuntimeError('Unexpected binary resource '+n)
                entries[n]=p.read_bytes()
        hashes={n:hashlib.sha256(b).hexdigest() for n,b in entries.items()}
        diffs=[n for n in set(hashes)|set(expected[part]) if hashes.get(n)!=expected[part].get(n)]
        if diffs and not args.allow_source_changes:raise RuntimeError('Audited source differs: '+repr(diffs[:20]))
        result[part]={'classes':len(sources),'entries':len(entries),'hash_differences':diffs}
        parts[part]=entries
    parts['outer']['com/nickuc/login/loader/plugin.jar']=archive(parts['embedded'])
    jar=archive(parts['outer']);dest=ROOT/'dist';dest.mkdir(exist_ok=True)
    (dest/'nLogin-2.0.19-cleaned.jar').write_bytes(jar)
    result.update(sha256=hashlib.sha256(jar).hexdigest(),seconds=round(time.time()-started,2),from_textual_source=True)
    (dest/'build-verification.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
