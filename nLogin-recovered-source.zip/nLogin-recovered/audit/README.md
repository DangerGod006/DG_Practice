# Evidence guide

`original-classes.tsv` maps stable audit IDs such as C0832 to original archive locations and class names. `original-calls.tsv` records invoked methods and their callers, including the removed payload. These are static inventories, not executable copies of the payload. `clean-classes.tsv` and `clean-calls.tsv` cover the rebuilt artifact; their IDs follow that artifact's different archive order.

`__v3_-strings.json` and `v_-strings.json` contain decoded payload indicators. `decoded-vendor-strings` and `vendor-decoded-strings.tsv` expose identified active string-table contents from the original nLogin core. The latter uses the original class IDs. `vendor-decode-failures.json` is empty after the final decoder pass. Ordinary string literals, resources, and runtime-generated strings are additional to this decoded set.

`vendor-comparison.json` compares the supplied outer archive to the independently downloaded vendor reference before cleanup. `../verification/final-rescan.json` compares the final rebuilt artifact recursively and lists all removed entries. The expected class/resource hashes used by the offline source build are in `../verification/expected-entries.json`.

Scripts under `scripts` document the analysis procedures. They are investigation utilities, not build dependencies or one-click audit commands: several retain paths into the original `work` investigation tree and expect its inventories/decompiler outputs. Original infected archives and their executable payload are deliberately not bundled. `Audit.java`, `Clean.java`, `Numbers.java`, and `VerifyBytecode.java` use ASM 9.8; the vendor string decoder uses Python cryptography. The project build itself uses only Python's standard library and the bundled Krakatau assembler.

Tools used: CFR 0.152, Vineflower 1.12.0 as a second decompilation view, ASM 9.8, and the Python branch of Krakatau. The complete retained assembly is authoritative if decompiled Java is ambiguous. No decompiler's output was blindly trusted as proof of behavior.
