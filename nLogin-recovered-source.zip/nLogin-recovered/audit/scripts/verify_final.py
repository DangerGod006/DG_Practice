import pathlib,zipfile,io,hashlib,json
r=pathlib.Path('work'); clean=zipfile.ZipFile('outputs/nLogin-recovered/dist/nLogin-2.0.19-cleaned.jar'); vendor=zipfile.ZipFile(r/'original/vendor-reference.jar')
def entries(z):
 result={}
 for n in z.namelist():
  if n.endswith('/'):continue
  b=z.read(n)
  if b[:4]==b'PK\x03\x04':
   for k,v in entries(zipfile.ZipFile(io.BytesIO(b))).items(): result[n+'!'+k]=v
  else:result[n]=b
 return result
c=entries(clean);v=entries(vendor)
changed=[n for n in c.keys()|v.keys() if c.get(n)!=v.get(n)]
assert not changed,changed
orig=entries(zipfile.ZipFile(r/'original/nLogin.jar'))
removed=[n for n in orig if n not in c]
assert len(removed)==80
for n,b in c.items():
 assert not any(x in b for x in [b'l/M/x/',b'l.M.x.',b'.gitkeep_',b'75.119.146.125']),n
report={'all_retained_entries':len(c),'exact_vendor_matches':len(c)-len(changed),'byte_differences_vs_vendor':changed,'constructor_difference':'none; identical bytes to vendor','removed_entries':removed,'remaining_payload_references':0,'original_sha256':hashlib.sha256((r/'original/nLogin.jar').read_bytes()).hexdigest(),'vendor_sha256':hashlib.sha256((r/'original/vendor-reference.jar').read_bytes()).hexdigest(),'clean_sha256':hashlib.sha256(pathlib.Path('outputs/nLogin-recovered/dist/nLogin-2.0.19-cleaned.jar').read_bytes()).hexdigest()}
pathlib.Path('outputs/nLogin-recovered/verification/final-rescan.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='removed_entries'},indent=2))

