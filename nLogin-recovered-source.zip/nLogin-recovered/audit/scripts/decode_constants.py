import pathlib,re,json,subprocess,zipfile,hashlib,collections
root=pathlib.Path('work')
def rem(a,b): return a - (abs(a)//abs(b) * (-1 if (a<0) != (b<0) else 1))*b
# Independently evaluated numeric expressions only. No target class is loaded.
for name in ['__v3_','v_']:
 s=(root/'decompiled/l/M/x'/f'{name}.java').read_text(encoding='utf8')
 types=dict((n,t) for t,n in re.findall(r'private static final /\* synthetic \*/ (int|long) (\w+);',s))
 assignments=re.findall(r'^        (\w+) = (.*);$',s,re.M)
 lines=[]
 for n,ex in assignments:
  if n not in types: continue
  ex=ex.replace('l.M.x.U.o','Integer.reverse').replace('l.M.x.U.N','Integer.rotateRight').replace('U.o','Integer.reverse').replace('U.N','Integer.rotateRight')
  if not re.fullmatch(r'[A-Za-z0-9_.() ,<>~+\-&|^]+',ex): raise ValueError(ex)
  ids=re.findall(r'\b[A-Za-z_]\w*(?:\.\w+)*',re.sub(r'0x[0-9A-Fa-f]+L?|\d+L?', '',ex))
  assert all(x in ['Integer.reverse','Integer.rotateRight','Long.reverse','Integer.MIN_VALUE'] for x in ids),ids
  lines.append(f'    {types[n]} {n} = {ex}; System.out.println("{n}="+{n});')
 code='public class NumericConstants { public static void main(String[] args) {\n'+'\n'.join(lines)+'\n}}'
 (root/'NumericConstants.java').write_text(code,encoding='utf8')
 subprocess.run(['javac','-d',str(root/'tool-classes'),str(root/'NumericConstants.java')],check=True)
 out=subprocess.check_output(['java','-cp',str(root/'tool-classes'),'NumericConstants'],text=True)
 vals=dict((k,int(v)) for k,v in (l.split('=') for l in out.splitlines()))
 (root/'inventory'/f'{name}-constants.json').write_text(json.dumps(vals,indent=2))
 if name=='__v3_': keys=[rem(vals['s5'],vals['tt']),rem(vals['wY'],vals['h']),rem(vals['RK'],vals['Qb'])]; mod=vals['cb']; xor=rem(vals['N'],vals['tn'])
 else: keys=[rem(vals['P'],vals['S7m']),rem(vals['Wv'],vals['Du']),rem(vals['x'],vals['gT'])]; mod=vals['FS']; xor=rem(vals['Y'],vals['CF'])
 result={}
 for idx,raw in re.findall(r'stringArray\['+name+r'\.(\w+)\] = '+name+r'\.\w+\("(.*?)"\);',s):
  enc=json.loads('"'+raw+'"')
  decoded=''.join(chr((ord(c)^(keys[i%4] if i%4<3 else len(enc)%mod)^xor)&65535) for i,c in enumerate(enc))
  result[vals[idx]]=decoded
 print(name, 'keys',keys,mod,xor,'constants', {k:vals[k] for k in (['A','n','a'] if name=='v_' else ['Y','m','n','B'])})
 print(json.dumps(result,indent=2))
 (root/'inventory'/f'{name}-strings.json').write_text(json.dumps(result,indent=2))

orig=zipfile.ZipFile(root/'original/nLogin.jar'); vendor=zipfile.ZipFile(root/'original/vendor-reference.jar')
print('VENDOR',vendor.read('plugin.yml').decode()[:160])
same=[];diff=[];missing=[]
for n in orig.namelist():
 if n.endswith('/'):continue
 if n not in vendor.namelist():missing.append(n)
 elif orig.read(n)==vendor.read(n):same.append(n)
 else:diff.append(n)
comparison={'same':same,'different':diff,'not_in_vendor':missing,'vendor_sha256':hashlib.sha256((root/'original/vendor-reference.jar').read_bytes()).hexdigest()}
(root/'inventory/vendor-comparison.json').write_text(json.dumps(comparison,indent=2))
print('vendor comparison same',len(same),'different',diff,'not in vendor',len(missing))

