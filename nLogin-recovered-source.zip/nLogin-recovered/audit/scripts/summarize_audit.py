import pathlib,collections,json,zipfile,io
r=pathlib.Path('work')
categories=collections.defaultdict(list)
for line in (r/'audit-original/calls.tsv').read_text(encoding='utf8').splitlines():
 id,caller,method,owner,target=line.split('\t',4)
 if caller.startswith('l/M/x/'):continue
 cat=None
 if owner in ['java/lang/Runtime','java/lang/ProcessBuilder']:cat='process'
 elif owner in ['java/net/URL','java/net/HttpURLConnection','java/net/URLConnection','javax/net/ssl/HttpsURLConnection','java/net/Socket','java/net/DatagramSocket','java/net/ServerSocket','java/net/URLClassLoader']:cat='network'
 elif owner.startswith('java/lang/reflect/') or (owner=='java/lang/Class' and target.startswith(('forName','getMethod','getDeclaredMethod'))):cat='reflection'
 elif target.startswith(('defineClass','loadLibrary')):cat='loading'
 elif target.startswith(('dispatchCommand','setOp','performCommand','executeAsync','executeImmediately')):cat='server-command'
 if cat:categories[cat].append(line)
for cat,lines in categories.items():
 (r/'inventory'/f'{cat}-calls.tsv').write_text('\n'.join(lines),encoding='utf8')
 print(cat,len(lines),'classes',sorted(set(l.split('\t')[0] for l in lines)))
 if cat in ['network','process','server-command','loading']:
  print('\n'.join(lines))
z=zipfile.ZipFile(r/'original/embedded.jar')
files=[(i.filename,i.file_size) for i in z.infolist() if not i.is_dir() and not i.filename.endswith('.class')]
(r/'inventory/embedded-resources.json').write_text(json.dumps(files,ensure_ascii=True,indent=2))
print('EMBEDDED RESOURCES',files)
