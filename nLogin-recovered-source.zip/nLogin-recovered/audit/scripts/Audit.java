import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.*;

// Parses class files only. Never defines or initializes any target class.
public class Audit {
  static PrintWriter calls, strings, index;
  static Path out;
  static int count;
  static String escape(Object o) { return String.valueOf(o).replace("\\", "\\\\").replace("\t", "\\t").replace("\r", "\\r").replace("\n", "\\n"); }
  static void scan(byte[] bytes, String location) throws Exception {
    if (bytes.length >= 4 && bytes[0] == (byte)0xca && bytes[1] == (byte)0xfe) {
      ClassReader cr = new ClassReader(bytes);
      ClassNode cn = new ClassNode(); cr.accept(cn, 0);
      String id = String.format("C%04d", ++count);
      index.println(id+"\t"+location+"\t"+cn.name+"\t"+cn.methods.size());
      try(PrintWriter p = new PrintWriter(Files.newBufferedWriter(out.resolve(id+".txt")))) {
        cr.accept(new TraceClassVisitor(p), 0);
      }
      for (FieldNode f: cn.fields) if(f.value instanceof String) strings.println(id+"\tFIELD "+f.name+"\t"+escape(f.value));
      for(MethodNode m: cn.methods) {
        for(AbstractInsnNode ins: m.instructions) {
          String prefix=id+"\t"+cn.name+"\t"+m.name+m.desc+"\t";
          if(ins instanceof MethodInsnNode x) calls.println(prefix+x.owner+"\t"+x.name+x.desc);
          if(ins instanceof InvokeDynamicInsnNode x) {
            calls.println(prefix+"INVOKEDYNAMIC\t"+escape(x.bsm));
            for(Object a:x.bsmArgs) {if(a instanceof Handle h) calls.println(prefix+h.getOwner()+"\t"+h.getName()+h.getDesc()); else if(a instanceof String) strings.println(id+"\t"+m.name+"\t"+escape(a));}
          }
          if(ins instanceof LdcInsnNode x && x.cst instanceof String) strings.println(id+"\t"+m.name+"\t"+escape(x.cst));
        }
      }
    } else if(bytes.length >= 4 && bytes[0]=='P' && bytes[1]=='K') {
      Set<String> seen = new HashSet<>();
      try(ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(bytes))) {
        ZipEntry e; while((e=z.getNextEntry())!=null) {if(!seen.add(e.getName())) throw new IOException("Duplicate: "+location+"!"+e.getName()); if(!e.isDirectory()) scan(z.readAllBytes(),location+"!"+e.getName());}
      }
    }
  }
  public static void main(String[] a)throws Exception {
    out=Paths.get(a[1]); Files.createDirectories(out);
    try(PrintWriter c=new PrintWriter(Files.newBufferedWriter(out.resolve("calls.tsv"))); PrintWriter s=new PrintWriter(Files.newBufferedWriter(out.resolve("strings.tsv"))); PrintWriter i=new PrintWriter(Files.newBufferedWriter(out.resolve("classes.tsv")))) {
      calls=c; strings=s; index=i; scan(Files.readAllBytes(Paths.get(a[0])),"root");
    }
    System.out.println("Parsed all "+count+" classes (including nested archives), without loading target classes.");
  }
}
