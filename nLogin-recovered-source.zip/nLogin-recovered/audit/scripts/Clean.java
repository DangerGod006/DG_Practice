import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import java.io.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.*;

public class Clean {
  static String text(byte[] b) {StringWriter s=new StringWriter();new ClassReader(b).accept(new TraceClassVisitor(new PrintWriter(s)),0);return s.toString();}
  public static void main(String[] a)throws Exception {
    int removed=0,patched=0,markers=0;
    try(ZipFile input=new ZipFile(a[0]); ZipFile reference=new ZipFile(a[1]); ZipOutputStream out=new ZipOutputStream(Files.newOutputStream(Paths.get(a[2])))) {
      for(ZipEntry e:Collections.list(input.entries())) {
        if(e.isDirectory())continue;
        if(e.getName().startsWith("l/M/x/") && e.getName().endsWith(".class")){removed++;continue;}
        if(e.getName().equals(".gitkeep_")){markers++;continue;}
        byte[] bytes=input.getInputStream(e).readAllBytes();
        if(e.getName().equals("com/nickuc/login/loader/nLoginBukkitLoader.class")) {
          ClassNode cn=new ClassNode();new ClassReader(bytes).accept(cn,0);
          for(MethodNode m:cn.methods)for(AbstractInsnNode ins:m.instructions.toArray()) {
            if(ins instanceof MethodInsnNode x && x.owner.startsWith("l/M/x/")) {
              if(!m.name.equals("<init>")||!m.desc.equals("()V")||x.getOpcode()!=Opcodes.INVOKESTATIC||!x.owner.equals("l/M/x/__v3_")||!x.name.equals("v")||!x.desc.equals("()V"))throw new IllegalStateException("Unexpected hook");
              m.instructions.remove(ins);patched++;
            }
          }
          ClassWriter cw=new ClassWriter(0);cn.accept(cw);bytes=cw.toByteArray();
          byte[] ref=reference.getInputStream(reference.getEntry(e.getName())).readAllBytes();
          if(!text(bytes).equals(text(ref)))throw new IllegalStateException("Cleaned constructor differs from official class");
          if(new String(bytes,java.nio.charset.StandardCharsets.ISO_8859_1).contains("l/M/x/"))throw new IllegalStateException("Stale payload constant");
        } else {
          ZipEntry ref=reference.getEntry(e.getName());
          if(ref==null||!Arrays.equals(bytes,reference.getInputStream(ref).readAllBytes()))throw new IllegalStateException("Unexpected difference: "+e.getName());
        }
        ZipEntry entry=new ZipEntry(e.getName());entry.setTime(315532800000L);out.putNextEntry(entry);out.write(bytes);out.closeEntry();
      }
    }
    if(removed!=79||patched!=1||markers!=1)throw new IllegalStateException("Unexpected removal counts");
    System.out.println("Removed 79 payload classes, one infection marker and one constructor call; all remaining content matches vendor (constructor verified structurally).");
  }
}
