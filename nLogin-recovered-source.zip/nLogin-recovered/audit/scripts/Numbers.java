import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import java.io.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

// Restricted numeric bytecode interpreter: no class loading, reflection or I/O from target.
public class Numbers implements Opcodes {
  public static void main(String[] args)throws Exception {
    try(ZipFile z=new ZipFile(args[0]);PrintWriter out=new PrintWriter(Files.newBufferedWriter(Paths.get(args[1])))) {
      for(ZipEntry e:Collections.list(z.entries()))if(e.getName().endsWith(".class")) {
        ClassNode c=new ClassNode();new ClassReader(z.getInputStream(e)).accept(c,0);
        Map<String,Number> fields=new HashMap<>(); List<Number> stack=new ArrayList<>();
        for(MethodNode m:c.methods)if(m.name.equals("<clinit>"))for(AbstractInsnNode ins:m.instructions) {
          try {
            int op=ins.getOpcode();if(op<0)continue;
            if(ins instanceof LdcInsnNode x){if(x.cst instanceof Number n)stack.add(n);else stack.clear();continue;}
            if(op>=ICONST_M1 && op<=ICONST_5){stack.add(op-ICONST_0);continue;}
            if(op==LCONST_0 || op==LCONST_1){stack.add((long)(op-LCONST_0));continue;}
            if(ins instanceof IntInsnNode x && (op==BIPUSH||op==SIPUSH)){stack.add(x.operand);continue;}
            if(ins instanceof FieldInsnNode f){
              if(op==PUTSTATIC&&(f.desc.equals("I")||f.desc.equals("J"))){Number n=pop(stack);fields.put(f.name+f.desc,n);out.println(c.name+"\t"+f.name+"\t"+f.desc+"\t"+n);}
              else if(op==GETSTATIC && fields.containsKey(f.name+f.desc))stack.add(fields.get(f.name+f.desc));else stack.clear();continue;
            }
            if(ins instanceof MethodInsnNode x){
              if(x.owner.equals("java/lang/Integer")&&x.name.equals("reverse"))stack.add(Integer.reverse(pop(stack).intValue()));
              else if(x.owner.equals("java/lang/Long")&&x.name.equals("reverse"))stack.add(Long.reverse(pop(stack).longValue()));
              else if(x.owner.equals("java/lang/Integer")&&x.name.equals("rotateRight")){int b=pop(stack).intValue();stack.add(Integer.rotateRight(pop(stack).intValue(),b));}
              else if(x.owner.equals("java/lang/Long")&&x.name.equals("rotateRight")){int b=pop(stack).intValue();stack.add(Long.rotateRight(pop(stack).longValue(),b));}
              else stack.clear();continue;
            }
            if(op==INEG){stack.add(-pop(stack).intValue());continue;}if(op==LNEG){stack.add(-pop(stack).longValue());continue;}
            if(op==I2L){stack.add(pop(stack).longValue());continue;}if(op==L2I){stack.add(pop(stack).intValue());continue;}
            if(op==I2B){stack.add((int)(byte)pop(stack).intValue());continue;}if(op==I2C){stack.add((int)(char)pop(stack).intValue());continue;}
            if(op==I2S){stack.add((int)(short)pop(stack).intValue());continue;}
            if(Set.of(IADD,ISUB,IMUL,IDIV,IREM,IAND,IOR,IXOR,ISHL,ISHR,IUSHR).contains(op)) {
              int b=pop(stack).intValue(),a=pop(stack).intValue();stack.add(switch(op){case IADD->a+b;case ISUB->a-b;case IMUL->a*b;case IDIV->a/b;case IREM->a%b;case IAND->a&b;case IOR->a|b;case IXOR->a^b;case ISHL->a<<b;case ISHR->a>>b;default->a>>>b;});continue;
            }
            if(Set.of(LADD,LSUB,LMUL,LDIV,LREM,LAND,LOR,LXOR,LSHL,LSHR,LUSHR).contains(op)) {
              long b=pop(stack).longValue(),a=pop(stack).longValue();stack.add(switch(op){case LADD->a+b;case LSUB->a-b;case LMUL->a*b;case LDIV->a/b;case LREM->a%b;case LAND->a&b;case LOR->a|b;case LXOR->a^b;case LSHL->a<<b;case LSHR->a>>b;default->a>>>b;});continue;
            }
            stack.clear();
          }catch(RuntimeException ex){stack.clear();}
        }
      }
    }
  }
  static Number pop(List<Number> s){return s.remove(s.size()-1);}
}
