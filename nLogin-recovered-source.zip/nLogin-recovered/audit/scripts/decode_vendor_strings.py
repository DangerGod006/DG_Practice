import pathlib,re,json,base64,collections
from cryptography.hazmat.primitives.ciphers import Cipher,modes
from cryptography.hazmat.decrepit.ciphers.algorithms import TripleDES

base=pathlib.Path('work/embedded-java')
out=pathlib.Path('work/vendor-decoded');out.mkdir(exist_ok=True)
mapping={line.split('\t')[2]:line.split('\t')[0] for line in pathlib.Path('work/audit-original/classes.tsv').read_text(encoding='utf8').splitlines()}
def rev(v):return int(f'{v&((1<<64)-1):064b}'[::-1],2)
allrows=[];fail=[]
numeric=collections.defaultdict(set)
for line in pathlib.Path('work/inventory/numeric-fields.tsv').read_text(encoding='utf8').splitlines():
 cn,field,typ,val=line.split('\t')
 if typ=='J':numeric[cn].add(int(val))
for p in base.rglob('*.java'):
 s=p.read_text(encoding='utf8'); name=p.relative_to(base).as_posix()[:-5];id=mapping.get(name,name)
 salt=re.findall(r'l \^= (0x[0-9a-fA-F]+|\d+)L;',s)
 if not salt:continue
 xor=0
 for v in salt[:2]:xor^=int(v,0)
 values=numeric[name]|set(int(v,0) for v in re.findall(r'(?<![\w\\])(-?(?:0x[0-9A-Fa-f]+|\d+))L\b',s))
 candidates=set(v^xor for v in values)|set(v^w^xor for v in values for w in values)
 setup=re.search(r'c = (-?(?:0x[0-9a-fA-F]+|\d+))L;\s*long l = c \^ (0x[0-9a-fA-F]+|\d+)L;',s)
 if setup:candidates={int(setup[1],0)^int(setup[2],0)}
 seen=set();rows=[]
 for idx,m,raw,b in re.findall(r'\.b\[(\d+)\] = \S+\.([A-F])\("((?:\\.|[^"\\])*)", \(byte\)(-?\d+), \d+\);',s):
  if idx in seen:continue
  seen.add(idx); enc=json.loads('"'+raw+'"');b=int(b)
  offset=127+2*b if m in 'AB' else 949+3*b if m in 'CD' else 1212+b
  enc=''.join(chr((ord(c)-offset-i)&65535) for i,c in enumerate(enc))
  matches=[]
  for k in candidates:
   try:
    d=Cipher(TripleDES((k&((1<<64)-1)).to_bytes(8,'big')*3),modes.CBC(bytes(8))).decryptor();dec=d.update(base64.b64decode(enc,validate=True))+d.finalize()
    pad=dec[-1]
    if not 1<=pad<=8 or dec[-pad:]!=bytes([pad])*pad:continue
    val=dec[:-pad].decode('utf8')
    matches.append(val)
   except Exception:pass
  matches=list(dict.fromkeys(matches))
  if len(matches)==1:
   rows.append((idx,matches[0]));allrows.append((id,name,idx,matches[0]))
  else: fail.append((id,idx,len(matches)))
 if rows:(out/(id+'.json')).write_text(json.dumps(dict(rows),ensure_ascii=True,indent=2),encoding='utf8')
pathlib.Path('work/inventory/vendor-decoded-strings.tsv').write_text('\n'.join('\t'.join([id,name,idx,json.dumps(val,ensure_ascii=False)]) for id,name,idx,val in allrows),encoding='utf8')
pathlib.Path('work/inventory/vendor-decode-failures.json').write_text(json.dumps(fail,indent=2))
print('Decoded',len(allrows),'strings; unresolved',len(fail),'classes',len(list(out.glob('*.json'))))
for row in allrows:
 if row[0]=='C0366' or re.search(r'https?://|webhook|powershell|cmd.exe|chmod|chattr',row[3],re.I):print(row[0],row[2],json.dumps(row[3]))
