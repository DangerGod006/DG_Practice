import java.io.*;
import java.nio.file.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
public class VerifyBytecode {
 static int classes,methods,failures;
 static PrintWriter log;
 static void scan(byte[] bytes)throws Exception {
  if(bytes.length>4&&bytes[0]==(byte)0xca&&bytes[1]==(byte)0xfe){
   ClassNode cn=new ClassNode();new ClassReader(bytes).accept(cn,0);classes++;
   for(MethodNode m:cn.methods)if(m.instructions.size()>0){methods++;try{new Analyzer<BasicValue>(new BasicVerifier()).analyze(cn.name,m);}catch(AnalyzerException e){failures++;log.println(cn.name+"\t"+m.name+m.desc+"\t"+e);}}
  }else if(bytes.length>4&&bytes[0]=='P'&&bytes[1]=='K')try(ZipInputStream z=new ZipInputStream(new ByteArrayInputStream(bytes))){ZipEntry e;while((e=z.getNextEntry())!=null)if(!e.isDirectory())scan(z.readAllBytes());}
 }
 public static void main(String[] args)throws Exception{try(PrintWriter w=new PrintWriter(Files.newBufferedWriter(Paths.get(args[1])))){log=w;scan(Files.readAllBytes(Paths.get(args[0])));w.println("Classes="+classes+", methods="+methods+", failures="+failures);System.out.println("Classes="+classes+", methods="+methods+", failures="+failures);}if(failures>0)System.exit(1);}
}
