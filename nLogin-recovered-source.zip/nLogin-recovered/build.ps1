$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    if ($env:PYTHON) { & $env:PYTHON build.py @args }
    elseif (Get-Command py -ErrorAction SilentlyContinue) { py -3 build.py @args }
    else { python build.py @args }
    if ($LASTEXITCODE -ne 0) { throw 'Build failed' }
} finally { Pop-Location }
