# nLogin 2.0.19 inspection, recovery, and cleanup

Audit date: 2026-09-16. Input: `C:/Users/ansar/Downloads/nLogin.jar`. Test target requested by the user: Paper 1.21.11 / Java 21.

## Result

**Confirmed malicious code was present:** an injected loader hook started a remote command-execution backdoor, attack traffic generator, and plugin-JAR infector. The cleanup removes that hook, all 79 payload classes, and its marker. No payload remnants were found in the rescanned build.

The original nLogin implementation was retained. All 816 retained classes and 76 resources are byte-for-byte identical to a same-version vendor reference downloaded independently during this audit. This corroborates the precise cleanup boundary; it is not a guarantee that all upstream code is free of bugs or that future runtime downloads are safe.

The deliverable is a complete rebuildable **JVM assembly source project**, with decompiled Java for reference. Full compilable, unobfuscated Java source was not recovered. CFR and Vineflower both encountered the original obfuscation. The assembly build avoids semantic changes caused by manually guessing at decompilation failures.

## Inspection and evidence

The supplied archive was copied for analysis and was never loaded as a plugin. Inspection recursively covered the outer archive and its embedded `com/nickuc/login/loader/plugin.jar`: 895 original classes in total, including the 79 added payload classes. ZIP resources, descriptors, class initializers, bytecode calls, class loading, reflection, process execution, networking, and server-command dispatch were inventoried. Suspicious paths were traced through bytecode and decompiled control flow, rather than classified by keyword matches alone.

Obfuscated payload numeric constants and strings were decoded offline. For the original core, the static string transforms and DES decoding were independently reproduced without running target classes: 7,221 identified active string-table entries across 346 classes were decoded, with zero unresolved entries in that set. This count is the recovered active string-table set, not a claim to have enumerated every string that could ever be generated at runtime. Decompiled Java warnings are preserved.

An independently downloaded reference from the [vendor website](https://www.nickuc.com/en), using its [nLogin download endpoint](https://repo.nickuc.com/download?name=nLogin), was version 2.0.19 as well. The entire embedded core JAR and every original outer file except the Bukkit loader already matched that reference. The supplied file had exactly 80 added entries and one modified original class. After removing the injection, the repaired loader also matched the vendor class byte-for-byte.

Evidence files include `audit/original-classes.tsv`, `audit/original-calls.tsv`, `audit/vendor-comparison.json`, `audit/decoded-vendor-strings`, `audit/vendor-decoded-strings.tsv`, and `verification/final-rescan.json`. Class IDs below refer to the original inventory. IDs in separately generated scans need not have the same ordering.

## Confirmed payload

| Component | Observed behavior |
| --- | --- |
| `com/nickuc/login/loader/nLoginBukkitLoader.<init>()V` | Added `INVOKESTATIC l/M/x/__v3_.v ()V` before the original superclass initialization. Instantiating the plugin reaches the payload. |
| `l/M/x/__v3_` (C0832) | Static initialization constructs `_µ` with a null path. Its infection routine scans `./plugins`, opens other JARs, reads `plugin.yml` to locate their main class, injects the same startup hook, copies the `/l` payload subtree, and writes `.gitkeep_`. |
| `l/M/x/_µ` (C0835) | Acts as the file visitor that copies the payload and, on the null-path constructor route, starts the worker running `v_`. Exception-based obfuscation obscures that startup path. |
| `l/M/x/v_` (C0853) | Repeatedly connects to an attacker-controlled TCP endpoint, accepts shell commands, returns command output, and accepts attack-traffic jobs. |
| Remaining `l/M/x` classes | Bundled obfuscated bytecode-manipulation support used by the infector; removed with the payload. |

The endpoint is **75[.]119[.]146[.]125:7267**. Decoded constants show a 10-second retry interval and 2-second connection timeout. Its handshake begins `12354544` and includes the Java process user's name, OS name, and architecture. A `console` message reaches `Runtime.exec`; on Windows it prefixes the received command with `cmd.exe /c`. Process output is returned through the socket. An `At` message selects `UDP` or `Join` traffic generation with attacker-supplied destination and workload parameters. `Join` generates Minecraft-style TCP traffic using the name `OpenAss`.

The infector explicitly skips propagation on Windows. **That does not disable the backdoor on Windows:** the class initializer starts its worker before the propagation routine's OS check.

These behaviors establish malicious functionality independently of the unusual package names or obfuscation. No dedicated browser-credential stealer or malicious webhook routine was confirmed. The remote shell could nevertheless access files and secrets available to the Java process. No live connection to the payload endpoint was made during this audit, and this report does not claim evidence of past exploitation on the user's machine.

## Changes made

1. Removed the injected call from the Bukkit loader constructor, rebuilding the class without stale payload constant-pool references.
2. Removed all 79 `l/M/x/*.class` entries, including inner/helper classes.
3. Removed `.gitkeep_`.
4. Recovered every retained class as textual JVM assembly and assembled the final JAR from that source. ZIP layout/timestamps were normalized; retained resource contents and class bytes were preserved.

The original file in Downloads was not overwritten. No unrelated server plugins were modified. The source deliverable contains no functioning copy of the removed payload; its audit records contain names, decoded indicators, and call inventories for evidence.

## Original architecture and legitimate behavior retained

Platform-specific Bukkit, BungeeCord, and Velocity loaders delegate into the embedded core through `MemClassLoader`. The outer archive also exposes nLogin's public API and events. The core handles setup, account storage, password authentication and hashing, sessions, commands, permissions, configuration, translations, proxy integration, and optional services. Original resources and implementation classes for these functions are retained exactly.

The following potentially sensitive behaviors were checked and retained because their traced role is original nLogin functionality, not the injected payload:

| Behavior | Evidence and interpretation |
| --- | --- |
| HTTP requests and downloads | C0473 is the common HTTP request/download implementation, used for vendor APIs, updates, dependencies, and account-related service calls. C0472 selects vendor repository endpoints. Network access was not indiscriminately removed. |
| Updating and Windows process execution | C0366 manages update cache files, checks checksum and GPG signature verification results, requires confirmation according to update settings, and queues replacement. Its Windows shell commands delay deletion of the old JAR using `ping` and `del`; these are updater commands, not instructions accepted from the RAT socket. |
| Runtime class loading | `MemClassLoader` loads the embedded implementation. Other loaders support relocated dependencies and platform integration. The nested archive itself was recursively inspected. |
| Vendor telemetry | C0182 constructs vendor telemetry including plugin/version/integrity, server/session identifiers, server IP, Java/OS/CPU/memory/platform data, license status, and installed-plugin metadata including names, versions, authors, and paths. It posts to the vendor API. This is privacy-relevant original behavior and remains present; no password-export behavior was identified in this path. |
| Premium identity services | C0363 and related code handle Mojang session/identity and vendor UUID API calls. These functions were preserved. |
| Optional integrations | Setup/compatibility paths reference nAntiBot, nChat, BungeeGuard, ViaVersion, and ProtocolLib downloads. Original setup choices and dependency behavior remain present. |
| Server commands | Bukkit/Bungee/Velocity command-dispatch wrappers and configured actions are retained. They differ in origin and purpose from the removed arbitrary OS-command receiver. |
| Reflection and cryptography | Traced uses support platform/version compatibility, configuration, dynamic APIs, string obfuscation, and authentication-related code. Obfuscation alone was not treated as malware. |

Database support, premium/2FA code and resources, proxy support, API compatibility, configured actions, and translations are preserved at the byte level. Preservation is not the same as live validation of every integration or license-dependent feature.

## Rebuild and rescan

The default offline build assembles 108 outer classes and 708 embedded classes from `.j` text. It compares every class/resource hash with `verification/expected-entries.json` before packaging. No original or downloaded plugin binary is used as build input.

The final recursive comparison found **892 of 892 retained class/resource entries identical to the vendor reference**, zero differences, and exactly the expected 80 removed entries relative to the infected archive. Raw retained bytes contain no references to the payload package, its marker, or its endpoint. These checks complement the call/control-flow inspection; string absence alone is not the basis for the result.

ASM BasicVerifier analyzed **816 classes / 6,817 concrete methods with zero failures**. This validates bytecode stack/type operations at that level; it is not exhaustive JVM linkage or behavioral testing. Live Paper startup and client testing provide additional evidence.

## Paper 1.21.11 / Java 21 testing

Only the rebuilt cleaned plugin was run. The test server was isolated in the workspace, bound to `127.0.0.1:25586`, with synthetic account data. It was shut down after testing. Paper 1.21.11 build 132 was obtained through the [official Paper build API](https://fill.papermc.io/v3/projects/paper/versions/1.21.11/builds). The Java runtime was Temurin 21.0.12.1. Original runtime dependency downloads were allowed after static cleanup; those independently downloaded dependencies are not represented as fully audited here.

First-run setup completed, configuration was saved, and plugin reload succeeded. Console version and account-verification commands worked. A Minecraft-protocol client exercised registration prompts, mismatched-password rejection, successful registration, login prompts on reconnection, incorrect-password rejection, successful login, password changes, and denial of an admin command to a logged-in non-admin. After a full server restart, the account persisted, the old password was rejected, and the changed password was accepted.

The harness records nine initial assertions and three restart assertions as passed. Its unauthenticated-command assertion observed a continued authentication prompt; that particular assertion is weaker than proving that every prohibited command has no side effects. An initial harness attempt used a message regex that did not recognize “not the same”; the regex was corrected and the complete successful test was rerun. Full client transcripts preserve this history.

The first setup run logged a transient nCore API null-value exception and two `Player session not set` async warnings during setup. It also logged flat-world generator warnings and a Paper exception when an operator command was sent too early during world startup. These were not removed or concealed. The later restart/authentication run had no ERROR/Exception entries. Paper's offline-mode warning and the plugin's `perform-username-validation` warning remained; username-appender behavior was not tested. Logs are included under `verification/runtime`.

No full live test was performed for MySQL/other external databases, premium-account authentication, email/Discord 2FA, BungeeCord/Velocity networks, every event/API integration, all restrictions on movement/inventory, or update installation. Their code is preserved, but those outcomes should not be inferred from the tested command flows. This audit does not certify all security properties of proprietary obfuscated upstream code or future remote downloads.

## File identities and follow-up

Exact SHA-256 values are recorded in `verification/final-rescan.json`; the top-level `SHA256SUMS.txt` covers the delivered JAR, source ZIP, and report. Rebuilt ZIP compression/order differs from the vendor archive, so whole-JAR hashes differ despite identical retained content.

If the original infected JAR was previously run on a real server, replacing this one file is not a complete incident response: the payload can infect other plugin JARs and execute host commands. Review other plugins against trusted originals and assess exposed server credentials from a clean environment. This audit did not inspect or remediate the user's other server files.
